// Blood Hero — lightweight in-memory sliding-window rate limiter.
// Deliberately dependency-free so production hardening needs no extra installs.
// NOTE: this is per-process. On Render (single instance) it is accurate; if you
// scale to multiple instances use a shared store (Redis) — see DEPLOYMENT.md.

function rateLimit({ windowMs = 60 * 1000, max = 120, keyPrefix = 'rl', message = 'Too many requests. Please try again later.' } = {}) {
  const buckets = new Map();

  const sweep = setInterval(() => {
    const now = Date.now();
    for (const [key, entry] of buckets) {
      if (now >= entry.resetAt) buckets.delete(key);
    }
  }, windowMs);
  if (typeof sweep.unref === 'function') sweep.unref();

  return (req, res, next) => {
    const ip = req.ip || req.socket?.remoteAddress || 'unknown';
    const key = `${keyPrefix}:${ip}`;
    const now = Date.now();
    let entry = buckets.get(key);
    if (!entry || now >= entry.resetAt) {
      entry = { count: 0, resetAt: now + windowMs };
      buckets.set(key, entry);
    }
    entry.count += 1;
    if (entry.count > max) {
      res.setHeader('Retry-After', String(Math.ceil((entry.resetAt - now) / 1000)));
      return res.status(429).json({ error: message });
    }
    next();
  };
}

module.exports = { rateLimit };