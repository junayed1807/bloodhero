const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // Route the file by its multipart field name so a donation proof always
    // lands in proofs/ and a profile picture always in profiles/ regardless of
    // which route accepted the upload.
    const type = file.fieldname === 'proof_image' ? 'proofs' : 'profiles';
    const dir = path.join(__dirname, '..', 'uploads', type);
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const safeName = uuidv4() + ext;
    cb(null, safeName);
  }
});

const fileFilter = (req, file, cb) => {
  const allowed = ['image/jpeg', 'image/png', 'image/webp'];
  if (allowed.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Invalid file type. Only JPG, PNG, WEBP allowed.'), false);
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024,
    files: 1
  }
});

// Magic-byte validation: a client can spoof the Content-Type header, so the
// saved file is checked against the real image signatures. Call this in a route
// handler after multer has written the file; on failure the file is deleted.
// Returns true when the file is a real JPEG/PNG/WEBP image.
function assertImageFile(filePath) {
  try {
    const buf = fs.readFileSync(filePath);
    if (buf.length < 12) return false;
    // JPEG: FF D8 FF
    if (buf[0] === 0xFF && buf[1] === 0xD8 && buf[2] === 0xFF) return true;
    // PNG: 89 50 4E 47 0D 0A 1A 0A
    if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4E && buf[3] === 0x47) return true;
    // WEBP: RIFF .... WEBP
    if (buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return true;
    return false;
  } catch {
    return false;
  }
}

module.exports = {
  uploadProfile: upload.single('profile_picture'),
  uploadProof: upload.single('proof_image'),
  uploadMultiple: upload.array('files', 5),
  assertImageFile,
};
