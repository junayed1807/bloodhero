const { v4: uuid } = require('uuid');
const { getDb } = require('../database');

const AUDIT_ACTIONS = {
  LOGIN: 'login',
  LOGOUT: 'logout',
  FAILED_LOGIN: 'failed_login',
  ACCOUNT_CREATED: 'account_created',
  ACCOUNT_SUSPENDED: 'account_suspended',
  ACCOUNT_ACTIVATED: 'account_activated',
  ACCOUNT_DISABLED: 'account_disabled',
  ACCOUNT_REVOKED: 'account_revoked',
  ROLE_ASSIGNED: 'role_assigned',
  PERMISSION_CHANGED: 'permission_changed',
  USER_MANAGEMENT: 'user_management',
  REQUEST_APPROVAL: 'request_approval',
  DONOR_VERIFICATION: 'donor_verification',
  HOSPITAL_VERIFICATION: 'hospital_verification',
  AMBULANCE_VERIFICATION: 'ambulance_verification',
  NID_VERIFICATION: 'nid_verification',
  DATA_MODIFICATION: 'data_modification',
  ADMIN_SETTINGS_CHANGE: 'admin_settings_change',
  SUB_ADMIN_CREATED: 'sub_admin_created',
  ADMIN_CREATED: 'admin_created',
  ADMIN_EDITED: 'admin_edited',
  OTP_REQUEST: 'otp_request',
  OTP_VERIFIED: 'otp_verified',
  OTP_FAILED: 'otp_failed',
  SECURITY_EVENT: 'security_event',
  PASSWORD_CHANGED: 'password_changed',
  PERMISSION_GRANTED: 'permission_granted',
  PERMISSION_REVOKED: 'permission_revoked',
  SUB_ADMIN_EDITED: 'sub_admin_edited',
};

function getClientIp(req) {
  return req.headers['x-forwarded-for']?.split(',')[0]?.trim() ||
         req.headers['x-real-ip'] ||
         req.connection?.remoteAddress ||
         req.socket?.remoteAddress ||
         null;
}

function auditLog({ actorId, actorRole, action, targetType, targetId, description, metadata, ip, userAgent, sessionId, scope }) {
  const db = getDb();
  const now = Math.floor(Date.now() / 1000);
  const auditScope = scope || actorRole;
  const record = {
    id: uuid(),
    admin_id: actorId || null,
    actor_role: actorRole || 'unknown',
    audit_scope: auditScope,
    action,
    target_type: targetType || null,
    target_id: targetId || null,
    description: description || '',
    metadata: metadata ? JSON.stringify(metadata) : null,
    ip_address: ip || null,
    user_agent: userAgent || null,
    session_id: sessionId || null,
    created_at: now,
  };
  const stmt = db.prepare(
    `INSERT INTO audit_logs (id, admin_id, action, target_type, target_id, description, metadata, ip_address, user_agent, actor_role, audit_scope, session_id, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  stmt.run(
    record.id, record.admin_id, record.action, record.target_type, record.target_id,
    record.description, record.metadata, record.ip_address, record.user_agent,
    record.actor_role, record.audit_scope, record.session_id, record.created_at,
    function (err) { if (err) console.error('auditLog error:', err.message); }
  );
  return record.id;
}

function loginEvent({ userId, phone, ip, userAgent, loginMethod, role, adminRole, success, failureReason, sessionId }) {
  const db = getDb();
  const now = Math.floor(Date.now() / 1000);
  const id = uuid();
  const stmt = db.prepare(
    `INSERT INTO login_history (id, user_id, phone, ip_address, user_agent, login_method, role, admin_role, success, failure_reason, session_id, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  stmt.run(
    id, userId || null, phone || '', ip || null, userAgent || null,
    loginMethod || 'password', role || 'donor', adminRole || null,
    success ? 1 : 0, failureReason || null, sessionId || null, now,
    function (err) { if (err) console.error('loginEvent error:', err.message); }
  );
  return id;
}

function securityEvent({ actorId, actorRole, eventType, targetType, targetId, description, ip, userAgent, severity }) {
  const db = getDb();
  const now = Math.floor(Date.now() / 1000);
  const id = uuid();
  const stmt = db.prepare(
    `INSERT INTO security_events (id, actor_id, actor_role, event_type, target_type, target_id, description, ip_address, user_agent, severity, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  stmt.run(
    id, actorId || null, actorRole || null, eventType, targetType || null, targetId || null,
    description || '', ip || null, userAgent || null, severity || 'medium', now,
    function (err) { if (err) console.error('securityEvent error:', err.message); }
  );
  return id;
}

module.exports = {
  AUDIT_ACTIONS,
  auditLog,
  loginEvent,
  securityEvent,
  getClientIp,
};
