const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { getDb } = require('../database');
const { auditLog, AUDIT_ACTIONS, securityEvent, getClientIp } = require('./audit');

const JWT_SECRET = process.env.JWT_SECRET || 'blood-hero-secret-change-in-production';
const JWT_EXPIRY = '7d';
const ADMIN_TOKEN_EXPIRY = '2h';

// Fail closed in production: refuse to boot with a default/weak signing secret.
if (process.env.NODE_ENV === 'production') {
  const DEV_SECRET = 'blood-hero-secret-change-in-production';
  if (!process.env.JWT_SECRET || process.env.JWT_SECRET === DEV_SECRET || process.env.JWT_SECRET.length < 32) {
    console.error('[FATAL] Set a strong, unique JWT_SECRET (>= 32 chars) in production. Refusing to start.');
    process.exit(1);
  }
}

const ROLE_LEVELS = {
  super_admin: 3,
  admin: 2,
  sub_admin: 1,
};

const ADMIN_ROLE_NAMES = {
  super_admin: 'Super Admin',
  admin: 'Admin',
  sub_admin: 'Sub-admin',
};

const AUDIT_SCOPE = {
  SYSTEM: 'SYSTEM',
  ADMIN: 'ADMIN',
  SUB_ADMIN: 'SUB_ADMIN',
  NONE: 'NONE',
};

function authenticateToken(req, res, next) {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Invalid or expired token' });

    // Token revocation check (token_version): a password change/reset bumps
    // users.token_version, invalidating every previously issued JWT for the
    // account. Tokens issued before this hardening simply carry no `v` claim
    // and are treated as version 0, so existing sessions stay valid.
    const db = getDb();
    db.get('SELECT id, token_version FROM users WHERE id = ?', [user.id], (dbErr, row) => {
      if (dbErr || !row) {
        return res.status(403).json({ error: 'Invalid or expired token' });
      }
      const storedVersion = row.token_version || 0;
      const tokenVersion = typeof user.v === 'number' ? user.v : 0;
      if (tokenVersion !== storedVersion) {
        return res.status(403).json({ error: 'Session revoked. Please log in again.' });
      }
      req.user = user;
      next();
    });
  });
}

function roleLevel(roleName) {
  return ROLE_LEVELS[roleName] || 0;
}

function auditScopeFor(roleName) {
  if (roleName === 'super_admin') return AUDIT_SCOPE.SYSTEM;
  if (roleName === 'admin') return AUDIT_SCOPE.ADMIN;
  if (roleName === 'sub_admin') return AUDIT_SCOPE.SUB_ADMIN;
  return AUDIT_SCOPE.NONE;
}

function canViewAuditScope(actorScope, targetScope) {
  if (actorScope === AUDIT_SCOPE.SYSTEM) return true;
  if (actorScope === AUDIT_SCOPE.ADMIN) {
    return targetScope === AUDIT_SCOPE.ADMIN || targetScope === AUDIT_SCOPE.SUB_ADMIN;
  }
  if (actorScope === AUDIT_SCOPE.SUB_ADMIN) {
    return targetScope === AUDIT_SCOPE.SUB_ADMIN;
  }
  return false;
}

const SUPER_ADMIN_PHONE = process.env.SUPER_ADMIN_PHONE || '01835038064';

function isSuperAdminProtected(phone) {
  return phone === SUPER_ADMIN_PHONE || phone === '+8801712345678';
}

function loadAdminContext(req, res, next) {
  const db = getDb();
  const userId = req.user?.id;
  if (!userId) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  db.get(
    `SELECT aa.id as account_id, aa.role_id, aa.status, aa.invited_by, aa.verified_at,
            ar.name as role_name, ar.display_name, ar.level,
            u.role as user_role, u.is_verified
     FROM admin_accounts aa
     JOIN admin_roles ar ON aa.role_id = ar.id
     JOIN users u ON aa.user_id = u.id
     WHERE aa.user_id = ?`,
    [userId],
    (err, row) => {
      if (err) {
        console.error('loadAdminContext error:', err);
        return res.status(500).json({ error: 'Database error' });
      }

      req.adminContext = null;

      if (!row) {
        req.adminContext = null;
        return next();
      }

      if (row.status !== 'active') {
        const actionMap = {
          pending_verification: AUDIT_ACTIONS.SECURITY_EVENT,
          suspended: AUDIT_ACTIONS.SECURITY_EVENT,
          disabled: AUDIT_ACTIONS.SECURITY_EVENT,
          revoked: AUDIT_ACTIONS.SECURITY_EVENT,
        };
        const blockedActions = {
          suspended: 'Account suspended — access denied',
          disabled: 'Account disabled — access denied',
          revoked: 'Account revoked — access denied',
          pending_verification: 'Account pending verification',
        };

        auditLog({
          actorId: userId,
          actorRole: row.role_name,
          action: actionMap[row.status] || AUDIT_ACTIONS.SECURITY_EVENT,
          targetType: 'admin_account',
          targetId: row.account_id,
          description: blockedActions[row.status] || 'Access blocked: account not active',
          ip: getClientIp(req),
          userAgent: req.headers['user-agent'],
        });

        securityEvent({
          actorId: userId,
          actorRole: row.role_name,
          eventType: 'blocked_access',
          targetType: 'admin_account',
          targetId: row.account_id,
          description: `Admin attempted access with status: ${row.status}`,
          ip: getClientIp(req),
          userAgent: req.headers['user-agent'],
          severity: 'high',
        });

        return res.status(403).json({
          error: blockedActions[row.status] || 'Account not active',
          accountStatus: row.status,
        });
      }

      const permissions = [];
      db.all(
        `SELECT p.code FROM role_permissions rp
         JOIN permissions p ON rp.permission_id = p.id
         WHERE rp.role_id = ?`,
        [row.role_id],
        (permErr, permRows) => {
          if (!permErr) {
            permRows.forEach(pr => permissions.push(pr.code));
          }

          req.adminContext = {
            accountId: row.account_id,
            role: row.role_name,
            roleDisplayName: row.display_name,
            roleLevel: row.level,
            status: row.status,
            permissions: permissions,
            auditScope: auditScopeFor(row.role_name),
          };

          req.user.adminRole = row.role_name;
          req.user.adminRoleLevel = row.level;
          req.user.isAdmin = true;

          next();
        }
      );
    }
  );
}

function requireAdmin(req, res, next) {
  if (!req.adminContext) {
    auditLog({
      actorId: req.user?.id,
      actorRole: 'none',
      action: AUDIT_ACTIONS.SECURITY_EVENT,
      targetType: 'admin_access',
      description: 'Non-admin user attempted to access admin endpoint',
      ip: getClientIp(req),
      userAgent: req.headers['user-agent'],
    });
    securityEvent({
      actorId: req.user?.id,
      eventType: 'unauthorized_admin_access',
      targetType: 'admin_endpoint',
      description: 'Non-admin attempted admin access',
      ip: getClientIp(req),
      userAgent: req.headers['user-agent'],
      severity: 'high',
    });
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}

function requireAdminRole(...minLevels) {
  const minLevel = Math.max(...minLevels.map(l => ROLE_LEVELS[l] || 0));
  return (req, res, next) => {
    if (!req.adminContext || req.adminContext.roleLevel < minLevel) {
      auditLog({
        actorId: req.user?.id,
        actorRole: req.adminContext?.role || 'none',
        action: AUDIT_ACTIONS.SECURITY_EVENT,
        targetType: 'admin_access',
        description: `Insufficient role level for endpoint (required ${minLevel}, have ${req.adminContext?.roleLevel || 0})`,
        ip: getClientIp(req),
        userAgent: req.headers['user-agent'],
      });
      securityEvent({
        actorId: req.user?.id,
        actorRole: req.adminContext?.role || 'none',
        eventType: 'privilege_escalation_attempt',
        targetType: 'admin_endpoint',
        description: `Role escalation attempt: user has ${req.adminContext?.role || 'no admin role'}, needs level ${minLevel}`,
        ip: getClientIp(req),
        userAgent: req.headers['user-agent'],
        severity: 'high',
      });
      return res.status(403).json({
        error: 'Insufficient role level',
        requiredLevel: minLevel,
        currentLevel: req.adminContext?.roleLevel || 0,
      });
    }
    next();
  };
}

function requirePermission(permissionCode) {
  return (req, res, next) => {
    const perms = req.adminContext?.permissions || [];
    if (!perms.includes(permissionCode)) {
      auditLog({
        actorId: req.user?.id,
        actorRole: req.adminContext?.role || 'none',
        action: AUDIT_ACTIONS.SECURITY_EVENT,
        targetType: 'permission_denied',
        description: `Missing permission: ${permissionCode}`,
        ip: getClientIp(req),
        userAgent: req.headers['user-agent'],
      });
      securityEvent({
        actorId: req.user?.id,
        actorRole: req.adminContext?.role || 'none',
        eventType: 'permission_denied',
        targetType: 'permission',
        targetId: permissionCode,
        description: `User lacks permission: ${permissionCode}`,
        ip: getClientIp(req),
        userAgent: req.headers['user-agent'],
        severity: 'medium',
      });
      return res.status(403).json({
        error: 'Missing permission',
        permission: permissionCode,
      });
    }
    next();
  };
}

function requireSuperAdmin(req, res, next) {
  return requireAdminRole('super_admin')(req, res, next);
}

function requireAdminOrAbove(req, res, next) {
  return requireAdminRole('admin')(req, res, next);
}

function requireVerified(req, res, next) {
  if (!req.user?.is_verified) {
    return res.status(403).json({ error: 'Account not verified' });
  }
  next();
}

async function hashPassword(password) {
  return bcrypt.hash(password, 12);
}

async function comparePassword(password, hash) {
  return bcrypt.compare(password, hash);
}

function generateToken(user) {
  return jwt.sign(
    { id: user.id, phone: user.phone, role: user.role, name: user.name, v: user.token_version || 0 },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRY }
  );
}

function generateAdminToken(user, adminContext) {
  const payload = {
    id: user.id,
    phone: user.phone,
    role: user.role,
    name: user.name,
    v: user.token_version || 0,
    adminRole: adminContext.role,
    adminRoleLevel: adminContext.roleLevel,
    accountId: adminContext.accountId,
  };
  return jwt.sign(payload, JWT_SECRET, { expiresIn: ADMIN_TOKEN_EXPIRY });
}

function requireVerifiedEmailOrPhone(req, res, next) {
  if (req.user?.email_verified || req.user?.is_verified) {
    return next();
  }
  return res.status(403).json({ error: 'Email or phone verification required' });
}

module.exports = {
  authenticateToken,
  loadAdminContext,
  requireAdmin,
  requireAdminRole,
  requirePermission,
  requireSuperAdmin,
  requireAdminOrAbove,
  requireVerified,
  requireVerifiedEmailOrPhone,
  hashPassword,
  comparePassword,
  generateToken,
  generateAdminToken,
  JWT_SECRET,
  JWT_EXPIRY,
  ADMIN_TOKEN_EXPIRY,
  ROLE_LEVELS,
  ADMIN_ROLE_NAMES,
  AUDIT_SCOPE,
  auditScopeFor,
  canViewAuditScope,
  isSuperAdminProtected,
  SUPER_ADMIN_PHONE,
};
