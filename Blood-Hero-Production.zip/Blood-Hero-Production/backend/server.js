require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const { initDatabase, getDb } = require('./database');
const { rateLimit } = require('./middleware/rate-limit');
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const requestRoutes = require('./routes/requests');
const donationRoutes = require('./routes/donations');
const uploadRoutes = require('./routes/upload');
const adminRoutes = require('./routes/admin');
const centerRoutes = require('./routes/centers');
const notificationRoutes = require('./routes/notifications');
const nidVerificationRoutes = require('./routes/nid-verifications');
const impactRoutes = require('./routes/impact');
const recipientProgramRoutes = require('./routes/recipient-programs');
const ambulanceRoutes = require('./routes/ambulances');
const conversionRoutes = require('./routes/conversion');
const hierarchyRoutes = require('./routes/hierarchy');
const { authenticateToken } = require('./middleware/auth');
const verifyRoutes = require('./routes/verify');
const publicRoutes = require('./routes/public');
const contentRoutes = require('./routes/content');

const app = express();
const isProduction = process.env.NODE_ENV === 'production';
const PORT = parseInt(process.env.PORT || '3000', 10);
const HOST = process.env.HOST || '0.0.0.0';

// Render (and most PaaS) terminate TLS and forward requests via a proxy.
// Trusting X-Forwarded-* is required for correct client IPs / rate limiting.
app.set('trust proxy', process.env.TRUST_PROXY === 'true' || isProduction ? 1 : false);

// ---- Security headers (helmet-style, dependency-free) ----
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('X-XSS-Protection', '0');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  res.setHeader('Content-Security-Policy', "default-src 'none'; frame-ancestors 'self'");
  // HSTS is harmless over plain HTTP (browsers ignore it) and mandatory once
  // the API is served over HTTPS by Render/proxies.
  res.setHeader('Strict-Transport-Security', 'max-age=63072000; includeSubDomains');
  next();
});

// Never cache API responses (auth tokens, PII, admin data).
app.use('/api', (req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  next();
});

// ---- CORS ----
// In production, requests should arrive same-origin through the Vercel proxy,
// so cross-origin is disabled unless CORS_ORIGIN explicitly lists origins.
// In development, all origins are allowed (localhost tooling).
const corsOrigins = (process.env.CORS_ORIGIN || '')
  .split(',')
  .map(s => s.trim())
  .filter(Boolean);
app.use(cors(
  corsOrigins.length
    ? { origin: corsOrigins }
    : (isProduction ? { origin: false } : {})
));

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

// ---- Rate limiting (in-memory, per-process; limits configurable via env) ----
const rl = (key, def, kind) => {
  const v = parseInt(process.env[key] || String(def), 10);
  return Number.isFinite(v) && v > 0 ? v : def;
};
app.use('/api', rateLimit({ windowMs: 60 * 1000, max: rl('API_RATE_LIMIT_MAX', 600), keyPrefix: 'rl-api' }));
app.use('/api/auth', rateLimit({ windowMs: 60 * 1000, max: rl('AUTH_RATE_LIMIT_MAX', 120), keyPrefix: 'rl-auth' }));
app.use('/api/upload', rateLimit({ windowMs: 60 * 1000, max: rl('UPLOAD_RATE_LIMIT_MAX', 30), keyPrefix: 'rl-upload' }));

// ---- Static ----
// In production the frontend is served by Vercel; this backend must NOT expose
// the project root (it would leak blood_hero.db, node_modules, .env).
// The root static mount is therefore dev-only. Set SERVE_STATIC=true to force
// single-server mode (all-in-one Render instance).
if (!isProduction || process.env.SERVE_STATIC === 'true') {
  // Defense-in-depth: even in single-server/dev mode, never serve sensitive
  // paths (backend source, node_modules, dotenv files, database files).
  app.use((req, res, next) => {
    const urlPath = decodeURIComponent(req.path);
    if (
      urlPath === '/backend' || urlPath.startsWith('/backend/') ||
      urlPath === '/node_modules' || urlPath.startsWith('/node_modules/') ||
      urlPath === '/.env' || urlPath.startsWith('/.env') ||
      urlPath === '/docs' || urlPath.startsWith('/docs/') ||
      /\.(db|db-wal|db-shm|db-journal|sqlite|sqlite3)$/i.test(urlPath)
    ) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    next();
  });
  app.use(express.static(path.join(__dirname, '..')));
}
// Uploaded profile pictures / donation proofs (kept under backend/uploads).
// Only image files are served (no HTML/JS/db), with no directory listing and
// nosniff. In production these should move to private cloud storage with
// signed URLs — see docs/ENVIRONMENT-VARIABLES.md.
app.use('/uploads', (req, res, next) => {
  if (!/\.(jpe?g|png|webp|gif|bmp)$/i.test(req.path)) {
    return res.status(403).json({ error: 'Forbidden' });
  }
  res.setHeader('X-Content-Type-Options', 'nosniff');
  next();
});
app.use('/uploads', express.static(path.join(__dirname, 'uploads'), { index: false, fallthrough: false }));

// Health checks — Render uses /health for liveness.
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'blood-hero-api', timestamp: Date.now() });
});
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'blood-hero-api', timestamp: Date.now() });
});

// Auth routes (login/register don't need pre-auth; /me, /logout, /change-password, sub-admin need session)
app.use('/api/auth', authRoutes);

// Server-issued/verified donor verification tokens (QR) — POST /issue is
// authenticated inside the route; GET /:token is intentionally public.
app.use('/api/verify', verifyRoutes);

// Public profile role badge (no authentication required)
app.get('/api/public-profile/:id', hierarchyRoutes.publicProfileHandler);

// Hierarchy management (admin role/permission based — middleware applied per-route)
app.use('/api/hierarchy', authenticateToken, hierarchyRoutes);

app.use('/api/users', authenticateToken, userRoutes);
app.use('/api/requests', authenticateToken, requestRoutes);
app.use('/api/donations', authenticateToken, donationRoutes);
app.use('/api/upload', authenticateToken, uploadRoutes);
app.use('/api/admin', authenticateToken, adminRoutes);
app.use('/api/admin/nid-verifications', authenticateToken, nidVerificationRoutes);
app.use('/api/nid-verifications', authenticateToken, nidVerificationRoutes);
app.use('/api/centers', centerRoutes);
app.use('/api/notifications', authenticateToken, notificationRoutes);
app.use('/api/impact', authenticateToken, impactRoutes);
app.use('/api/recipient-programs', authenticateToken, recipientProgramRoutes);
app.use('/api/ambulances', ambulanceRoutes);
app.use('/api/conversion', authenticateToken, conversionRoutes);
// Public website content (stats, donors, camps, campaigns, gallery, news,
// partners, downloads, stories, volunteers, faq, contact) — no auth required.
app.use('/api/public', publicRoutes);
// Admin content management (camps, campaigns, articles, gallery, partners,
// downloads, stories, faq, volunteers, contact messages) — RBAC enforced.
app.use('/api/admin/content', authenticateToken, contentRoutes);

// 404 for unknown /api routes
app.use('/api', (req, res) => {
  res.status(404).json({ error: 'Not found' });
});

// Error handler — never leak stack traces to the client.
app.use((err, req, res, next) => {
  if (isProduction) console.error('[ERROR]', err);
  else console.error(err);
  res.status(500).json({ error: 'Something went wrong. Please try again.' });
});

// ---- Boot + graceful shutdown ----
initDatabase().then(() => {
  const server = app.listen(PORT, HOST, () => {
    console.log(`Blood Hero Backend running on http://${HOST}:${PORT}${isProduction ? ' (production)' : ''}`);
  });

  const shutdown = (signal) => {
    console.log(`[${signal}] shutting down gracefully...`);
    server.close(() => {
      const db = getDb();
      if (db && typeof db.close === 'function') {
        db.close((err) => {
          if (err) console.error('DB close error:', err.message);
          process.exit(0);
        });
      } else {
        process.exit(0);
      }
    });
    // Force-exit if graceful close hangs (e.g. open connections).
    setTimeout(() => process.exit(1), 10000).unref();
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}).catch((err) => {
  console.error('Failed to initialize database:', err);
  process.exit(1);
});