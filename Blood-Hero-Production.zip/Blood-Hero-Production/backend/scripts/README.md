# backend/scripts — Database migration helpers

## migrate-sqlite-to-postgres.js

Read-only SQLite → PostgreSQL planning tool. See the top of the file for details.

```bash
cd backend
node scripts/migrate-sqlite-to-postgres.js            # uses ../blood_hero.db
node scripts/migrate-sqlite-to-postgres.js --db <path> # explicit source
```

- Opens the source database **read-only**.
- Writes JSON data dumps, original DDL, a per-table row-count summary, and a
  translated `postgres-schema.sql` into `backend/scripts/output/`.
- Never connects to PostgreSQL and never modifies the SQLite file.

The `output/` directory is git-ignored (temporary/derived data).