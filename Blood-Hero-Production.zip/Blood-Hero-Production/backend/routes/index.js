const express = require('express');
const authRoutes = require('./auth');
const userRoutes = require('./users');
const requestRoutes = require('./requests');
const donationRoutes = require('./donations');
const uploadRoutes = require('./upload');
const adminRoutes = require('./admin');
const centerRoutes = require('./centers');
const notificationRoutes = require('./notifications');
const hierarchyRoutes = require('./hierarchy');

const router = express.Router();

router.use('/auth', authRoutes);
router.use('/users', userRoutes);
router.use('/requests', requestRoutes);
router.use('/donations', donationRoutes);
router.use('/upload', uploadRoutes);
router.use('/admin', adminRoutes);
router.use('/centers', centerRoutes);
router.use('/notifications', notificationRoutes);
router.use('/hierarchy', hierarchyRoutes);

module.exports = router;
