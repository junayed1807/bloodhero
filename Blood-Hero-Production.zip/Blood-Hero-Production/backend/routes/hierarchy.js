const express = require('express');
const { v4: uuid } = require('uuid');
const { getDb } = require('../database');
const {
  loadAdminContext, requireAdmin, requireAdminRole, requirePermission,
  isSuperAdminProtected, SUPER_ADMIN_PHONE,
} = require('../middleware/auth');
const { auditLog, AUDIT_ACTIONS, securityEvent, getClientIp } = require('../middleware/audit');

const router = express.Router();

// ============================================================
// Helper: Check Super Admin protection
// ============================================================
function checkSuperAdminProtection(req, targetUserId) {
  if (isSuperAdminProtected(null)) return false;

  const db = getDb();
  return new Promise((resolve) => {
    db.get('SELECT phone FROM users WHERE id = ?', [targetUserId], (err, row) => {
      if (err || !row) return resolve(false);
      resolve(isSuperAdminProtected(row.phone));
    });
  });
}

// ============================================================
// Public Profile Role Badge (only public info — no audit/sensitive data)
// This handler is exported and mounted without authentication middleware
const publicProfileHandler = (req, res) => {
  const db = getDb();
  db.get(
    `SELECT u.id, u.name, u.blood_group, u.district, u.role,
            aa.status as admin_status, ar.name as admin_role, ar.display_name
     FROM users u
     LEFT JOIN admin_accounts aa ON aa.user_id = u.id AND aa.status = 'active'
     LEFT JOIN admin_roles ar ON aa.role_id = ar.id
     WHERE u.id = ?`,
    [req.params.id],
    (err, row) => {
      if (err || !row) return res.status(404).json({ error: 'User not found' });

      let roleBadge = null;
      if (row.admin_role === 'super_admin') {
        roleBadge = { role: 'super_admin', label: 'Super Admin', icon: 'Shield', color: 'red' };
      } else if (row.admin_role === 'admin') {
        roleBadge = { role: 'admin', label: 'Admin', icon: 'Circle', color: 'blue' };
      } else if (row.admin_role === 'sub_admin') {
        roleBadge = { role: 'sub_admin', label: 'Sub-admin', icon: 'Circle', color: 'green' };
      }

      res.json({
        id: row.id,
        name: row.name,
        bloodGroup: row.blood_group,
        district: row.district,
        roleBadge,
      });
    }
  );
};

// ============================================================
// AUDIT LOGS — with server-side visibility filtering
// ============================================================
router.get('/audit-logs', loadAdminContext, requireAdmin, async (req, res) => {
  const ctx = req.adminContext;
  const { actor_role, action, target_type, limit, offset } = req.query;
  const db = getDb();

  // CRITICAL: Admin CANNOT see Super Admin activity
  // If admin requests super_admin audit data → return 403
  if (actor_role === 'super_admin' && ctx.role !== 'super_admin') {
    securityEvent({
      actorId: req.user.id,
      actorRole: ctx.role,
      eventType: 'unauthorized_audit_access',
      targetType: 'audit_logs',
      description: `Admin attempted to access Super Admin audit records`,
      ip: getClientIp(req),
      userAgent: req.headers['user-agent'],
      severity: 'critical',
    });
    auditLog({
      actorId: req.user.id,
      actorRole: ctx.role,
      action: AUDIT_ACTIONS.SECURITY_EVENT,
      targetType: 'audit_logs',
      description: `Blocked: ${ctx.role} attempted to view Super Admin audit records`,
      ip: getClientIp(req),
      userAgent: req.headers['user-agent'],
    });
    return res.status(403).json({
      error: 'Forbidden: You do not have permission to view Super Admin activity logs',
    });
  }

  // Build query based on audit scope
  // Super Admin (SYSTEM scope) → see ALL
  // Admin (ADMIN scope) → see admin + sub_admin activity ONLY (NOT super_admin)
  // Sub-admin (SUB_ADMIN scope) → see only their own activity

  const params = [];
  let scopeFilter = '';

  if (ctx.role === 'super_admin') {
    // No scope filter — see everything
  } else if (ctx.role === 'admin') {
    // Admin: see admin + sub_admin, NOT super_admin
    scopeFilter = ' AND actor_role IN (?, ?) AND audit_scope != ?';
    params.push('admin', 'sub_admin', 'SYSTEM');
  } else if (ctx.role === 'sub_admin') {
    // Sub-admin: see only their own activity
    scopeFilter = ' AND admin_id = ?';
    params.push(req.user.id);
  }

  if (actor_role) {
    // CRITICAL: Non-super-admin roles CANNOT filter by higher-level roles
    // This prevents discovering higher-level admin activity through filters
    const blockedRoles = {
      super_admin: ['admin', 'super_admin'],
      admin: ['super_admin'],
    };
    const roleLevel = ctx.role === 'super_admin' ? 3 : ctx.role === 'admin' ? 2 : 1;

    if (actor_role === 'super_admin' && ctx.role !== 'super_admin') {
      securityEvent({
        actorId: req.user.id,
        actorRole: ctx.role,
        eventType: 'unauthorized_audit_access',
        targetType: 'audit_logs',
        description: `${ctx.role} attempted to filter audit by super_admin role`,
        ip: getClientIp(req),
        userAgent: req.headers['user-agent'],
        severity: 'critical',
      });
      auditLog({
        actorId: req.user.id,
        actorRole: ctx.role,
        action: AUDIT_ACTIONS.SECURITY_EVENT,
        targetType: 'audit_logs',
        description: `Blocked: ${ctx.role} attempted to view Super Admin audit records`,
        ip: getClientIp(req),
        userAgent: req.headers['user-agent'],
      });
      return res.status(403).json({
        error: 'Forbidden: You do not have permission to view Super Admin activity logs',
      });
    }

    // Sub-admin cannot filter by 'admin' role (would reveal admin activity)
    if (actor_role === 'admin' && ctx.role === 'sub_admin') {
      securityEvent({
        actorId: req.user.id,
        actorRole: ctx.role,
        eventType: 'unauthorized_audit_access',
        targetType: 'audit_logs',
        description: `Sub-admin attempted to filter audit by admin role`,
        ip: getClientIp(req),
        userAgent: req.headers['user-agent'],
        severity: 'high',
      });
      return res.status(403).json({
        error: 'Forbidden: You do not have permission to view Admin activity logs',
      });
    }

    scopeFilter += (scopeFilter ? ' AND ' : ' AND ') + 'actor_role = ?';
    params.push(actor_role);
  }

  if (action) {
    scopeFilter += (scopeFilter ? ' AND ' : ' AND ') + 'action = ?';
    params.push(action);
  }

  if (target_type) {
    scopeFilter += (scopeFilter ? ' AND ' : ' AND ') + 'target_type = ?';
    params.push(target_type);
  }

  const lim = parseInt(limit) || 100;
  const off = parseInt(offset) || 0;

  db.all(
    `SELECT id, admin_id, actor_role, audit_scope, action, target_type, target_id, description, ip_address, user_agent, session_id, created_at
     FROM audit_logs
     WHERE 1=1${scopeFilter}
     ORDER BY created_at DESC
     LIMIT ? OFFSET ?`,
    [...params, lim, off],
    (err, rows) => {
      if (err) return res.status(500).json({ error: 'Failed to fetch audit logs' });

      auditLog({
        actorId: req.user.id,
        actorRole: ctx.role,
        action: AUDIT_ACTIONS.SECURITY_EVENT,
        targetType: 'audit_logs',
        description: `${ctx.role} viewed audit logs (count: ${rows.length})`,
        ip: getClientIp(req),
        userAgent: req.headers['user-agent'],
      });

      res.json({ logs: rows, count: rows.length });
    }
  );
});

// ============================================================
// SECURITY EVENTS
// ============================================================
router.get('/security-events', loadAdminContext, requireAdmin, async (req, res) => {
  const ctx = req.adminContext;
  const { severity, eventType, limit, offset } = req.query;
  const db = getDb();

  // Only Super Admin can see ALL security events
  // Admin can only see their own scope (admin + sub_admin, not super_admin)
  const params = [];
  let scopeFilter = '';

  if (ctx.role === 'super_admin') {
    // Super Admin sees everything
  } else if (ctx.role === 'admin') {
    // Admin: see security events for admin + sub_admin actors only
    scopeFilter = ' AND actor_role IN (?, ?)';
    params.push('admin', 'sub_admin');
  } else if (ctx.role === 'sub_admin') {
    // Sub-admin: only see their own
    scopeFilter = ' AND actor_id = ?';
    params.push(req.user.id);
  }

  if (severity) {
    scopeFilter += (scopeFilter ? ' AND ' : ' AND ') + 'severity = ?';
    params.push(severity);
  }

  if (eventType) {
    scopeFilter += (scopeFilter ? ' AND ' : ' AND ') + 'event_type = ?';
    params.push(eventType);
  }

  const lim = parseInt(limit) || 100;
  const off = parseInt(offset) || 0;

  db.all(
    `SELECT id, actor_id, actor_role, event_type, target_type, target_id, description, ip_address, severity, resolved, created_at
     FROM security_events
     WHERE 1=1${scopeFilter}
     ORDER BY created_at DESC
     LIMIT ? OFFSET ?`,
    [...params, lim, off],
    (err, rows) => {
      if (err) return res.status(500).json({ error: 'Failed to fetch security events' });
      res.json({ events: rows, count: rows.length });
    }
  );
});

// ============================================================
// LOGIN HISTORY
// ============================================================
router.get('/login-history', loadAdminContext, requireAdmin, async (req, res) => {
  const ctx = req.adminContext;
  const { phone, success, limit, offset } = req.query;
  const db = getDb();

  const params = [];
  let scopeFilter = '';

  if (ctx.role === 'super_admin') {
    // Super Admin sees ALL login history
  } else if (ctx.role === 'admin') {
    // Admin: see admin + sub_admin logins (NOT super_admin)
    scopeFilter = ' AND role NOT IN (?)';
    params.push('super_admin');
  } else if (ctx.role === 'sub_admin') {
    // Sub-admin: only their own
    scopeFilter = ' AND user_id = ?';
    params.push(req.user.id);
  }

  if (phone) {
    scopeFilter += (scopeFilter ? ' AND ' : ' AND ') + 'phone = ?';
    params.push(phone);
  }

  if (success !== undefined) {
    scopeFilter += (scopeFilter ? ' AND ' : ' AND ') + 'success = ?';
    params.push(success === 'true' ? 1 : 0);
  }

  const lim = parseInt(limit) || 100;
  const off = parseInt(offset) || 0;

  // Admin CANNOT query Super Admin login history
  if (ctx.role !== 'super_admin' && success === undefined) {
    // Already filtered by scope above
  }

  db.all(
    `SELECT id, user_id, phone, login_method, role, admin_role, success, failure_reason, ip_address, created_at
     FROM login_history
     WHERE 1=1${scopeFilter}
     ORDER BY created_at DESC
     LIMIT ? OFFSET ?`,
    [...params, lim, off],
    (err, rows) => {
      if (err) return res.status(500).json({ error: 'Failed to fetch login history' });
      res.json({ history: rows, count: rows.length });
    }
  );
});

// ============================================================
// ADMIN MANAGEMENT (Super Admin only)
// ============================================================

// List all admin accounts
router.get('/admins', loadAdminContext, requireAdminRole('super_admin'), (req, res) => {
  const db = getDb();
  db.all(
    `SELECT aa.id as account_id, aa.status, aa.verified_at, aa.invited_by, aa.created_at,
            ar.name as role_name, ar.display_name,
            u.id as user_id, u.phone, u.name, u.email, u.is_verified
     FROM admin_accounts aa
     JOIN admin_roles ar ON aa.role_id = ar.id
     JOIN users u ON aa.user_id = u.id
     ORDER BY aa.created_at DESC`,
    (err, rows) => {
      if (err) return res.status(500).json({ error: 'Failed to fetch admin accounts' });
      res.json(rows);
    }
  );
});

// Create a new Admin account (Super Admin only)
router.post('/admins', loadAdminContext, requireAdminRole('super_admin'), requirePermission('admins.manage'), async (req, res) => {
  const { phone, name, password, email } = req.body;

  if (!phone || !name || !password) {
    return res.status(400).json({ error: 'Phone, name, and password are required' });
  }

  // Prevent creating admin for Super Admin phone numbers
  if (isSuperAdminProtected(phone)) {
    securityEvent({
      actorId: req.user.id,
      actorRole: req.adminContext.role,
      eventType: 'privilege_escalation_attempt',
      targetType: 'admin',
      targetId: phone,
      description: 'Attempt to create admin account for protected Super Admin phone number',
      ip: getClientIp(req),
      userAgent: req.headers['user-agent'],
      severity: 'critical',
    });
    return res.status(403).json({ error: 'Cannot create admin account for this phone number' });
  }

  const db = getDb();
  const now = Math.floor(Date.now() / 1000);
  const passwordHash = await require('../middleware/auth').hashPassword(password);

  db.serialize(() => {
    // Check if user exists
    db.get('SELECT id FROM users WHERE phone = ?', [phone], (err, existingUser) => {
      if (err) return res.status(500).json({ error: 'Database error' });

      const doCreate = (userId) => {
        const accountId = uuid();
        db.run(
          `INSERT INTO admin_accounts (id, user_id, role_id, status, invited_by, verified_at, created_at)
           VALUES (?, ?, ?, 'active', ?, ?, ?)`,
          [accountId, userId, 'role_admin', req.user.id, now, now],
          (insertErr) => {
            if (insertErr) {
              if (insertErr.message.includes('UNIQUE')) {
                return res.status(409).json({ error: 'Admin account already exists for this phone' });
              }
              return res.status(500).json({ error: 'Failed to create admin account' });
            }

            auditLog({
              actorId: req.user.id,
              actorRole: 'super_admin',
              action: AUDIT_ACTIONS.ADMIN_CREATED,
              targetType: 'admin',
              targetId: accountId,
              description: `Super Admin created admin account for ${phone} (${name})`,
              metadata: { phone, name, email },
              ip: getClientIp(req),
              userAgent: req.headers['user-agent'],
            });

            res.status(201).json({
              success: true,
              message: 'Admin account created',
              admin: { accountId, userId, phone, name, role: 'admin' },
            });
          }
        );
      };

      if (existingUser) {
        // Update existing user with password + role
        db.run('UPDATE users SET password_hash = ?, role = ?, updated_at = strftime("%s", "now") WHERE id = ?',
          [passwordHash, 'admin', existingUser.id], (updateErr) => {
            if (updateErr) return res.status(500).json({ error: 'Failed to update user' });
            doCreate(existingUser.id);
          });
      } else {
        const newUserId = uuid();
        db.run(
          `INSERT INTO users (id, phone, name, email, role, is_verified, password_hash, created_at, updated_at)
           VALUES (?, ?, ?, ?, 'admin', 1, ?, ?, ?)`,
          [newUserId, phone, name, email || null, passwordHash, now, now],
          (insertErr) => {
            if (insertErr) return res.status(500).json({ error: 'Failed to create user' });
            doCreate(newUserId);
          }
        );
      }
    });
  });
});

// Edit / suspend / disable / revoke / restore an Admin account
router.patch('/admins/:id', loadAdminContext, requireAdminRole('super_admin'), (req, res) => {
  const { action } = req.body;
  const accountId = req.params.id;

  if (!action) {
    return res.status(400).json({ error: 'Action is required (suspend, activate, disable, revoke, restore)' });
  }

  const db = getDb();
  const now = Math.floor(Date.now() / 1000);

  // Get the admin account + user to check Super Admin protection
  db.get(
    `SELECT aa.id, aa.status, u.id as user_id, u.phone, u.name, ar.name as role_name
     FROM admin_accounts aa
     JOIN admin_roles ar ON aa.role_id = ar.id
     JOIN users u ON aa.user_id = u.id
     WHERE aa.id = ?`,
    [accountId],
    (err, row) => {
      if (err || !row) return res.status(404).json({ error: 'Admin account not found' });

      if (row.role_name === 'super_admin' && isSuperAdminProtected(row.phone)) {
        securityEvent({
          actorId: req.user.id,
          actorRole: 'super_admin',
          eventType: 'super_admin_target_access_attempt',
          targetType: 'admin',
          targetId: accountId,
          description: `Attempt to modify Super Admin account (${row.phone})`,
          ip: getClientIp(req),
          userAgent: req.headers['user-agent'],
          severity: 'critical',
        });
        return res.status(403).json({ error: 'Cannot modify the protected initial Super Admin account' });
      }

      const validActions = ['suspend', 'activate', 'disable', 'revoke', 'restore'];
      if (!validActions.includes(action)) {
        return res.status(400).json({ error: `Invalid action. Must be one of: ${validActions.join(', ')}` });
      }

      const statusMap = {
        suspend: 'suspended',
        activate: 'active',
        disable: 'disabled',
        revoke: 'revoked',
        restore: 'active',
      };

      const newStatus = statusMap[action];

      // Bind the RESOLVED status (e.g. 'suspended') — the previous code bound
      // the raw action name (e.g. 'suspend') into the status column, so a
      // suspend/activate wrote an invalid status value ('suspend'/'activate').
      db.run(
        `UPDATE admin_accounts SET status = ?,
         suspended_at = CASE WHEN ? = 'suspended' THEN ? ELSE suspended_at END,
         disabled_at = CASE WHEN ? = 'disabled' THEN ? ELSE disabled_at END,
         revoked_at = CASE WHEN ? = 'revoked' THEN ? ELSE revoked_at END,
         verified_at = CASE WHEN ? = 'active' AND verified_at IS NULL THEN ? ELSE verified_at END
         WHERE id = ?`,
        [newStatus, newStatus, now, newStatus, now, newStatus, now, newStatus, now, accountId],
        (updateErr) => {
          if (updateErr) return res.status(500).json({ error: 'Failed to update admin account' });

          const actionMap = {
            suspend: AUDIT_ACTIONS.ACCOUNT_SUSPENDED,
            activate: AUDIT_ACTIONS.ACCOUNT_ACTIVATED,
            disable: AUDIT_ACTIONS.ACCOUNT_DISABLED,
            revoke: AUDIT_ACTIONS.ACCOUNT_REVOKED,
            restore: AUDIT_ACTIONS.ACCOUNT_ACTIVATED,
          };

          auditLog({
            actorId: req.user.id,
            actorRole: 'super_admin',
            action: actionMap[action],
            targetType: 'admin',
            targetId: accountId,
            description: `${row.role_name} account ${action}: ${row.phone} (${row.name})`,
            ip: getClientIp(req),
            userAgent: req.headers['user-agent'],
          });

          // Revoke session: if user has an active token, they lose access immediately
          // (Token will still be valid until expiry, but loadAdminContext checks status)

          res.json({ success: true, status: newStatus });
        }
      );
    }
  );
});

// Delete an Admin account (Super Admin only — cannot delete Super Admin)
router.delete('/admins/:id', loadAdminContext, requireAdminRole('super_admin'), (req, res) => {
  const accountId = req.params.id;
  const db = getDb();

  db.get(
    `SELECT aa.id, u.id as user_id, u.phone, ar.name as role_name
     FROM admin_accounts aa
     JOIN admin_roles ar ON aa.role_id = ar.id
     JOIN users u ON aa.user_id = u.id
     WHERE aa.id = ?`,
    [accountId],
    (err, row) => {
      if (err || !row) return res.status(404).json({ error: 'Admin account not found' });

      if (row.role_name === 'super_admin' && isSuperAdminProtected(row.phone)) {
        securityEvent({
          actorId: req.user.id,
          actorRole: 'super_admin',
          eventType: 'super_admin_delete_attempt',
          targetType: 'admin',
          targetId: accountId,
          description: 'Attempt to delete protected Super Admin account',
          ip: getClientIp(req),
          userAgent: req.headers['user-agent'],
          severity: 'critical',
        });
        return res.status(403).json({ error: 'Cannot delete the protected initial Super Admin account' });
      }

      db.run('DELETE FROM admin_accounts WHERE id = ?', [accountId], (deleteErr) => {
        if (deleteErr) return res.status(500).json({ error: 'Failed to delete admin account' });

        auditLog({
          actorId: req.user.id,
          actorRole: 'super_admin',
          action: 'admin_deleted',
          targetType: 'admin',
          targetId: accountId,
          description: `Admin account deleted for ${row.phone} (${row.role_name})`,
          ip: getClientIp(req),
          userAgent: req.headers['user-agent'],
        });

        res.json({ success: true });
      });
    }
  );
});

// ============================================================
// SUB-ADMIN MANAGEMENT (Admin + Super Admin)
// ============================================================

// List sub-admins
router.get('/sub-admins', loadAdminContext, requireAdminRole('admin'), (req, res) => {
  const db = getDb();
  db.all(
    `SELECT aa.id as account_id, aa.status, aa.verified_at, aa.invited_by, aa.created_at,
            ar.name as role_name, ar.display_name,
            u.id as user_id, u.phone, u.name, u.email, u.is_verified
     FROM admin_accounts aa
     JOIN admin_roles ar ON aa.role_id = ar.id
     JOIN users u ON aa.user_id = u.id
     WHERE ar.name = 'sub_admin'
     ORDER BY aa.created_at DESC`,
    (err, rows) => {
      if (err) return res.status(500).json({ error: 'Failed to fetch sub-admins' });
      res.json(rows);
    }
  );
});

// Assign permissions to a sub-admin
router.patch('/sub-admins/:id/permissions', loadAdminContext, requireAdminRole('admin'), requirePermission('sub_admins.manage'), (req, res) => {
  const accountId = req.params.id;
  const { permissions: permissionCodes } = req.body;

  if (!Array.isArray(permissionCodes)) {
    return res.status(400).json({ error: 'permissions must be an array of permission codes' });
  }

  const db = getDb();

  // Get current role of target sub-admin
  db.get(
    `SELECT aa.id, aa.role_id, ar.name as role_name, u.phone
     FROM admin_accounts aa
     JOIN admin_roles ar ON aa.role_id = ar.id
     JOIN users u ON aa.user_id = u.id
     WHERE aa.id = ?`,
    [accountId],
    (err, row) => {
      if (err || !row) return res.status(404).json({ error: 'Sub-admin account not found' });

      if (isSuperAdminProtected(row.phone)) {
        securityEvent({
          actorId: req.user.id,
          actorRole: req.adminContext.role,
          eventType: 'privilege_escalation_attempt',
          targetType: 'sub_admin',
          targetId: accountId,
          description: 'Attempt to modify protected Super Admin phone',
          ip: getClientIp(req),
          userAgent: req.headers['user-agent'],
          severity: 'critical',
        });
        return res.status(403).json({ error: 'Cannot modify this account' });
      }

      // Clear existing permissions and assign new ones
      db.serialize(() => {
        db.run('DELETE FROM role_permissions WHERE role_id = ?', [row.role_id]);

        if (permissionCodes.length > 0) {
          const rpStmt = db.prepare(
            `INSERT INTO role_permissions (id, role_id, permission_id)
             SELECT ?, ?, id FROM permissions WHERE code = ?`
          );
          permissionCodes.forEach(code => {
            rpStmt.run(uuid(), row.role_id, code);
          });
          rpStmt.finalize();

          // Reload permissions
          db.all(
            `SELECT p.code FROM role_permissions rp JOIN permissions p ON rp.permission_id = p.id WHERE rp.role_id = ?`,
            [row.role_id],
            (permErr, permRows) => {
              const assigned = permRows ? permRows.map(pr => pr.code) : [];

              auditLog({
                actorId: req.user.id,
                actorRole: req.adminContext.role,
                action: AUDIT_ACTIONS.PERMISSION_CHANGED,
                targetType: 'sub_admin',
                targetId: accountId,
                description: `${req.adminContext.role} updated permissions for sub-admin ${row.phone}: [${permissionCodes.join(', ')}]`,
                ip: getClientIp(req),
                userAgent: req.headers['user-agent'],
              });

              res.json({
                success: true,
                permissions: assigned,
                message: `Assigned ${assigned.length} permissions to sub-admin`,
              });
            }
          );
        } else {
          auditLog({
            actorId: req.user.id,
            actorRole: req.adminContext.role,
            action: AUDIT_ACTIONS.PERMISSION_REVOKED,
            targetType: 'sub_admin',
            targetId: accountId,
            description: `${req.adminContext.role} revoked all permissions for sub-admin ${row.phone}`,
            ip: getClientIp(req),
            userAgent: req.headers['user-agent'],
          });

          res.json({ success: true, permissions: [], message: 'All permissions revoked' });
        }
      });
    }
  );
});

// Suspend / activate / disable / revoke sub-admin
router.patch('/sub-admins/:id', loadAdminContext, requireAdminRole('admin'), requirePermission('sub_admins.manage'), (req, res) => {
  const { action } = req.body;
  const accountId = req.params.id;

  if (!action) return res.status(400).json({ error: 'Action is required' });

  const validActions = ['suspend', 'activate', 'disable', 'revoke', 'restore'];
  if (!validActions.includes(action)) {
    return res.status(400).json({ error: `Invalid action: ${action}` });
  }

  const db = getDb();
  const now = Math.floor(Date.now() / 1000);

  db.get(
    `SELECT aa.id, aa.status, u.id as user_id, u.phone, ar.name as role_name
     FROM admin_accounts aa
     JOIN admin_roles ar ON aa.role_id = ar.id
     JOIN users u ON aa.user_id = u.id
     WHERE aa.id = ?`,
    [accountId],
    (err, row) => {
      if (err || !row) return res.status(404).json({ error: 'Sub-admin account not found' });

      if (isSuperAdminProtected(row.phone)) {
        securityEvent({
          actorId: req.user.id,
          actorRole: req.adminContext.role,
          eventType: 'privilege_escalation_attempt',
          targetType: 'sub_admin',
          targetId: accountId,
          description: 'Attempt to modify protected account',
          ip: getClientIp(req),
          userAgent: req.headers['user-agent'],
          severity: 'critical',
        });
        return res.status(403).json({ error: 'Cannot modify this account' });
      }

      const statusMap = {
        suspend: 'suspended',
        activate: 'active',
        disable: 'disabled',
        revoke: 'revoked',
        restore: 'active',
      };

      db.run('UPDATE admin_accounts SET status = ? WHERE id = ?', [statusMap[action], accountId], (updateErr) => {
        if (updateErr) return res.status(500).json({ error: 'Failed to update sub-admin' });

        const actionMap = {
          suspend: AUDIT_ACTIONS.ACCOUNT_SUSPENDED,
          activate: AUDIT_ACTIONS.ACCOUNT_ACTIVATED,
          disable: AUDIT_ACTIONS.ACCOUNT_DISABLED,
          revoke: AUDIT_ACTIONS.ACCOUNT_REVOKED,
          restore: AUDIT_ACTIONS.ACCOUNT_ACTIVATED,
        };

        auditLog({
          actorId: req.user.id,
          actorRole: req.adminContext.role,
          action: actionMap[action],
          targetType: 'sub_admin',
          targetId: accountId,
          description: `${req.adminContext.role} ${action} sub-admin ${row.phone}`,
          ip: getClientIp(req),
          userAgent: req.headers['user-agent'],
        });

        res.json({ success: true, status: statusMap[action] });
      });
    }
  );
});

// ============================================================
// ROLE MANAGEMENT (Super Admin only)
// ============================================================

// List all roles with their permissions
router.get('/roles', loadAdminContext, requireAdminRole('super_admin'), requirePermission('roles.manage'), (req, res) => {
  const db = getDb();
  db.all(
    `SELECT r.id, r.name, r.display_name, r.description, r.level,
            r.can_manage_admins, r.can_manage_sub_admins, r.can_view_super_admin_audit, r.can_assign_permissions
     FROM admin_roles r ORDER BY r.level DESC`,
    (err, roles) => {
      if (err) return res.status(500).json({ error: 'Failed to fetch roles' });

      db.all('SELECT id, code, name, module FROM permissions ORDER BY module, code', (permErr, perms) => {
        if (permErr) return res.status(500).json({ error: 'Failed to fetch permissions' });

        db.all(
          `SELECT rp.role_id, p.code FROM role_permissions rp
           JOIN permissions p ON rp.permission_id = p.id`,
          (rpErr, rpRows) => {
            if (rpErr) return res.status(500).json({ error: 'Failed' });

            const rolePerms = {};
            rpRows.forEach(rp => {
              const existing = rolePerms[rp.role_id] || [];
              existing.push(rp.code);
              rolePerms[rp.role_id] = existing;
            });

            roles.forEach(r => { r.permissions = rolePerms[r.id] || []; });

            res.json({ roles, permissions: perms });
          }
        );
      });
    }
  );
});

// Get current permissions for a role (Super Admin only)
router.get('/roles/:roleId/permissions', loadAdminContext, requireAdminRole('super_admin'), requirePermission('permissions.manage'), (req, res) => {
  const db = getDb();
  db.all(
    `SELECT p.code FROM role_permissions rp
     JOIN permissions p ON rp.permission_id = p.id
     WHERE rp.role_id = ?`,
    [req.params.roleId],
    (err, rows) => {
      if (err) return res.status(500).json({ error: 'Failed' });
      res.json({ permissions: rows.map(r => r.code) });
    }
  );
});

// Assign permissions to a role (Super Admin only)
router.post('/roles/:roleId/permissions', loadAdminContext, requireAdminRole('super_admin'), requirePermission('permissions.manage'), (req, res) => {
  const { permissionCodes } = req.body;
  const roleId = req.params.roleId;
  const db = getDb();

  if (!Array.isArray(permissionCodes)) {
    return res.status(400).json({ error: 'permissionCodes must be an array' });
  }

  db.run('DELETE FROM role_permissions WHERE role_id = ?', [roleId], (delErr) => {
    if (delErr) return res.status(500).json({ error: 'Failed to clear permissions' });

    if (permissionCodes.length === 0) {
      auditLog({
        actorId: req.user.id,
        actorRole: 'super_admin',
        action: AUDIT_ACTIONS.PERMISSION_REVOKED,
        targetType: 'role',
        targetId: roleId,
        description: `All permissions removed from role ${roleId}`,
        ip: getClientIp(req),
        userAgent: req.headers['user-agent'],
      });
      return res.json({ success: true, permissions: [] });
    }

    db.serialize(() => {
      const stmt = db.prepare(
        `INSERT INTO role_permissions (id, role_id, permission_id)
         SELECT ?, ?, id FROM permissions WHERE code = ?`
      );
      permissionCodes.forEach(code => stmt.run(uuid(), roleId, code));
      stmt.finalize((finalErr) => {
        if (finalErr) console.error('Permission assignment finalize error:', finalErr);

        db.all(
          `SELECT p.code FROM role_permissions rp JOIN permissions p ON rp.permission_id = p.id WHERE rp.role_id = ?`,
          [roleId],
          (selectErr, rows) => {
            const assigned = rows ? rows.map(r => r.code) : [];

            auditLog({
              actorId: req.user.id,
              actorRole: 'super_admin',
              action: AUDIT_ACTIONS.PERMISSION_CHANGED,
              targetType: 'role',
              targetId: roleId,
              description: `Permissions updated for role ${roleId}: [${permissionCodes.join(', ')}]`,
              ip: getClientIp(req),
              userAgent: req.headers['user-agent'],
            });

            res.json({ success: true, permissions: assigned });
          }
        );
      });
    });
  });
});

// ============================================================
// ADMIN HIERARCHY TREE
// ============================================================
router.get('/hierarchy', loadAdminContext, requireAdmin, (req, res) => {
  const db = getDb();
  const ctx = req.adminContext;

  db.all(
    `SELECT aa.id as account_id, aa.status, aa.created_at,
            ar.name as role_name, ar.display_name, ar.level,
            u.id as user_id, u.phone, u.name
     FROM admin_accounts aa
     JOIN admin_roles ar ON aa.role_id = ar.id
     JOIN users u ON aa.user_id = u.id
     ORDER BY ar.level DESC, aa.created_at DESC`,
    (err, rows) => {
      if (err) return res.status(500).json({ error: 'Failed to fetch hierarchy' });

      // Super Admin sees full hierarchy
      // Admin sees admin + sub_admin (NOT super_admin details)
      // Sub-admin sees only themselves + sub_admins under their scope
      let filtered = rows;
      if (ctx.role === 'admin') {
        filtered = rows.filter(r => r.role_name !== 'super_admin');
      } else if (ctx.role === 'sub_admin') {
        filtered = rows.filter(r => r.user_id === req.user.id);
      }

      const hierarchy = {
        super_admin: filtered.filter(r => r.role_name === 'super_admin'),
        admin: filtered.filter(r => r.role_name === 'admin'),
        sub_admin: filtered.filter(r => r.role_name === 'sub_admin'),
      };

      res.json(hierarchy);
    }
  );
});

// ============================================================
// Current admin's permissions and role info
// ============================================================
router.get('/permissions', loadAdminContext, requireAdmin, (req, res) => {
  if (!req.adminContext) {
    return res.status(403).json({ error: 'No admin context' });
  }
  res.json({
    role: req.adminContext.role,
    roleDisplayName: req.adminContext.roleDisplayName,
    roleLevel: req.adminContext.roleLevel,
    status: req.adminContext.status,
    auditScope: req.adminContext.auditScope,
    permissions: req.adminContext.permissions,
  });
});

module.exports = router;
module.exports.publicProfileHandler = publicProfileHandler;
