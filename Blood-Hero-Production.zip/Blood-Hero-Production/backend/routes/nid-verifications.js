const express = require('express');
const { v4: uuid } = require('uuid');
const { getDb } = require('../database');
const {
  authenticateToken, loadAdminContext, requireAdmin, requirePermission,
} = require('../middleware/auth');
const { auditLog, AUDIT_ACTIONS, getClientIp } = require('../middleware/audit');

const router = express.Router();

// ---- User-side: submit own NID verification (JWT) ----
router.post('/', authenticateToken, (req, res) => {
  const { nidNumber, dob, legalName } = req.body || {};
  if (!nidNumber || !/^\d{10,17}$/.test(String(nidNumber))) {
    return res.status(400).json({ error: 'A valid 10–17 digit NID number is required' });
  }
  if (!dob) return res.status(400).json({ error: 'Date of birth is required' });
  if (!legalName || !String(legalName).trim()) return res.status(400).json({ error: 'Legal name is required' });

  const db = getDb();
  db.get(
    'SELECT status FROM nid_verifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 1',
    [req.user.id],
    (err, row) => {
      if (err) return res.status(500).json({ error: 'Failed' });
      if (row && (row.status === 'pending' || row.status === 'approved')) {
        return res.status(409).json({ error: 'A verification is already pending or approved for this account' });
      }

      const id = uuid();
      const now = Math.floor(Date.now() / 1000);
      db.run(
        `INSERT INTO nid_verifications (id, user_id, nid_number, dob, legal_name, status, created_at)
         VALUES (?, ?, ?, ?, ?, 'pending', ?)`,
        [id, req.user.id, String(nidNumber), dob, String(legalName).trim(), now],
        (insErr) => {
          if (insErr) return res.status(500).json({ error: 'Failed to submit' });

          auditLog({
            actorId: req.user.id,
            actorRole: 'donor',
            action: AUDIT_ACTIONS.NID_VERIFICATION,
            targetType: 'nid_verification',
            targetId: id,
            description: `User submitted NID verification (${String(nidNumber).slice(-4).padStart(String(nidNumber).length, '*')})`,
            ip: getClientIp(req),
            userAgent: req.headers['user-agent'],
          });

          // Never echo the full NID number back to the client.
          res.status(201).json({ success: true, id, status: 'pending' });
        }
      );
    }
  );
});

// ---- User-side: my NID verification status (JWT) ----
// NID number is never returned — only the verification status.
router.get('/me', authenticateToken, (req, res) => {
  const db = getDb();
  db.get(
    'SELECT id, status, created_at, reviewed_at FROM nid_verifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 1',
    [req.user.id],
    (err, row) => {
      if (err) return res.status(500).json({ error: 'Failed' });
      res.json(row ? { id: row.id, status: row.status, createdAt: row.created_at, reviewedAt: row.reviewed_at } : null);
    }
  );
});

router.get('/', loadAdminContext, requireAdmin, requirePermission('verification.nid'), (req, res) => {
  const db = getDb();
  db.all(
    `SELECT nv.*, u.phone, u.name as account_name
     FROM nid_verifications nv
     LEFT JOIN users u ON u.id = nv.user_id
     ORDER BY nv.created_at DESC`,
    (err, rows) => {
      if (err) return res.status(500).json({ error: 'Failed' });
      // Defense in depth: mask the full NID in list responses. The admin UI
      // already renders only the first 4 digits; the full number stays
      // available on the permission-gated detail endpoint for verification.
      const out = (rows || []).map(r => {
        const copy = { ...r };
        if (r.nid_number) copy.nid_number = String(r.nid_number).slice(0, 4) + '••••';
        return copy;
      });
      res.json(out);
    }
  );
});

router.get('/:id', loadAdminContext, requireAdmin, requirePermission('verification.nid'), (req, res) => {
  const db = getDb();
  db.get('SELECT * FROM nid_verifications WHERE id = ?', [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    if (!row) return res.status(404).json({ error: 'Not found' });
    res.json(row);
  });
});

router.patch('/:id/status', loadAdminContext, requireAdmin, requirePermission('verification.nid'), (req, res) => {
  const db = getDb();
  const { status } = req.body;

  const ALLOWED = ['pending', 'approved', 'rejected', 'resubmission_required'];
  if (!ALLOWED.includes(status)) {
    return res.status(400).json({ error: 'Invalid verification status' });
  }

  db.get('SELECT user_id, nid_number FROM nid_verifications WHERE id = ?', [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    if (!row) return res.status(404).json({ error: 'Not found' });

    db.run(
      'UPDATE nid_verifications SET status = ?, reviewed_by = ?, reviewed_at = strftime("%s", "now") WHERE id = ?',
      [status, req.user.name || req.user.id, req.params.id],
      function (uerr) {
        if (uerr) return res.status(500).json({ error: 'Failed' });

        // Keep the donor record in sync: approval marks the account verified.
        if (status === 'approved') {
          db.run('UPDATE users SET is_verified = 1, nid_status = ? WHERE id = ?', ['approved', row.user_id], () => {});
        } else if (status === 'rejected' || status === 'resubmission_required') {
          db.run('UPDATE users SET nid_status = ? WHERE id = ?', [status, row.user_id], () => {});
        }

        auditLog({
          actorId: req.user.id,
          actorRole: req.adminContext.role,
          action: AUDIT_ACTIONS.NID_VERIFICATION,
          targetType: 'nid_verification',
          targetId: req.params.id,
          description: `NID verification ${status} by ${req.adminContext.role} (masked ${String(row.nid_number || '').slice(0, 4)}••••)`,
          ip: getClientIp(req),
          userAgent: req.headers['user-agent'],
        });

        res.json({ success: true });
      }
    );
  });
});

module.exports = router;
