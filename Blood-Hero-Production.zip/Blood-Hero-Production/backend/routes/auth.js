const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { v4: uuid } = require('uuid');
const { getDb } = require('../database');
const {
  authenticateToken, generateToken, generateAdminToken, hashPassword, comparePassword, JWT_SECRET,
  loadAdminContext, requireAdmin, requireAdminRole, requirePermission,
  isSuperAdminProtected,
} = require('../middleware/auth');
const { auditLog, AUDIT_ACTIONS, securityEvent, loginEvent, getClientIp } = require('../middleware/audit');
const { sendOtpSms, isDemoMode } = require('../services/sms-provider');

const router = express.Router();

// --- OTP config ---
const OTP_EXPIRY_SECONDS = parseInt(process.env.OTP_EXPIRY_SECONDS || '300', 10); // 5 minutes
const OTP_MAX_ATTEMPTS = parseInt(process.env.OTP_MAX_ATTEMPTS || '3', 10);
const OTP_RATE_LIMIT_WINDOW = parseInt(process.env.OTP_RATE_LIMIT_WINDOW || '60000', 10); // 1 min
const OTP_RATE_LIMIT_MAX = parseInt(process.env.OTP_RATE_LIMIT_MAX || '3', 10); // 3 per minute

const otpRateLimit = new Map();

function checkOtpRateLimit(key) {
  const now = Date.now();
  const entry = otpRateLimit.get(key);
  if (!entry || now - entry.ts > OTP_RATE_LIMIT_WINDOW) {
    otpRateLimit.set(key, { ts: now, count: 1 });
    return true;
  }
  if (entry.count >= OTP_RATE_LIMIT_MAX) return false;
  entry.count++;
  return true;
}

// Cryptographically secure 6-digit OTP.
function generateOtp() {
  return crypto.randomInt(100000, 1000000).toString();
}

// True when the stored value is a bcrypt hash (new format); legacy rows stored
// the plaintext code (demo-era) and are compared directly for compatibility.
function otpMatches(stored, otp) {
  if (typeof stored === 'string' && stored.startsWith('$2')) {
    return bcrypt.compareSync(otp, stored);
  }
  return stored === otp;
}

// --- Regular user registration (unchanged) ---
router.post('/register', async (req, res) => {
  try {
    const { phone, name, password, blood_group, district, upazila, age, weight, gender, emergency_contact } = req.body;

    if (!phone || !name || !password) {
      return res.status(400).json({ error: 'Phone, name, and password are required' });
    }

    if (!/^\+?[0-9]{10,15}$/.test(String(phone))) {
      return res.status(400).json({ error: 'A valid phone number is required' });
    }

    if (typeof password !== 'string' || password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    const db = getDb();
    const existing = await new Promise((resolve, reject) => {
      db.get('SELECT id FROM users WHERE phone = ?', [phone], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    if (existing) {
      return res.status(409).json({ error: 'Phone already registered' });
    }

    const passwordHash = await hashPassword(password);
    const userId = uuid();
    const now = Math.floor(Date.now() / 1000);
    await new Promise((resolve, reject) => {
      db.run(
        `INSERT INTO users (id, phone, name, password_hash, blood_group, district, upazila, age, weight, gender, emergency_contact, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [userId, phone, name, passwordHash, blood_group || null, district || null, upazila || null, age || null, weight || null, gender || null, emergency_contact || null, now, now],
        (err) => err ? reject(err) : resolve()
      );
    });

    const user = { id: userId, phone, name, role: 'donor' };
    const token = generateToken(user);

    auditLog({
      actorId: userId,
      actorRole: 'donor',
      action: AUDIT_ACTIONS.ACCOUNT_CREATED,
      targetType: 'user',
      targetId: userId,
      description: `User registered: ${name}`,
      ip: getClientIp(req),
      userAgent: req.headers['user-agent'],
    });

    res.status(201).json({ token, user });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// --- Admin login: phone + password ---
// Role is resolved SERVER-SIDE — never trusted from client
router.post('/login', async (req, res) => {
  try {
    const { phone, password } = req.body;

    if (!phone || !password) {
      return res.status(400).json({ error: 'Phone and password are required' });
    }

    const db = getDb();
    const user = await new Promise((resolve, reject) => {
      db.get('SELECT * FROM users WHERE phone = ?', [phone], (err, row) => {
        if (err) reject(err);
        else resolve(row);
      });
    });

    // Do not reveal whether the phone exists
    if (!user || !user.password_hash) {
      loginEvent({
        phone,
        ip: getClientIp(req),
        userAgent: req.headers['user-agent'],
        loginMethod: 'password',
        role: 'unknown',
        success: false,
        failureReason: 'user_not_found_or_no_password',
      });
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const valid = await comparePassword(password, user.password_hash);
    if (!valid) {
      loginEvent({
        userId: user.id,
        phone,
        ip: getClientIp(req),
        userAgent: req.headers['user-agent'],
        loginMethod: 'password',
        role: user.role,
        success: false,
        failureReason: 'invalid_password',
      });

      auditLog({
        actorId: user.id,
        actorRole: user.role,
        action: AUDIT_ACTIONS.FAILED_LOGIN,
        targetType: 'user',
        targetId: user.id,
        description: `Failed login attempt for ${phone}`,
        ip: getClientIp(req),
        userAgent: req.headers['user-agent'],
      });

      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // --- Server-side role resolution ---
    // Check if this user has an admin account
    db.get(
      `SELECT aa.id as account_id, aa.role_id, aa.status,
              ar.name as role_name, ar.level
       FROM admin_accounts aa
       JOIN admin_roles ar ON aa.role_id = ar.id
       WHERE aa.user_id = ? AND aa.status = 'active'`,
      [user.id],
      (err, adminRow) => {
        if (err) {
          console.error(err);
          return res.status(500).json({ error: 'Login failed' });
        }

        const sessionId = uuid();
        const now = Math.floor(Date.now() / 1000);

        if (!adminRow) {
          // Regular (non-admin) user login
          loginEvent({
            userId: user.id,
            phone,
            ip: getClientIp(req),
            userAgent: req.headers['user-agent'],
            loginMethod: 'password',
            role: user.role,
            success: true,
            sessionId,
          });

          auditLog({
            actorId: user.id,
            actorRole: user.role,
            action: AUDIT_ACTIONS.LOGIN,
            targetType: 'user',
            targetId: user.id,
            description: `User logged in: ${user.name}`,
            ip: getClientIp(req),
            userAgent: req.headers['user-agent'],
            sessionId,
          });

          const token = generateToken(user);
          return res.json({
            token,
            user: { id: user.id, phone: user.phone, name: user.name, role: user.role },
            isAdmin: false,
          });
        }

        // Admin login — role is determined server-side
        const adminContext = {
          accountId: adminRow.account_id,
          role: adminRow.role_name,
          roleLevel: adminRow.level,
          status: adminRow.status,
          permissions: [],
          auditScope: adminRow.role_name === 'super_admin' ? 'SYSTEM' :
                       adminRow.role_name === 'admin' ? 'ADMIN' : 'SUB_ADMIN',
        };

        // Load permissions
        db.all(
          `SELECT p.code FROM role_permissions rp
           JOIN permissions p ON rp.permission_id = p.id
           WHERE rp.role_id = ?`,
          [adminRow.role_id],
          (permErr, permRows) => {
            if (!permErr) {
              adminContext.permissions = permRows.map(pr => pr.code);
            }

            loginEvent({
              userId: user.id,
              phone,
              ip: getClientIp(req),
              userAgent: req.headers['user-agent'],
              loginMethod: 'password',
              role: user.role,
              adminRole: adminRow.role_name,
              success: true,
              sessionId,
            });

            auditLog({
              actorId: user.id,
              actorRole: adminRow.role_name,
              action: AUDIT_ACTIONS.LOGIN,
              targetType: 'admin_account',
              targetId: adminRow.account_id,
              description: `${adminRow.role_name} login: ${user.name} (${phone})`,
              ip: getClientIp(req),
              userAgent: req.headers['user-agent'],
              sessionId,
            });

            const token = generateAdminToken(
              { id: user.id, phone: user.phone, name: user.name, role: user.role },
              adminContext
            );

            res.json({
              token,
              user: {
                id: user.id,
                phone: user.phone,
                name: user.name,
                role: user.role,
              },
              adminContext: {
                role: adminRow.role_name,
                roleDisplayName: adminRow.role_name === 'super_admin' ? 'Super Admin' :
                                 adminRow.role_name === 'admin' ? 'Admin' : 'Sub-admin',
                roleLevel: adminRow.level,
                permissions: adminContext.permissions,
                auditScope: adminContext.auditScope,
              },
              isAdmin: true,
            });
          }
        );
      }
    );
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Login failed' });
  }
});

// --- /me endpoint: resolves full context server-side ---
router.get('/me', authenticateToken, loadAdminContext, (req, res) => {
  const db = getDb();
  db.get('SELECT id, phone, name, blood_group, district, role, is_verified, created_at FROM users WHERE id = ?',
    [req.user.id], (err, userRow) => {
      if (err || !userRow) return res.status(404).json({ error: 'User not found' });

      if (!req.adminContext) {
        return res.json({ user: userRow, isAdmin: false });
      }

      res.json({
        user: { id: userRow.id, phone: userRow.phone, name: userRow.name, role: userRow.role },
        isAdmin: true,
        adminContext: {
          role: req.adminContext.role,
          roleDisplayName: req.adminContext.roleDisplayName,
          roleLevel: req.adminContext.roleLevel,
          status: req.adminContext.status,
          permissions: req.adminContext.permissions,
          auditScope: req.adminContext.auditScope,
        },
      });
    }
  );
});

// --- Logout ---
router.post('/logout', authenticateToken, (req, res) => {
  const role = req.adminContext?.role || 'donor';
  auditLog({
    actorId: req.user.id,
    actorRole: role,
    action: AUDIT_ACTIONS.LOGOUT,
    targetType: 'user',
    targetId: req.user.id,
    description: `Logout: ${req.user.name}`,
    ip: getClientIp(req),
    userAgent: req.headers['user-agent'],
  });
  res.json({ success: true });
});

// --- Change password ---
router.post('/change-password', authenticateToken, async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!newPassword) {
    return res.status(400).json({ error: 'New password required' });
  }

  const db = getDb();
  db.get('SELECT password_hash FROM users WHERE id = ?', [req.user.id], async (err, user) => {
    if (err || !user) return res.status(404).json({ error: 'User not found' });

    // Users who only signed in via phone OTP have no password yet — let them
    // set one (skipping the current-password check). Otherwise require it.
    if (user.password_hash) {
      if (!currentPassword) return res.status(400).json({ error: 'Current password required' });
      const valid = await comparePassword(currentPassword, user.password_hash);
      if (!valid) return res.status(401).json({ error: 'Current password incorrect' });
    }

    const newHash = await hashPassword(newPassword);
    db.run('UPDATE users SET password_hash = ?, token_version = token_version + 1, updated_at = strftime("%s", "now") WHERE id = ?',
      [newHash, req.user.id], (updateErr) => {
        if (updateErr) return res.status(500).json({ error: 'Failed' });

        auditLog({
          actorId: req.user.id,
          actorRole: req.adminContext?.role || 'donor',
          action: AUDIT_ACTIONS.PASSWORD_CHANGED,
          targetType: 'user',
          targetId: req.user.id,
          description: 'Password changed',
          ip: getClientIp(req),
          userAgent: req.headers['user-agent'],
        });

        res.json({ success: true });
      });
  });
});

// ============================================================
// FORGOT PASSWORD (phone-OTP reset for public + admin accounts)
// ============================================================
router.post('/user/forgot-password', async (req, res) => {
  try {
    const phone = String(req.body.phone || '').trim();
    if (!/^\+?[0-9]{10,15}$/.test(phone)) {
      return res.status(400).json({ error: 'A valid phone number is required' });
    }
    if (!checkOtpRateLimit('user_reset_' + phone)) {
      return res.status(429).json({ error: 'Too many requests. Please wait.' });
    }

    const db = getDb();
    const user = await new Promise((resolve, reject) => {
      db.get('SELECT id, phone FROM users WHERE phone = ?', [phone], (err, row) => err ? reject(err) : resolve(row));
    });

    // Do not reveal whether the phone exists.
    if (!user) {
      return res.json({ success: true, message: 'If this phone is registered, an OTP was sent.' });
    }

    const now = Math.floor(Date.now() / 1000);
    const code = generateOtp();
    const otpHash = await hashPassword(code);
    await new Promise((resolve, reject) => {
      db.run('DELETE FROM user_otp WHERE phone = ?', [phone], (err) => err ? reject(err) : resolve());
    });
    await new Promise((resolve, reject) => {
      db.run(
        'INSERT INTO user_otp (id, phone, otp_hash, otp_expires_at, max_attempts, created_at) VALUES (?, ?, ?, ?, ?, ?)',
        [uuid(), phone, otpHash, now + OTP_EXPIRY_SECONDS, OTP_MAX_ATTEMPTS, now],
        (err) => err ? reject(err) : resolve()
      );
    });

    auditLog({
      actorId: user.id,
      actorRole: 'donor',
      action: AUDIT_ACTIONS.OTP_VERIFIED,
      targetType: 'password_reset',
      targetId: phone,
      description: `Password reset OTP requested for ${phone}`,
      ip: getClientIp(req),
      userAgent: req.headers['user-agent'],
    });

    const sms = await sendOtpSms(phone, code);
    res.json({
      success: true,
      message: 'OTP sent to phone',
      expires_in_seconds: OTP_EXPIRY_SECONDS,
      ...(sms.demo ? { demo: true, devOtp: sms.devOtp } : {}),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to send OTP' });
  }
});

router.post('/user/reset-password', async (req, res) => {
  try {
    const { phone, otp, newPassword } = req.body;
    if (!phone || !otp || !newPassword) {
      return res.status(400).json({ error: 'Phone, OTP and new password are required' });
    }
    if (String(newPassword).length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    const db = getDb();
    const now = Math.floor(Date.now() / 1000);
    const row = await new Promise((resolve, reject) => {
      db.get(
        'SELECT * FROM user_otp WHERE phone = ? ORDER BY created_at DESC LIMIT 1',
        [phone], (err, r) => err ? reject(err) : resolve(r)
      );
    });

    if (!row || row.otp_expires_at < now) {
      return res.status(404).json({ error: 'OTP not found or expired. Request a new code.' });
    }
    if (row.consumed) return res.status(400).json({ error: 'OTP already used. Request a new code.' });
    if (row.attempts >= row.max_attempts) {
      return res.status(403).json({ error: 'Maximum OTP attempts exceeded. Request a new code.' });
    }

    db.run('UPDATE user_otp SET attempts = attempts + 1 WHERE id = ?', [row.id]);
    const valid = await comparePassword(otp, row.otp_hash);
    if (!valid) return res.status(401).json({ error: 'Invalid OTP code' });
    db.run('UPDATE user_otp SET consumed = 1 WHERE id = ?', [row.id]);

    const newHash = await hashPassword(newPassword);
    await new Promise((resolve, reject) => {
      db.run(
        'UPDATE users SET password_hash = ?, token_version = token_version + 1, updated_at = strftime("%s", "now") WHERE phone = ?',
        [newHash, phone], (err) => err ? reject(err) : resolve()
      );
    });

    auditLog({
      actorRole: 'donor',
      action: AUDIT_ACTIONS.PASSWORD_CHANGED,
      targetType: 'user',
      targetId: phone,
      description: `Password reset via phone OTP for ${phone}`,
      ip: getClientIp(req),
      userAgent: req.headers['user-agent'],
    });

    res.json({ success: true, message: 'Password reset. You can now log in.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Reset failed' });
  }
});

// ============================================================
// PUBLIC APP OTP LOGIN BRIDGE
// ============================================================
// The public (donor/recipient) app authenticates via phone OTP so its pages
// (impact, recipient programs, …) can talk to the backend with real data.
// The OTP is always hashed at rest and sent via the SMS provider; the code is
// returned in the response ONLY while the provider runs in demo/log mode.

// Request an OTP for a phone number. Creates a backend user on first contact
// so the public app has a real identity to connect to.
router.post('/user/request-otp', async (req, res) => {
  try {
    const phone = String(req.body.phone || '').trim();
    if (!/^\+?[0-9]{10,15}$/.test(phone)) {
      return res.status(400).json({ error: 'A valid phone number is required' });
    }

    if (!checkOtpRateLimit('user_otp_' + phone)) {
      return res.status(429).json({ error: 'Too many OTP requests. Please wait.' });
    }

    const db = getDb();
    const now = Math.floor(Date.now() / 1000);
    const code = generateOtp();
    const otpHash = await hashPassword(code);
    const otpId = uuid();
    const expiry = now + OTP_EXPIRY_SECONDS;

    await new Promise((resolve, reject) => {
      db.run('DELETE FROM user_otp WHERE phone = ?', [phone], (err) => err ? reject(err) : resolve());
    });

    // NOTE: no user account is created here anymore. A backend identity is only
    // created AFTER the phone proves the OTP (see verify-otp). This prevents
    // unauthenticated account creation from a bare OTP request.

    await new Promise((resolve, reject) => {
      db.run(
        `INSERT INTO user_otp (id, phone, otp_hash, otp_expires_at, max_attempts, created_at)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [otpId, phone, otpHash, expiry, OTP_MAX_ATTEMPTS, now],
        (err) => err ? reject(err) : resolve()
      );
    });

    const sms = await sendOtpSms(phone, code);
    res.json({
      success: true,
      message: 'OTP sent to phone',
      expires_in_seconds: OTP_EXPIRY_SECONDS,
      // Present ONLY in demo/log SMS mode — see sms-provider.js
      ...(sms.demo ? { demo: true, devOtp: sms.devOtp } : {}),
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to send OTP' });
  }
});

// Verify the OTP and issue a JWT for the public app.
router.post('/user/verify-otp', async (req, res) => {
  try {
    const { phone, otp } = req.body;
    if (!phone || !otp) {
      return res.status(400).json({ error: 'Phone and OTP code are required' });
    }

    const db = getDb();
    const now = Math.floor(Date.now() / 1000);

    const row = await new Promise((resolve, reject) => {
      db.get(
        'SELECT * FROM user_otp WHERE phone = ? ORDER BY created_at DESC LIMIT 1',
        [phone],
        (err, r) => err ? reject(err) : resolve(r)
      );
    });

    if (!row || row.otp_expires_at < now) {
      return res.status(404).json({ error: 'OTP not found or expired. Request a new code.' });
    }
    if (row.consumed) {
      return res.status(400).json({ error: 'OTP already used. Request a new code.' });
    }
    if (row.attempts >= row.max_attempts) {
      return res.status(403).json({ error: 'Maximum OTP attempts exceeded. Request a new code.' });
    }

    db.run('UPDATE user_otp SET attempts = attempts + 1 WHERE id = ?', [row.id]);

    const valid = await comparePassword(otp, row.otp_hash);
    if (!valid) {
      return res.status(401).json({ error: 'Invalid OTP code' });
    }

    db.run('UPDATE user_otp SET consumed = 1 WHERE id = ?', [row.id]);

    const now2 = Math.floor(Date.now() / 1000);

    // Find-or-create the backend identity ONLY after the OTP is verified.
    const user = await new Promise((resolve, reject) => {
      db.get('SELECT id, phone, name, role, is_verified FROM users WHERE phone = ?', [phone],
        (err, r) => err ? reject(err) : resolve(r));
    });

    let finalUser = user;
    if (!finalUser) {
      finalUser = await new Promise((resolve, reject) => {
        const userId = uuid();
        db.run(
          `INSERT INTO users (id, phone, name, role, is_verified, created_at, updated_at)
           VALUES (?, ?, ?, 'donor', 1, ?, ?)`,
          [userId, phone, phone, now2, now2],
          (insErr) => insErr
            ? reject(insErr)
            : resolve({ id: userId, phone, name: phone, role: 'donor', is_verified: 1 })
        );
      });
    }

    // Mark phone verified after successful OTP login.
    db.run('UPDATE users SET is_verified = 1, updated_at = strftime("%s", "now") WHERE id = ?', [finalUser.id]);

    loginEvent({
      userId: finalUser.id,
      phone,
      ip: getClientIp(req),
      userAgent: req.headers['user-agent'],
      loginMethod: 'otp',
      role: finalUser.role,
      success: true,
    });

    auditLog({
      actorId: finalUser.id,
      actorRole: finalUser.role,
      action: AUDIT_ACTIONS.LOGIN,
      targetType: 'user',
      targetId: finalUser.id,
      description: `User logged in via phone OTP: ${finalUser.name}`,
      ip: getClientIp(req),
      userAgent: req.headers['user-agent'],
    });

    const token = generateToken(finalUser);
    res.json({
      token,
      user: { id: finalUser.id, phone: finalUser.phone, name: finalUser.name, role: finalUser.role, is_verified: 1 },
      isAdmin: false,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Verification failed' });
  }
});

// ============================================================
// SUB-ADMIN REGISTRATION FLOW (Two-step OTP verification)
// ============================================================

// Step 0: Super Admin / Admin creates sub-admin invitation → sends OTP
router.post('/sub-admin/invitation', authenticateToken, loadAdminContext, requireAdmin, requirePermission('sub_admins.manage'), (req, res) => {
  const { phone, permissions } = req.body;

  if (!phone) {
    return res.status(400).json({ error: 'Phone number is required' });
  }

  // Prevent creating sub-admins for Super Admin phone numbers
  if (isSuperAdminProtected(phone)) {
    securityEvent({
      actorId: req.user.id,
      actorRole: req.adminContext.role,
      eventType: 'privilege_escalation_attempt',
      targetType: 'sub_admin',
      targetId: phone,
      description: `Attempt to create sub-admin with protected Super Admin phone number`,
      ip: getClientIp(req),
      userAgent: req.headers['user-agent'],
      severity: 'critical',
    });
    return res.status(403).json({ error: 'Cannot create admin account for this phone number' });
  }

  const db = getDb();

  // Rate limit OTP requests per phone
  if (!checkOtpRateLimit('send_otp_' + phone)) {
    return res.status(429).json({ error: 'Too many OTP requests. Please wait.' });
  }

  db.serialize(() => {
    db.get('SELECT id FROM users WHERE phone = ?', [phone], (err, userRow) => {
      if (err) return res.status(500).json({ error: 'Database error' });

      // Clean up any existing pending OTPs for this phone
      db.run('DELETE FROM admin_otp WHERE phone = ?', [phone], (delErr) => {
        if (delErr) return res.status(500).json({ error: 'Database error' });

        // Generate two OTP codes for two-step verification.
        // Codes are HASHED at rest; the plaintext is returned to the inviter
        // ONLY in demo/log mode. In production the codes go to the phone
        // out-of-band (SMS/email provider) and never appear in a response.
        const otp1 = generateOtp();
        const otp2 = generateOtp();
        const otp1Hash = bcrypt.hashSync(otp1, 10);
        const otp2Hash = bcrypt.hashSync(otp2, 10);
        const demo = isDemoMode();
        const now = Math.floor(Date.now() / 1000);
        const expiry = now + OTP_EXPIRY_SECONDS;

        // Step 1 OTP
        const otp1Id = uuid();
        db.run(
          `INSERT INTO admin_otp (id, phone, invited_by, role_id, step, otp_code, otp_expires_at, max_attempts, created_at)
           VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?)`,
          [otp1Id, phone, req.user.id, 'role_sub_admin', otp1Hash, expiry, OTP_MAX_ATTEMPTS, now]
        );

        // Step 2 OTP (linked to same phone)
        const otp2Id = uuid();
        db.run(
          `INSERT INTO admin_otp (id, phone, invited_by, role_id, step, otp_code, otp_expires_at, max_attempts, created_at)
           VALUES (?, ?, ?, ?, 2, ?, ?, ?, ?)`,
          [otp2Id, phone, req.user.id, 'role_sub_admin', otp2Hash, expiry, OTP_MAX_ATTEMPTS, now]
        );

        // If user exists, prepare an admin account (pending)
        if (userRow) {
          const accountId = uuid();
          db.run(
            `INSERT OR IGNORE INTO admin_accounts (id, user_id, role_id, status, invited_by, created_at)
             VALUES (?, ?, ?, 'pending_verification', ?, ?)`,
            [accountId, userRow.id, 'role_sub_admin', req.user.id, now]
          );
        }

        auditLog({
          actorId: req.user.id,
          actorRole: req.adminContext.role,
          action: AUDIT_ACTIONS.SUB_ADMIN_CREATED,
          targetType: 'sub_admin_invitation',
          targetId: phone,
          description: `Sub-admin invitation created for ${phone} with permissions: ${JSON.stringify(permissions || [])}`,
          metadata: { phone, permissions: permissions || [], invited_by: req.user.id },
          ip: getClientIp(req),
          userAgent: req.headers['user-agent'],
        });

        // OTPs are delivered out-of-band to the phone. The codes are echoed back
        // ONLY in demo/log mode so local development & tests can complete the flow.
        res.json({
          success: true,
          message: 'OTP verification codes generated. Send step 1 code to the phone number.',
          ...(demo ? { otp_step1: otp1, otp_step2: otp2 } : {}),
          phone,
          expires_in_seconds: OTP_EXPIRY_SECONDS,
        });
      });
    });
  });
});

// Step 1: Verify first OTP
router.post('/sub-admin/verify-step1', (req, res) => {
  const { phone, otp } = req.body;

  if (!phone || !otp) {
    return res.status(400).json({ error: 'Phone and OTP code are required' });
  }

  const db = getDb();
  const now = Math.floor(Date.now() / 1000);

  db.get(
    `SELECT id, otp_code, otp_expires_at, attempts, max_attempts, consumed
     FROM admin_otp WHERE phone = ? AND step = 1 ORDER BY created_at DESC LIMIT 1`,
    [phone],
    (err, row) => {
      if (err || !row) return res.status(404).json({ error: 'OTP not found or expired. Request a new code.' });

      if (row.consumed) {
        return res.status(400).json({ error: 'OTP already used. Request a new code.' });
      }

      if (row.otp_expires_at < now) {
        return res.status(400).json({ error: 'OTP expired. Request a new code.' });
      }

      if (row.attempts >= row.max_attempts) {
        return res.status(403).json({ error: 'Maximum OTP attempts exceeded. Request a new code.' });
      }

      // Increment attempts BEFORE checking
      db.run('UPDATE admin_otp SET attempts = attempts + 1 WHERE id = ?', [row.id]);

      if (!otpMatches(row.otp_code, otp)) {
        return res.status(401).json({ error: 'Invalid OTP code' });
      }

      // OTP verified — mark as consumed to prevent reuse
      db.run('UPDATE admin_otp SET consumed = 1 WHERE id = ?', [row.id]);

      auditLog({
        actorRole: 'sub_admin',
        action: AUDIT_ACTIONS.OTP_VERIFIED,
        targetType: 'sub_admin_verification',
        targetId: phone,
        description: `Step 1 OTP verified for ${phone}`,
        ip: getClientIp(req),
        userAgent: req.headers['user-agent'],
      });

      res.json({
        success: true,
        message: 'Step 1 verification successful. Proceed to step 2.',
        step1_verified: true,
      });
    }
  );
});

// Step 2: Verify second OTP
router.post('/sub-admin/verify-step2', (req, res) => {
  const { phone, otp } = req.body;

  if (!phone || !otp) {
    return res.status(400).json({ error: 'Phone and OTP code are required' });
  }

  const db = getDb();
  const now = Math.floor(Date.now() / 1000);

  db.get(
    `SELECT id, otp_code, otp_expires_at, attempts, max_attempts, consumed
     FROM admin_otp WHERE phone = ? AND step = 2 ORDER BY created_at DESC LIMIT 1`,
    [phone],
    (err, row) => {
      if (err || !row) return res.status(404).json({ error: 'OTP not found or expired. Request a new code.' });

      if (row.consumed) {
        return res.status(400).json({ error: 'OTP already used. Request a new code.' });
      }

      if (row.otp_expires_at < now) {
        return res.status(400).json({ error: 'OTP expired. Request a new code.' });
      }

      if (row.attempts >= row.max_attempts) {
        return res.status(403).json({ error: 'Maximum OTP attempts exceeded. Request a new code.' });
      }

      db.run('UPDATE admin_otp SET attempts = attempts + 1 WHERE id = ?', [row.id]);

      if (!otpMatches(row.otp_code, otp)) {
        auditLog({
          actorRole: 'sub_admin',
          action: AUDIT_ACTIONS.OTP_FAILED,
          targetType: 'sub_admin_verification',
          targetId: phone,
          description: `Step 2 OTP failed for ${phone}`,
          ip: getClientIp(req),
          userAgent: req.headers['user-agent'],
        });
        securityEvent({
          eventType: 'otp_failed',
          targetType: 'sub_admin_verification',
          targetId: phone,
          description: `Step 2 OTP verification failed for ${phone}`,
          ip: getClientIp(req),
          userAgent: req.headers['user-agent'],
          severity: 'medium',
        });
        return res.status(401).json({ error: 'Invalid OTP code' });
      }

      db.run('UPDATE admin_otp SET consumed = 1 WHERE id = ?', [row.id]);

      auditLog({
        actorRole: 'sub_admin',
        action: AUDIT_ACTIONS.OTP_VERIFIED,
        targetType: 'sub_admin_verification',
        targetId: phone,
        description: `Step 2 OTP verified for ${phone}`,
        ip: getClientIp(req),
        userAgent: req.headers['user-agent'],
      });

      res.json({
        success: true,
        message: 'Step 2 verification successful. Phone number verified.',
        step2_verified: true,
        phone_verified: true,
      });
    }
  );
});

// Set password and activate sub-admin account
router.post('/sub-admin/set-password', async (req, res) => {
  const { phone, password } = req.body;

  if (!phone || !password) {
    return res.status(400).json({ error: 'Phone and password are required' });
  }

  if (password.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters' });
  }

  const db = getDb();
  const now = Math.floor(Date.now() / 1000);

  // Verify both steps were completed (both OTPs consumed)
  db.get(
    `SELECT COUNT(*) as count, invited_by FROM admin_otp WHERE phone = ? AND consumed = 1 AND step IN (1, 2) AND otp_expires_at > ?`,
    [phone, now],
    async (err, countRow) => {
      if (err || !countRow || countRow.count < 2) {
        return res.status(403).json({
          error: 'Phone verification required. Complete both OTP verification steps first.',
          needs_verification: true,
        });
      }

      const inviterId = countRow.invited_by || null;
      const passwordHash = await hashPassword(password);

      // Check if user account exists
      db.get('SELECT id FROM users WHERE phone = ?', [phone], (err2, userRow) => {
        if (err2) return res.status(500).json({ error: 'Database error' });

        if (userRow) {
          activateSubAdmin(userRow.id);
        } else {
          // Create a new user record — the sub-admin has completed OTP verification
          const newUserId = uuid();
          const now2 = Math.floor(Date.now() / 1000);
          db.run(
            `INSERT INTO users (id, phone, name, role, is_verified, password_hash, created_at, updated_at)
             VALUES (?, ?, ?, 'sub_admin', 1, ?, ?, ?)`,
            [newUserId, phone, phone, passwordHash, now2, now2],
            (createErr) => {
              if (createErr) return res.status(500).json({ error: 'Failed to create user account' });
              activateSubAdmin(newUserId);
            }
          );
        }
      });

      function activateSubAdmin(userId) {
        db.serialize(() => {
          // Update password on the user
          db.run('UPDATE users SET password_hash = ?, updated_at = strftime("%s", "now") WHERE id = ?',
            [passwordHash, userId], (updateErr) => {
              if (updateErr) console.error('Password update error:', updateErr.message);
            });

          // Create or activate admin account (DELETE existing then INSERT)
          db.run('DELETE FROM admin_accounts WHERE user_id = ?', [userId], (delErr) => {
            if (delErr) console.error('Delete admin_account error:', delErr.message);

            db.run(
              `INSERT INTO admin_accounts (id, user_id, role_id, status, invited_by, verified_at, created_at)
               VALUES (?, ?, ?, 'active', ?, ?, ?)`,
              [uuid(), userId, 'role_sub_admin', inviterId, now, now],
              (insErr) => {
                if (insErr) console.error('Insert admin_account error:', insErr.message);

                auditLog({
                  actorId: userId,
                  actorRole: 'sub_admin',
                  action: AUDIT_ACTIONS.ACCOUNT_ACTIVATED,
                  targetType: 'admin_account',
                  targetId: userId,
                  description: `Sub-admin account activated for ${phone}`,
                  ip: getClientIp(req),
                  userAgent: req.headers['user-agent'],
                });

                res.json({
                  success: true,
                  message: 'Sub-admin account activated. You can now log in.',
                });
              }
            );
          });
        });
      }
    }
  );
});

module.exports = router;