const express = require('express');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const { getDb } = require('../database');
const {
  loadAdminContext, requireAdmin, requirePermission,
} = require('../middleware/auth');
const { auditLog, AUDIT_ACTIONS, getClientIp } = require('../middleware/audit');
const { uploadProof, assertImageFile } = require('../middleware/upload');

const router = express.Router();

// Donations are private PII. Admins may read any donation; regular users only
// see their own.
router.get('/', loadAdminContext, (req, res) => {
  const db = getDb();
  const { status, donor_id } = req.query;
  let query = 'SELECT * FROM donations WHERE 1=1';
  const params = [];

  if (req.adminContext) {
    if (status) { query += ' AND status = ?'; params.push(status); }
    if (donor_id) { query += ' AND donor_id = ?'; params.push(donor_id); }
  } else {
    query += ' AND donor_id = ?';
    params.push(req.user.id);
    if (status) { query += ' AND status = ?'; params.push(status); }
  }

  query += ' ORDER BY created_at DESC';

  db.all(query, params, (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed to fetch donations' });
    res.json(rows);
  });
});

router.get('/:id', loadAdminContext, (req, res) => {
  const db = getDb();
  db.get('SELECT * FROM donations WHERE id = ?', [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ error: 'Failed to fetch donation' });
    if (!row) return res.status(404).json({ error: 'Donation not found' });
    if (!req.adminContext && row.donor_id !== req.user.id) {
      return res.status(404).json({ error: 'Donation not found' });
    }
    res.json(row);
  });
});

router.post('/submit', uploadProof, (req, res) => {
  const db = getDb();

  // Reject files that are not actually JPEG/PNG/WEBP (spoofed Content-Type).
  if (req.file && !assertImageFile(req.file.path)) {
    fs.unlink(req.file.path, () => {});
    return res.status(400).json({ error: 'Uploaded file is not a valid image' });
  }

  const { request_id, hospital, blood_group, donation_date, location, notes } = req.body;

  if (!request_id || !hospital || !blood_group) {
    if (req.file) fs.unlink(req.file.path, () => {});
    return res.status(400).json({ error: 'Request ID, hospital, and blood group are required' });
  }

  const proofUrl = req.file ? `/uploads/proofs/${req.file.filename}` : null;

  db.get('SELECT * FROM blood_requests WHERE id = ? AND donor_id = ?', [request_id, req.user.id], (err, request) => {
    if (err) {
      if (req.file) fs.unlink(req.file.path, () => {});
      return res.status(500).json({ error: 'Validation failed' });
    }
    if (!request) {
      if (req.file) fs.unlink(req.file.path, () => {});
      return res.status(404).json({ error: 'Request not found or not yours' });
    }

    db.get('SELECT id FROM donations WHERE request_id = ? AND donor_id = ?', [request_id, req.user.id], (err, existing) => {
      if (err) {
        if (req.file) fs.unlink(req.file.path, () => {});
        return res.status(500).json({ error: 'Duplicate check failed' });
      }
      if (existing) {
        if (req.file) fs.unlink(req.file.path, () => {});
        return res.status(409).json({ error: 'Already submitted for this request' });
      }

      const id = uuidv4();
      db.run(
        `INSERT INTO donations (id, request_id, donor_id, blood_group, hospital, donation_date, location, proof_url, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending_verification')`,
        [id, request_id, req.user.id, blood_group, hospital, donation_date || new Date().toISOString().split('T')[0], location || '', proofUrl],
        function (err) {
          if (err) {
            if (req.file) fs.unlink(req.file.path, () => {});
            return res.status(500).json({ error: 'Failed to submit donation' });
          }

          db.run('INSERT INTO notifications (id, user_id, type, title, body, data) VALUES (?, ?, ?, ?, ?, ?)',
            [uuidv4(), req.user.id, 'donation_submitted', 'Donation Submitted', 'Your donation proof is pending verification', JSON.stringify({ donation_id: id })]);

          res.status(201).json({ id, message: 'Donation submitted for verification' });
        }
      );
    });
  });
});

router.post('/:id/approve', loadAdminContext, requireAdmin, requirePermission('verification.donation'), (req, res) => {
  const db = getDb();
  const { admin_note } = req.body;

  db.get('SELECT * FROM donations WHERE id = ?', [req.params.id], (err, donation) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    if (!donation) return res.status(404).json({ error: 'Donation not found' });
    if (donation.status === 'verified') return res.status(400).json({ error: 'Already verified' });
    if (donation.status === 'rejected') return res.status(400).json({ error: 'Already rejected' });

    db.serialize(() => {
      db.run('BEGIN TRANSACTION');

      db.run('UPDATE donations SET status = ?, reviewed_by = ?, reviewed_at = strftime("%s", "now"), admin_note = ? WHERE id = ?',
        ['verified', req.user.name || req.user.id, admin_note || '', req.params.id],
        function (err) {
          if (err) { db.run('ROLLBACK'); return res.status(500).json({ error: 'Approval failed' }); }

          db.run('UPDATE users SET total_donations = total_donations + 1, points = points + 100, stars = stars + 1 WHERE id = ?',
            [donation.donor_id],
            function (err) {
              if (err) { db.run('ROLLBACK'); return res.status(500).json({ error: 'Reward failed' }); }

              const newPoints = 100;
              let newLevel = 'New Donor';
              db.get('SELECT total_donations FROM users WHERE id = ?', [donation.donor_id], (err, u) => {
                const count = u?.total_donations || 0;
                if (count >= 100) newLevel = 'Legend';
                else if (count >= 50) newLevel = 'Century Champion';
                else if (count >= 25) newLevel = 'Regular Hero';
                else if (count >= 10) newLevel = 'Life Saver';
                else if (count >= 5) newLevel = 'Iron Heart';
                else if (count >= 1) newLevel = 'First Drop';

                db.run('UPDATE users SET level = ? WHERE id = ?', [newLevel, donation.donor_id]);

                db.run('INSERT INTO reward_ledger (id, user_id, donation_id, points, type, reason) VALUES (?, ?, ?, ?, ?, ?)',
                  [uuidv4(), donation.donor_id, req.params.id, newPoints, 'donation', 'Verified blood donation']);

                db.run('INSERT INTO notifications (id, user_id, type, title, body, data) VALUES (?, ?, ?, ?, ?, ?)',
                  [uuidv4(), donation.donor_id, 'donation_approved', 'Donation Verified', `Your donation has been verified. +${newPoints} points, +1 star.`, JSON.stringify({ donation_id: req.params.id })]);

                auditLog({
                  actorId: req.user.id,
                  actorRole: req.adminContext?.role || 'admin',
                  action: AUDIT_ACTIONS.DONOR_VERIFICATION,
                  targetType: 'donation',
                  targetId: req.params.id,
                  description: `Approved donation for user ${donation.donor_id}`,
                  ip: getClientIp(req),
                  userAgent: req.headers['user-agent'],
                });

                db.run('COMMIT');
                res.json({ success: true, points: newPoints, level: newLevel });
              });
            }
          );
        }
      );
    });
  });
});

router.post('/:id/reject', loadAdminContext, requireAdmin, requirePermission('verification.donation'), (req, res) => {
  const db = getDb();
  const { rejection_reason, admin_note } = req.body;

  if (!rejection_reason) return res.status(400).json({ error: 'Rejection reason required' });

  db.run('UPDATE donations SET status = ?, rejection_reason = ?, reviewed_by = ?, reviewed_at = strftime("%s", "now"), admin_note = ? WHERE id = ?',
    ['rejected', rejection_reason, req.user.name || req.user.id, admin_note || '', req.params.id],
    function (err) {
      if (err) return res.status(500).json({ error: 'Rejection failed' });

      db.run('INSERT INTO notifications (id, user_id, type, title, body, data) SELECT id, donor_id, ?, ?, ?, ? FROM donations WHERE id = ?',
        ['donation_rejected', 'Donation Rejected', `Your donation was rejected: ${rejection_reason}`, JSON.stringify({ donation_id: req.params.id }), req.params.id]);

      auditLog({
        actorId: req.user.id,
        actorRole: req.adminContext?.role || 'admin',
        action: AUDIT_ACTIONS.DONOR_VERIFICATION,
        targetType: 'donation',
        targetId: req.params.id,
        description: `Rejected donation: ${rejection_reason}`,
        ip: getClientIp(req),
        userAgent: req.headers['user-agent'],
      });

      res.json({ success: true });
    }
  );
});

module.exports = router;
