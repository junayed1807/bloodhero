const express = require('express');
const { getDb } = require('../database');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

router.get('/', (req, res) => {
  const db = getDb();
  db.all('SELECT * FROM notifications WHERE user_id = ? OR user_id IS NULL ORDER BY created_at DESC LIMIT 50', [req.user.id], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    res.json(rows);
  });
});

router.patch('/:id/read', (req, res) => {
  const db = getDb();
  db.run('UPDATE notifications SET read = 1 WHERE id = ? AND user_id = ?', [req.params.id, req.user.id], function(err) {
    if (err) return res.status(500).json({ error: 'Failed' });
    res.json({ success: true });
  });
});

module.exports = router;
