const express = require('express');
const { getDb } = require('../database');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

router.post('/track', (req, res) => {
  const db = getDb();
  const { event_type, request_id, metadata } = req.body;
  
  const id = require('uuid').v4();
  db.run(
    'INSERT INTO conversion_events (id, user_id, event_type, request_id, metadata) VALUES (?, ?, ?, ?, ?)',
    [id, req.user.id, event_type, request_id || null, metadata ? JSON.stringify(metadata) : null],
    function(err) {
      if (err) return res.status(500).json({ error: 'Failed' });
      res.json({ success: true, id });
    }
  );
});

router.get('/stats', (req, res) => {
  const db = getDb();
  db.all(`
    SELECT event_type, COUNT(*) as count 
    FROM conversion_events 
    WHERE user_id = ?
    GROUP BY event_type
  `, [req.user.id], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    res.json(rows);
  });
});

module.exports = router;
