// Blood Hero — Server-issued donor verification tokens (QR codes).
// The public QR token previously used a client-side secret that shipped in
// js/db.js, so anyone could forge a "verified donor" token. Now tokens are
// issued and verified with an HMAC signed by a server secret:
//   POST /api/verify/issue   (authenticated)  → { token }
//   GET  /api/verify/:token  (public)         → { valid, sub, exp }
const express = require('express');
const crypto = require('crypto');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Dedicated secret so a leaked JWT_SECRET doesn't also forge QR tokens.
// Falls back to JWT_SECRET when unset (both are server-only).
const VERIFY_SECRET = process.env.VERIFY_TOKEN_SECRET || process.env.JWT_SECRET || 'blood-hero-secret-change-in-production';
const TTL_MS = parseInt(process.env.VERIFY_TOKEN_TTL_MS || '300000', 10);

function base64url(input) {
  return Buffer.from(input).toString('base64')
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function sign(body) {
  return base64url(crypto.createHmac('sha256', VERIFY_SECRET).update(body).digest());
}

router.post('/issue', authenticateToken, (req, res) => {
  const now = Date.now();
  const payload = { sub: req.user.id, iat: now, exp: now + TTL_MS };
  const body = base64url(JSON.stringify(payload));
  res.json({ token: `${body}.${sign(body)}`, expires_in_ms: TTL_MS });
});

router.get('/:token', (req, res) => {
  const token = String(req.params.token || '');
  const [body, sig] = token.split('.');
  if (!body || !sig) {
    return res.status(400).json({ valid: false, error: 'Malformed token' });
  }

  const expected = sign(body);
  const a = Buffer.from(String(sig));
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(400).json({ valid: false, error: 'Invalid token signature' });
  }

  let payload;
  try {
    const json = Buffer.from(body.replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8');
    payload = JSON.parse(json);
  } catch {
    return res.status(400).json({ valid: false, error: 'Malformed token' });
  }

  if (!payload.exp || payload.exp < Date.now()) {
    return res.status(400).json({ valid: false, error: 'Token expired' });
  }

  res.json({ valid: true, sub: payload.sub, exp: payload.exp });
});

module.exports = router;