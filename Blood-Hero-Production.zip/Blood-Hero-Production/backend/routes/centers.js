const express = require('express');
const { getDb } = require('../database');
const {
  authenticateToken, loadAdminContext, requireAdmin, requirePermission,
} = require('../middleware/auth');

const router = express.Router();

router.get('/', (req, res) => {
  const db = getDb();
  db.all('SELECT id, name, type, district, upazila, address, phone, verified FROM centers ORDER BY name', (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    res.json(rows);
  });
});

router.post('/', authenticateToken, loadAdminContext, requireAdmin, requirePermission('hospitals.manage'), (req, res) => {
  const db = getDb();
  const { name, type, district, upazila, address, phone } = req.body;
  
  const id = require('uuid').v4();
  db.run('INSERT INTO centers (id, name, type, district, upazila, address, phone) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [id, name, type || 'hospital', district, upazila, address, phone],
    function(err) {
      if (err) return res.status(500).json({ error: 'Failed' });
      res.status(201).json({ id });
    }
  );
});

module.exports = router;
