const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../database');
const { loadAdminContext } = require('../middleware/auth');

const router = express.Router();

// Contact numbers are PII: non-admin callers only see the requester's own
// contact in full; everyone else gets a masked number.
function maskContact(value) {
  if (!value) return value;
  const s = String(value);
  if (s.length <= 4) return '****';
  return '****' + s.slice(-4);
}

const ALLOWED_STATUSES = ['pending', 'accepted', 'fulfilled', 'cancelled'];

function canManageRequest(adminContext) {
  return !!(adminContext && adminContext.permissions.includes('requests.manage'));
}

// ---------- ABO/Rh compatibility ----------
// Key: recipient group -> donor groups that can donate to that recipient.
const COMPATIBLE_DONORS = {
  'A+': ['A+', 'A-', 'O+', 'O-'],
  'A-': ['A-', 'O-'],
  'B+': ['B+', 'B-', 'O+', 'O-'],
  'B-': ['B-', 'O-'],
  'AB+': ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'],
  'AB-': ['A-', 'B-', 'AB-', 'O-'],
  'O+': ['O+', 'O-'],
  'O-': ['O-'],
};

function compatibleDonorGroups(recipientGroup) {
  return COMPATIBLE_DONORS[recipientGroup] || [];
}

// Score a donor against a request (0..70). Real fields only — never fabricated.
function matchScore(donor, request) {
  let score = 0;
  if (compatibleDonorGroups(request.blood_group).includes(donor.blood_group)) score += 20;
  if (donor.is_available) score += 10;
  if (donor.is_verified) score += 10;
  score += Math.min(donor.total_donations || 0, 10);
  if (donor.district && donor.district === request.district) score += 15;
  if (donor.upazila && donor.upazila === request.upazila) score += 10;
  // Eligibility: no last donation, or last donation at least 90 days ago.
  const lastDonation = donor.last_donation ? new Date(donor.last_donation).getTime() : 0;
  const ninetyDays = 90 * 24 * 60 * 60 * 1000;
  if (!lastDonation || (Date.now() - lastDonation) >= ninetyDays) score += 5;
  return score;
}

// Find the best compatible donors for a request, record request_matches and
// create privacy-safe notifications for each matched donor.
function createMatchesForRequest(req, request, done) {
  const db = getDb();
  const groups = compatibleDonorGroups(request.blood_group);
  if (!groups.length) return done(null, 0);

  const placeholders = groups.map(() => '?').join(',');
  db.all(
    `SELECT id, name, phone, blood_group, district, upazila, is_available, is_verified,
            total_donations, last_donation
     FROM users
     WHERE blood_group IN (${placeholders}) AND role = 'donor'
       AND id != ?
     ORDER BY is_available DESC, is_verified DESC, total_donations DESC
     LIMIT 300`,
    [...groups, request.created_by],
    (err, donors) => {
      if (err || !donors) return done(err, 0);

      const scored = donors
        .map(d => ({ donor: d, score: matchScore(d, request) }))
        .filter(m => m.score > 0)
        .sort((a, b) => b.score - a.score)
        .slice(0, 20);

      if (!scored.length) return done(null, 0);

      const now = Math.floor(Date.now() / 1000);
      const insert = db.prepare(
        `INSERT OR IGNORE INTO request_matches (id, request_id, donor_id, score, status, notified_at, created_at)
         VALUES (?, ?, ?, ?, 'notified', ?, ?)`
      );
      const notify = db.prepare(
        `INSERT INTO notifications (id, user_id, type, title, body, data, created_at)
         VALUES (?, ?, 'request_match', ?, ?, ?, ?)`
      );
      scored.forEach(m => {
        insert.run(uuidv4(), request.id, m.donor.id, m.score, now, now);
        const body = `Blood needed: ${request.blood_group}${request.units > 1 ? ' (' + request.units + ' units)' : ''} at ${request.hospital || 'a hospital'}${request.district ? ', ' + request.district : ''}.${request.urgency === 'critical' || request.urgency === 'urgent' ? ' URGENT.' : ''}`;
        notify.run(uuidv4(), m.donor.id, request.urgency === 'critical' || request.urgency === 'urgent' ? 'EMERGENCY blood needed' : 'New blood request near you', body, JSON.stringify({ requestId: request.id }), now);
      });

      done(null, scored.length);
    }
  );
}

router.get('/', loadAdminContext, (req, res) => {
  const db = getDb();
  const { status, blood_group, district } = req.query;
  let query = 'SELECT * FROM blood_requests WHERE 1=1';
  const params = [];
  
  if (status) { query += ' AND status = ?'; params.push(status); }
  if (blood_group) { query += ' AND blood_group = ?'; params.push(blood_group); }
  if (district) { query += ' AND district = ?'; params.push(district); }
  
  query += ' ORDER BY created_at DESC';
  
  db.all(query, params, (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed to fetch requests' });
    const isAdmin = !!req.adminContext;
    const out = (rows || []).map(r => {
      const copy = { ...r };
      if (!isAdmin && r.created_by !== req.user.id && r.contact) {
        copy.contact = maskContact(r.contact);
      }
      return copy;
    });
    res.json(out);
  });
});

router.get('/:id', loadAdminContext, (req, res) => {
  const db = getDb();
  db.get('SELECT * FROM blood_requests WHERE id = ?', [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ error: 'Failed to fetch request' });
    if (!row) return res.status(404).json({ error: 'Request not found' });
    if (!req.adminContext && row.created_by !== req.user.id && row.contact) {
      row.contact = maskContact(row.contact);
    }
    res.json(row);
  });
});

router.post('/', (req, res) => {
  const db = getDb();
  const { patient_name, blood_group, component, units, urgency, hospital, district, upazila, union_area, contact, note, needed_by } = req.body;
  
  if (!blood_group || !contact) {
    return res.status(400).json({ error: 'Blood group and contact are required' });
  }

  const oneHourAgo = Math.floor(Date.now() / 1000) - 6 * 3600;
  db.get(
    `SELECT id FROM blood_requests WHERE blood_group = ? AND hospital = ? AND created_at > ? AND created_by = ? AND status != 'cancelled'`,
    [blood_group, hospital || '', oneHourAgo, req.user.id],
    (err, existing) => {
      if (err) return res.status(500).json({ error: 'Duplicate check failed' });
      if (existing) return res.status(409).json({ error: 'Duplicate request within 6 hours' });

      const id = require('uuid').v4();
      db.run(
        `INSERT INTO blood_requests (id, donor_id, patient_name, blood_group, component, units, urgency, hospital, district, upazila, union_area, contact, note, needed_by, created_by) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [id, req.user.id, patient_name, blood_group, component || 'Whole Blood', units || 1, urgency || 'normal', hospital || '', district || '', upazila || '', union_area || '', contact, note || '', needed_by || null, req.user.id],
        function(insErr) {
          if (insErr) return res.status(500).json({ error: 'Failed to create request' });

          const created = {
            id, blood_group, units: units || 1, hospital: hospital || '',
            district: district || '', upazila: upazila || '',
            urgency: urgency || 'normal', created_by: req.user.id,
          };
          // Match compatible donors + notify them (best-effort, non-blocking).
          createMatchesForRequest(req, created, (matchErr, matched) => {
            res.status(201).json({ id, message: 'Request created', matchedDonors: matched || 0 });
          });
        }
      );
    }
  );
});

router.post('/:id/accept', (req, res) => {
  const db = getDb();
  
  db.get('SELECT * FROM blood_requests WHERE id = ?', [req.params.id], (err, request) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    if (!request) return res.status(404).json({ error: 'Request not found' });
    if (request.status !== 'pending') return res.status(400).json({ error: 'Request not available' });
    if (request.created_by === req.user.id) return res.status(400).json({ error: 'Cannot accept own request' });

    const now = Math.floor(Date.now() / 1000);
    db.run(
      'UPDATE blood_requests SET status = ?, accepted_by = ?, updated_at = ? WHERE id = ?',
      ['accepted', req.user.id, now, req.params.id],
      function(uerr) {
        if (uerr) return res.status(500).json({ error: 'Failed to accept' });

        // Record this donor's match response.
        db.run(
          `UPDATE request_matches SET status = 'accepted', responded_at = ? WHERE request_id = ? AND donor_id = ?`,
          [now, req.params.id, req.user.id],
          () => {}
        );

        // Notify the requester so they can coordinate with the accepting donor.
        const donorLabel = `${req.user.name || 'A donor'}${req.user.phone ? ' (' + req.user.phone + ')' : ''}`;
        db.run(
          `INSERT INTO notifications (id, user_id, type, title, body, data, created_at)
           VALUES (?, ?, 'request_accepted', ?, ?, ?, ?)`,
          [uuidv4(), request.created_by,
           'Your blood request was accepted',
           `${donorLabel} accepted your request for ${request.blood_group} at ${request.hospital || 'the hospital'}. Please contact them to coordinate.`,
           JSON.stringify({ requestId: req.params.id, donorId: req.user.id }), now],
          () => {}
        );

        res.json({ success: true, message: 'Request accepted' });
      }
    );
  });
});

// GET /api/requests/:id/matches — Compatible donors matched to a request.
// Owner or admin only; returns privacy-safe donor fields plus score.
router.get('/:id/matches', loadAdminContext, (req, res) => {
  const db = getDb();
  db.get('SELECT created_by FROM blood_requests WHERE id = ?', [req.params.id], (err, request) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    if (!request) return res.status(404).json({ error: 'Request not found' });
    const isOwner = request.created_by === req.user.id;
    const isAdmin = canManageRequest(req.adminContext);
    if (!isOwner && !isAdmin) return res.status(403).json({ error: 'Access denied' });

    db.all(
      `SELECT m.id as match_id, m.score, m.status as match_status, m.created_at as matched_at,
              u.id as donor_id, u.name, u.blood_group, u.district, u.upazila,
              u.total_donations, u.is_available, u.is_verified, u.photo_url
       FROM request_matches m
       JOIN users u ON u.id = m.donor_id
       WHERE m.request_id = ?
       ORDER BY m.score DESC, m.created_at ASC`,
      [req.params.id],
      (merr, rows) => {
        if (merr) return res.status(500).json({ error: 'Failed to load matches' });
        // Never expose donor contact numbers here — coordination happens via
        // the requester's own contact number shared on acceptance.
        res.json(rows || []);
      }
    );
  });
});

router.patch('/:id/status', loadAdminContext, (req, res) => {
  const db = getDb();
  const { status } = req.body;

  if (!ALLOWED_STATUSES.includes(status)) {
    return res.status(400).json({ error: 'Invalid status' });
  }

  db.get('SELECT * FROM blood_requests WHERE id = ?', [req.params.id], (err, request) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    if (!request) return res.status(404).json({ error: 'Request not found' });

    const isAdmin = canManageRequest(req.adminContext);
    const isOwner = request.created_by === req.user.id;
    if (!isAdmin && !isOwner) {
      return res.status(403).json({ error: 'You do not have permission to update this request' });
    }

    db.run('UPDATE blood_requests SET status = ?, updated_at = strftime("%s", "now") WHERE id = ?', [status, req.params.id], function (updateErr) {
      if (updateErr) return res.status(500).json({ error: 'Failed to update' });
      res.json({ success: true });
    });
  });
});

router.delete('/:id', loadAdminContext, (req, res) => {
  const db = getDb();
  db.get('SELECT created_by FROM blood_requests WHERE id = ?', [req.params.id], (err, request) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    if (!request) return res.status(404).json({ error: 'Request not found' });

    const isAdmin = canManageRequest(req.adminContext);
    const isOwner = request.created_by === req.user.id;
    if (!isAdmin && !isOwner) {
      return res.status(403).json({ error: 'You do not have permission to delete this request' });
    }

    db.run('DELETE FROM blood_requests WHERE id = ?', [req.params.id], function (delErr) {
      if (delErr) return res.status(500).json({ error: 'Failed to delete' });
      res.json({ success: true });
    });
  });
});

module.exports = router;
