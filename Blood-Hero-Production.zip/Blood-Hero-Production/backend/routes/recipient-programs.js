const express = require('express');
const { getDb } = require('../database');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

router.get('/', (req, res) => {
  const db = getDb();
  db.all('SELECT * FROM donation_programs WHERE recipient_id = ? AND active = 1', [req.user.id], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    res.json(rows);
  });
});

router.post('/', (req, res) => {
  const db = getDb();
  const { name, blood_group, interval_days, preferred_centre, preferred_donor_pool, next_request_date } = req.body;
  
  if (!blood_group) {
    return res.status(400).json({ error: 'Blood group is required' });
  }

  const id = require('uuid').v4();
  db.run(
    `INSERT INTO donation_programs (id, recipient_id, name, blood_group, interval_days, preferred_centre, preferred_donor_pool, next_request_date) 
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [id, req.user.id, name || 'Regular Recipient', blood_group, interval_days || 14, preferred_centre || '', preferred_donor_pool || '', next_request_date || null],
    function(err) {
      if (err) return res.status(500).json({ error: 'Failed to create program' });
      res.status(201).json({ id, message: 'Recipient program created' });
    }
  );
});

router.patch('/:id', (req, res) => {
  const db = getDb();
  const { next_request_date, active } = req.body;
  
  db.run('UPDATE donation_programs SET next_request_date = ?, active = ? WHERE id = ? AND recipient_id = ?',
    [next_request_date, active !== undefined ? active : 1, req.params.id, req.user.id],
    function(err) {
      if (err) return res.status(500).json({ error: 'Failed' });
      res.json({ success: true });
    }
  );
});

router.delete('/:id', (req, res) => {
  const db = getDb();
  db.run('DELETE FROM donation_programs WHERE id = ? AND recipient_id = ?', [req.params.id, req.user.id], function(err) {
    if (err) return res.status(500).json({ error: 'Failed' });
    res.json({ success: true });
  });
});

module.exports = router;
