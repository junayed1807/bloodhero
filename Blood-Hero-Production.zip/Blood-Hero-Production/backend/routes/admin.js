const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../database');
const {
  loadAdminContext, requireAdmin, requireAdminRole, requirePermission,
  AUDIT_SCOPE,
} = require('../middleware/auth');
const { auditLog, AUDIT_ACTIONS, securityEvent, getClientIp } = require('../middleware/audit');

const router = express.Router();

// ============================================================
// Admin stats dashboard
// ============================================================
router.get('/stats', loadAdminContext, requireAdmin, requirePermission('audit.view'), (req, res) => {
  const db = getDb();

  const queries = {
    totalUsers: 'SELECT COUNT(*) as count FROM users',
    activeUsers: 'SELECT COUNT(*) as count FROM users WHERE is_available = 1',
    totalRequests: 'SELECT COUNT(*) as count FROM blood_requests',
    pendingRequests: 'SELECT COUNT(*) as count FROM blood_requests WHERE status = ?',
    totalDonations: 'SELECT COUNT(*) as count FROM donations',
    pendingVerifications: 'SELECT COUNT(*) as count FROM donations WHERE status = ?',
    verifiedDonations: 'SELECT COUNT(*) as count FROM donations WHERE status = ?',
    totalAdmins: 'SELECT COUNT(*) as count FROM admin_accounts',
    totalSubAdmins: 'SELECT COUNT(*) as count FROM admin_accounts WHERE role_id = ?',
    totalSecurityEvents: 'SELECT COUNT(*) as count FROM security_events WHERE created_at > ?',
  };

  const results = {};
  let pending = 0;
  const total = Object.keys(queries).length;

  const done = () => {
    pending--;
    if (pending <= 0) {
      res.json(results);
    }
  };

  pending = total;

  db.get(queries.totalUsers, (err, row) => { results.totalUsers = row?.count || 0; done(); });
  db.get(queries.activeUsers, (err, row) => { results.activeUsers = row?.count || 0; done(); });
  db.get(queries.totalRequests, (err, row) => { results.totalRequests = row?.count || 0; done(); });
  db.get(queries.pendingRequests, ['pending'], (err, row) => { results.pendingRequests = row?.count || 0; done(); });
  db.get(queries.totalDonations, (err, row) => { results.totalDonations = row?.count || 0; done(); });
  db.get(queries.pendingVerifications, ['pending_verification'], (err, row) => { results.pendingVerifications = row?.count || 0; done(); });
  db.get(queries.verifiedDonations, ['verified'], (err, row) => { results.verifiedDonations = row?.count || 0; done(); });
  db.get(queries.totalAdmins, (err, row) => { results.totalAdmins = row?.count || 0; done(); });
  db.get(queries.totalSubAdmins, ['role_sub_admin'], (err, row) => { results.totalSubAdmins = row?.count || 0; done(); });
  db.get(queries.totalSecurityEvents, [Math.floor(Date.now() / 1000) - 86400], (err, row) => { results.securityEvents24h = row?.count || 0; done(); });
});

// ============================================================
// User list (Admin + Sub-admin with permission)
// ============================================================
router.get('/users', loadAdminContext, requireAdmin, requirePermission('users.view'), (req, res) => {
  const db = getDb();
  db.all(
    'SELECT id, phone, name, blood_group, district, role, is_available, total_donations, points, level, created_at FROM users ORDER BY created_at DESC',
(err, rows) => {
      if (err) return res.status(500).json({ error: 'Failed' });
      const out = (rows || []).map(r => {
        const copy = { ...r };
        if (r.nid_number) copy.nid_number = String(r.nid_number).slice(0, 4) + '••••';
        return copy;
      });
      res.json(out);
    }
  );
});

// Suspend / unsuspend user
router.patch('/users/:id/suspend', loadAdminContext, requireAdmin, requirePermission('users.suspend'), (req, res) => {
  const { suspend } = req.body;
  const db = getDb();

  db.run(
    'UPDATE users SET is_available = ?, updated_at = strftime("%s", "now") WHERE id = ?',
    [suspend ? 0 : 1, req.params.id],
    function (err) {
      if (err) return res.status(500).json({ error: 'Failed' });

      auditLog({
        actorId: req.user.id,
        actorRole: req.adminContext.role,
        action: suspend ? AUDIT_ACTIONS.ACCOUNT_SUSPENDED : AUDIT_ACTIONS.ACCOUNT_ACTIVATED,
        targetType: 'user',
        targetId: req.params.id,
        description: `User ${suspend ? 'suspended' : 'activated'} by ${req.adminContext.role}`,
        ip: getClientIp(req),
        userAgent: req.headers['user-agent'],
      });

      res.json({ success: true });
    }
  );
});

// User detail (Admin + Sub-admin with users.view)
router.get('/users/:id', loadAdminContext, requireAdmin, requirePermission('users.view'), (req, res) => {
  const db = getDb();
  db.get(
    `SELECT id, phone, name, blood_group, district, upazila, union_area, age, weight, gender,
            emergency_contact, address, role, is_available, is_verified, total_donations, points,
            level, last_donation, created_at, updated_at
     FROM users WHERE id = ?`,
    [req.params.id],
    (err, user) => {
      if (err) return res.status(500).json({ error: 'Failed' });
      if (!user) return res.status(404).json({ error: 'User not found' });
      db.serialize(() => {
        const done = (extra) => res.json({ ...user, ...extra });
        db.get('SELECT COUNT(*) as count FROM donations WHERE donor_id = ?', [req.params.id], (e1, r1) => {
          db.get('SELECT COUNT(*) as count FROM blood_requests WHERE contact = ?', [user.phone], (e2, r2) => {
            db.get(
              'SELECT status, created_at FROM nid_verifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 1',
              [req.params.id], (e3, r3) => {
                done({ donationsCount: r1?.count || 0, requestsCount: r2?.count || 0, nid: r3 || null });
              });
          });
        });
      });
    }
  );
});

// ============================================================
// Blood requests management
// ============================================================
router.get('/requests', loadAdminContext, requireAdmin, requirePermission('requests.view'), (req, res) => {
  const db = getDb();
  const { status, blood_group, district } = req.query;
  let query = 'SELECT * FROM blood_requests WHERE 1=1';
  const params = [];

  if (status) { query += ' AND status = ?'; params.push(status); }
  if (blood_group) { query += ' AND blood_group = ?'; params.push(blood_group); }
  if (district) { query += ' AND district = ?'; params.push(district); }

  query += ' ORDER BY created_at DESC';

  db.all(query, params, (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed to fetch requests' });
    res.json(rows);
  });
});

// Approve / reject request (admin action)
router.patch('/requests/:id/status', loadAdminContext, requireAdmin, requirePermission('requests.approve'), (req, res) => {
  const { status, note } = req.body;
  const db = getDb();

  if (!status) return res.status(400).json({ error: 'Status is required' });

  db.run(
    'UPDATE blood_requests SET status = ?, updated_at = strftime("%s", "now") WHERE id = ?',
    [status, req.params.id],
    function (err) {
      if (err) return res.status(500).json({ error: 'Failed to update' });

      auditLog({
        actorId: req.user.id,
        actorRole: req.adminContext.role,
        action: AUDIT_ACTIONS.REQUEST_APPROVAL,
        targetType: 'request',
        targetId: req.params.id,
        description: `Request ${status === 'accepted' ? 'approved' : 'rejected'} by ${req.adminContext.role}`,
        metadata: { note: note || '', newStatus: status },
        ip: getClientIp(req),
        userAgent: req.headers['user-agent'],
      });

      res.json({ success: true, changes: this.changes });
    }
  );
});

// Delete request
router.delete('/requests/:id', loadAdminContext, requireAdmin, requirePermission('requests.manage'), (req, res) => {
  const db = getDb();
  db.run('DELETE FROM blood_requests WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json({ error: 'Failed to delete' });

    auditLog({
      actorId: req.user.id,
      actorRole: req.adminContext.role,
      action: 'delete_request',
      targetType: 'request',
      targetId: req.params.id,
      description: `Request deleted by ${req.adminContext.role}`,
      ip: getClientIp(req),
      userAgent: req.headers['user-agent'],
    });

    res.json({ success: true });
  });
});

// ============================================================
// Donations management
// ============================================================
router.get('/donations', loadAdminContext, requireAdmin, requirePermission('verification.donation'), (req, res) => {
  const db = getDb();
  const { status } = req.query;
  let query = 'SELECT * FROM donations WHERE 1=1';
  const params = [];

  if (status) { query += ' AND status = ?'; params.push(status); }
  query += ' ORDER BY created_at DESC';

  db.all(query, params, (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed to fetch donations' });
    res.json(rows);
  });
});

router.get('/donations/:id', loadAdminContext, requireAdmin, requirePermission('verification.donation'), (req, res) => {
  const db = getDb();
  db.get('SELECT * FROM donations WHERE id = ?', [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    if (!row) return res.status(404).json({ error: 'Donation not found' });
    res.json(row);
  });
});

router.post('/donations/:id/approve', loadAdminContext, requireAdmin, requirePermission('verification.donation'), (req, res) => {
  const db = getDb();
  const { admin_note } = req.body;

  db.get('SELECT * FROM donations WHERE id = ?', [req.params.id], (err, donation) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    if (!donation) return res.status(404).json({ error: 'Donation not found' });
    if (donation.status !== 'pending_verification') return res.status(400).json({ error: 'Not pending' });

    db.serialize(() => {
      db.run('BEGIN TRANSACTION');

      db.run(
        'UPDATE donations SET status = ?, reviewed_by = ?, reviewed_at = strftime("%s", "now"), admin_note = ? WHERE id = ?',
        ['verified', req.user.name || req.user.id, admin_note || '', req.params.id],
        function (err) {
          if (err) { db.run('ROLLBACK'); return res.status(500).json({ error: 'Approval failed' }); }

          db.run(
            'UPDATE users SET total_donations = total_donations + 1, points = points + 100, stars = stars + 1 WHERE id = ?',
            [donation.donor_id],
            function (err) {
              if (err) { db.run('ROLLBACK'); return res.status(500).json({ error: 'Reward failed' }); }

              db.get('SELECT total_donations FROM users WHERE id = ?', [donation.donor_id], (err, user) => {
                const count = user?.total_donations || 0;
                let newLevel = 'New Donor';
                if (count >= 100) newLevel = 'Legend';
                else if (count >= 50) newLevel = 'Century Champion';
                else if (count >= 25) newLevel = 'Regular Hero';
                else if (count >= 10) newLevel = 'Life Saver';
                else if (count >= 5) newLevel = 'Iron Heart';
                else if (count >= 1) newLevel = 'First Drop';

                db.run('UPDATE users SET level = ? WHERE id = ?', [newLevel, donation.donor_id]);

                db.run(
                  'INSERT INTO reward_ledger (id, user_id, donation_id, points, type, reason) VALUES (?, ?, ?, ?, ?, ?)',
                  [uuidv4(), donation.donor_id, req.params.id, 100, 'donation', 'Verified blood donation']
                );

                db.run(
                  'INSERT INTO notifications (id, user_id, type, title, body) VALUES (?, ?, ?, ?)',
                  [uuidv4(), donation.donor_id, 'donation_approved', 'Donation Verified', 'Your blood donation has been verified!']
                );

                auditLog({
                  actorId: req.user.id,
                  actorRole: req.adminContext.role,
                  action: AUDIT_ACTIONS.DONOR_VERIFICATION,
                  targetType: 'donation',
                  targetId: req.params.id,
                  description: `Approved donation for user ${donation.donor_id}`,
                  ip: getClientIp(req),
                  userAgent: req.headers['user-agent'],
                });

                db.run('COMMIT');
                res.json({ success: true, points: 100, level: newLevel });
              });
            }
          );
        }
      );
    });
  });
});

router.post('/donations/:id/reject', loadAdminContext, requireAdmin, requirePermission('verification.donation'), (req, res) => {
  const db = getDb();
  const { rejection_reason, admin_note } = req.body;

  if (!rejection_reason) return res.status(400).json({ error: 'Rejection reason required' });

  db.run(
    'UPDATE donations SET status = ?, rejection_reason = ?, reviewed_by = ?, reviewed_at = strftime("%s", "now"), admin_note = ? WHERE id = ?',
    ['rejected', rejection_reason, req.user.name || req.user.id, admin_note || '', req.params.id],
    function (err) {
      if (err) return res.status(500).json({ error: 'Rejection failed' });

      db.run(
        'INSERT INTO notifications (id, user_id, type, title, body) SELECT id, donor_id, ?, ?, ? FROM donations WHERE id = ?',
        ['donation_rejected', 'Donation Rejected', `Reason: ${rejection_reason}`, req.params.id]
      );

      auditLog({
        actorId: req.user.id,
        actorRole: req.adminContext.role,
        action: AUDIT_ACTIONS.DONOR_VERIFICATION,
        targetType: 'donation',
        targetId: req.params.id,
        description: `Rejected donation: ${rejection_reason}`,
        ip: getClientIp(req),
        userAgent: req.headers['user-agent'],
      });

      res.json({ success: true });
    }
  );
});

// ============================================================
// Audit logs — server-side visibility enforcement
// ============================================================
// Note: The /api/admin/audit-logs endpoint is replaced by /api/hierarchy/audit-logs
// which enforces strict server-side audit scope filtering.
// This stub remains for backwards compatibility but delegates to the hierarchy route.
router.get('/audit-logs', loadAdminContext, requireAdmin, (req, res) => {
  const ctx = req.adminContext;

  // CRITICAL: Admin must NOT see Super Admin activity
  if (req.query.actor_role === 'super_admin' && ctx.role !== 'super_admin') {
    securityEvent({
      actorId: req.user.id,
      actorRole: ctx.role,
      eventType: 'unauthorized_audit_access',
      targetType: 'audit_logs',
      description: 'Blocked attempt to access Super Admin audit records via /api/admin/audit-logs',
      ip: getClientIp(req),
      userAgent: req.headers['user-agent'],
      severity: 'critical',
    });
    return res.status(403).json({ error: 'Forbidden: You do not have permission to view Super Admin activity' });
  }

  const db = getDb();
  const params = [];
  let scopeFilter = '';

  if (ctx.role === 'super_admin') {
    // No filter — see all
  } else if (ctx.role === 'admin') {
    scopeFilter = ' AND actor_role IN (?, ?) AND audit_scope != ?';
    params.push('admin', 'sub_admin', 'SYSTEM');
  } else if (ctx.role === 'sub_admin') {
    scopeFilter = ' AND admin_id = ?';
    params.push(req.user.id);
  }

  db.all(
    `SELECT id, admin_id, actor_role, audit_scope, action, target_type, target_id, description, ip_address, created_at
     FROM audit_logs
     WHERE 1=1${scopeFilter}
     ORDER BY created_at DESC LIMIT 100`,
    params,
    (err, rows) => {
      if (err) return res.status(500).json({ error: 'Failed' });
      res.json(rows);
    }
  );
});

// ============================================================
// NID Verifications
// ============================================================
router.get('/nid-verifications', loadAdminContext, requireAdmin, requirePermission('verification.nid'), (req, res) => {
  const db = getDb();
  db.all(
    `SELECT nv.*, u.phone, u.name as account_name
     FROM nid_verifications nv
     LEFT JOIN users u ON u.id = nv.user_id
     ORDER BY nv.created_at DESC`,
    (err, rows) => {
      if (err) return res.status(500).json({ error: 'Failed' });
      res.json(rows);
    }
  );
});

router.get('/nid-verifications/:id', loadAdminContext, requireAdmin, requirePermission('verification.nid'), (req, res) => {
  const db = getDb();
  db.get('SELECT * FROM nid_verifications WHERE id = ?', [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    if (!row) return res.status(404).json({ error: 'Not found' });
    res.json(row);
  });
});

router.patch('/nid-verifications/:id/status', loadAdminContext, requireAdmin, requirePermission('verification.nid'), (req, res) => {
  const db = getDb();
  const { status } = req.body;

  const ALLOWED = ['pending', 'approved', 'rejected', 'resubmission_required'];
  if (!ALLOWED.includes(status)) {
    return res.status(400).json({ error: 'Invalid verification status' });
  }

  db.get('SELECT user_id, nid_number FROM nid_verifications WHERE id = ?', [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    if (!row) return res.status(404).json({ error: 'Not found' });

    db.run(
      'UPDATE nid_verifications SET status = ?, reviewed_by = ?, reviewed_at = strftime("%s", "now") WHERE id = ?',
      [status, req.user.name || req.user.id, req.params.id],
      function (uerr) {
        if (uerr) return res.status(500).json({ error: 'Failed' });

        // Keep the donor record in sync: approval marks the account verified.
        if (status === 'approved') {
          db.run('UPDATE users SET is_verified = 1, nid_status = ? WHERE id = ?', ['approved', row.user_id], () => {});
        } else if (status === 'rejected' || status === 'resubmission_required') {
          db.run('UPDATE users SET nid_status = ? WHERE id = ?', [status, row.user_id], () => {});
        }

        auditLog({
          actorId: req.user.id,
          actorRole: req.adminContext.role,
          action: AUDIT_ACTIONS.NID_VERIFICATION,
          targetType: 'nid_verification',
          targetId: req.params.id,
          description: `NID verification ${status} by ${req.adminContext.role} (masked ${String(row.nid_number || '').slice(0, 4)}••••)`,
          ip: getClientIp(req),
          userAgent: req.headers['user-agent'],
        });

        res.json({ success: true });
      }
    );
  });
});

module.exports = router;
