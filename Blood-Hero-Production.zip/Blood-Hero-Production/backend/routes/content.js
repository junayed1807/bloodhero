// Blood Hero — Admin Content Management Routes
// CRUD for public-website content modules: camps, campaigns, news (articles),
// gallery, partners, downloads, success stories, FAQ, volunteers, contact messages.
// RBAC enforced per-module via requirePermission. Every mutation is audit-logged.
const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../database');
const {
  loadAdminContext, requireAdmin, requirePermission,
} = require('../middleware/auth');
const { auditLog, getClientIp } = require('../middleware/audit');

const router = express.Router();

router.use(loadAdminContext, requireAdmin);

// ---------- validation helpers ----------
const str = (v, max = 5000) => String(v ?? '').trim().slice(0, max);
const allowList = (value, list, fallback) => list.includes(value) ? value : fallback;

const CAMP_STATUS = ['upcoming', 'ongoing', 'completed', 'cancelled'];
const CAMPAIGN_STATUS = ['upcoming', 'active', 'completed'];
const ARTICLE_STATUS = ['draft', 'published', 'archived'];
const STORY_STATUS = ['draft', 'published', 'archived'];
const VOLUNTEER_STATUS = ['pending', 'approved', 'rejected'];
const CONTACT_STATUS = ['new', 'read'];

function slugify(text) {
  const base = String(text || '').toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
  return base || 'article-' + Date.now();
}

function audit(req, ctx, action, targetType, targetId, description) {
  auditLog({
    actorId: ctx.actorId,
    actorRole: ctx.role,
    action,
    targetType,
    targetId,
    description,
    ip: getClientIp(req),
    userAgent: req.headers['user-agent'],
    scope: ctx.auditScope,
  });
}

// ============================================================
// BLOOD CAMPS
// ============================================================
router.get('/camps', requirePermission('content.manage'), (req, res) => {
  getDb().all('SELECT * FROM blood_camps ORDER BY date DESC', (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    res.json(rows || []);
  });
});

router.post('/camps', requirePermission('content.manage'), (req, res) => {
  const b = req.body || {};
  const id = uuidv4();
  const now = Math.floor(Date.now() / 1000);
  getDb().run(
    `INSERT INTO blood_camps (id, title, description, venue, district, upazila, date, start_time, end_time,
       target_units, collected_units, status, organizer, banner_url, registration_open, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [id, str(b.title, 200), str(b.description), str(b.venue, 200), str(b.district, 100), str(b.upazila, 100),
     str(b.date, 20), str(b.start_time, 10), str(b.end_time, 10),
     parseInt(b.target_units, 10) || 0, parseInt(b.collected_units, 10) || 0,
     allowList(b.status, CAMP_STATUS, 'upcoming'), str(b.organizer, 150), str(b.banner_url, 500),
     b.registration_open === false ? 0 : 1, now, now],
    function (err) {
      if (err) return res.status(500).json({ error: 'Failed to create camp' });
      audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
        'content_create', 'blood_camp', id, `Created blood camp: ${str(b.title, 200)}`);
      res.status(201).json({ id });
    }
  );
});

router.get('/camps/:id', requirePermission('content.manage'), (req, res) => {
  getDb().get('SELECT * FROM blood_camps WHERE id = ?', [req.params.id], (err, row) => {
    if (err || !row) return res.status(404).json({ error: 'Not found' });
    res.json(row);
  });
});

router.patch('/camps/:id', requirePermission('content.manage'), (req, res) => {
  const b = req.body || {};
  const now = Math.floor(Date.now() / 1000);
  getDb().get('SELECT * FROM blood_camps WHERE id = ?', [req.params.id], (err, existing) => {
    if (err || !existing) return res.status(404).json({ error: 'Not found' });
    const row = {
      title: str(b.title ?? existing.title, 200),
      description: str(b.description ?? existing.description),
      venue: str(b.venue ?? existing.venue, 200),
      district: str(b.district ?? existing.district, 100),
      upazila: str(b.upazila ?? existing.upazila, 100),
      date: str(b.date ?? existing.date, 20),
      start_time: str(b.start_time ?? existing.start_time, 10),
      end_time: str(b.end_time ?? existing.end_time, 10),
      target_units: parseInt(b.target_units ?? existing.target_units, 10) || 0,
      collected_units: parseInt(b.collected_units ?? existing.collected_units, 10) || 0,
      status: allowList(b.status ?? existing.status, CAMP_STATUS, existing.status),
      organizer: str(b.organizer ?? existing.organizer, 150),
      banner_url: str(b.banner_url ?? existing.banner_url, 500),
      registration_open: b.registration_open === undefined ? existing.registration_open : (b.registration_open ? 1 : 0),
    };
    getDb().run(
      `UPDATE blood_camps SET title=?, description=?, venue=?, district=?, upazila=?, date=?, start_time=?,
         end_time=?, target_units=?, collected_units=?, status=?, organizer=?, banner_url=?, registration_open=?, updated_at=?
       WHERE id = ?`,
      [row.title, row.description, row.venue, row.district, row.upazila, row.date, row.start_time, row.end_time,
       row.target_units, row.collected_units, row.status, row.organizer, row.banner_url, row.registration_open, now, req.params.id],
      (uerr) => {
        if (uerr) return res.status(500).json({ error: 'Failed to update camp' });
        audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
          'content_update', 'blood_camp', req.params.id, `Updated blood camp: ${row.title}`);
        res.json({ id: req.params.id, ...row });
      }
    );
  });
});

router.delete('/camps/:id', requirePermission('content.manage'), (req, res) => {
  getDb().run('DELETE FROM blood_camps WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json({ error: 'Failed to delete camp' });
    if (!this.changes) return res.status(404).json({ error: 'Not found' });
    audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
      'content_delete', 'blood_camp', req.params.id, `Deleted blood camp ${req.params.id}`);
    res.json({ ok: true });
  });
});

// ============================================================
// CAMPAIGNS
// ============================================================
router.get('/campaigns', requirePermission('content.manage'), (req, res) => {
  getDb().all('SELECT * FROM campaigns ORDER BY start_date DESC', (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    res.json(rows || []);
  });
});

router.post('/campaigns', requirePermission('content.manage'), (req, res) => {
  const b = req.body || {};
  const id = uuidv4();
  const now = Math.floor(Date.now() / 1000);
  getDb().run(
    `INSERT INTO campaigns (id, title, description, banner_url, category, start_date, end_date, goal, achieved, organizer, status, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [id, str(b.title, 200), str(b.description), str(b.banner_url, 500), str(b.category, 60),
     str(b.start_date, 20), str(b.end_date, 20), parseInt(b.goal, 10) || 0, parseInt(b.achieved, 10) || 0,
     str(b.organizer, 150), allowList(b.status, CAMPAIGN_STATUS, 'upcoming'), now, now],
    function (err) {
      if (err) return res.status(500).json({ error: 'Failed to create campaign' });
      audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
        'content_create', 'campaign', id, `Created campaign: ${str(b.title, 200)}`);
      res.status(201).json({ id });
    }
  );
});

router.patch('/campaigns/:id', requirePermission('content.manage'), (req, res) => {
  const b = req.body || {};
  const now = Math.floor(Date.now() / 1000);
  getDb().get('SELECT * FROM campaigns WHERE id = ?', [req.params.id], (err, existing) => {
    if (err || !existing) return res.status(404).json({ error: 'Not found' });
    const row = {
      title: str(b.title ?? existing.title, 200),
      description: str(b.description ?? existing.description),
      banner_url: str(b.banner_url ?? existing.banner_url, 500),
      category: str(b.category ?? existing.category, 60),
      start_date: str(b.start_date ?? existing.start_date, 20),
      end_date: str(b.end_date ?? existing.end_date, 20),
      goal: parseInt(b.goal ?? existing.goal, 10) || 0,
      achieved: parseInt(b.achieved ?? existing.achieved, 10) || 0,
      organizer: str(b.organizer ?? existing.organizer, 150),
      status: allowList(b.status ?? existing.status, CAMPAIGN_STATUS, existing.status),
    };
    getDb().run(
      `UPDATE campaigns SET title=?, description=?, banner_url=?, category=?, start_date=?, end_date=?, goal=?, achieved=?, organizer=?, status=?, updated_at=? WHERE id = ?`,
      [row.title, row.description, row.banner_url, row.category, row.start_date, row.end_date, row.goal, row.achieved, row.organizer, row.status, now, req.params.id],
      (uerr) => {
        if (uerr) return res.status(500).json({ error: 'Failed to update campaign' });
        audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
          'content_update', 'campaign', req.params.id, `Updated campaign: ${row.title}`);
        res.json({ id: req.params.id, ...row });
      }
    );
  });
});

router.delete('/campaigns/:id', requirePermission('content.manage'), (req, res) => {
  getDb().run('DELETE FROM campaigns WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json({ error: 'Failed to delete campaign' });
    if (!this.changes) return res.status(404).json({ error: 'Not found' });
    audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
      'content_delete', 'campaign', req.params.id, `Deleted campaign ${req.params.id}`);
    res.json({ ok: true });
  });
});

// ============================================================
// NEWS / ARTICLES
// ============================================================
router.get('/articles', requirePermission('content.manage'), (req, res) => {
  getDb().all('SELECT * FROM articles ORDER BY COALESCE(published_at, created_at) DESC', (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    res.json(rows || []);
  });
});

router.post('/articles', requirePermission('content.manage'), (req, res) => {
  const b = req.body || {};
  const id = uuidv4();
  const now = Math.floor(Date.now() / 1000);
  const slug = slugify(b.slug || b.title_en || b.title_bn);
  const publishedAt = (b.status === 'published') ? (parseInt(b.published_at, 10) || now) : null;
  getDb().run(
    `INSERT INTO articles (id, title_bn, title_en, body_bn, body_en, slug, excerpt_bn, excerpt_en, category, image_url, published_at, author_name, status, published, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [id, str(b.title_bn, 300), str(b.title_en, 300), str(b.body_bn, 60000), str(b.body_en, 60000), slug,
     str(b.excerpt_bn, 1000), str(b.excerpt_en, 1000), str(b.category, 60), str(b.image_url, 500),
     publishedAt, str(b.author_name, 150), allowList(b.status, ARTICLE_STATUS, 'published'),
     b.status === 'published' ? 1 : 0, now],
    function (err) {
      if (err) {
        if (err.message && err.message.includes('UNIQUE')) return res.status(409).json({ error: 'Slug already exists' });
        return res.status(500).json({ error: 'Failed to create article' });
      }
      audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
        'content_create', 'article', id, `Created article: ${slug}`);
      res.status(201).json({ id, slug });
    }
  );
});

router.get('/articles/:id', requirePermission('content.manage'), (req, res) => {
  getDb().get('SELECT * FROM articles WHERE id = ?', [req.params.id], (err, row) => {
    if (err || !row) return res.status(404).json({ error: 'Not found' });
    res.json(row);
  });
});

router.patch('/articles/:id', requirePermission('content.manage'), (req, res) => {
  const b = req.body || {};
  const now = Math.floor(Date.now() / 1000);
  getDb().get('SELECT * FROM articles WHERE id = ?', [req.params.id], (err, existing) => {
    if (err || !existing) return res.status(404).json({ error: 'Not found' });
    const status = allowList(b.status ?? existing.status, ARTICLE_STATUS, existing.status);
    const publishedAt = parseInt(b.published_at, 10) || existing.published_at || now;
    getDb().run(
      `UPDATE articles SET title_bn=?, title_en=?, body_bn=?, body_en=?, slug=?, excerpt_bn=?, excerpt_en=?,
         category=?, image_url=?, published_at=?, author_name=?, status=?, published=? WHERE id = ?`,
      [str(b.title_bn ?? existing.title_bn, 300), str(b.title_en ?? existing.title_en, 300),
       str(b.body_bn ?? existing.body_bn, 60000), str(b.body_en ?? existing.body_en, 60000),
       slugify(b.slug || existing.slug), str(b.excerpt_bn ?? existing.excerpt_bn, 1000),
       str(b.excerpt_en ?? existing.excerpt_en, 1000), str(b.category ?? existing.category, 60),
       str(b.image_url ?? existing.image_url, 500), status === 'published' ? publishedAt : existing.published_at,
       str(b.author_name ?? existing.author_name, 150), status, status === 'published' ? 1 : 0, req.params.id],
      (uerr) => {
        if (uerr) {
          if (uerr.message && uerr.message.includes('UNIQUE')) return res.status(409).json({ error: 'Slug already exists' });
          return res.status(500).json({ error: 'Failed to update article' });
        }
        audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
          'content_update', 'article', req.params.id, `Updated article: ${slugify(b.slug || existing.slug)}`);
        res.json({ id: req.params.id });
      }
    );
  });
});

router.delete('/articles/:id', requirePermission('content.manage'), (req, res) => {
  getDb().run('DELETE FROM articles WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json({ error: 'Failed to delete article' });
    if (!this.changes) return res.status(404).json({ error: 'Not found' });
    audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
      'content_delete', 'article', req.params.id, `Deleted article ${req.params.id}`);
    res.json({ ok: true });
  });
});

// ============================================================
// GALLERY (albums + images)
// ============================================================
router.get('/gallery', requirePermission('content.manage'), (req, res) => {
  getDb().all(
    `SELECT a.*, (SELECT COUNT(*) FROM gallery_images i WHERE i.album_id = a.id) as image_count
     FROM gallery_albums a ORDER BY a.created_at DESC`,
    (err, rows) => {
      if (err) return res.status(500).json({ error: 'Failed' });
      res.json(rows || []);
    }
  );
});

router.post('/gallery', requirePermission('content.manage'), (req, res) => {
  const b = req.body || {};
  const id = uuidv4();
  getDb().run(
    'INSERT INTO gallery_albums (id, title, description, category, cover_url, event_date) VALUES (?, ?, ?, ?, ?, ?)',
    [id, str(b.title, 200), str(b.description), str(b.category, 60), str(b.cover_url, 500), str(b.event_date, 20)],
    function (err) {
      if (err) return res.status(500).json({ error: 'Failed to create album' });
      audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
        'content_create', 'gallery_album', id, `Created gallery album: ${str(b.title, 200)}`);
      res.status(201).json({ id });
    }
  );
});

router.get('/gallery/:id', requirePermission('content.manage'), (req, res) => {
  const db = getDb();
  db.get('SELECT * FROM gallery_albums WHERE id = ?', [req.params.id], (err, album) => {
    if (err || !album) return res.status(404).json({ error: 'Not found' });
    db.all('SELECT * FROM gallery_images WHERE album_id = ? ORDER BY sort_order ASC', [req.params.id], (ierr, images) => {
      res.json({ ...album, images: images || [] });
    });
  });
});

router.patch('/gallery/:id', requirePermission('content.manage'), (req, res) => {
  const b = req.body || {};
  getDb().get('SELECT * FROM gallery_albums WHERE id = ?', [req.params.id], (err, existing) => {
    if (err || !existing) return res.status(404).json({ error: 'Not found' });
    getDb().run(
      'UPDATE gallery_albums SET title=?, description=?, category=?, cover_url=?, event_date=? WHERE id = ?',
      [str(b.title ?? existing.title, 200), str(b.description ?? existing.description),
       str(b.category ?? existing.category, 60), str(b.cover_url ?? existing.cover_url, 500),
       str(b.event_date ?? existing.event_date, 20), req.params.id],
      (uerr) => {
        if (uerr) return res.status(500).json({ error: 'Failed to update album' });
        audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
          'content_update', 'gallery_album', req.params.id, `Updated gallery album ${req.params.id}`);
        res.json({ id: req.params.id });
      }
    );
  });
});

router.delete('/gallery/:id', requirePermission('content.manage'), (req, res) => {
  const db = getDb();
  db.run('DELETE FROM gallery_images WHERE album_id = ?', [req.params.id], (err) => {
    if (err) return res.status(500).json({ error: 'Failed to delete album images' });
    db.run('DELETE FROM gallery_albums WHERE id = ?', [req.params.id], function (derr) {
      if (derr) return res.status(500).json({ error: 'Failed to delete album' });
      if (!this.changes) return res.status(404).json({ error: 'Not found' });
      audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
        'content_delete', 'gallery_album', req.params.id, `Deleted gallery album ${req.params.id}`);
      res.json({ ok: true });
    });
  });
});

// Add image to album
router.post('/gallery/:id/images', requirePermission('content.manage'), (req, res) => {
  const b = req.body || {};
  const imgId = uuidv4();
  getDb().get('SELECT id FROM gallery_albums WHERE id = ?', [req.params.id], (err, album) => {
    if (err || !album) return res.status(404).json({ error: 'Album not found' });
    getDb().run(
      'INSERT INTO gallery_images (id, album_id, url, caption, sort_order) VALUES (?, ?, ?, ?, ?)',
      [imgId, req.params.id, str(b.url, 500), str(b.caption, 300), parseInt(b.sort_order, 10) || 0],
      function (ierr) {
        if (ierr) return res.status(500).json({ error: 'Failed to add image' });
        audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
          'content_create', 'gallery_image', imgId, `Added image to album ${req.params.id}`);
        res.status(201).json({ id: imgId });
      }
    );
  });
});

router.delete('/gallery/:id/images/:imageId', requirePermission('content.manage'), (req, res) => {
  getDb().run('DELETE FROM gallery_images WHERE id = ? AND album_id = ?', [req.params.imageId, req.params.id], function (err) {
    if (err) return res.status(500).json({ error: 'Failed to delete image' });
    if (!this.changes) return res.status(404).json({ error: 'Not found' });
    audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
      'content_delete', 'gallery_image', req.params.imageId, `Deleted image from album ${req.params.id}`);
    res.json({ ok: true });
  });
});

// ============================================================
// PARTNERS
// ============================================================
router.get('/partners', requirePermission('content.manage'), (req, res) => {
  getDb().all('SELECT * FROM partners ORDER BY sort_order ASC, name ASC', (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    res.json(rows || []);
  });
});

router.post('/partners', requirePermission('content.manage'), (req, res) => {
  const b = req.body || {};
  const id = uuidv4();
  getDb().run(
    'INSERT INTO partners (id, name, type, logo_url, website, description, active, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    [id, str(b.name, 200), str(b.type, 60), str(b.logo_url, 500), str(b.website, 300), str(b.description), b.active === false ? 0 : 1, parseInt(b.sort_order, 10) || 0],
    function (err) {
      if (err) return res.status(500).json({ error: 'Failed to create partner' });
      audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
        'content_create', 'partner', id, `Created partner: ${str(b.name, 200)}`);
      res.status(201).json({ id });
    }
  );
});

router.patch('/partners/:id', requirePermission('content.manage'), (req, res) => {
  const b = req.body || {};
  getDb().get('SELECT * FROM partners WHERE id = ?', [req.params.id], (err, existing) => {
    if (err || !existing) return res.status(404).json({ error: 'Not found' });
    getDb().run(
      'UPDATE partners SET name=?, type=?, logo_url=?, website=?, description=?, active=?, sort_order=? WHERE id = ?',
      [str(b.name ?? existing.name, 200), str(b.type ?? existing.type, 60), str(b.logo_url ?? existing.logo_url, 500),
       str(b.website ?? existing.website, 300), str(b.description ?? existing.description),
       b.active === undefined ? existing.active : (b.active ? 1 : 0), parseInt(b.sort_order ?? existing.sort_order, 10) || 0, req.params.id],
      (uerr) => {
        if (uerr) return res.status(500).json({ error: 'Failed to update partner' });
        audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
          'content_update', 'partner', req.params.id, `Updated partner ${req.params.id}`);
        res.json({ id: req.params.id });
      }
    );
  });
});

router.delete('/partners/:id', requirePermission('content.manage'), (req, res) => {
  getDb().run('DELETE FROM partners WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json({ error: 'Failed to delete partner' });
    if (!this.changes) return res.status(404).json({ error: 'Not found' });
    audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
      'content_delete', 'partner', req.params.id, `Deleted partner ${req.params.id}`);
    res.json({ ok: true });
  });
});

// ============================================================
// DOWNLOADS
// ============================================================
router.get('/downloads', requirePermission('content.manage'), (req, res) => {
  getDb().all('SELECT * FROM downloads ORDER BY created_at DESC', (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    res.json(rows || []);
  });
});

router.post('/downloads', requirePermission('content.manage'), (req, res) => {
  const b = req.body || {};
  const id = uuidv4();
  getDb().run(
    'INSERT INTO downloads (id, title, description, file_url, category, file_size, active) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [id, str(b.title, 200), str(b.description), str(b.file_url, 500), str(b.category, 60), str(b.file_size, 40), b.active === false ? 0 : 1],
    function (err) {
      if (err) return res.status(500).json({ error: 'Failed to create download' });
      audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
        'content_create', 'download', id, `Created download: ${str(b.title, 200)}`);
      res.status(201).json({ id });
    }
  );
});

router.patch('/downloads/:id', requirePermission('content.manage'), (req, res) => {
  const b = req.body || {};
  getDb().get('SELECT * FROM downloads WHERE id = ?', [req.params.id], (err, existing) => {
    if (err || !existing) return res.status(404).json({ error: 'Not found' });
    getDb().run(
      'UPDATE downloads SET title=?, description=?, file_url=?, category=?, file_size=?, active=? WHERE id = ?',
      [str(b.title ?? existing.title, 200), str(b.description ?? existing.description),
       str(b.file_url ?? existing.file_url, 500), str(b.category ?? existing.category, 60),
       str(b.file_size ?? existing.file_size, 40), b.active === undefined ? existing.active : (b.active ? 1 : 0), req.params.id],
      (uerr) => {
        if (uerr) return res.status(500).json({ error: 'Failed to update download' });
        audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
          'content_update', 'download', req.params.id, `Updated download ${req.params.id}`);
        res.json({ id: req.params.id });
      }
    );
  });
});

router.delete('/downloads/:id', requirePermission('content.manage'), (req, res) => {
  getDb().run('DELETE FROM downloads WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json({ error: 'Failed to delete download' });
    if (!this.changes) return res.status(404).json({ error: 'Not found' });
    audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
      'content_delete', 'download', req.params.id, `Deleted download ${req.params.id}`);
    res.json({ ok: true });
  });
});

// ============================================================
// SUCCESS STORIES
// ============================================================
router.get('/stories', requirePermission('content.manage'), (req, res) => {
  getDb().all('SELECT * FROM success_stories ORDER BY featured DESC, created_at DESC', (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    res.json(rows || []);
  });
});

router.post('/stories', requirePermission('content.manage'), (req, res) => {
  const b = req.body || {};
  const id = uuidv4();
  getDb().run(
    'INSERT INTO success_stories (id, title, content, image_url, category, author_name, status, featured) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    [id, str(b.title, 200), str(b.content, 20000), str(b.image_url, 500), str(b.category, 60),
     str(b.author_name, 150), allowList(b.status, STORY_STATUS, 'published'), b.featured ? 1 : 0],
    function (err) {
      if (err) return res.status(500).json({ error: 'Failed to create story' });
      audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
        'content_create', 'success_story', id, `Created success story: ${str(b.title, 200)}`);
      res.status(201).json({ id });
    }
  );
});

router.patch('/stories/:id', requirePermission('content.manage'), (req, res) => {
  const b = req.body || {};
  getDb().get('SELECT * FROM success_stories WHERE id = ?', [req.params.id], (err, existing) => {
    if (err || !existing) return res.status(404).json({ error: 'Not found' });
    getDb().run(
      'UPDATE success_stories SET title=?, content=?, image_url=?, category=?, author_name=?, status=?, featured=? WHERE id = ?',
      [str(b.title ?? existing.title, 200), str(b.content ?? existing.content, 20000),
       str(b.image_url ?? existing.image_url, 500), str(b.category ?? existing.category, 60),
       str(b.author_name ?? existing.author_name, 150), allowList(b.status ?? existing.status, STORY_STATUS, existing.status),
       b.featured === undefined ? existing.featured : (b.featured ? 1 : 0), req.params.id],
      (uerr) => {
        if (uerr) return res.status(500).json({ error: 'Failed to update story' });
        audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
          'content_update', 'success_story', req.params.id, `Updated success story ${req.params.id}`);
        res.json({ id: req.params.id });
      }
    );
  });
});

router.delete('/stories/:id', requirePermission('content.manage'), (req, res) => {
  getDb().run('DELETE FROM success_stories WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json({ error: 'Failed to delete story' });
    if (!this.changes) return res.status(404).json({ error: 'Not found' });
    audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
      'content_delete', 'success_story', req.params.id, `Deleted success story ${req.params.id}`);
    res.json({ ok: true });
  });
});

// ============================================================
// FAQ
// ============================================================
router.get('/faq', requirePermission('content.manage'), (req, res) => {
  getDb().all('SELECT * FROM faq ORDER BY sort_order ASC, created_at ASC', (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    res.json(rows || []);
  });
});

router.post('/faq', requirePermission('content.manage'), (req, res) => {
  const b = req.body || {};
  const id = uuidv4();
  getDb().run(
    'INSERT INTO faq (id, question_bn, question_en, answer_bn, answer_en, category, active, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    [id, str(b.question_bn, 500), str(b.question_en, 500), str(b.answer_bn, 5000), str(b.answer_en, 5000),
     str(b.category, 60), b.active === false ? 0 : 1, parseInt(b.sort_order, 10) || 0],
    function (err) {
      if (err) return res.status(500).json({ error: 'Failed to create FAQ' });
      audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
        'content_create', 'faq', id, `Created FAQ entry`);
      res.status(201).json({ id });
    }
  );
});

router.patch('/faq/:id', requirePermission('content.manage'), (req, res) => {
  const b = req.body || {};
  getDb().get('SELECT * FROM faq WHERE id = ?', [req.params.id], (err, existing) => {
    if (err || !existing) return res.status(404).json({ error: 'Not found' });
    getDb().run(
      'UPDATE faq SET question_bn=?, question_en=?, answer_bn=?, answer_en=?, category=?, active=?, sort_order=? WHERE id = ?',
      [str(b.question_bn ?? existing.question_bn, 500), str(b.question_en ?? existing.question_en, 500),
       str(b.answer_bn ?? existing.answer_bn, 5000), str(b.answer_en ?? existing.answer_en, 5000),
       str(b.category ?? existing.category, 60), b.active === undefined ? existing.active : (b.active ? 1 : 0),
       parseInt(b.sort_order ?? existing.sort_order, 10) || 0, req.params.id],
      (uerr) => {
        if (uerr) return res.status(500).json({ error: 'Failed to update FAQ' });
        audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
          'content_update', 'faq', req.params.id, `Updated FAQ ${req.params.id}`);
        res.json({ id: req.params.id });
      }
    );
  });
});

router.delete('/faq/:id', requirePermission('content.manage'), (req, res) => {
  getDb().run('DELETE FROM faq WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json({ error: 'Failed to delete FAQ' });
    if (!this.changes) return res.status(404).json({ error: 'Not found' });
    audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
      'content_delete', 'faq', req.params.id, `Deleted FAQ ${req.params.id}`);
    res.json({ ok: true });
  });
});

// ============================================================
// VOLUNTEERS (approval + list)
// ============================================================
router.get('/volunteers', requirePermission('volunteers.manage'), (req, res) => {
  getDb().all('SELECT * FROM volunteer_registrations ORDER BY created_at DESC', (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    res.json(rows || []);
  });
});

router.patch('/volunteers/:id/status', requirePermission('volunteers.manage'), (req, res) => {
  const b = req.body || {};
  const status = allowList(b.status, VOLUNTEER_STATUS, null);
  if (!status) return res.status(400).json({ error: 'Invalid status' });
  const now = Math.floor(Date.now() / 1000);
  getDb().run(
    'UPDATE volunteer_registrations SET status = ?, reviewed_by = ?, reviewed_at = ? WHERE id = ?',
    [status, req.user.id, now, req.params.id],
    function (err) {
      if (err) return res.status(500).json({ error: 'Failed to update volunteer' });
      if (!this.changes) return res.status(404).json({ error: 'Not found' });
      audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
        'content_update', 'volunteer', req.params.id, `Volunteer status -> ${status}`);
      res.json({ id: req.params.id, status });
    }
  );
});

router.delete('/volunteers/:id', requirePermission('volunteers.manage'), (req, res) => {
  getDb().run('DELETE FROM volunteer_registrations WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json({ error: 'Failed to delete volunteer' });
    if (!this.changes) return res.status(404).json({ error: 'Not found' });
    audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
      'content_delete', 'volunteer', req.params.id, `Deleted volunteer ${req.params.id}`);
    res.json({ ok: true });
  });
});

// ============================================================
// CONTACT MESSAGES
// ============================================================
router.get('/contact-messages', requirePermission('contact.view'), (req, res) => {
  getDb().all('SELECT * FROM contact_messages ORDER BY created_at DESC', (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    res.json(rows || []);
  });
});

router.patch('/contact-messages/:id/status', requirePermission('contact.view'), (req, res) => {
  const b = req.body || {};
  const status = allowList(b.status, CONTACT_STATUS, null);
  if (!status) return res.status(400).json({ error: 'Invalid status' });
  getDb().run('UPDATE contact_messages SET status = ? WHERE id = ?', [status, req.params.id], function (err) {
    if (err) return res.status(500).json({ error: 'Failed to update message' });
    if (!this.changes) return res.status(404).json({ error: 'Not found' });
    audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
      'content_update', 'contact_message', req.params.id, `Contact message status -> ${status}`);
    res.json({ id: req.params.id, status });
  });
});

router.delete('/contact-messages/:id', requirePermission('contact.view'), (req, res) => {
  getDb().run('DELETE FROM contact_messages WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json({ error: 'Failed to delete message' });
    if (!this.changes) return res.status(404).json({ error: 'Not found' });
    audit(req, { actorId: req.user.id, role: req.user.adminRole, auditScope: req.adminContext.auditScope },
      'content_delete', 'contact_message', req.params.id, `Deleted contact message ${req.params.id}`);
    res.json({ ok: true });
  });
});

module.exports = router;