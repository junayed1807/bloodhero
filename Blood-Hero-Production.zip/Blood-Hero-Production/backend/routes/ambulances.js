const express = require('express');
const { getDb } = require('../database');
const {
  authenticateToken, loadAdminContext, requireAdmin, requirePermission,
} = require('../middleware/auth');

const router = express.Router();

router.get('/', (req, res) => {
  const db = getDb();
  const { district, upazila, available } = req.query;
  let query = 'SELECT * FROM ambulances WHERE 1=1';
  const params = [];

  if (district) { query += ' AND district = ?'; params.push(district); }
  if (upazila) { query += ' AND upazila = ?'; params.push(upazila); }
  if (available !== undefined) { query += ' AND availability_status = ?'; params.push(available ? 'available' : 'unavailable'); }

  query += ' ORDER BY is_verified DESC, name';

  db.all(query, params, (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed to fetch ambulances' });
    res.json(rows);
  });
});

router.get('/:id', (req, res) => {
  const db = getDb();
  db.get('SELECT * FROM ambulances WHERE id = ?', [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    if (!row) return res.status(404).json({ error: 'Ambulance not found' });
    res.json(row);
  });
});

router.post('/', authenticateToken, loadAdminContext, requireAdmin, requirePermission('ambulances.manage'), (req, res) => {
  const db = getDb();
  const { name, provider, phone, district, upazila, service_area, availability_status, notes } = req.body;
  
  if (!name || !phone) {
    return res.status(400).json({ error: 'Name and phone are required' });
  }

  const id = require('uuid').v4();
  db.run(
    `INSERT INTO ambulances (id, name, provider, phone, district, upazila, service_area, availability_status, notes) 
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [id, name, provider || '', phone, district || '', upazila || '', service_area || '', availability_status || 'available', notes || ''],
    function(err) {
      if (err) return res.status(500).json({ error: 'Failed to add ambulance' });
      res.status(201).json({ id });
    }
  );
});

router.patch('/:id', authenticateToken, loadAdminContext, requireAdmin, requirePermission('ambulances.manage'), (req, res) => {
  const db = getDb();
  const { name, provider, phone, district, upazila, service_area, availability_status, is_verified, notes } = req.body;
  
  db.run(
    `UPDATE ambulances SET name = ?, provider = ?, phone = ?, district = ?, upazila = ?, service_area = ?, availability_status = ?, is_verified = ?, notes = ?, last_verified_at = strftime('%s', 'now') WHERE id = ?`,
    [name, provider, phone, district, upazila, service_area, availability_status, is_verified ? 1 : 0, notes, req.params.id],
    function(err) {
      if (err) return res.status(500).json({ error: 'Failed to update' });
      res.json({ success: true });
    }
  );
});

router.delete('/:id', authenticateToken, loadAdminContext, requireAdmin, requirePermission('ambulances.manage'), (req, res) => {
  const db = getDb();
  db.run('DELETE FROM ambulances WHERE id = ?', [req.params.id], function(err) {
    if (err) return res.status(500).json({ error: 'Failed' });
    res.json({ success: true });
  });
});

module.exports = router;
