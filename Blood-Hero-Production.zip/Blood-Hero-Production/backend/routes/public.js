// Blood Hero — Public API Routes (no authentication required)
// Read-only data for the public website. Privacy-safe: never exposes phone,
// NID, email or other sensitive donor fields.
const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../database');

const router = express.Router();

// Helper: promisify db.all / db.get
const dbAll = (db, sql, params = []) => new Promise((resolve, reject) => {
  db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows || []));
});
const dbGet = (db, sql, params = []) => new Promise((resolve, reject) => {
  db.get(sql, params, (err, row) => err ? reject(err) : resolve(row));
});

// --- GET /api/public/stats — Aggregated impact stats (real database data) ---
router.get('/stats', async (req, res) => {
  try {
    const db = getDb();
    const [donors, verifiedDonors, requests, pendingRequests, fulfilled, verifiedDonations, camps, volunteers, centers, ambulances] = await Promise.all([
      dbGet(db, 'SELECT COUNT(*) as n FROM users'),
      dbGet(db, "SELECT COUNT(*) as n FROM users WHERE is_verified = 1"),
      dbGet(db, 'SELECT COUNT(*) as n FROM blood_requests'),
      dbGet(db, "SELECT COUNT(*) as n FROM blood_requests WHERE status = 'pending'"),
      dbGet(db, "SELECT COUNT(*) as n FROM blood_requests WHERE status = 'fulfilled'"),
      dbGet(db, "SELECT COUNT(*) as n FROM donations WHERE status IN ('verified', 'approved')"),
      dbGet(db, "SELECT COUNT(*) as n FROM blood_camps WHERE status != 'cancelled'"),
      dbGet(db, "SELECT COUNT(*) as n FROM volunteer_registrations WHERE status = 'approved'"),
      dbGet(db, 'SELECT COUNT(*) as n FROM centers'),
      dbGet(db, 'SELECT COUNT(*) as n FROM ambulances'),
    ]);
    res.json({
      donors: donors?.n || 0,
      verifiedDonors: verifiedDonors?.n || 0,
      requests: requests?.n || 0,
      pendingRequests: pendingRequests?.n || 0,
      fulfilled: fulfilled?.n || 0,
      verifiedDonations: verifiedDonations?.n || 0,
      camps: camps?.n || 0,
      volunteers: volunteers?.n || 0,
      centers: centers?.n || 0,
      ambulances: ambulances?.n || 0,
      lives: (verifiedDonations?.n || 0) * 3, // Each verified unit can help up to 3 patients
    });
  } catch (err) {
    console.error('Public stats error:', err.message);
    res.json({ donors: 0, verifiedDonors: 0, requests: 0, pendingRequests: 0, fulfilled: 0, verifiedDonations: 0, camps: 0, volunteers: 0, centers: 0, ambulances: 0, lives: 0 });
  }
});

// --- GET /api/public/donors — Public donor search (masked, privacy-safe) ---
router.get('/donors', async (req, res) => {
  try {
    const db = getDb();
    const { group, district, upazila, limit } = req.query;
    let sql = `SELECT id, name, blood_group, district, upazila, union_area,
               total_donations, last_donation, gender, is_available, is_verified, photo_url, created_at
               FROM users`;
    const where = [];
    const params = [];
    if (group) { where.push('blood_group = ?'); params.push(group); }
    if (district) { where.push('district = ?'); params.push(district); }
    if (upazila) { where.push('upazila = ?'); params.push(upazila); }
    if (where.length) sql += ' WHERE ' + where.join(' AND ');
    sql += ' ORDER BY is_available DESC, total_donations DESC, is_verified DESC LIMIT ?';
    params.push(parseInt(limit) || 50);

    const rows = await dbAll(db, sql, params);
    const sanitized = rows.map(d => ({
      id: d.id,
      name: d.name,
      bloodGroup: d.blood_group,
      district: d.district,
      upazila: d.upazila,
      union: d.union_area,
      available: !!d.is_available,
      totalDonations: d.total_donations || 0,
      lastDonation: d.last_donation,
      gender: d.gender,
      verified: !!d.is_verified || (d.total_donations || 0) >= 5,
      photoUrl: d.photo_url || null,
      // No phone, no email, no NID, no address — public safety
    }));
    res.json(sanitized);
  } catch (err) {
    console.error('Public donors error:', err.message);
    res.json([]);
  }
});

// --- GET /api/public/requests/urgent — Active urgent/critical requests (no contact/patient PII) ---
router.get('/requests/urgent', async (req, res) => {
  try {
    const db = getDb();
    const rows = await dbAll(db,
      `SELECT id, blood_group, hospital, district, upazila, units, urgency, status, needed_by, created_at
       FROM blood_requests
       WHERE status = 'pending' AND urgency IN ('urgent', 'critical')
       ORDER BY urgency DESC, created_at DESC LIMIT 10`
    );
    const sanitized = rows.map(r => ({
      id: r.id,
      bloodGroup: r.blood_group,
      hospital: r.hospital,
      district: r.district,
      upazila: r.upazila,
      units: r.units,
      urgency: r.urgency,
      status: r.status,
      neededBy: r.needed_by,
      createdAt: r.created_at,
    }));
    res.json(sanitized);
  } catch (err) {
    console.error('Public urgent requests error:', err.message);
    res.json([]);
  }
});

// --- GET /api/public/articles — Published news/articles ---
router.get('/articles', async (req, res) => {
  try {
    const db = getDb();
    const rows = await dbAll(db,
      `SELECT id, title_en, title_bn, excerpt_en, excerpt_bn, category,
              image_url, slug, author_name, published_at, created_at
       FROM articles WHERE status = 'published'
       ORDER BY COALESCE(published_at, created_at) DESC LIMIT ?`,
      [parseInt(req.query.limit) || 20]
    );
    res.json(rows);
  } catch (err) {
    res.json([]);
  }
});

// --- GET /api/public/articles/:slug — Single article ---
router.get('/articles/:slug', async (req, res) => {
  try {
    const db = getDb();
    const row = await dbGet(db,
      `SELECT * FROM articles WHERE slug = ? AND status = 'published'`,
      [req.params.slug]
    );
    if (!row) return res.status(404).json({ error: 'Article not found' });
    res.json(row);
  } catch (err) {
    res.status(404).json({ error: 'Article not found' });
  }
});

// --- GET /api/public/faq — Active FAQ entries ---
router.get('/faq', async (req, res) => {
  try {
    const db = getDb();
    const rows = await dbAll(db,
      `SELECT id, question_bn, question_en, answer_bn, answer_en, category
       FROM faq WHERE active = 1 ORDER BY sort_order ASC, created_at ASC`
    );
    res.json(rows);
  } catch (err) {
    res.json([]);
  }
});

// --- GET /api/public/camps — Blood camps (all statuses available, upcoming first) ---
router.get('/camps', async (req, res) => {
  try {
    const db = getDb();
    const rows = await dbAll(db,
      `SELECT id, title, description, venue, district, upazila, date, start_time, end_time,
              target_units, collected_units, status, organizer, banner_url, registration_open
       FROM blood_camps
       WHERE status != 'cancelled'
       ORDER BY CASE status WHEN 'ongoing' THEN 0 WHEN 'upcoming' THEN 1 ELSE 2 END, date ASC LIMIT ?`,
      [parseInt(req.query.limit) || 30]
    );
    res.json(rows);
  } catch (err) {
    res.json([]);
  }
});

// --- GET /api/public/camps/:id — Single camp ---
router.get('/camps/:id', async (req, res) => {
  try {
    const db = getDb();
    const row = await dbGet(db, 'SELECT * FROM blood_camps WHERE id = ?', [req.params.id]);
    if (!row) return res.status(404).json({ error: 'Camp not found' });
    res.json(row);
  } catch (err) {
    res.status(404).json({ error: 'Camp not found' });
  }
});

// --- GET /api/public/campaigns — Campaigns ---
router.get('/campaigns', async (req, res) => {
  try {
    const db = getDb();
    const rows = await dbAll(db,
      `SELECT id, title, description, banner_url, category, start_date, end_date, goal, achieved, organizer, status
       FROM campaigns
       ORDER BY CASE status WHEN 'active' THEN 0 WHEN 'upcoming' THEN 1 ELSE 2 END, start_date ASC LIMIT ?`,
      [parseInt(req.query.limit) || 30]
    );
    res.json(rows);
  } catch (err) {
    res.json([]);
  }
});

// --- GET /api/public/campaigns/:id — Single campaign ---
router.get('/campaigns/:id', async (req, res) => {
  try {
    const db = getDb();
    const row = await dbGet(db, 'SELECT * FROM campaigns WHERE id = ?', [req.params.id]);
    if (!row) return res.status(404).json({ error: 'Campaign not found' });
    res.json(row);
  } catch (err) {
    res.status(404).json({ error: 'Campaign not found' });
  }
});

// --- GET /api/public/gallery — Gallery albums ---
router.get('/gallery', async (req, res) => {
  try {
    const db = getDb();
    const rows = await dbAll(db,
      `SELECT a.id, a.title, a.description, a.category, a.cover_url, a.event_date, a.created_at,
              (SELECT COUNT(*) FROM gallery_images i WHERE i.album_id = a.id) as image_count
       FROM gallery_albums a
       ORDER BY a.created_at DESC LIMIT ?`,
      [parseInt(req.query.limit) || 30]
    );
    res.json(rows);
  } catch (err) {
    res.json([]);
  }
});

// --- GET /api/public/gallery/:id — Album images ---
router.get('/gallery/:id', async (req, res) => {
  try {
    const db = getDb();
    const album = await dbGet(db, 'SELECT * FROM gallery_albums WHERE id = ?', [req.params.id]);
    if (!album) return res.status(404).json({ error: 'Album not found' });
    const images = await dbAll(db,
      'SELECT id, url, caption, sort_order FROM gallery_images WHERE album_id = ? ORDER BY sort_order ASC, created_at ASC',
      [req.params.id]
    );
    res.json({ album, images });
  } catch (err) {
    res.status(404).json({ error: 'Album not found' });
  }
});

// --- GET /api/public/partners — Active partners ---
router.get('/partners', async (req, res) => {
  try {
    const db = getDb();
    const rows = await dbAll(db,
      `SELECT id, name, type, logo_url, website, description
       FROM partners WHERE active = 1 ORDER BY sort_order ASC, name ASC`
    );
    res.json(rows);
  } catch (err) {
    res.json([]);
  }
});

// --- GET /api/public/downloads — Available downloads ---
router.get('/downloads', async (req, res) => {
  try {
    const db = getDb();
    const rows = await dbAll(db,
      `SELECT id, title, description, file_url, category, file_size
       FROM downloads WHERE active = 1 ORDER BY created_at DESC`
    );
    res.json(rows);
  } catch (err) {
    res.json([]);
  }
});

// --- GET /api/public/success-stories — Published success stories ---
router.get('/success-stories', async (req, res) => {
  try {
    const db = getDb();
    const rows = await dbAll(db,
      `SELECT id, title, content, image_url, category, author_name, created_at
       FROM success_stories WHERE status = 'published'
       ORDER BY featured DESC, created_at DESC LIMIT ?`,
      [parseInt(req.query.limit) || 20]
    );
    res.json(rows);
  } catch (err) {
    res.json([]);
  }
});

// --- GET /api/public/volunteers — Approved volunteers (privacy-safe) ---
router.get('/volunteers', async (req, res) => {
  try {
    const db = getDb();
    const rows = await dbAll(db,
      `SELECT id, name, district, upazila, skills, created_at
       FROM volunteer_registrations WHERE status = 'approved'
       ORDER BY created_at DESC LIMIT ?`,
      [parseInt(req.query.limit) || 50]
    );
    res.json(rows);
  } catch (err) {
    res.json([]);
  }
});

// --- POST /api/public/volunteers/register — Public volunteer signup ---
router.post('/volunteers/register', (req, res) => {
  const db = getDb();
  const b = req.body || {};
  const clean = (v) => String(v || '').trim();
  const cName = clean(b.name);
  const cPhone = clean(b.phone).replace(/[^0-9+]/g, '');
  if (!cName || !cPhone || cPhone.length < 10 || cPhone.length > 15) {
    return res.status(400).json({ error: 'Name and a valid phone number are required.' });
  }
  if (b.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clean(b.email))) {
    return res.status(400).json({ error: 'A valid email is required.' });
  }
  const id = uuidv4();
  db.run(
    `INSERT INTO volunteer_registrations (id, user_id, name, phone, email, district, upazila, skills, availability, message, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')`,
    [id, b.user_id || null, cName.slice(0, 120), cPhone, clean(b.email).slice(0, 160),
     clean(b.district).slice(0, 100), clean(b.upazila).slice(0, 100),
     clean(b.skills).slice(0, 500), clean(b.availability).slice(0, 500), clean(b.message).slice(0, 2000)],
    function (err) {
      if (err) return res.status(500).json({ error: 'Failed to register as volunteer' });
      res.status(201).json({ id, status: 'pending' });
    }
  );
});

// --- POST /api/public/contact — Contact form (validated, stored) ---
router.post('/contact', (req, res) => {
  const db = getDb();
  const { name, email, phone, subject, message } = req.body || {};
  const clean = (v) => String(v || '').trim();

  const cName = clean(name);
  const cMessage = clean(message);
  if (!cName || cMessage.length < 5) {
    return res.status(400).json({ error: 'Name and a message (min 5 chars) are required.' });
  }
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clean(email))) {
    return res.status(400).json({ error: 'A valid email is required.' });
  }
  const cPhone = clean(phone).replace(/[^0-9+]/g, '');
  if (cPhone && (cPhone.length < 10 || cPhone.length > 15)) {
    return res.status(400).json({ error: 'A valid phone number is required.' });
  }

  const id = uuidv4();
  db.run(
    'INSERT INTO contact_messages (id, name, email, phone, subject, message, status) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [id, cName.slice(0, 120), clean(email).slice(0, 160), cPhone, clean(subject).slice(0, 200), cMessage.slice(0, 3000), 'new'],
    function (err) {
      if (err) return res.status(500).json({ error: 'Failed to send message' });
      res.status(201).json({ id, status: 'new' });
    }
  );
});

module.exports = router;