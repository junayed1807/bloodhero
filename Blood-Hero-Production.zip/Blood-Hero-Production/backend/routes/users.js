const express = require('express');
const fs = require('fs');
const { getDb } = require('../database');
const { authenticateToken } = require('../middleware/auth');
const { uploadProfile, assertImageFile } = require('../middleware/upload');

const router = express.Router();

router.get('/profile', (req, res) => {
  const db = getDb();
  db.get('SELECT id, phone, name, blood_group, district, upazila, union_area AS "union", age, weight, gender, emergency_contact, photo_url, role, last_donation, points, stars, level, is_available, created_at FROM users WHERE id = ?', [req.user.id], (err, row) => {
    if (err) return res.status(500).json({ error: 'Failed to fetch profile' });
    if (!row) return res.status(404).json({ error: 'User not found' });
    res.json(row);
  });
});

router.put('/profile', (req, res) => {
  const db = getDb();
  const allowed = ['name', 'blood_group', 'district', 'upazila', 'age', 'weight', 'gender', 'emergency_contact', 'address', 'photo_url'];
  const columnMap = { union: 'union_area' };
  const updates = [];
  const values = [];
  
  Object.keys(req.body).forEach(key => {
    if (allowed.includes(key)) {
      updates.push(`${key} = ?`);
      values.push(req.body[key]);
    } else if (columnMap[key]) {
      updates.push(`${columnMap[key]} = ?`);
      values.push(req.body[key]);
    }
  });
  
  if (updates.length === 0) return res.status(400).json({ error: 'No valid fields' });
  
  updates.push('updated_at = strftime("%s", "now")');
  values.push(req.user.id);
  
  db.run(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`, values, function(err) {
    if (err) return res.status(500).json({ error: 'Update failed' });
    res.json({ success: true, changes: this.changes });
  });
});

router.post('/profile/picture', uploadProfile, (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  // Reject spoofed Content-Type files that are not real images.
  if (!assertImageFile(req.file.path)) {
    fs.unlink(req.file.path, () => {});
    return res.status(400).json({ error: 'Uploaded file is not a valid image' });
  }
  
  const db = getDb();
  const photoUrl = `/uploads/profiles/${req.file.filename}`;
  
  db.run('UPDATE users SET photo_url = ?, updated_at = strftime("%s", "now") WHERE id = ?', [photoUrl, req.user.id], function(err) {
    if (err) {
      fs.unlink(req.file.path, () => {});
      return res.status(500).json({ error: 'Upload failed' });
    }
    res.json({ photo_url: photoUrl });
  });
});

router.get('/donation-history', (req, res) => {
  const db = getDb();
  db.all('SELECT * FROM donations WHERE donor_id = ? ORDER BY created_at DESC', [req.user.id], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Failed to fetch history' });
    res.json(rows);
  });
});

router.get('/stats', (req, res) => {
  const db = getDb();
  const verifiedCount = new Promise((resolve) => {
    db.get('SELECT COUNT(*) as count FROM donations WHERE donor_id = ? AND status = ?', [req.user.id, 'verified'], (err, row) => {
      resolve(row?.count || 0);
    });
  });
  
  const points = new Promise((resolve) => {
    db.get('SELECT SUM(points) as total FROM reward_ledger WHERE user_id = ?', [req.user.id], (err, row) => {
      resolve(row?.total || 0);
    });
  });
  
  Promise.all([verifiedCount, points]).then(([count, pts]) => {
    res.json({ verified_donations: count, points: pts || 0 });
  });
});

module.exports = router;
