const express = require('express');
const { getDb } = require('../database');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

router.get('/my-impact', (req, res) => {
  const db = getDb();
  const donorId = req.user.id;
  
  db.all(`
    SELECT 
      d.id,
      d.donation_date,
      d.hospital,
      d.blood_group,
      d.status,
      d.reviewed_at,
      d.created_at,
      br.patient_name,
      br.blood_group as request_blood_group,
      br.hospital as request_hospital,
      br.district,
      br.upazila,
      'verified' as impact_status
    FROM donations d
    LEFT JOIN blood_requests br ON d.request_id = br.id
    WHERE d.donor_id = ?
    AND d.status = 'verified'
    ORDER BY d.created_at DESC
  `, [donorId], (err, donations) => {
    if (err) return res.status(500).json({ error: 'Failed to fetch impact data' });
    
    // Counts are based on verified donations only. The previous `* 3` multiplier
    // presented a fabricated "lives saved" number; we now report the real count.
    const totalDonations = (donations || []).length;
    const totalLives = totalDonations;
    const recentDonations = (donations || []).slice(0, 5);
    
    res.json({
      totalDonations,
      totalLives,
      recentDonations,
      impactMessage: totalDonations > 0 
        ? `Your ${totalDonations} verified donation(s) helped patients in need.`
        : 'Start donating to track your impact!'
    });
  });
});

router.get('/:donationId/timeline', (req, res) => {
  const db = getDb();
  const donationId = req.params.donationId;
  
  db.get(`
    SELECT d.*, br.patient_name, br.blood_group as request_blood_group, br.hospital as request_hospital
    FROM donations d
    LEFT JOIN blood_requests br ON d.request_id = br.id
    WHERE d.id = ? AND d.donor_id = ?
  `, [donationId, req.user.id], (err, donation) => {
    if (err) return res.status(500).json({ error: 'Failed' });
    if (!donation) return res.status(404).json({ error: 'Donation not found' });
    
    const timeline = [
      {
        status: 'submitted',
        title: 'Donation Submitted',
        description: 'Your donation proof has been submitted for verification',
        timestamp: donation.created_at,
        completed: true
      },
      {
        status: 'verified',
        title: 'Verification Complete',
        description: donation.status === 'verified' 
          ? 'Your donation has been verified and counted!' 
          : 'Pending verification',
        timestamp: donation.reviewed_at || donation.created_at,
        completed: donation.status === 'verified'
      },
      {
        status: 'impact',
        title: 'Impact Delivered',
        description: `Your blood donation helped save lives at ${donation.request_hospital || donation.hospital}`,
        timestamp: donation.reviewed_at || donation.created_at,
        completed: donation.status === 'verified'
      }
    ];
    
    res.json({ donation, timeline });
  });
});

module.exports = router;
