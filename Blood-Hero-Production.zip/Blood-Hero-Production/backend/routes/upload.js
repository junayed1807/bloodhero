const express = require('express');
const fs = require('fs');
const { getDb } = require('../database');
const { authenticateToken } = require('../middleware/auth');
const { uploadProfile, uploadProof, assertImageFile } = require('../middleware/upload');

const router = express.Router();

router.post('/profile-picture', authenticateToken, uploadProfile, (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

  if (!assertImageFile(req.file.path)) {
    fs.unlink(req.file.path, () => {});
    return res.status(400).json({ error: 'Uploaded file is not a valid image' });
  }
  
  const db = getDb();
  const photoUrl = `/uploads/profiles/${req.file.filename}`;
  
  db.run('UPDATE users SET photo_url = ?, updated_at = strftime("%s", "now") WHERE id = ?', [photoUrl, req.user.id], function(err) {
    if (err) {
      fs.unlink(req.file.path, () => {});
      return res.status(500).json({ error: 'Upload failed' });
    }
    res.json({ photo_url: photoUrl });
  });
});

router.post('/donation-proof', authenticateToken, uploadProof, (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No proof image uploaded' });

  if (!assertImageFile(req.file.path)) {
    fs.unlink(req.file.path, () => {});
    return res.status(400).json({ error: 'Uploaded file is not a valid image' });
  }
  
  const db = getDb();
  const proofUrl = `/uploads/proofs/${req.file.filename}`;
  
  res.json({ proof_url: proofUrl });
});

module.exports = router;
