// Clean SMS provider abstraction.
// Select the active provider via SMS_PROVIDER env var. When no real SMS
// provider is configured the provider falls back to "log" mode, which prints
// the code to the server console and returns it as `devOtp` so the demo/tests
// can complete the flow. NEVER return the code in production mode.

const https = require('https');

const provider = (process.env.SMS_PROVIDER || 'log').toLowerCase();
const isProduction = process.env.NODE_ENV === 'production';

function isDemoMode() {
  // Demo modes are disabled entirely in production — OTP codes must be
  // delivered out-of-band (real SMS/email provider), never echoed to the client.
  if (isProduction) return false;
  return provider === 'log' || provider === 'console';
}

// Twilio REST client implemented on the built-in https module (no extra
// dependency). Enabled only when SMS_PROVIDER=twilio AND the credentials are
// present. Accepts both the documented TWILIO_ACCOUNT_SID / TWILIO_PHONE_NUMBER
// names and the legacy TWILIO_SID / TWILIO_FROM aliases.
function getTwilioConfig() {
  const accountSid = process.env.TWILIO_ACCOUNT_SID || process.env.TWILIO_SID || '';
  const authToken = process.env.TWILIO_AUTH_TOKEN || '';
  const from = process.env.TWILIO_PHONE_NUMBER || process.env.TWILIO_FROM || '';
  return { accountSid, authToken, from };
}

function twilioSend(phone, body) {
  const { accountSid, authToken, from } = getTwilioConfig();
  if (!accountSid || !authToken || !from) {
    throw new Error('Twilio SMS provider is not configured (set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN and TWILIO_PHONE_NUMBER).');
  }

  return new Promise((resolve, reject) => {
    const postData = new URLSearchParams({ From: from, To: phone, Body: body }).toString();
    const options = {
      hostname: 'api.twilio.com',
      port: 443,
      path: `/2010-04-01/Accounts/${encodeURIComponent(accountSid)}/Messages.json`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(postData),
        'Authorization': 'Basic ' + Buffer.from(`${accountSid}:${authToken}`).toString('base64'),
      },
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
          resolve({ success: true });
        } else {
          reject(new Error(`Twilio error ${res.statusCode}: ${data.slice(0, 300)}`));
        }
      });
    });
    req.on('error', reject);
    req.setTimeout(15000, () => req.destroy(new Error('Twilio request timed out')));
    req.write(postData);
    req.end();
  });
}

async function sendOtpSms(phone, code) {
  if (provider === 'twilio') {
    // Real provider: fail closed if credentials are missing.
    const twilioResult = await twilioSend(phone, `Your Blood Hero verification code is ${code}. It expires in 5 minutes.`);
    return twilioResult;
  }

  // Fail closed: in production an unconfigured SMS provider must never leak
  // the code to the client nor pretend the message was delivered.
  if (isProduction) {
    throw new Error('No real SMS provider configured for production (set SMS_PROVIDER and provider credentials).');
  }

  // Demo / log mode: print to console, return devOtp for demo & tests only.
  console.log(`[SMS-DEMO] OTP for ${phone}: ${code} (expires in 5 minutes)`);
  return { demo: true, devOtp: code };
}

module.exports = { sendOtpSms, isDemoMode };