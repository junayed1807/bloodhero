const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const path = require('path');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'blood_hero.db');
let db = null;

function getDb() {
  if (!db) {
    db = new sqlite3.Database(DB_PATH, (err) => {
      if (err) console.error('Database connection error:', err);
    });
  }
  return db;
}

function auditScopeForRole(role) {
  if (role === 'super_admin') return 'SYSTEM';
  if (role === 'admin') return 'ADMIN';
  if (role === 'sub_admin') return 'SUB_ADMIN';
  return 'NONE';
}

function initDatabase() {
  const database = getDb();
  
  return new Promise((resolve, reject) => {
    database.serialize(() => {
      database.run('PRAGMA journal_mode = WAL');
      database.run('PRAGMA foreign_keys = OFF');

      database.run(`CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        phone TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        email TEXT,
        blood_group TEXT,
        district TEXT,
        upazila TEXT,
        union_area TEXT,
        age INTEGER,
        weight REAL,
        gender TEXT,
        address TEXT,
        emergency_contact TEXT,
        photo_url TEXT,
        role TEXT DEFAULT 'donor',
        last_donation TEXT,
        total_donations INTEGER DEFAULT 0,
        points INTEGER DEFAULT 0,
        stars INTEGER DEFAULT 0,
        level TEXT DEFAULT 'New Donor',
        nid_status TEXT DEFAULT 'not_submitted',
        is_available INTEGER DEFAULT 1,
        is_verified INTEGER DEFAULT 0,
        password_hash TEXT,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        updated_at INTEGER DEFAULT (strftime('%s', 'now'))
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS blood_requests (
        id TEXT PRIMARY KEY,
        donor_id TEXT,
        patient_name TEXT,
        blood_group TEXT NOT NULL,
        component TEXT DEFAULT 'Whole Blood',
        units INTEGER DEFAULT 1,
        urgency TEXT DEFAULT 'normal',
        hospital TEXT,
        district TEXT,
        upazila TEXT,
        union_area TEXT,
        contact TEXT NOT NULL,
        note TEXT,
        status TEXT DEFAULT 'pending',
        needed_by TEXT,
        accepted_by TEXT,
        created_by TEXT,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        updated_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (created_by) REFERENCES users(id)
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS donations (
        id TEXT PRIMARY KEY,
        request_id TEXT NOT NULL,
        donor_id TEXT NOT NULL,
        recipient_id TEXT,
        blood_group TEXT NOT NULL,
        hospital TEXT NOT NULL,
        donation_date TEXT NOT NULL,
        location TEXT,
        proof_url TEXT,
        status TEXT DEFAULT 'pending_verification',
        rejection_reason TEXT,
        reviewed_by TEXT,
        reviewed_at INTEGER,
        admin_note TEXT,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (donor_id) REFERENCES users(id),
        FOREIGN KEY (request_id) REFERENCES blood_requests(id)
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS reward_ledger (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        donation_id TEXT NOT NULL,
        points INTEGER NOT NULL,
        type TEXT DEFAULT 'donation',
        reason TEXT,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (donation_id) REFERENCES donations(id),
        UNIQUE(donation_id, user_id)
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS badges (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        icon TEXT,
        requirement_type TEXT,
        requirement_value INTEGER,
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS user_badges (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        badge_id TEXT NOT NULL,
        earned_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (badge_id) REFERENCES badges(id),
        UNIQUE(user_id, badge_id)
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS notifications (
        id TEXT PRIMARY KEY,
        user_id TEXT,
        type TEXT DEFAULT 'system',
        title TEXT,
        body TEXT NOT NULL,
        data TEXT,
        read INTEGER DEFAULT 0,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (user_id) REFERENCES users(id)
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS audit_logs (
        id TEXT PRIMARY KEY,
        admin_id TEXT,
        action TEXT NOT NULL,
        target_type TEXT,
        target_id TEXT,
        description TEXT,
        metadata TEXT,
        ip_address TEXT,
        user_agent TEXT,
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS nid_verifications (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        nid_number TEXT NOT NULL,
        dob TEXT,
        legal_name TEXT,
        status TEXT DEFAULT 'pending',
        reviewed_by TEXT,
        reviewed_at INTEGER,
        rejection_reason TEXT,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (user_id) REFERENCES users(id)
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS request_matches (
        id TEXT PRIMARY KEY,
        request_id TEXT NOT NULL,
        donor_id TEXT NOT NULL,
        score INTEGER DEFAULT 0,
        status TEXT DEFAULT 'notified',
        notified_at INTEGER,
        viewed_at INTEGER,
        responded_at INTEGER,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (request_id) REFERENCES blood_requests(id),
        FOREIGN KEY (donor_id) REFERENCES users(id),
        UNIQUE(request_id, donor_id)
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS health_declarations (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        score INTEGER,
        eligible INTEGER,
        reason TEXT,
        retry_date TEXT,
        valid_until INTEGER,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (user_id) REFERENCES users(id)
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS referral_codes (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        code TEXT UNIQUE NOT NULL,
        used_count INTEGER DEFAULT 0,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (user_id) REFERENCES users(id)
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS conversion_events (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        event_type TEXT NOT NULL,
        request_id TEXT,
        metadata TEXT,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (user_id) REFERENCES users(id)
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS donation_programs (
        id TEXT PRIMARY KEY,
        recipient_id TEXT NOT NULL,
        name TEXT,
        blood_group TEXT,
        interval_days INTEGER DEFAULT 14,
        preferred_centre TEXT,
        preferred_donor_pool TEXT,
        next_request_date TEXT,
        active INTEGER DEFAULT 1,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (recipient_id) REFERENCES users(id)
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS family_members (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        name TEXT NOT NULL,
        blood_group TEXT,
        relation TEXT,
        phone TEXT,
        notes TEXT,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (user_id) REFERENCES users(id)
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS centers (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT DEFAULT 'hospital',
        district TEXT,
        upazila TEXT,
        address TEXT,
        phone TEXT,
        email TEXT,
        website TEXT,
        latitude REAL,
        longitude REAL,
        verified INTEGER DEFAULT 0,
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS ambulances (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        provider TEXT,
        phone TEXT NOT NULL,
        district TEXT,
        upazila TEXT,
        service_area TEXT,
        availability_status TEXT DEFAULT 'available',
        is_verified INTEGER DEFAULT 0,
        last_verified_at INTEGER,
        notes TEXT,
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS articles (
        id TEXT PRIMARY KEY,
        title_bn TEXT NOT NULL,
        title_en TEXT NOT NULL,
        body_bn TEXT NOT NULL,
        body_en TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        published INTEGER DEFAULT 1,
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS areas (
        id TEXT PRIMARY KEY,
        division TEXT,
        district TEXT NOT NULL,
        upazila TEXT,
        union_area TEXT,
        name_bn TEXT,
        name_en TEXT
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT,
        updated_at INTEGER DEFAULT (strftime('%s', 'now'))
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS super_admins (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (user_id) REFERENCES users(id)
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS admin_roles (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        display_name TEXT NOT NULL,
        description TEXT,
        level INTEGER NOT NULL,
        can_manage_admins INTEGER DEFAULT 0,
        can_manage_sub_admins INTEGER DEFAULT 0,
        can_view_super_admin_audit INTEGER DEFAULT 0,
        can_assign_permissions INTEGER DEFAULT 0,
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS permissions (
        id TEXT PRIMARY KEY,
        code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        module TEXT NOT NULL,
        description TEXT,
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS role_permissions (
        id TEXT PRIMARY KEY,
        role_id TEXT NOT NULL,
        permission_id TEXT NOT NULL,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (role_id) REFERENCES admin_roles(id),
        FOREIGN KEY (permission_id) REFERENCES permissions(id),
        UNIQUE(role_id, permission_id)
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS admin_accounts (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        role_id TEXT NOT NULL,
        status TEXT DEFAULT 'pending_verification',
        invited_by TEXT,
        verified_at INTEGER,
        suspended_at INTEGER,
        disabled_at INTEGER,
        revoked_at INTEGER,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (role_id) REFERENCES admin_roles(id),
        FOREIGN KEY (invited_by) REFERENCES users(id)
      )`);

      database.run(`CREATE TABLE IF NOT EXISTS admin_invitations (
        id TEXT PRIMARY KEY,
        phone TEXT NOT NULL,
        role_id TEXT NOT NULL,
        invited_by TEXT NOT NULL,
        verification_code TEXT NOT NULL,
        code_expires_at INTEGER NOT NULL,
        attempts INTEGER DEFAULT 0,
        max_attempts INTEGER DEFAULT 5,
        status TEXT DEFAULT 'pending',
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (role_id) REFERENCES admin_roles(id),
        FOREIGN KEY (invited_by) REFERENCES users(id)
      )`);

      // ---- ADMIN HIERARCHY: Enhanced tables ----

      // Enhanced audit_logs with actor_role and audit_scope for visibility isolation
      database.run(`CREATE TABLE IF NOT EXISTS audit_logs_enhanced (
        id TEXT PRIMARY KEY,
        admin_id TEXT NOT NULL,
        actor_role TEXT NOT NULL,
        audit_scope TEXT NOT NULL,
        action TEXT NOT NULL,
        target_type TEXT,
        target_id TEXT,
        description TEXT,
        metadata TEXT,
        ip_address TEXT,
        user_agent TEXT,
        session_id TEXT,
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
      )`);

      // Add actor_role and audit_scope columns to legacy audit_logs if missing (migration)
      database.run(`ALTER TABLE audit_logs ADD COLUMN actor_role TEXT DEFAULT 'admin'`, function (err) {
        if (err && !err.message.includes('duplicate column name')) {
          console.error('Migration actor_role failed:', err.message);
        }
      });
      database.run(`ALTER TABLE audit_logs ADD COLUMN audit_scope TEXT DEFAULT 'ADMIN'`, function (err) {
        if (err && !err.message.includes('duplicate column name')) {
          console.error('Migration audit_scope failed:', err.message);
        }
      });
      database.run(`ALTER TABLE audit_logs ADD COLUMN session_id TEXT`, function (err) {
        if (err && !err.message.includes('duplicate column name')) {
          console.error('Migration session_id failed:', err.message);
        }
      });

      // Login history tracking
      database.run(`CREATE TABLE IF NOT EXISTS login_history (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        phone TEXT NOT NULL,
        ip_address TEXT,
        user_agent TEXT,
        login_method TEXT NOT NULL,
        role TEXT NOT NULL,
        admin_role TEXT,
        success INTEGER DEFAULT 1,
        failure_reason TEXT,
        session_id TEXT,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (user_id) REFERENCES users(id)
      )`);

      // Security events (unauthorized access attempts, privilege escalation, etc.)
      database.run(`CREATE TABLE IF NOT EXISTS security_events (
        id TEXT PRIMARY KEY,
        actor_id TEXT,
        actor_role TEXT,
        event_type TEXT NOT NULL,
        target_type TEXT,
        target_id TEXT,
        description TEXT,
        ip_address TEXT,
        user_agent TEXT,
        severity TEXT DEFAULT 'medium',
        resolved INTEGER DEFAULT 0,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (actor_id) REFERENCES users(id)
      )`);

      // Two-step OTP verification for sub-admin registration
      database.run(`CREATE TABLE IF NOT EXISTS admin_otp (
        id TEXT PRIMARY KEY,
        phone TEXT NOT NULL,
        admin_account_id TEXT,
        invited_by TEXT NOT NULL,
        role_id TEXT NOT NULL,
        step INTEGER NOT NULL,
        otp_code TEXT NOT NULL,
        otp_expires_at INTEGER NOT NULL,
        attempts INTEGER DEFAULT 0,
        max_attempts INTEGER DEFAULT 3,
        consumed INTEGER DEFAULT 0,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (admin_account_id) REFERENCES admin_accounts(id),
        FOREIGN KEY (invited_by) REFERENCES users(id),
        FOREIGN KEY (role_id) REFERENCES admin_roles(id)
      )`);

      // Phone-OTP login bridge for the public (user) app.
      // Used so donor/recipient flows can authenticate against the backend.
      // otp_code stores a hashed value (never plaintext).
      database.run(`CREATE TABLE IF NOT EXISTS user_otp (
        id TEXT PRIMARY KEY,
        phone TEXT NOT NULL,
        otp_hash TEXT NOT NULL,
        otp_expires_at INTEGER NOT NULL,
        attempts INTEGER DEFAULT 0,
        max_attempts INTEGER DEFAULT 3,
        consumed INTEGER DEFAULT 0,
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
      )`);

      // ---- PUBLIC WEBSITE CONTENT MODULES ----
      // Blood donation camps (public + admin-managed)
      database.run(`CREATE TABLE IF NOT EXISTS blood_camps (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT,
        venue TEXT,
        district TEXT,
        upazila TEXT,
        date TEXT,
        start_time TEXT,
        end_time TEXT,
        target_units INTEGER DEFAULT 0,
        collected_units INTEGER DEFAULT 0,
        status TEXT DEFAULT 'upcoming',
        organizer TEXT,
        banner_url TEXT,
        registration_open INTEGER DEFAULT 1,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        updated_at INTEGER DEFAULT (strftime('%s', 'now'))
      )`);

      // Donation/awareness campaigns
      database.run(`CREATE TABLE IF NOT EXISTS campaigns (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT,
        banner_url TEXT,
        category TEXT DEFAULT 'blood_donation',
        start_date TEXT,
        end_date TEXT,
        goal INTEGER DEFAULT 0,
        achieved INTEGER DEFAULT 0,
        organizer TEXT,
        status TEXT DEFAULT 'upcoming',
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        updated_at INTEGER DEFAULT (strftime('%s', 'now'))
      )`);

      // Gallery albums + images (public + admin-managed)
      database.run(`CREATE TABLE IF NOT EXISTS gallery_albums (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT,
        category TEXT DEFAULT 'blood_camps',
        cover_url TEXT,
        event_date TEXT,
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
      )`);
      database.run(`CREATE TABLE IF NOT EXISTS gallery_images (
        id TEXT PRIMARY KEY,
        album_id TEXT NOT NULL,
        url TEXT NOT NULL,
        caption TEXT,
        sort_order INTEGER DEFAULT 0,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (album_id) REFERENCES gallery_albums(id)
      )`);

      // Partners (hospitals, NGOs, universities, blood banks, companies)
      database.run(`CREATE TABLE IF NOT EXISTS partners (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT DEFAULT 'organization',
        logo_url TEXT,
        website TEXT,
        description TEXT,
        active INTEGER DEFAULT 1,
        sort_order INTEGER DEFAULT 0,
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
      )`);

      // Downloads / resources
      database.run(`CREATE TABLE IF NOT EXISTS downloads (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT,
        file_url TEXT,
        category TEXT DEFAULT 'guide',
        file_size TEXT,
        active INTEGER DEFAULT 1,
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
      )`);

      // Success stories
      database.run(`CREATE TABLE IF NOT EXISTS success_stories (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        content TEXT,
        image_url TEXT,
        category TEXT DEFAULT 'donation',
        author_name TEXT,
        status TEXT DEFAULT 'published',
        featured INTEGER DEFAULT 0,
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
      )`);

      // Volunteer registrations (public signup, admin-approved)
      database.run(`CREATE TABLE IF NOT EXISTS volunteer_registrations (
        id TEXT PRIMARY KEY,
        user_id TEXT,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        email TEXT,
        district TEXT,
        upazila TEXT,
        skills TEXT,
        availability TEXT,
        message TEXT,
        status TEXT DEFAULT 'pending',
        reviewed_by TEXT,
        reviewed_at INTEGER,
        created_at INTEGER DEFAULT (strftime('%s', 'now')),
        FOREIGN KEY (user_id) REFERENCES users(id)
      )`);

      // Contact form messages
      database.run(`CREATE TABLE IF NOT EXISTS contact_messages (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT,
        phone TEXT,
        subject TEXT,
        message TEXT NOT NULL,
        status TEXT DEFAULT 'new',
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
      )`);

      // FAQ entries (bilingual, ordered)
      database.run(`CREATE TABLE IF NOT EXISTS faq (
        id TEXT PRIMARY KEY,
        question_bn TEXT,
        question_en TEXT NOT NULL,
        answer_bn TEXT,
        answer_en TEXT NOT NULL,
        category TEXT DEFAULT 'general',
        active INTEGER DEFAULT 1,
        sort_order INTEGER DEFAULT 0,
        created_at INTEGER DEFAULT (strftime('%s', 'now'))
      )`);

      // ---- Article content columns (migration, idempotent) ----
      const articleCols = [
        ['excerpt_bn', 'TEXT'],
        ['excerpt_en', 'TEXT'],
        ['category', "TEXT DEFAULT 'news'"],
        ['image_url', 'TEXT'],
        ['published_at', 'INTEGER'],
        ['author_name', 'TEXT'],
        ['status', "TEXT DEFAULT 'published'"],
      ];
      articleCols.forEach(([col, def]) => {
        database.run(`ALTER TABLE articles ADD COLUMN ${col} ${def}`, function (err) {
          if (err && !err.message.includes('duplicate column name')) {
            console.error(`Migration articles.${col} failed:`, err.message);
          }
        });
      });

      // ---- RBAC: Seed admin roles ----
      const roleStmt = database.prepare(`INSERT OR IGNORE INTO admin_roles (id, name, display_name, description, level, can_manage_admins, can_manage_sub_admins, can_view_super_admin_audit, can_assign_permissions) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);

      const adminRoles = [
        ['role_super_admin', 'super_admin', 'Super Admin', 'Highest administrative authority with full system access', 3, 1, 1, 1, 1],
        ['role_admin', 'admin', 'Admin', 'Full administrative access to assigned modules', 2, 0, 1, 0, 0],
        ['role_sub_admin', 'sub_admin', 'Sub-admin', 'Limited permissions with explicitly assigned module access', 1, 0, 0, 0, 0],
      ];
      adminRoles.forEach(r => roleStmt.run(r));

      // ---- RBAC: Seed granular permissions ----
      const permStmt = database.prepare(`INSERT OR IGNORE INTO permissions (id, code, name, module) VALUES (?, ?, ?, ?)`);

      const permissions = [
        // User management
        ['perm_users_view', 'users.view', 'View Users', 'users'],
        ['perm_users_edit', 'users.edit', 'Edit Users', 'users'],
        ['perm_users_suspend', 'users.suspend', 'Suspend/Activate Users', 'users'],
        // Blood request management
        ['perm_requests_view', 'requests.view', 'View Requests', 'requests'],
        ['perm_requests_approve', 'requests.approve', 'Approve Requests', 'requests'],
        ['perm_requests_manage', 'requests.manage', 'Manage Requests', 'requests'],
        // Donor management
        ['perm_donors_view', 'donors.view', 'View Donors', 'donors'],
        ['perm_donors_verify', 'donors.verify', 'Verify Donors', 'donors'],
        // Verification
        ['perm_verification_nid', 'verification.nid', 'NID Verification', 'verification'],
        ['perm_verification_donation', 'verification.donation', 'Donation Verification', 'verification'],
        // Hospital/ambulance management
        ['perm_hospitals_manage', 'hospitals.manage', 'Manage Hospitals', 'hospitals'],
        ['perm_ambulances_manage', 'ambulances.manage', 'Manage Ambulances', 'ambulances'],
        // Camp management
        ['perm_camps_manage', 'camps.manage', 'Manage Camps', 'camps'],
        // User support
        ['perm_support_view', 'support.view', 'User Support', 'support'],
        // Reports
        ['perm_reports_view', 'reports.view', 'View Reports', 'reports'],
        // Admin hierarchy management
        ['perm_admins_manage', 'admins.manage', 'Manage Admins', 'admins'],
        ['perm_sub_admins_manage', 'sub_admins.manage', 'Manage Sub-admins', 'admins'],
        ['perm_roles_manage', 'roles.manage', 'Manage Roles', 'admins'],
        ['perm_permissions_manage', 'permissions.manage', 'Manage Permissions', 'admins'],
        // Audit & security
        ['perm_audit_view', 'audit.view', 'View Audit Logs', 'audit'],
        ['perm_security_view', 'security.view', 'View Security Events', 'audit'],
        ['perm_login_history_view', 'login_history.view', 'View Login History', 'audit'],
        // Settings
        ['perm_settings_manage', 'settings.manage', 'Manage Settings', 'settings'],
        // Public profile role badge
        ['perm_profile_view', 'profile.view', 'View Public Profiles', 'users'],
        // Website content management (camps, campaigns, news, gallery, partners, downloads, stories, faq)
        ['perm_content_manage', 'content.manage', 'Manage Website Content', 'content'],
        // Volunteer management
        ['perm_volunteers_manage', 'volunteers.manage', 'Manage Volunteers', 'volunteers'],
        // Contact form messages
        ['perm_contact_view', 'contact.view', 'View Contact Messages', 'support'],
      ];
      permissions.forEach(p => permStmt.run(p));

      // ---- RBAC: Seed role-permission mappings ----
      const rpStmt = database.prepare(`INSERT OR IGNORE INTO role_permissions (id, role_id, permission_id) VALUES (?, ?, ?)`);

      // Super Admin: ALL permissions
      const permIds = permissions.map(p => p[0]);
      permIds.forEach(pid => {
        rpStmt.run(uuidv4(), 'role_super_admin', pid);
      });

      // Admin: all permissions except admin hierarchy management & super admin audit
      const adminPerms = permIds.filter(pid => {
        return !['perm_admins_manage', 'perm_roles_manage', 'perm_permissions_manage'].includes(pid);
      });
      // Admins CAN manage sub-admins but NOT super admins, roles, or permissions
      adminPerms.push('perm_sub_admins_manage');
      adminPerms.forEach(pid => {
        rpStmt.run(uuidv4(), 'role_admin', pid);
      });

      // Sub-admin: NO permissions by default — must be explicitly assigned
      // (no default permissions seeded — sub-admins get nothing until explicitly granted)

      const badges = [
        ['badge_1', 'First Drop', 'Completed first blood donation', '💧', 'verified_donations', 1],
        ['badge_5', 'Iron Heart', 'Completed 5 blood donations', '❤️', 'verified_donations', 5],
        ['badge_10', 'Life Saver', 'Completed 10 blood donations', '🩺', 'verified_donations', 10],
        ['badge_25', 'Regular Hero', 'Completed 25 blood donations', '🦸', 'verified_donations', 25],
        ['badge_50', 'Century Champion', 'Completed 50 blood donations', '🏆', 'verified_donations', 50],
        ['badge_100', 'Legend', 'Completed 100 blood donations', '👑', 'verified_donations', 100],
      ];

      const insertBadge = database.prepare(`INSERT OR IGNORE INTO badges (id, name, description, icon, requirement_type, requirement_value) VALUES (?, ?, ?, ?, ?, ?)`);
      badges.forEach(b => insertBadge.run(b));

      const seedAdmin = (phone, name, password, roleName, roleId) => {
        const userId = uuidv4();
        const passwordHash = bcrypt.hashSync(password, 12);
        const now = Math.floor(Date.now() / 1000);
        database.run(
          `INSERT OR IGNORE INTO users (id, phone, name, role, is_verified, points, stars, level, password_hash, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [userId, phone, name, roleName, 1, 9999, 99, roleName === 'super_admin' ? 'Super Admin' : 'Admin', passwordHash, now, now]
        );
        if (roleId) {
          const accountId = uuidv4();
          database.run(
            `INSERT OR IGNORE INTO admin_accounts (id, user_id, role_id, status, verified_at, created_at) VALUES (?, ?, ?, ?, ?, ?)`,
            [accountId, userId, roleId, 'active', now, now]
          );
          if (roleId === 'role_super_admin') {
            database.run(
              `INSERT OR IGNORE INTO super_admins (id, user_id, created_at) VALUES (?, ?, ?)`,
              [uuidv4(), userId, now]
            );
          }
        }
      };

      // ---- Seed initial admin accounts ----
      // Demo admins (admin123) are DEV-ONLY. They are NEVER seeded in production;
      // instead a super admin can be provisioned from ADMIN_INIT_* env vars.
      const isProduction = process.env.NODE_ENV === 'production';
      if (!isProduction) {
        seedAdmin('01835038064', 'Super Admin', 'admin123', 'super_admin', 'role_super_admin');
        seedAdmin('+8801712345678', 'Junayed Islam', 'admin123', 'super_admin', 'role_super_admin');
        seedAdmin('+8801812345678', 'Admin Two', 'admin123', 'admin', 'role_admin');
      }

      // Production bootstrap: create the initial super admin from environment.
      const initPhone = process.env.ADMIN_INIT_PHONE;
      const initPassword = process.env.ADMIN_INIT_PASSWORD;
      if (initPhone && initPassword) {
        seedAdmin(initPhone, process.env.ADMIN_INIT_NAME || 'Super Admin', initPassword, 'super_admin', 'role_super_admin');
      }

      // ---- H7: token revocation support ----
      // users.token_version lets the server invalidate every previously issued
      // JWT (password change/reset bumps it). Added idempotently.
      database.run(`ALTER TABLE users ADD COLUMN token_version INTEGER DEFAULT 0`, function (err) {
        if (err && !err.message.includes('duplicate column name')) {
          console.error('Migration token_version failed:', err.message);
        }
      });

      // ---- C3 data repair (idempotent, safe) ----
      // Older builds wrote the raw action name ('suspend'/'activate'/'disable'/
      // 'revoke'/'restore') into admin_accounts.status instead of the resolved
      // status value. Normalize any such rows so authorization checks
      // (status === 'active') behave correctly.
      const statusRepair = {
        suspend: 'suspended',
        activate: 'active',
        disable: 'disabled',
        revoke: 'revoked',
        restore: 'active',
      };
      Object.keys(statusRepair).forEach(actionName => {
        database.run(
          `UPDATE admin_accounts SET status = ? WHERE status = ?`,
          [statusRepair[actionName], actionName],
          function (err) {
            if (err) console.error('Admin status repair failed:', err.message);
          }
        );
      });

      resolve(database);
    });
  });
}

module.exports = {
  getDb,
  initDatabase,
  auditScopeForRole,
};
