# Deploy configuration

## Vercel — static frontend

`deploy/vercel.json` (copied to the repo root when you deploy, or kept in root):

- Static site (no build step; `cleanUrls` on).
- Hash-based routing (`#/`) → no SPA rewrite needed.
- `/api/:path*` is **rewritten** to `https://api.YOUR-DOMAIN/api/:path*`
  (replace `YOUR-DOMAIN` with the real backend domain). Alternatively, leave
  `API_BASE` unset and the app talks `/api` same-origin through this proxy.
- `sw.js` served with `no-cache` + `Service-Worker-Allowed: /`.
- Security headers applied at the edge.

Deploy: connect the repo to Vercel, set **Root Directory** = repo root, output
default. Or drag-and-drop the folder into `vercel deploy`.

## Render — backend

`deploy/render.yaml` is a Blueprint:

- Runtime `node`, `npm install` → `npm start`.
- `healthCheckPath: /health` (returns `{"status":"ok","service":"blood-hero-api"}`).
- `TRUST_PROXY=true`, `HOST=0.0.0.0`, `NODE_ENV=production`.
- A persistent disk is mounted at `/var/data` and `DB_PATH` points there
  (SQLite survives deploys/restarts).
- **Secrets must be added in the Render dashboard** (Environment), never in the
  blueprint:
  - `JWT_SECRET` (≥32 random chars)
  - `ADMIN_INIT_PHONE` / `ADMIN_INIT_PASSWORD` (first super-admin, set once)
  - `TWILIO_SID` / `TWILIO_AUTH_TOKEN` / `TWILIO_FROM` (to enable real OTP)
  - `DATABASE_URL` (after PostgreSQL migration)

After first boot, the initial super-admin is created from `ADMIN_INIT_*`.
Subsequent boots are idempotent (`INSERT OR IGNORE`).

## Firestore / Firebase

`deploy/firebase-setup.md` (from the reference project) documents the client-side
Firestore rules. **Before public launch, tighten those rules** — see
`docs/SECURITY-AUDIT.md` items C4 (deny `role` self-update, restrict `donors`
reads) — and prefer server-side RBAC for anything sensitive.