# Blood Hero — Production Checklist (Firebase + Security)

Everything below is **copy-paste-ready**. Do these 5 steps in Firebase Console and the app moves from demo to fully live & secure.

---

## 1. Enable Phone Authentication
1. Firebase Console → your project **blood-hero-2efa3** → **Build → Authentication → Sign-in method**
2. Enable **Phone** provider.
3. Under **Authentication → Settings → Authorized domains**, add your host:
   - `localhost` (for local dev) ✅ allowed by default
   - your domain, e.g. `bloodhero.app` / `yoursite.github.io`

> Until a real domain is added, OTP only works on localhost. On any other origin the app shows a clear Bangla error instead of failing silently.

---

## 2. Paste these Firestore Security Rules
**Build → Firestore Database → Rules** → replace with:

```js
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // ---- helper ----
    function signedIn() { return request.auth != null; }
    function isAdmin() {
      return signedIn() &&
        exists(/databases/$(database)/documents/admins/$(request.auth.token.phone_number));
    }

    // A phone number becomes ADMIN by creating a doc:
    //   admins/{+8801XXXXXXXXX}   { note: "created by hand in console" }
    match /admins/{phone} {
      allow read: if signedIn();          // needed for the role check
      allow write: if false;              // only editable in console (never by clients)
    }

    // ---- donors ----
    match /donors/{id} {
      allow read: if true;                                   // public directory (shareable)
      allow create: if signedIn()
        && request.resource.data.phone == request.auth.token.phone_number  // you only create YOURSELF
        && request.resource.data.role != 'admin';                          // can't self-promote
      allow update: if signedIn() &&
        (resource.data.phone == request.auth.token.phone_number            // yourself
         || isAdmin());                                                    // or an admin
      allow delete: if isAdmin();
    }

    // ---- blood requests ----
    match /requests/{id} {
      allow read: if true;                                   // anyone can see requests
      allow create: if true;                                 // recipients often aren't registered
      allow update, delete: if isAdmin();                    // only admins change status/remove
    }

    // ---- lookups that are safe to expose ----
    match /centers/{id}      { allow read: if true; allow write: if isAdmin(); }
    match /notifications/{id}{ allow read: if signedIn(); allow write: if isAdmin(); }

    // ---- audit log: write-only by clients, read-only by admins ----
    match /audit/{id} {
      allow create: if signedIn();
      allow read:   if isAdmin();
      allow update, delete: if false;                        // immutable
    }
  }
}
```

**Make your phone an admin (one-time):**
1. **Firestore → Start collection** → name it `admins`
2. Document ID = your full phone, e.g. `+8801712345678`
3. Field: `role` (string) = `admin`, `note` = `creator`

The app client already checks this: after OTP it looks up your phone in `admins/` → if found, `role` becomes `admin` and the Admin Panel unlocks. No secrets in the code.

---

## 3. Turn on App Check (stops bots/abuse of OTP & DB)
**Build → App Check** → register your web app → choose **reCAPTCHA v3**. Then copy its site-key into the app's auth module. (Free, one line, blocks scripted abuse of SMS.)

---

## 4. Test login
1. Serve the app (`python -m http.server 8080`)
2. Enter your phone → real SMS OTP should arrive.
3. Whichever number you put in `admins/` will see the **Admin** panel; every other phone stays a normal donor.

---

## 5. Offline / demo mode stays as a safety net
If Firestore is unreachable the app automatically falls back to the built-in demo data (no login needed) — that's expected and intentional, so a demo always works even offline. For real users, ensure connectivity.
