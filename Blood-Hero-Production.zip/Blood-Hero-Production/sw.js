/* Blood Hero — Service Worker (PWA offline shell) */
const CACHE = 'blood-hero-v4';
const SHELL = [
  './',
  './index.html',
  './css/main.css',
  './css/premium.css',
  './js/app.js',
  './js/config.js',
  './js/db.js',
  './js/i18n.js',
  './js/ui.js',
  './js/auth.js',
  './js/rbac.js',
  './js/lib/eligibility.js',
  './js/lib/validate.js',
  './js/lib/rateLimit.js',
  './js/components/Logo.js',
  './js/pages/home.js',
  './js/pages/donors.js',
  './js/pages/requests.js',
  './js/pages/profile.js',
  './js/pages/misc.js',
  './js/pages/support.js',
  './js/pages/tracking.js',
  './js/pages/screening.js',
  './js/pages/leaderboard.js',
  './js/pages/centers.js',
  './js/pages/social.js',
  './js/pages/verify.js',
  './js/pages/directory.js',
  './js/pages/need.js',
  './js/pages/donorDetail.js',
  './js/pages/heatmap.js',
  './js/pages/awareness.js',
  './js/pages/ambulances.js',
  './js/pages/impact.js',
  './js/pages/recipient.js',
  './js/admin/admin.js',
  './js/data/rangpur.js',
  './shared/js/api-config.js',
  './shared/js/api.js',
  './shared/js/backend-api.js',
  './shared/js/storage.js',
  './manifest.webmanifest',
  './assets/images/logo.svg',
  './assets/images/logo-192.png',
  './assets/images/logo-512.png',
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

// Never let the service worker intercept or cache API / upload responses.
// Caching them can leak another user's data and serve stale private info.
const url = u => (u instanceof URL ? u : new URL(u, self.location.href));
const isPrivileged = u => u.pathname.startsWith('/api/') || u.pathname.startsWith('/uploads/') || u.pathname.startsWith('/admin-panel/');

self.addEventListener('fetch', e => {
  const req = e.request;
  const u = url(req.url);
  if (req.method !== 'GET' || isPrivileged(u)) return;
  e.respondWith(
    caches.match(req).then(cached => {
      const fetchPromise = fetch(req).then(res => {
        if (res && res.status === 200) {
          const clone = res.clone();
          caches.open(CACHE).then(c => c.put(req, clone));
        }
        return res;
      }).catch(() => cached);
      return cached || fetchPromise;
    })
  );
});

self.addEventListener('message', e => {
  if (e.data && e.data.type === 'SKIP_WAITING') self.skipWaiting();
});
