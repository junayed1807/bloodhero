// Admin panel — shared backend API client.
// Uses the same token that index.html stores via shared/js/api.js (bh_token).
import { API_BASE } from '../../../shared/js/api-config.js';

export async function adminApi(path, options = {}) {
  const token = localStorage.getItem('bh_token');
  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers,
  };
  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw Object.assign(new Error(data.error || `HTTP ${res.status}`), { status: res.status, data });
  return data;
}

export const api = {
  get: (p) => adminApi(p),
  post: (p, b) => adminApi(p, { method: 'POST', body: JSON.stringify(b) }),
  patch: (p, b) => adminApi(p, { method: 'PATCH', body: JSON.stringify(b) }),
  delete: (p) => adminApi(p, { method: 'DELETE' }),
};

// Simple Bangla/English helper for inline labels.
export function bn(bangla, english) {
  return (localStorage.getItem('bh_lang') || 'bn') === 'bn' ? bangla : english;
}