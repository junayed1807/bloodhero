// Admin Dashboard — live stats + recent activity
import { t, lang } from '../../../js/i18n.js';
import { esc, icon, bloodBadge, timeAgo } from '../../../js/ui.js';
import { api, bn } from '../api-client.js';

export async function renderAdminDashboard(root) {
  let stats = {};
  let audit = [];
  let donations = [];
  let loaded = false;

  try {
    [stats, audit, donations] = await Promise.all([
      api.get('/admin/stats'),
      api.get('/admin/audit-logs'),
      api.get('/admin/donations').catch(() => []),
    ]);
    loaded = true;
  } catch {}

  root.innerHTML = `
    <div class="admin-hero">
      <div><h2>${esc(t('overview'))}</h2><p class="muted">${bn('লাইভ সিস্টেম স্ন্যাপশট', 'Live system snapshot')}</p></div>
      <span class="badge ${loaded ? 'green pulsing' : 'gray'}">● ${loaded ? bn('অনলাইন', 'Online') : bn('অফলাইন', 'Offline')}</span>
    </div>
    <div class="stat-grid admin">
      <div class="stat">${icon('users')}<strong>${stats.totalUsers || 0}</strong><span>${esc(t('totalUsers'))}</span></div>
      <div class="stat">${icon('users')}<strong>${stats.activeUsers || 0}</strong><span>${bn('সক্রিয় ব্যবহারকারী', 'Active Users')}</span></div>
      <div class="stat">${icon('list')}<strong>${stats.totalRequests || 0}</strong><span>${esc(t('requests'))}</span></div>
      <div class="stat">${icon('alert')}<strong>${stats.pendingRequests || 0}</strong><span>${bn('অপেক্ষমাণ অনুরোধ', 'Pending Requests')}</span></div>
      <div class="stat">${icon('drop')}<strong>${stats.totalDonations || 0}</strong><span>${esc(t('donationProofs'))}</span></div>
      <div class="stat">${icon('check')}<strong>${stats.verifiedDonations || 0}</strong><span>${bn('যাচাইকৃত দান', 'Verified Donations')}</span></div>
      <div class="stat">${icon('clock')}<strong>${stats.pendingVerifications || 0}</strong><span>${esc(t('statusPending'))}</span></div>
      <div class="stat">${icon('shield')}<strong>${(stats.totalAdmins || 0) + (stats.totalSubAdmins || 0)}</strong><span>${bn('অ্যাডমিন', 'Admins')}</span></div>
      <div class="stat">${icon('alert')}<strong>${stats.securityEvents24h || 0}</strong><span>${bn('সিকিউরিটি (২৪ঘ)', 'Security (24h)')}</span></div>
    </div>
    <div class="grid-2 area">
      <div class="panel">
        <div class="panel-head"><h3>${bn('সাম্প্রতিক অডিট', 'Recent Audit')}</h3></div>
        <div id="dashAudit">${renderAudit(audit)}</div>
      </div>
      <div class="panel">
        <div class="panel-head"><h3>${bn('সাম্প্রতিক দান', 'Recent Donations')}</h3></div>
        <div id="dashDonations">${renderDonations(donations)}</div>
      </div>
    </div>`;
}

function renderAudit(rows) {
  if (!rows || rows.length === 0) return `<div class="empty sm">${icon('info')} ${bn('কোনো লগ নেই।', 'No logs yet.')}</div>`;
  return `<div class="mini-list">${rows.slice(0, 6).map(r => `
    <div class="mini-row"><span><strong>${esc(r.action || '—')}</strong><br><small>${esc(r.description || '')}</small></span>
    <small>${r.created_at ? timeAgo(r.created_at * 1000, (localStorage.getItem('bh_lang') || 'bn') === 'bn') : ''}</small></div>`).join('')}</div>`;
}

function renderDonations(rows) {
  if (!rows || rows.length === 0) return `<div class="empty sm">${icon('info')} ${bn('কোনো দান নেই।', 'No donations yet.')}</div>`;
  return `<div class="mini-list">${rows.slice(0, 6).map(d => `
    <div class="mini-row"><span><strong>${esc(d.patient_name || d.recipient_name || bn('দান', 'Donation'))}</strong>
      ${bloodBadge(d.blood_group)}<br><small>${esc(d.status || '')}</small></span>
    <small>${d.created_at ? timeAgo(d.created_at * 1000, (localStorage.getItem('bh_lang') || 'bn') === 'bn') : ''}</small></div>`).join('')}</div>`;
}