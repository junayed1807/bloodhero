// Sub-admin Management (Admin + Super Admin)
import { t, lang } from '../../../js/i18n.js';
import { esc, icon, toast } from '../../../js/ui.js';
import { API_BASE } from '../../../shared/js/api-config.js';
const $ = s => document.querySelector(s);

async function apiFetch(path, options = {}) {
  const token = localStorage.getItem('bh_token');
  const headers = { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` };
  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw { ...data, status: res.status };
  return data;
}

const ALL_PERMISSIONS = [
  { code: 'users.view', label: 'View Users', module: 'users' },
  { code: 'users.edit', label: 'Edit Users', module: 'users' },
  { code: 'users.suspend', label: 'Suspend/Activate Users', module: 'users' },
  { code: 'requests.view', label: 'View Requests', module: 'requests' },
  { code: 'requests.approve', label: 'Approve Requests', module: 'requests' },
  { code: 'requests.manage', label: 'Manage Requests', module: 'requests' },
  { code: 'donors.view', label: 'View Donors', module: 'donors' },
  { code: 'donors.verify', label: 'Verify Donors', module: 'donors' },
  { code: 'verification.nid', label: 'NID Verification', module: 'verification' },
  { code: 'verification.donation', label: 'Donation Verification', module: 'verification' },
  { code: 'hospitals.manage', label: 'Manage Hospitals', module: 'hospitals' },
  { code: 'ambulances.manage', label: 'Manage Ambulances', module: 'ambulances' },
  { code: 'camps.manage', label: 'Manage Camps', module: 'camps' },
  { code: 'support.view', label: 'User Support', module: 'support' },
  { code: 'reports.view', label: 'View Reports', module: 'reports' },
  { code: 'settings.manage', label: 'Manage Settings', module: 'settings' },
  { code: 'profile.view', label: 'View Public Profiles', module: 'users' },
];

export async function renderAdminSubAdmins(root) {
  let subAdmins = [];
  try {
    subAdmins = await apiFetch('/hierarchy/sub-admins');
  } catch (e) {
    toast('Failed to load sub-admins', 'error');
  }

  root.innerHTML = `
    <div class="admin-hero">
      <div><h2>${icon('settings')} Sub-admin Management</h2><p class="muted">Invite and manage sub-admins with granular permissions</p></div>
      <button class="btn primary sm" id="inviteSubAdminBtn">${icon('add')} Invite Sub-admin</button>
    </div>
    <div class="table-wrap panel">
      <table class="bh-table">
        <thead>
          <tr><th>Name</th><th>Phone</th><th>Status</th><th>Permissions</th><th>Invited</th><th class="ta-r">Actions</th></tr>
        </thead>
        <tbody>
          ${subAdmins.length === 0 ? `<tr><td colspan="6" style="text-align:center;color:var(--muted)">No sub-admin accounts</td></tr>` :
          subAdmins.map(s => `
            <tr data-id="${s.account_id}" data-phone="${s.phone}">
              <td class="bold">${esc(s.name || s.phone)}</td>
              <td dir="ltr" class="mono">${esc(s.phone)}</td>
              <td><span class="badge ${s.status === 'active' ? 'green' : s.status === 'pending_verification' ? 'amber' : 'red'}">${esc(s.status)}</span></td>
              <td class="mono" style="font-size:.68rem;">${s.permissions ? esc(s.permissions.join(', ')) : '<span class="muted">None</span>'}</td>
              <td>${s.created_at ? new Date(s.created_at * 1000).toLocaleDateString() : '—'}</td>
              <td class="ta-r">
                <select class="subActSelect" data-id="${s.account_id}">
                  <option value="">${esc(t('action'))}</option>
                  <option value="suspend">Suspend</option>
                  <option value="activate">Activate</option>
                  <option value="disable">Disable</option>
                  <option value="revoke">Revoke</option>
                </select>
                <button class="btn ghost sm permBtn" data-id="${s.account_id}">${icon('settings')} Permissions</button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>`;

  // Invite sub-admin
  $('#inviteSubAdminBtn').addEventListener('click', () => {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
      <div class="modal">
        <div class="modal-head"><h3>${icon('add')} Invite Sub-admin</h3><button class="modal-close">${icon('close')}</button></div>
        <div class="modal-body">
          <label class="field-row"><span>Phone Number</span><input class="field" id="subAdminPhone" type="tel" value="+880" required /></label>
          <label class="field-row"><span>Permissions</span>
            <div class="perm-grid" style="max-height:200px;overflow-y:auto;border:1px solid var(--line);padding:8px;border-radius:6px;">
              ${ALL_PERMISSIONS.map(p => `
                <label style="display:flex;align-items:center;gap:6px;padding:4px;">
                  <input type="checkbox" name="perms" value="${p.code}" />
                  <span style="font-size:.72rem;">${esc(p.label)}</span>
                </label>
              `).join('')}
            </div>
          </label>
        </div>
        <div class="modal-foot">
          <button class="btn light sm modal-cancel">${esc(t('cancel'))}</button>
          <button class="btn primary sm modal-send">Send Invitation</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    modal.querySelector('.modal-cancel').addEventListener('click', () => modal.remove());
    modal.querySelector('.modal-close').addEventListener('click', () => modal.remove());
    modal.querySelector('.modal-send').addEventListener('click', async () => {
      const phone = modal.querySelector('#subAdminPhone').value.trim();
      const perms = Array.from(modal.querySelectorAll('input[name="perms"]:checked')).map(c => c.value);
      try {
        const result = await apiFetch('/auth/sub-admin/invitation', {
          method: 'POST', body: JSON.stringify({ phone, permissions: perms })
        });
        toast(`Invitation sent. OTP Step1: ${result.otp_step1}, Step2: ${result.otp_step2}`, 'success');
        modal.remove();
      } catch (e) {
        toast(e.error || 'Failed to send invitation', 'error');
      }
    });
  });

  // Handle action select
  root.querySelectorAll('.subActSelect').forEach(sel => {
    sel.addEventListener('change', async () => {
      const id = sel.dataset.id;
      const action = sel.value;
      if (!action) return;
      try {
        await apiFetch(`/hierarchy/sub-admins/${id}`, { method: 'PATCH', body: JSON.stringify({ action }) });
        toast(`Sub-admin ${action}ed`, 'success');
        sel.value = '';
        renderAdminSubAdmins(root);
      } catch (e) {
        toast(e.error || 'Failed', 'error');
      }
    });
  });

  // Permission management
  root.querySelectorAll('.permBtn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.id;
      const permModal = document.createElement('div');
      permModal.className = 'modal-overlay';
      permModal.innerHTML = `
        <div class="modal">
          <div class="modal-head"><h3>Manage Permissions</h3><button class="modal-close">${icon('close')}</button></div>
          <div class="modal-body">
            <div class="perm-grid" style="max-height:240px;overflow-y:auto;border:1px solid var(--line);padding:8px;border-radius:6px;">
              ${ALL_PERMISSIONS.map(p => `
                <label style="display:flex;align-items:center;gap:6px;padding:4px;">
                  <input type="checkbox" name="perms" value="${p.code}" class="permCheck" data-module="${p.module}" />
                  <span style="font-size:.72rem;">${esc(p.label)}</span>
                </label>
              `).join('')}
            </div>
          </div>
          <div class="modal-foot">
            <button class="btn light sm modal-cancel">${esc(t('cancel'))}</button>
            <button class="btn primary sm modal-save">Save Permissions</button>
          </div>
        </div>
      `;
      document.body.appendChild(permModal);

      // Load current permissions
      try {
        const detail = await apiFetch(`/hierarchy/sub-admins/${id}/permissions`);
        if (detail.permissions) {
          detail.permissions.forEach(code => {
            const cb = permModal.querySelector(`.permCheck[value="${code}"]`);
            if (cb) cb.checked = true;
          });
        }
      } catch (e) { console.error(e); }

      permModal.querySelector('.modal-cancel').addEventListener('click', () => permModal.remove());
      permModal.querySelector('.modal-close').addEventListener('click', () => permModal.remove());
      permModal.querySelector('.modal-save').addEventListener('click', async () => {
        const perms = Array.from(permModal.querySelectorAll('input[name="perms"]:checked')).map(c => c.value);
        try {
          await apiFetch(`/hierarchy/sub-admins/${id}/permissions`, {
            method: 'PATCH', body: JSON.stringify({ permissions: perms })
          });
          toast(`${perms.length} permissions assigned`, 'success');
          permModal.remove();
          renderAdminSubAdmins(root);
        } catch (e) {
          toast(e.error || 'Failed', 'error');
        }
      });
    });
  });
}
