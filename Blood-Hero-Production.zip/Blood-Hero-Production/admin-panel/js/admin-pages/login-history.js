// Login History Viewer
import { t, lang } from '../../../js/i18n.js';
import { esc, icon, toast } from '../../../js/ui.js';
import { API_BASE } from '../../../shared/js/api-config.js';
const $ = s => document.querySelector(s);

async function apiFetch(path, options = {}) {
  const token = localStorage.getItem('bh_token');
  const headers = { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` };
  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw { ...data, status: res.status };
  return data;
}

export async function renderAdminLoginHistory(root) {
  root.innerHTML = `
    <div class="admin-hero">
      <div><h2>${icon('clock')} Login History</h2><p class="muted">Track administrative login events</p></div>
      <div class="filter-bar" style="display:flex;gap:8px;">
        <input class="field sm" id="phoneFilter" placeholder="phone" style="width:160px;" />
        <button class="btn primary sm" id="histFilterBtn">${icon('filter')} Filter</button>
        <button class="btn light sm" id="histRefreshBtn">${icon('list')} Refresh</button>
      </div>
    </div>
    <div class="table-wrap panel">
      <table class="bh-table">
        <thead><tr><th>Phone</th><th>Role</th><th>Method</th><th>Result</th><th>IP</th><th>Date</th></tr></thead>
        <tbody id="histTableBody"><tr><td colspan="6" style="text-align:center;color:var(--muted)">${icon('loading')} Loading...</td></tr></tbody>
      </table>
    </div>`;

  async function loadHistory() {
    const params = new URLSearchParams();
    if ($('#phoneFilter').value) params.set('phone', $('#phoneFilter').value);
    try {
      const result = await apiFetch(`/hierarchy/login-history?${params.toString()}`);
      const history = result.history || [];
      const tbody = $('#histTableBody');
      if (history.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:var(--muted)">No login history</td></tr>`;
      } else {
        tbody.innerHTML = history.map(h => `
          <tr>
            <td dir="ltr" class="mono" style="font-size:.68rem;">${esc(h.phone || '—')}</td>
            <td><span class="badge ${h.role === 'super_admin' ? 'red' : h.role === 'admin' ? 'blue' : h.role === 'sub_admin' ? 'green' : 'gray'}">${esc(h.admin_role || h.role)}</span></td>
            <td class="mono" style="font-size:.68rem;">${esc(h.login_method)}</td>
            <td><span class="badge ${h.success ? 'green' : 'red'}">${h.success ? 'Success' : 'Failed'}</span></td>
            <td class="mono" style="font-size:.64rem;">${esc(h.ip_address || '—')}</td>
            <td class="mono" style="font-size:.64rem;">${new Date(h.created_at * 1000).toLocaleString()}</td>
          </tr>
        `).join('');
      }
    } catch (e) {
      toast(e.error || 'Failed to load login history', 'error');
    }
  }

  $('#histFilterBtn').addEventListener('click', loadHistory);
  $('#histRefreshBtn').addEventListener('click', loadHistory);
  await loadHistory();
}
