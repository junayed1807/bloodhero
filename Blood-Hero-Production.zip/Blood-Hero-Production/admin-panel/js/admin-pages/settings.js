// Admin Settings — preferences + password change
import { t } from '../../../js/i18n.js';
import { esc, icon, toast } from '../../../js/ui.js';
import { api, bn } from '../api-client.js';

export async function renderAdminSettings(root) {
  root.innerHTML = `
    <div class="admin-hero"><div><h2>${esc(t('settings'))}</h2></div></div>
    <div class="panel">
      <div class="mini-row"><span>${bn('মেইনটেন্যান্স মোড', 'Maintenance mode')}</span>
        <label class="switch-inline"><input type="checkbox" id="mMode"/><span class="switch"></span></label></div>
      <div class="mini-row"><span>${esc(t('pushNotif'))}</span>
        <label class="switch-inline"><input type="checkbox" checked /><span class="switch"></span></label></div>
      <div class="mini-row"><span>${bn('FX অ্যানিমেশন', 'FX Animations')}</span>
        <label class="switch-inline"><input type="checkbox" id="fxToggle" checked /><span class="switch"></span></label></div>
    </div>
    <div class="panel">
      <div class="panel-head"><h3>${icon('lock')} ${bn('পাসওয়ার্ড পরিবর্তন', 'Change Password')}</h3></div>
      <form id="pwdForm" class="form-card flat">
        <label class="field-row"><span>${bn('বর্তমান পাসওয়ার্ড', 'Current password')} *</span>
          <input class="field" name="currentPassword" type="password" required autocomplete="current-password" /></label>
        <label class="field-row"><span>${bn('নতুন পাসওয়ার্ড', 'New password')} *</span>
          <input class="field" name="newPassword" type="password" minlength="6" required autocomplete="new-password" /></label>
        <label class="field-row"><span>${bn('নতুন পাসওয়ার্ড (আবার)', 'Confirm new password')} *</span>
          <input class="field" name="confirmPassword" type="password" minlength="6" required autocomplete="new-password" /></label>
        <button class="btn primary">${icon('check')} ${bn('পাসওয়ার্ড আপডেট', 'Update Password')}</button>
      </form>
    </div>
    <button class="btn danger-ghost" id="adminLogout">${icon('logout')} ${esc(t('logout'))}</button>`;
  root.querySelector('#adminLogout').addEventListener('click', async () => { localStorage.removeItem('bh_token'); location.reload(); });
  root.querySelector('#mMode').addEventListener('change', e => toast(bn('মেইনটেন্যান্স ', 'Maintenance ') + (e.target.checked ? 'ON' : 'OFF'), 'info'));
  root.querySelector('#fxToggle').addEventListener('change', e => {
    try { localStorage.setItem('bh_fx_off', e.target.checked ? '0' : '1'); } catch {}
    toast(e.target.checked ? 'FX ON' : 'FX OFF', 'success');
  });
  root.querySelector('#pwdForm').addEventListener('submit', async e => {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(e.target).entries());
    if (d.newPassword !== d.confirmPassword) { toast(bn('পাসওয়ার্ড মেলেনি', 'Passwords do not match'), 'error'); return; }
    try {
      await api.post('/auth/change-password', { currentPassword: d.currentPassword, newPassword: d.newPassword });
      toast(bn('পাসওয়ার্ড পরিবর্তন হয়েছে', 'Password updated'), 'success');
      e.target.reset();
    } catch (err) {
      toast(err.message || 'Failed', 'error');
    }
  });
}