// Admin Panel — Content Management (camps, campaigns, articles, gallery,
// partners, downloads, stories, FAQ) + volunteers + contact messages.
// Backed by backend /api/admin/content CRUD (RBAC: content.manage,
// volunteers.manage, contact.view). Every mutation is audit-logged server-side.
import { t, lang } from '../../../js/i18n.js';
import { esc, icon, toast } from '../../../js/ui.js';
import { api } from '../api-client.js';

const B = () => lang() === 'bn';

// ---------- generic modal ----------
function modal(title, bodyHtml) {
  const ov = document.createElement('div');
  ov.className = 'modal-overlay';
  ov.innerHTML = `
    <div class="modal wide">
      <div class="modal-head"><h3>${esc(title)}</h3><button class="modal-close" data-x aria-label="Close">×</button></div>
      <div class="modal-body">${bodyHtml}</div>
    </div>`;
  document.body.appendChild(ov);
  ov.addEventListener('click', e => { if (e.target === ov || e.target.hasAttribute('data-x')) ov.remove(); });
  return ov;
}

// ---------- field builders ----------
function fieldHtml(f, val = '') {
  const id = 'f_' + f.n;
  const req = f.r ? ' required' : '';
  switch (f.type) {
    case 'textarea':
      return `<label class="field-row" style="margin-bottom:10px;"><span>${esc(f.l)}${f.r ? ' *' : ''}</span>
        <textarea class="field" name="${f.n}" rows="${f.rows || 3}" ${req}>${esc(val)}</textarea></label>`;
    case 'select':
      return `<label class="field-row" style="margin-bottom:10px;"><span>${esc(f.l)}</span>
        <select class="field" name="${f.n}">${f.options.map(o => `<option value="${esc(o)}" ${String(val) === o ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select></label>`;
    case 'checkbox':
      return `<label class="field-row" style="margin-bottom:10px;"><span>${esc(f.l)}</span>
        <input type="checkbox" class="field-chk" name="${f.n}" ${val ? 'checked' : ''} /></label>`;
    case 'date':
      return `<label class="field-row" style="margin-bottom:10px;"><span>${esc(f.l)}</span>
        <input class="field" type="date" name="${f.n}" value="${esc(String(val || '').slice(0, 10))}" /></label>`;
    default:
      return `<label class="field-row" style="margin-bottom:10px;"><span>${esc(f.l)}${f.r ? ' *' : ''}</span>
        <input class="field" type="${f.type || 'text'}" name="${f.n}" value="${esc(val ?? '')}" ${req} /></label>`;
  }
}

function collectValues(form) {
  const data = Object.fromEntries(new FormData(form).entries());
  form.querySelectorAll('input[type="checkbox"]').forEach(c => { data[c.name] = c.checked; });
  return data;
}

// ---------- CRUD factory ----------
function crud({ base, title, fields, columns, gallery = false }) {
  return async function render(root) {
    let list = [];
    try { list = await api.get(`/admin/content/${base}`); } catch {}

    const head = `<div class="admin-hero"><div><h2>${esc(title)}</h2><p class="muted">${list.length} ${B() ? 'আইটেম' : 'items'}</p></div>
      <button class="btn primary sm" data-new>${icon('plus')} ${B() ? 'নতুন যোগ করুন' : 'Add New'}</button></div>`;

    const ths = columns.map(c => `<th>${esc(c.l)}</th>`).join('');
    const rows = list.map(row => {
      const tds = columns.map(c => `<td>${c.h ? c.h(row) : esc(row[c.k] ?? '—')}</td>`).join('');
      const galleryBtn = gallery ? `<button class="btn ghost sm" data-imgs="${row.id}">${icon('camera')} ${B() ? 'ছবি' : 'Images'}</button> ` : '';
      return `<tr>${tds}<td class="ta-r">${galleryBtn}
        <button class="btn ghost sm" data-edit="${row.id}">${icon('wrench')}</button>
        <button class="btn danger-ghost sm" data-del="${row.id}">${icon('close')}</button></td></tr>`;
    }).join('') || `<tr><td colspan="${columns.length + 1}" style="text-align:center;color:var(--muted)">${B() ? 'কোনো আইটেম নেই' : 'No items yet'}</td></tr>`;

    root.innerHTML = `${head}
      <div class="table-wrap panel"><table class="bh-table">
        <thead><tr>${ths}<th class="ta-r">${B() ? 'অ্যাকশন' : 'Actions'}</th></tr></thead>
        <tbody>${rows}</tbody></table></div>`;

    root.querySelector('[data-new]').addEventListener('click', () => openForm(null));
    root.querySelectorAll('[data-edit]').forEach(b => b.addEventListener('click', () => {
      const row = list.find(r => r.id === b.dataset.edit);
      if (row) openForm(row);
    }));
    root.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', async () => {
      if (!confirm(B() ? 'নিশ্চিত মুছবেন?' : 'Delete this item?')) return;
      try { await api.delete(`/admin/content/${base}/${b.dataset.del}`); toast('✓', 'success'); render(root); }
      catch (e) { toast(e.message || 'Failed', 'error'); }
    }));
    if (gallery) {
      root.querySelectorAll('[data-imgs]').forEach(b => b.addEventListener('click', () => openGallery(list.find(r => r.id === b.dataset.imgs))));
    }

    function openForm(row) {
      const isEdit = !!row;
      const body = `<form id="crudForm" class="form-card flat">
        ${fields.map(f => fieldHtml(f, row ? row[f.n] : '')).join('')}
        <div class="grid-2" style="margin-top:4px;">
          <button type="button" class="btn ghost lg" data-cancel>${B() ? 'বাতিল' : 'Cancel'}</button>
          <button type="submit" class="btn primary lg">${isEdit ? (B() ? 'আপডেট' : 'Update') : (B() ? 'তৈরি করুন' : 'Create')}</button>
        </div>
        <p class="muted" id="crudMsg" style="font-size:.72rem; margin-top:8px;"></p></form>`;
      const ov = modal(isEdit ? (B() ? 'সম্পাদনা' : 'Edit') + ' — ' + title : (B() ? 'নতুন' : 'New') + ' — ' + title, body);
      ov.querySelector('[data-cancel]').addEventListener('click', () => ov.remove());
      ov.querySelector('#crudForm').addEventListener('submit', async e => {
        e.preventDefault();
        const data = collectValues(e.target);
        const msg = ov.querySelector('#crudMsg');
        try {
          if (isEdit) await api.patch(`/admin/content/${base}/${row.id}`, data);
          else await api.post(`/admin/content/${base}`, data);
          toast('✓', 'success');
          ov.remove();
          render(root);
        } catch (err) { msg.textContent = err.message || 'Failed'; }
      });
    }

    function openGallery(album) {
      if (!album) return;
      (async () => {
        let detail = { images: [] };
        try { detail = await api.get(`/admin/content/gallery/${album.id}`); } catch {}
        const body = `
          <p class="muted" style="font-size:.8rem;">${esc(album.title)} — ${B() ? 'ছবি' : 'Images'}: ${detail.images.length}</p>
          <form id="imgForm" class="form-card flat" style="margin:10px 0;">
            <div class="grid-2">
              <label class="field-row"><span>Image URL</span><input class="field" name="url" placeholder="https://…" required /></label>
              <label class="field-row"><span>Caption</span><input class="field" name="caption" /></label>
            </div>
            <button class="btn primary sm" type="submit">${icon('plus')} ${B() ? 'ছবি যোগ করুন' : 'Add Image'}</button>
          </form>
          <div class="gal-admin-list">
            ${detail.images.map(im => `
              <div class="gal-admin-row">
                ${im.url ? `<img src="${esc(im.url)}" alt="" loading="lazy" />` : `<div class="gal-admin-ph">${icon('camera')}</div>`}
                <span class="muted">${esc(im.caption || im.url || '')}</span>
                <button class="btn danger-ghost sm" data-idel="${im.id}">${icon('close')}</button>
              </div>`).join('') || `<p class="muted">${B() ? 'এখনো ছবি নেই' : 'No images yet'}</p>`}
          </div>`;
        const ov = modal(B() ? 'অ্যালবামের ছবি' : 'Album Images', body);
        ov.querySelector('#imgForm').addEventListener('submit', async e => {
          e.preventDefault();
          const data = Object.fromEntries(new FormData(e.target).entries());
          try { await api.post(`/admin/content/gallery/${album.id}/images`, data); toast('✓', 'success'); ov.remove(); openGallery(album); }
          catch (err) { toast(err.message || 'Failed', 'error'); }
        });
        ov.querySelectorAll('[data-idel]').forEach(b => b.addEventListener('click', async () => {
          if (!confirm(B() ? 'ছবি মুছবেন?' : 'Delete image?')) return;
          try { await api.delete(`/admin/content/gallery/${album.id}/images/${b.dataset.idel}`); toast('✓', 'success'); ov.remove(); openGallery(album); }
          catch (err) { toast(err.message || 'Failed', 'error'); }
        }));
      })();
    }
  };
}

// ---------- entity configs ----------
const MODULES = {
  camps: crud({
    base: 'camps', title: B() ? 'রক্তদান ক্যাম্প' : 'Blood Camps',
    columns: [
      { k: 'title', l: B() ? 'শিরোনাম' : 'Title' },
      { k: 'status', l: 'Status' },
      { k: 'date', l: 'Date' },
      { k: 'district', l: 'District' },
    ],
    fields: [
      { n: 'title', l: B() ? 'শিরোনাম' : 'Title', r: true },
      { n: 'description', l: B() ? 'বর্ণনা' : 'Description', type: 'textarea' },
      { n: 'venue', l: B() ? 'স্থান' : 'Venue' },
      { n: 'district', l: B() ? 'জেলা' : 'District' },
      { n: 'upazila', l: 'Upazila' },
      { n: 'date', l: 'Date', type: 'date' },
      { n: 'start_time', l: 'Start Time' },
      { n: 'end_time', l: 'End Time' },
      { n: 'target_units', l: B() ? 'লক্ষ্য (ইউনিট)' : 'Target Units', type: 'number' },
      { n: 'collected_units', l: B() ? 'সংগৃহীত (ইউনিট)' : 'Collected Units', type: 'number' },
      { n: 'status', l: 'Status', type: 'select', options: ['upcoming', 'ongoing', 'completed', 'cancelled'] },
      { n: 'organizer', l: B() ? 'আয়োজক' : 'Organizer' },
      { n: 'banner_url', l: 'Banner URL' },
      { n: 'registration_open', l: B() ? 'নিবন্ধন খোলা' : 'Registration Open', type: 'checkbox' },
    ],
  }),
  campaigns: crud({
    base: 'campaigns', title: B() ? 'অভিযান' : 'Campaigns',
    columns: [
      { k: 'title', l: B() ? 'শিরোনাম' : 'Title' },
      { k: 'status', l: 'Status' },
      { k: 'start_date', l: 'Start' },
      { k: 'goal', l: 'Goal' },
    ],
    fields: [
      { n: 'title', l: B() ? 'শিরোনাম' : 'Title', r: true },
      { n: 'description', l: B() ? 'বর্ণনা' : 'Description', type: 'textarea' },
      { n: 'banner_url', l: 'Banner URL' },
      { n: 'category', l: 'Category' },
      { n: 'start_date', l: 'Start Date', type: 'date' },
      { n: 'end_date', l: 'End Date', type: 'date' },
      { n: 'goal', l: B() ? 'লক্ষ্য (ইউনিট)' : 'Goal (units)', type: 'number' },
      { n: 'achieved', l: B() ? 'অর্জিত' : 'Achieved', type: 'number' },
      { n: 'organizer', l: B() ? 'আয়োজক' : 'Organizer' },
      { n: 'status', l: 'Status', type: 'select', options: ['upcoming', 'active', 'completed'] },
    ],
  }),
  articles: crud({
    base: 'articles', title: B() ? 'সংবাদ ও নিবন্ধ' : 'News & Articles',
    columns: [
      { k: 'title_en', l: 'Title (EN)' },
      { k: 'status', l: 'Status' },
      { k: 'category', l: 'Category' },
      { k: 'published_at', l: B() ? 'প্রকাশ' : 'Published', h: r => r.published_at ? new Date(r.published_at * 1000).toLocaleDateString() : '—' },
    ],
    fields: [
      { n: 'title_bn', l: B() ? 'শিরোনাম (বাংলা)' : 'Title (Bangla)', r: true },
      { n: 'title_en', l: 'Title (English)', r: true },
      { n: 'body_bn', l: B() ? 'বিস্তারিত (বাংলা)' : 'Body (Bangla)', type: 'textarea', rows: 6 },
      { n: 'body_en', l: 'Body (English)', type: 'textarea', rows: 6 },
      { n: 'excerpt_bn', l: B() ? 'সারাংশ (বাংলা)' : 'Excerpt (Bangla)', type: 'textarea', rows: 2 },
      { n: 'excerpt_en', l: 'Excerpt (English)', type: 'textarea', rows: 2 },
      { n: 'slug', l: 'Slug (URL)' },
      { n: 'category', l: 'Category' },
      { n: 'image_url', l: 'Image URL' },
      { n: 'author_name', l: B() ? 'লেখক' : 'Author' },
      { n: 'status', l: 'Status', type: 'select', options: ['draft', 'published', 'archived'] },
    ],
  }),
  gallery: crud({
    base: 'gallery', title: B() ? 'গ্যালারি' : 'Gallery', gallery: true,
    columns: [
      { k: 'title', l: B() ? 'অ্যালবাম' : 'Album' },
      { k: 'category', l: 'Category' },
      { k: 'image_count', l: B() ? 'ছবি' : 'Images' },
      { k: 'event_date', l: B() ? 'ইভেন্ট তারিখ' : 'Event Date' },
    ],
    fields: [
      { n: 'title', l: B() ? 'অ্যালবামের নাম' : 'Album Title', r: true },
      { n: 'description', l: B() ? 'বর্ণনা' : 'Description', type: 'textarea' },
      { n: 'category', l: 'Category' },
      { n: 'cover_url', l: 'Cover URL' },
      { n: 'event_date', l: B() ? 'ইভেন্ট তারিখ' : 'Event Date', type: 'date' },
    ],
  }),
  partners: crud({
    base: 'partners', title: B() ? 'অংশীদার' : 'Partners',
    columns: [
      { k: 'name', l: 'Name' },
      { k: 'type', l: 'Type' },
      { k: 'active', l: 'Active', h: r => r.active ? '✓' : '—' },
    ],
    fields: [
      { n: 'name', l: 'Name', r: true },
      { n: 'type', l: 'Type' },
      { n: 'logo_url', l: 'Logo URL' },
      { n: 'website', l: 'Website' },
      { n: 'description', l: B() ? 'বর্ণনা' : 'Description', type: 'textarea' },
      { n: 'sort_order', l: 'Sort Order', type: 'number' },
      { n: 'active', l: 'Active', type: 'checkbox' },
    ],
  }),
  downloads: crud({
    base: 'downloads', title: B() ? 'ডাউনলোড' : 'Downloads',
    columns: [
      { k: 'title', l: B() ? 'শিরোনাম' : 'Title' },
      { k: 'category', l: 'Category' },
      { k: 'active', l: 'Active', h: r => r.active ? '✓' : '—' },
    ],
    fields: [
      { n: 'title', l: B() ? 'শিরোনাম' : 'Title', r: true },
      { n: 'description', l: B() ? 'বর্ণনা' : 'Description', type: 'textarea' },
      { n: 'file_url', l: 'File URL' },
      { n: 'category', l: 'Category' },
      { n: 'file_size', l: 'File Size' },
      { n: 'active', l: 'Active', type: 'checkbox' },
    ],
  }),
  stories: crud({
    base: 'stories', title: B() ? 'সাফল্যের গল্প' : 'Success Stories',
    columns: [
      { k: 'title', l: B() ? 'শিরোনাম' : 'Title' },
      { k: 'status', l: 'Status' },
      { k: 'author_name', l: B() ? 'লেখক' : 'Author' },
    ],
    fields: [
      { n: 'title', l: B() ? 'শিরোনাম' : 'Title', r: true },
      { n: 'content', l: B() ? 'গল্প' : 'Content', type: 'textarea', rows: 6 },
      { n: 'image_url', l: 'Image URL' },
      { n: 'category', l: 'Category' },
      { n: 'author_name', l: B() ? 'লেখক' : 'Author' },
      { n: 'status', l: 'Status', type: 'select', options: ['draft', 'published', 'archived'] },
      { n: 'featured', l: 'Featured', type: 'checkbox' },
    ],
  }),
  faq: crud({
    base: 'faq', title: 'FAQ',
    columns: [
      { k: 'question_en', l: 'Question (EN)' },
      { k: 'category', l: 'Category' },
      { k: 'active', l: 'Active', h: r => r.active ? '✓' : '—' },
    ],
    fields: [
      { n: 'question_bn', l: B() ? 'প্রশ্ন (বাংলা)' : 'Question (Bangla)', r: true },
      { n: 'question_en', l: 'Question (English)', r: true },
      { n: 'answer_bn', l: B() ? 'উত্তর (বাংলা)' : 'Answer (Bangla)', type: 'textarea' },
      { n: 'answer_en', l: 'Answer (English)', type: 'textarea' },
      { n: 'category', l: 'Category' },
      { n: 'sort_order', l: 'Sort Order', type: 'number' },
      { n: 'active', l: 'Active', type: 'checkbox' },
    ],
  }),
};

export async function renderAdminContent(root, section) {
  const mod = MODULES[section] || MODULES.articles;
  await mod(root);
}

// ---------- volunteers ----------
export async function renderAdminVolunteers(root) {
  let list = [];
  try { list = await api.get('/admin/content/volunteers'); } catch {}

  const statusBadge = s => {
    const cls = { pending: 'amber', approved: 'green', rejected: 'red' }[s] || 'gray';
    return `<span class="badge ${cls}">${esc(s)}</span>`;
  };

  root.innerHTML = `
    <div class="admin-hero"><div><h2>${B() ? 'স্বেচ্ছাসেবী' : 'Volunteers'}</h2><p class="muted">${list.length} ${B() ? 'আবেদন' : 'applications'}</p></div></div>
    <div class="table-wrap panel"><table class="bh-table">
      <thead><tr><th>${B() ? 'নাম' : 'Name'}</th><th>${B() ? 'ফোন' : 'Phone'}</th><th>${B() ? 'জেলা' : 'District'}</th><th>${B() ? 'দক্ষতা' : 'Skills'}</th><th>${B() ? 'স্থিতি' : 'Status'}</th><th class="ta-r">${B() ? 'অ্যাকশন' : 'Actions'}</th></tr></thead>
      <tbody>${list.map(v => `
        <tr>
          <td class="bold">${esc(v.name)}</td>
          <td>${esc(v.phone || '—')}</td>
          <td>${esc(v.district || '—')}${v.upazila ? ', ' + esc(v.upazila) : ''}</td>
          <td class="muted" style="font-size:.75rem;">${esc(v.skills || '—')}</td>
          <td>${statusBadge(v.status)}</td>
          <td class="ta-r">
            ${v.status === 'pending' ? `
              <button class="btn success sm" data-approve="${v.id}">${icon('check')} ${B() ? 'অনুমোদন' : 'Approve'}</button>
              <button class="btn danger-ghost sm" data-reject="${v.id}">${icon('close')} ${B() ? 'প্রত্যাখ্যান' : 'Reject'}</button>` : ''}
            <button class="btn danger-ghost sm" data-del="${v.id}">${icon('close')}</button>
          </td>
        </tr>`).join('') || `<tr><td colspan="6" style="text-align:center;color:var(--muted)">${B() ? 'কোনো আবেদন নেই' : 'No applications'}</td></tr>`}
      </tbody></table></div>`;

  root.querySelectorAll('[data-approve]').forEach(b => b.addEventListener('click', async () => {
    try { await api.patch(`/admin/content/volunteers/${b.dataset.approve}/status`, { status: 'approved' }); toast('✓', 'success'); renderAdminVolunteers(root); }
    catch (e) { toast(e.message || 'Failed', 'error'); }
  }));
  root.querySelectorAll('[data-reject]').forEach(b => b.addEventListener('click', async () => {
    try { await api.patch(`/admin/content/volunteers/${b.dataset.reject}/status`, { status: 'rejected' }); toast('✓', 'success'); renderAdminVolunteers(root); }
    catch (e) { toast(e.message || 'Failed', 'error'); }
  }));
  root.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', async () => {
    if (!confirm(B() ? 'নিশ্চিত মুছবেন?' : 'Delete?')) return;
    try { await api.delete(`/admin/content/volunteers/${b.dataset.del}`); toast('✓', 'success'); renderAdminVolunteers(root); }
    catch (e) { toast(e.message || 'Failed', 'error'); }
  }));
}

// ---------- contact messages ----------
export async function renderAdminMessages(root) {
  let list = [];
  try { list = await api.get('/admin/content/contact-messages'); } catch {}

  root.innerHTML = `
    <div class="admin-hero"><div><h2>${B() ? 'যোগাযোগ বার্তা' : 'Contact Messages'}</h2><p class="muted">${list.length} ${B() ? 'বার্তা' : 'messages'}</p></div></div>
    <div class="table-wrap panel"><table class="bh-table">
      <thead><tr><th>${B() ? 'নাম' : 'Name'}</th><th>${B() ? 'যোগাযোগ' : 'Contact'}</th><th>${B() ? 'বিষয়' : 'Subject'}</th><th>${B() ? 'বার্তা' : 'Message'}</th><th>${B() ? 'স্থিতি' : 'Status'}</th><th class="ta-r">${B() ? 'অ্যাকশন' : 'Actions'}</th></tr></thead>
      <tbody>${list.map(m => `
        <tr>
          <td class="bold">${esc(m.name)}</td>
          <td>${esc(m.phone || '')}${m.email ? '<br/>' + esc(m.email) : ''}</td>
          <td>${esc(m.subject || '—')}</td>
          <td class="muted" style="font-size:.75rem; max-width:280px;">${esc(m.message || '')}</td>
          <td><span class="badge ${m.status === 'new' ? 'amber' : 'gray'}">${esc(m.status || 'new')}</span></td>
          <td class="ta-r">
            ${m.status === 'new' ? `<button class="btn ghost sm" data-read="${m.id}">${icon('check')} ${B() ? 'পঠিত' : 'Read'}</button>` : ''}
            <button class="btn danger-ghost sm" data-del="${m.id}">${icon('close')}</button>
          </td>
        </tr>`).join('') || `<tr><td colspan="6" style="text-align:center;color:var(--muted)">${B() ? 'কোনো বার্তা নেই' : 'No messages'}</td></tr>`}
      </tbody></table></div>`;

  root.querySelectorAll('[data-read]').forEach(b => b.addEventListener('click', async () => {
    try { await api.patch(`/admin/content/contact-messages/${b.dataset.read}/status`, { status: 'read' }); toast('✓', 'success'); renderAdminMessages(root); }
    catch (e) { toast(e.message || 'Failed', 'error'); }
  }));
  root.querySelectorAll('[data-del]').forEach(b => b.addEventListener('click', async () => {
    if (!confirm(B() ? 'নিশ্চিত মুছবেন?' : 'Delete?')) return;
    try { await api.delete(`/admin/content/contact-messages/${b.dataset.del}`); toast('✓', 'success'); renderAdminMessages(root); }
    catch (e) { toast(e.message || 'Failed', 'error'); }
  }));
}