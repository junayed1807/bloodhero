// Admin Users Management — search, filter, sort, pagination, detail modal
import { t, lang } from '../../../js/i18n.js';
import { esc, icon, bloodBadge, toast } from '../../../js/ui.js';
import { api, bn } from '../api-client.js';

const PAGE_SIZE = 12;
const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];

export async function renderAdminUsers(root) {
  let all = [];
  let state = { q: '', group: '', district: '', role: '', sort: 'created_at', dir: -1, page: 0 };

  root.innerHTML = `
    <div class="admin-hero">
      <div><h2>${esc(t('users'))}</h2><p class="muted" id="usersCount">${bn('লোড হচ্ছে…', 'Loading…')}</p></div>
      <div class="filter-bar">
        <input class="field sm" id="uSearch" placeholder="${bn('নাম/ফোন খুঁজুন…', 'Search name/phone…')}" />
        <select class="field sm" id="uGroup"><option value="">${bn('সব গ্রুপ', 'All groups')}</option>${BLOOD_GROUPS.map(g => `<option>${g}</option>`).join('')}</select>
        <input class="field sm" id="uDistrict" placeholder="${bn('জেলা', 'District')}" />
        <select class="field sm" id="uRole">
          <option value="">${bn('সব ভূমিকা', 'All roles')}</option>
          <option value="donor">donor</option><option value="admin">admin</option><option value="sub_admin">sub_admin</option>
          <option value="super_admin">super_admin</option><option value="org_admin">org_admin</option>
        </select>
      </div>
    </div>
    <div class="table-wrap panel">
      <table class="bh-table">
        <thead><tr>
          <th><a href="#" data-sort="name" class="sort-link">${esc(t('name'))}</a></th>
          <th>${esc(t('bloodGroup'))}</th>
          <th>${esc(t('contact'))}</th>
          <th>${esc(t('district'))}</th>
          <th>${esc(t('availability'))}</th>
          <th>${esc(t('role'))}</th>
          <th class="ta-r">${esc(t('action'))}</th>
        </tr></thead>
        <tbody id="userTbody"><tr><td colspan="7"><div class="empty sm">${icon('loading')} ${bn('লোড হচ্ছে…', 'Loading…')}</div></td></tr></tbody>
      </table>
    </div>
    <div id="userPager" class="filter-bar" style="justify-content:center;"></div>`;

  try {
    all = await api.get('/admin/users');
    bindEvents();
    apply();
  } catch (err) {
    root.querySelector('#userTbody').innerHTML = `<tr><td colspan="7"><div class="empty sm">${icon('alert')} ${bn('ব্যবহারকারী লোড করতে ব্যর্থ হয়েছে।', 'Failed to load users.')}</div></td></tr>`;
  }

  function bindEvents() {
    const debounce = (fn, ms) => { let tm; return (...a) => { clearTimeout(tm); tm = setTimeout(() => fn(...a), ms); }; };
    document.getElementById('uSearch').addEventListener('input', debounce(() => { state.q = document.getElementById('uSearch').value.trim().toLowerCase(); state.page = 0; apply(); }, 250));
    document.getElementById('uGroup').addEventListener('change', () => { state.group = document.getElementById('uGroup').value; state.page = 0; apply(); });
    document.getElementById('uDistrict').addEventListener('input', debounce(() => { state.district = document.getElementById('uDistrict').value.trim().toLowerCase(); state.page = 0; apply(); }, 250));
    document.getElementById('uRole').addEventListener('change', () => { state.role = document.getElementById('uRole').value; state.page = 0; apply(); });
    root.querySelectorAll('.sort-link').forEach(a => a.addEventListener('click', e => {
      e.preventDefault();
      const key = a.dataset.sort;
      if (state.sort === key) state.dir *= -1; else { state.sort = key; state.dir = -1; }
      state.page = 0;
      apply();
    }));
  }

  function filtered() {
    let rows = all;
    if (state.q) rows = rows.filter(u => (u.name || '').toLowerCase().includes(state.q) || (u.phone || '').includes(state.q));
    if (state.group) rows = rows.filter(u => (u.blood_group || '') === state.group);
    if (state.district) rows = rows.filter(u => (u.district || '').toLowerCase().includes(state.district));
    if (state.role) rows = rows.filter(u => (u.role || 'donor') === state.role);
    rows = [...rows].sort((a, b) => {
      let va = a[state.sort], vb = b[state.sort];
      if (state.sort === 'name') { va = (a.name || '').toLowerCase(); vb = (b.name || '').toLowerCase(); }
      else if (state.sort === 'created_at') { va = a.created_at || 0; vb = b.created_at || 0; }
      if (va == null) va = '';
      if (vb == null) vb = '';
      return va < vb ? state.dir : va > vb ? -state.dir : 0;
    });
    return rows;
  }

  function apply() {
    const rows = filtered();
    document.getElementById('usersCount').textContent = `${rows.length} ${bn('জন', 'users')}`;
    const pages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
    if (state.page >= pages) state.page = pages - 1;
    const slice = rows.slice(state.page * PAGE_SIZE, state.page * PAGE_SIZE + PAGE_SIZE);
    document.getElementById('userTbody').innerHTML = slice.length === 0
      ? `<tr><td colspan="7"><div class="empty sm">${icon('info')} ${bn('কোনো ব্যবহারকারী পাওয়া যায়নি।', 'No users found.')}</div></td></tr>`
      : slice.map(u => `
        <tr>
          <td class="bold">${esc(u.name)}</td>
          <td>${bloodBadge(u.blood_group)}</td>
          <td dir="ltr" class="mono">${esc(u.phone || '—')}</td>
          <td>${esc(u.district || '—')}</td>
          <td><label class="switch-inline sm"><input type="checkbox" data-id="${u.id}" class="availTgl" ${u.is_available ? 'checked' : ''}/><span class="switch"></span></label></td>
          <td><span class="badge ${u.role === 'super_admin' ? 'red' : u.role === 'admin' ? 'blue' : u.role === 'sub_admin' ? 'green' : 'gray'}">${esc(u.role || 'donor')}</span></td>
          <td class="ta-r"><button class="btn light sm" data-view="${u.id}">${icon('user')} ${bn('বিস্তারিত', 'View')}</button></td>
        </tr>`).join('');

    root.querySelectorAll('.availTgl').forEach(c => c.addEventListener('change', () => toggleAvail(c)));
    root.querySelectorAll('[data-view]').forEach(b => b.addEventListener('click', () => showDetail(b.dataset.view)));

    document.getElementById('userPager').innerHTML = pages > 1
      ? `<button class="btn light sm" id="pgPrev" ${state.page === 0 ? 'disabled' : ''}>${bn('আগের', 'Prev')}</button>
         <span class="muted" style="font-size:.72rem;">${state.page + 1} / ${pages}</span>
         <button class="btn light sm" id="pgNext" ${state.page >= pages - 1 ? 'disabled' : ''}>${bn('পরের', 'Next')}</button>`
      : '';
    document.getElementById('pgPrev')?.addEventListener('click', () => { state.page--; apply(); });
    document.getElementById('pgNext')?.addEventListener('click', () => { state.page++; apply(); });
  }

  async function toggleAvail(c) {
    try {
      await api.patch(`/admin/users/${c.dataset.id}/suspend`, { suspend: !c.checked });
      toast(bn('স্থিতি আপডেট হয়েছে', 'Status updated'), 'success');
    } catch (err) {
      toast(err.message || 'Failed', 'error');
      c.checked = !c.checked;
    }
  }

  async function showDetail(id) {
    try {
      const u = await api.get(`/admin/users/${id}`);
      const isBn = (localStorage.getItem('bh_lang') || 'bn') === 'bn';
      const rows = [
        [t('name'), u.name, true],
        [t('bloodGroup'), u.blood_group || bn('দেওয়া হয়নি', 'Not provided')],
        [t('contact'), u.phone],
        [t('district'), u.district || '—'],
        [bn('উপজেলা', 'Upazila'), u.upazila || '—'],
        [bn('ইউনিয়ন', 'Union'), u.union_area || '—'],
        [bn('বয়স', 'Age'), u.age != null ? `${u.age} ${bn('বছর', 'yrs')}` : '—'],
        [bn('ওজন', 'Weight'), u.weight != null ? `${u.weight} kg` : '—'],
        [bn('লিঙ্গ', 'Gender'), u.gender || '—'],
        [bn('জরুরি যোগাযোগ', 'Emergency Contact'), u.emergency_contact || '—'],
        [bn('ভূমিকা', 'Role'), u.role],
        [bn('NID স্ট্যাটাস', 'NID Status'), u.nid?.status || bn('অনুরোধ করা হয়নি', 'Not requested')],
        [bn('মোট দান', 'Total Donations'), u.donationsCount ?? u.total_donations ?? 0],
        [bn('রক্তের অনুরোধ', 'Blood Requests'), u.requestsCount ?? 0],
        [bn('সদস্য হয়েছেন', 'Member Since'), u.created_at ? new Date(u.created_at * 1000).toLocaleDateString(isBn ? 'bn-BD' : 'en-GB') : '—'],
      ];
      const modal = document.createElement('div');
      modal.className = 'modal-overlay';
      modal.innerHTML = `
        <div class="modal">
          <div class="modal-head"><h3>${icon('user')} ${esc(u.name)}</h3>
            <button class="modal-close" data-close>×</button></div>
          <div class="modal-body">
            ${rows.map(([k, v, bold]) => `
              <div class="mini-row"><span><small>${esc(k)}</small></span><strong class="${bold ? 'bold' : ''}" ${k === t('contact') ? 'dir="ltr"' : ''}>${esc(v)}</strong></div>`).join('')}
          </div>
          <div class="modal-foot">
            <button class="btn light sm" data-close>${esc(t('close'))}</button>
          </div>
        </div>`;
      document.body.appendChild(modal);
      modal.addEventListener('click', e => { if (e.target === modal || e.target.hasAttribute('data-close')) modal.remove(); });
    } catch (err) {
      toast(err.message || 'Failed', 'error');
    }
  }
}