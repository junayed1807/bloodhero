// Admin Hierarchy Management (Super Admin only)
import { t, lang } from '../../../js/i18n.js';
import { esc, icon, toast } from '../../../js/ui.js';
import { API_BASE } from '../../../shared/js/api-config.js';
const $ = s => document.querySelector(s);

async function apiFetch(path, options = {}) {
  const token = localStorage.getItem('bh_token');
  const headers = { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` };
  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw { ...data, status: res.status };
  return data;
}

export async function renderAdminHierarchy(root) {
  let admins = [];
  try {
    admins = await apiFetch('/hierarchy/admins');
  } catch (e) {
    toast('Failed to load admin accounts', 'error');
  }

  root.innerHTML = `
    <div class="admin-hero">
      <div><h2>ðŸ›¡ï¸ Admin Management</h2><p class="muted">Super Admin only — manage admin accounts</p></div>
      <button class="btn primary sm" id="createAdminBtn">${icon('add')} Create Admin</button>
    </div>
    <div class="table-wrap panel">
      <table class="bh-table">
        <thead>
          <tr>
            <th>Name</th><th>Phone</th><th>Role</th><th>Status</th><th>Invited By</th><th>Created</th><th class="ta-r">Actions</th>
          </tr>
        </thead>
        <tbody>
          ${admins.length === 0 ? `<tr><td colspan="7" style="text-align:center;color:var(--muted)">No admin accounts</td></tr>` :
          admins.map(a => `
            <tr data-id="${a.account_id}" data-phone="${a.phone}" data-role="${a.role_name}">
              <td class="bold">${esc(a.name)}</td>
              <td dir="ltr" class="mono">${esc(a.phone)}</td>
              <td>${esc(a.role_name)}</td>
              <td><span class="badge ${a.status === 'active' ? 'green' : a.status === 'suspended' ? 'amber' : 'red'}">${esc(a.status)}</span></td>
              <td>${esc(a.invited_by_name || '—')}</td>
              <td>${a.created_at ? new Date(a.created_at * 1000).toLocaleString() : '—'}</td>
              <td class="ta-r">
                ${a.role_name !== 'super_admin' ? `
                  <select class="actSelect" data-id="${a.account_id}">
                    <option value="">${esc(t('action'))}</option>
                    <option value="suspend">Suspend</option>
                    <option value="activate">Activate</option>
                    <option value="disable">Disable</option>
                    <option value="revoke">Revoke</option>
                    <option value="restore">Restore</option>
                  </select>` : `<span class="muted">Protected</span>`}
                <button class="btn danger-ghost sm delBtn" data-id="${a.account_id}" data-role="${a.role_name}" data-phone="${a.phone}" ${a.role_name === 'super_admin' && (a.phone === '01835038064' || a.phone === '+8801712345678') ? 'disabled' : ''}>${icon('close')}</button>
              </td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>`;

  // Create admin modal
  $('#createAdminBtn').addEventListener('click', () => {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
      <div class="modal">
        <div class="modal-head"><h3>${icon('add')} Create Admin</h3><button class="modal-close">${icon('close')}</button></div>
        <div class="modal-body">
          <label class="field-row"><span>Phone Number</span><input class="field" id="newAdminPhone" type="tel" value="+880" required /></label>
          <label class="field-row"><span>${esc(t('name'))}</span><input class="field" id="newAdminName" required /></label>
          <label class="field-row"><span>Password</span><input class="field" id="newAdminPass" type="password" required /></label>
        </div>
        <div class="modal-foot">
          <button class="btn light sm modal-cancel">${esc(t('cancel'))}</button>
          <button class="btn primary sm modal-save">${esc(t('save'))}</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    modal.querySelector('.modal-cancel').addEventListener('click', () => modal.remove());
    modal.querySelector('.modal-close').addEventListener('click', () => modal.remove());
    modal.querySelector('.modal-save').addEventListener('click', async () => {
      const phone = modal.querySelector('#newAdminPhone').value.trim();
      const name = modal.querySelector('#newAdminName').value.trim();
      const password = modal.querySelector('#newAdminPass').value.trim();
      try {
        await apiFetch('/hierarchy/admins', { method: 'POST', body: JSON.stringify({ phone, name, password }) });
        toast('Admin created', 'success');
        modal.remove();
        renderAdminHierarchy(root);
      } catch (e) {
        toast(e.error || 'Failed to create admin', 'error');
      }
    });
  });

  // Handle action select
  root.querySelectorAll('.actSelect').forEach(sel => {
    sel.addEventListener('change', async () => {
      const id = sel.dataset.id;
      const action = sel.value;
      if (!action) return;
      try {
        await apiFetch(`/hierarchy/admins/${id}`, { method: 'PATCH', body: JSON.stringify({ action }) });
        toast(`Admin ${action}ed`, 'success');
        sel.value = '';
        renderAdminHierarchy(root);
      } catch (e) {
        toast(e.error || 'Failed', 'error');
      }
    });
  });

  // Handle delete
  root.querySelectorAll('.delBtn').forEach(btn => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.id;
      const role = btn.dataset.role;
      const phone = btn.dataset.phone;
      if (role === 'super_admin' && (phone === '01835038064' || phone === '+8801712345678')) {
        toast('Cannot delete protected Super Admin', 'error');
        return;
      }
      if (!confirm('Delete this admin account?')) return;
      try {
        await apiFetch(`/hierarchy/admins/${id}`, { method: 'DELETE' });
        toast('Admin deleted', 'success');
        renderAdminHierarchy(root);
      } catch (e) {
        toast(e.error || 'Failed', 'error');
      }
    });
  });
}
