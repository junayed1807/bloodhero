// Audit Logs Viewer — with server-side visibility filtering
import { t, lang } from '../../../js/i18n.js';
import { esc, icon, toast } from '../../../js/ui.js';
import { API_BASE } from '../../../shared/js/api-config.js';
const $ = s => document.querySelector(s);

async function apiFetch(path, options = {}) {
  const token = localStorage.getItem('bh_token');
  const headers = { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` };
  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw { ...data, status: res.status };
  return data;
}

export async function renderAdminAudit(root) {
  let logs = [];
  let actorRole = '';
  let action = '';
  let targetType = '';

  const state = JSON.parse(localStorage.getItem('bh_admin_state') || '{}');
  const isSuperAdmin = state.role === 'super_admin';

  const filterRow = `
    <div class="admin-hero">
      <div><h2>${icon('check')} ${esc(t('auditLog'))}</h2>
        <p class="muted">${state.role === 'super_admin' ? 'SYSTEM scope — full visibility' : state.role === 'admin' ? 'ADMIN scope — admin + sub-admin activity only' : 'SUB-ADMIN scope — own activity only'}
        ${!isSuperAdmin ? '<span style="color:red;"> — you cannot view Super Admin activity</span>' : ''}</p>
      </div>
      <div class="filter-bar" style="display:flex;gap:8px;flex-wrap:wrap;">
        ${isSuperAdmin ? `<input class="field sm permInput" id="auditRole" placeholder="actor role" style="width:120px;" />` : ''}
        <input class="field sm permInput" id="auditAction" placeholder="action" style="width:140px;" />
        <input class="field sm permInput" id="auditTarget" placeholder="target type" style="width:140px;" />
        <button class="btn primary sm" id="auditFilterBtn">${icon('filter')} Filter</button>
        <button class="btn light sm" id="auditRefreshBtn">${icon('list')} Refresh</button>
      </div>
    </div>
  `;

  root.innerHTML = filterRow + `<div class="table-wrap panel"><table class="bh-table">
    <thead><tr>
      <th>Actor</th><th>Role</th><th>Action</th><th>Target</th><th>Description</th><th>IP</th><th>Date</th>
    </tr></thead>
    <tbody id="auditTableBody">
      <tr><td colspan="7" style="text-align:center;color:var(--muted)">${icon('loading')} Loading...</td></tr>
    </tbody>
  </table></div>`;

  async function loadLogs() {
    const params = new URLSearchParams();
    if (isSuperAdmin && $('#auditRole')) params.set('actor_role', $('#auditRole').value);
    if ($('#auditAction').value) params.set('action', $('#auditAction').value);
    if ($('#auditTarget').value) params.set('target_type', $('#auditTarget').value);
    try {
      const result = await apiFetch(`/hierarchy/audit-logs?${params.toString()}`);
      logs = result.logs || [];
      const tbody = $('#auditTableBody');
      if (logs.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;color:var(--muted)">No audit records</td></tr>`;
      } else {
        tbody.innerHTML = logs.map(l => `
          <tr>
            <td class="mono" style="font-size:.68rem;">${esc((l.admin_id || 'system').slice(0, 8))}</td>
            <td><span class="badge ${l.actor_role === 'super_admin' ? 'red' : l.actor_role === 'admin' ? 'blue' : 'gray'}">${esc(l.actor_role)}</span></td>
            <td class="mono" style="font-size:.68rem;">${esc(l.action)}</td>
            <td class="mono" style="font-size:.68rem;">${esc(l.target_type || '—')}/${l.target_id ? esc((l.target_id || '').slice(0, 8)) : ''}</td>
            <td style="font-size:.68rem;max-width:240px;">${esc(l.description || '')}</td>
            <td class="mono" style="font-size:.64rem;">${esc(l.ip_address || '—')}</td>
            <td class="mono" style="font-size:.64rem;">${new Date(l.created_at * 1000).toLocaleString()}</td>
          </tr>
        `).join('');
      }
    } catch (e) {
      if (e.status === 403) {
        $('#auditTableBody').innerHTML = `<tr><td colspan="7" style="text-align:center;color:red;">${icon('alert')} ${esc(e.error || 'Access denied — you cannot view this audit data')}</td></tr>`;
      } else {
        toast(e.error || 'Failed to load audit logs', 'error');
      }
    }
  }

  $('#auditFilterBtn').addEventListener('click', loadLogs);
  $('#auditRefreshBtn').addEventListener('click', loadLogs);
  await loadLogs();
}
