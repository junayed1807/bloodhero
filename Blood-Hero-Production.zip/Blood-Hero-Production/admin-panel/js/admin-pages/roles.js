// Roles & Permissions Management (Super Admin only)
import { t, lang } from '../../../js/i18n.js';
import { esc, icon, toast } from '../../../js/ui.js';
import { API_BASE } from '../../../shared/js/api-config.js';
const $ = s => document.querySelector(s);

async function apiFetch(path, options = {}) {
  const token = localStorage.getItem('bh_token');
  const headers = { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` };
  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw { ...data, status: res.status };
  return data;
}

export async function renderAdminRoles(root) {
  let rolesData = null;

  root.innerHTML = `
    <div class="admin-hero">
      <div><h2>${icon('settings')} Roles & Permissions</h2><p class="muted">Manage role hierarchy and granular permissions (Super Admin only)</p></div>
      <button class="btn light sm" id="rolesRefreshBtn">${icon('list')} Refresh</button>
    </div>
    <div class="table-wrap panel">
      <table class="bh-table">
        <thead><tr><th>Role</th><th>Level</th><th>Permissions</th><th>Permission Count</th><th>Actions</th></tr></thead>
        <tbody id="rolesTableBody"><tr><td colspan="5" style="text-align:center;color:var(--muted)">${icon('loading')} Loading...</td></tr></tbody>
      </table>
    </div>`;

  async function loadRoles() {
    try {
      rolesData = await apiFetch('/hierarchy/roles');
      const tbody = $('#rolesTableBody');
      if (!rolesData.roles || rolesData.roles.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;color:var(--muted)">No roles</td></tr>`;
        return;
      }
      tbody.innerHTML = rolesData.roles.map(r => {
        const isProtected = r.name === 'super_admin';
        const permCount = r.permissions?.length || 0;
        return `
          <tr data-role="${r.name}" data-roleid="${r.id}">
            <td class="bold">${esc(r.display_name)}</td>
            <td class="mono">${r.level}</td>
            <td class="mono" style="font-size:.68rem;max-width:300px;">${r.permissions ? esc(r.permissions.join(', ')) : '<span class="muted">None</span>'}</td>
            <td>${permCount}</td>
            <td>
              ${isProtected ? '<span class="muted">Protected</span>' : `<button class="btn ghost sm editPermsBtn" data-role="${r.name}" data-roleid="${r.id}">${icon('settings')} Edit</button>`}
            </td>
          </tr>
        `;
      }).join('');

      // Attach edit handlers
      tbody.querySelectorAll('.editPermsBtn').forEach(btn => {
        btn.addEventListener('click', async () => {
          const roleId = btn.dataset.roleid;
          const roleName = btn.dataset.role;
          openPermissionModal(roleId, roleName);
        });
      });
    } catch (e) {
      toast(e.error || 'Failed to load roles', 'error');
    }
  }

  function openPermissionModal(roleId, roleName) {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    const allPerms = rolesData.permissions || [];
    modal.innerHTML = `
      <div class="modal" style="min-width:480px;">
        <div class="modal-head"><h3>Edit Permissions — ${roleName}</h3><button class="modal-close">${icon('close')}</button></div>
        <div class="modal-body">
          <div class="perm-grid" style="max-height:280px;overflow-y:auto;border:1px solid var(--line);padding:8px;border-radius:6px;">
            ${allPerms.map(p => `
              <label style="display:flex;align-items:center;gap:6px;padding:4px;">
                <input type="checkbox" name="perms" value="${p.code}" class="permCheck" data-module="${p.module}" />
                <span style="font-size:.72rem;">${esc(p.label || p.code)}</span>
              </label>
            `).join('')}
          </div>
        </div>
        <div class="modal-foot">
          <button class="btn light sm modal-cancel">${esc(t('cancel'))}</button>
          <button class="btn primary sm modal-save">Save Permissions</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    // Load current permissions for this role
    apiFetch(`/hierarchy/roles/${roleId}/permissions`)
      .then(detail => {
        if (detail.permissions) {
          detail.permissions.forEach(code => {
            const cb = modal.querySelector(`.permCheck[value="${code}"]`);
            if (cb) cb.checked = true;
          });
        }
      })
      .catch(() => {});

    modal.querySelector('.modal-cancel').addEventListener('click', () => modal.remove());
    modal.querySelector('.modal-close').addEventListener('click', () => modal.remove());
    modal.querySelector('.modal-save').addEventListener('click', async () => {
      const perms = Array.from(modal.querySelectorAll('input[name="perms"]:checked')).map(c => c.value);
      try {
        await apiFetch(`/hierarchy/roles/${roleId}/permissions`, {
          method: 'POST', body: JSON.stringify({ permissionCodes: perms })
        });
        toast(`${perms.length} permissions assigned to ${roleName}`, 'success');
        modal.remove();
        loadRoles();
      } catch (e) {
        toast(e.error || 'Failed', 'error');
      }
    });
  }

  $('#rolesRefreshBtn').addEventListener('click', loadRoles);
  await loadRoles();
}
