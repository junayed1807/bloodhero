// Security Events Viewer
import { t, lang } from '../../../js/i18n.js';
import { esc, icon, toast } from '../../../js/ui.js';
import { API_BASE } from '../../../shared/js/api-config.js';
const $ = s => document.querySelector(s);

async function apiFetch(path, options = {}) {
  const token = localStorage.getItem('bh_token');
  const headers = { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` };
  const res = await fetch(`${API_BASE}${path}`, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw { ...data, status: res.status };
  return data;
}

export async function renderAdminSecurity(root) {
  root.innerHTML = `
    <div class="admin-hero">
      <div><h2>${icon('alert')} Security Events</h2><p class="muted">Monitor unauthorized access attempts and security events</p></div>
      <div class="filter-bar" style="display:flex;gap:8px;">
        <input class="field sm" id="sevFilter" placeholder="severity" style="width:120px;" />
        <input class="field sm" id="typeFilter" placeholder="event type" style="width:160px;" />
        <button class="btn primary sm" id="secFilterBtn">${icon('filter')} Filter</button>
        <button class="btn light sm" id="secRefreshBtn">${icon('list')} Refresh</button>
      </div>
    </div>
    <div class="table-wrap panel">
      <table class="bh-table">
        <thead><tr><th>Actor</th><th>Role</th><th>Event Type</th><th>Target</th><th>Description</th><th>Severity</th><th>Date</th></tr></thead>
        <tbody id="secTableBody"><tr><td colspan="7" style="text-align:center;color:var(--muted)">${icon('loading')} Loading...</td></tr></tbody>
      </table>
    </div>`;

  async function loadEvents() {
    const params = new URLSearchParams();
    if ($('#sevFilter').value) params.set('severity', $('#sevFilter').value);
    if ($('#typeFilter').value) params.set('eventType', $('#typeFilter').value);
    try {
      const result = await apiFetch(`/hierarchy/security-events?${params.toString()}`);
      const events = result.events || [];
      const tbody = $('#secTableBody');
      if (events.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;color:var(--muted)">No security events</td></tr>`;
      } else {
        tbody.innerHTML = events.map(e => `
          <tr>
            <td class="mono" style="font-size:.68rem;">${esc((e.actor_id || 'system').slice(0, 8))}</td>
            <td>${esc(e.actor_role || '—')}</td>
            <td class="mono" style="font-size:.68rem;">${esc(e.event_type)}</td>
            <td class="mono" style="font-size:.68rem;">${esc(e.target_type || '—')}</td>
            <td style="font-size:.68rem;max-width:240px;">${esc(e.description || '')}</td>
            <td><span class="badge ${e.severity === 'critical' ? 'red' : e.severity === 'high' ? 'amber' : e.severity === 'medium' ? 'blue' : 'gray'}">${esc(e.severity)}</span></td>
            <td class="mono" style="font-size:.64rem;">${new Date(e.created_at * 1000).toLocaleString()}</td>
          </tr>
        `).join('');
      }
    } catch (e) {
      toast(e.error || 'Failed to load security events', 'error');
    }
  }

  $('#secFilterBtn').addEventListener('click', loadEvents);
  $('#secRefreshBtn').addEventListener('click', loadEvents);
  await loadEvents();
}
