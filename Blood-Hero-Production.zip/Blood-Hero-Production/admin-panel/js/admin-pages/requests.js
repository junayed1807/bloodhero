// Admin Requests Management
import { t, lang } from '../../../js/i18n.js';
import { esc, icon, bloodBadge, timeAgo, statusBadge, toast } from '../../../js/ui.js';
import { API_BASE } from '../../../shared/js/api-config.js';

export async function renderAdminRequests(root) {
  let list = [];
  try {
    const res = await fetch(`${API_BASE}/requests`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('bh_token')}` }
    });
    if (res.ok) list = await res.json();
  } catch {}

  root.innerHTML = `
    <div class="admin-hero"><div><h2>${esc(t('reqMgmt'))}</h2><p class="muted">${list.filter(r => r.status === 'pending').length} ${esc(t('statusPending'))}</p></div></div>
    <div class="card-list">
      ${list.length === 0 ? `<div class="empty">${icon('list')} —</div>` : list.map(r => `
        <article class="req-card ${r.urgency === 'critical' ? 'emg' : ''} admin">
          <div class="req-main">${bloodBadge(r.blood_group)}
            <div class="req-info">
              <h4>${esc(r.patient_name || '—')} · ${esc(r.hospital || '—')}</h4>
              <p>${r.units} ${esc(t('units'))} · ${r.urgency === 'critical' ? `<span class="badge red">${esc(t('critical'))}</span>` : r.urgency === 'urgent' ? `<span class="badge amber">${esc(t('urgent'))}</span>` : ''} ${statusBadge(r.status)}</p>
              <p class="loc">${icon('location')} ${esc([r.upazila, r.district].filter(Boolean).join(', ') || '—')} · ${timeAgo(r.created_at || Date.now(), lang() === 'bn')}</p>
            </div>
          </div>
          <div class="req-actions">
            ${r.status === 'pending' ? `
              <button class="btn success sm" data-act="accepted" data-id="${r.id}">${icon('check')} ${esc(t('approve'))}</button>
              <button class="btn ghost sm" data-act="cancelled" data-id="${r.id}">${icon('close')} ${esc(t('reject'))}</button>` : ''}
            <button class="btn danger-ghost sm" data-act="__del" data-id="${r.id}">${icon('close')}</button>
          </div>
        </article>`).join('')}
    </div>`;
  root.querySelectorAll('[data-act]').forEach(b => b.addEventListener('click', async () => {
    const id = b.dataset.id, act = b.dataset.act;
    if (act === '__del') {
      if (!confirm(lang() === 'bn' ? 'মুছে ফেলবেন?' : 'Delete this request?')) return;
      await fetch(`${API_BASE}/requests/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${localStorage.getItem('bh_token')}` }
      });
    } else {
      await fetch(`${API_BASE}/requests/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('bh_token')}` },
        body: JSON.stringify({ status: act })
      });
    }
    toast('✓', 'success');
    renderAdminRequests(root);
  }));
}
