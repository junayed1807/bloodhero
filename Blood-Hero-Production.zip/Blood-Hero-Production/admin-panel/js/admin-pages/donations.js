// Admin Donations Verification
import { t, lang } from '../../../js/i18n.js';
import { esc, icon, bloodBadge, toast } from '../../../js/ui.js';
import { API_BASE } from '../../../shared/js/api-config.js';

export async function renderAdminDonations(root) {
  let list = [];
  try {
    const res = await fetch(`${API_BASE}/admin/donations`, {
      headers: { Authorization: `Bearer ${localStorage.getItem('bh_token')}` }
    });
    if (res.ok) list = await res.json();
  } catch {}

  root.innerHTML = `
    <div class="admin-hero"><div><h2>${esc(t('donationProofs'))}</h2><p class="muted">${list.length} total</p></div></div>
    <div class="table-wrap panel">
      <table class="bh-table">
        <thead><tr><th>${esc(t('donorName'))}</th><th>${esc(t('hospital'))}</th><th>${esc(t('bloodGroup'))}</th><th>${esc(t('status'))}</th><th class="ta-r">${esc(t('action'))}</th></tr></thead>
        <tbody>
          ${list.map(d => `
            <tr>
              <td class="bold">${esc(d.donor_id || '—')}</td>
              <td>${esc(d.hospital || '—')}</td>
              <td>${bloodBadge(d.blood_group)}</td>
              <td><span class="badge ${d.status === 'verified' ? 'green' : d.status === 'pending_verification' ? 'amber' : d.status === 'rejected' ? 'red' : 'gray'}">${esc(d.status || 'pending')}</span></td>
              <td class="ta-r">${d.status === 'pending_verification' ? `
                <button class="btn success sm" data-act="verified" data-id="${d.id}">${icon('check')}</button>
                <button class="btn danger-ghost sm" data-act="rejected" data-id="${d.id}">${icon('close')}</button>` : '—'}
              </td>
            </tr>`).join('') || `<tr><td colspan="5" style="text-align:center;color:var(--muted)">—</td></tr>`}
        </tbody>
      </table>
    </div>`;
  root.querySelectorAll('[data-act]').forEach(b => b.addEventListener('click', async () => {
    const id = b.dataset.id, act = b.dataset.act;
    const endpoint = act === 'verified' ? 'approve' : 'reject';
    const body = act === 'rejected' ? { rejection_reason: 'Rejected by admin', admin_note: '' } : {};
    await fetch(`${API_BASE}/admin/donations/${id}/${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('bh_token')}` },
      body: JSON.stringify(body)
    });
    toast('✓', 'success');
    renderAdminDonations(root);
  }));
}
