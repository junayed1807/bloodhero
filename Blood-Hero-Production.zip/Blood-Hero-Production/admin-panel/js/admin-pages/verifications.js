// Admin NID Verifications — review submissions (privacy: NID masked)
import { t } from '../../../js/i18n.js';
import { esc, icon, toast } from '../../../js/ui.js';
import { api, bn } from '../api-client.js';

export async function renderAdminVerifications(root) {
  let list = [];
  try {
    list = await api.get('/admin/nid-verifications');
  } catch (err) {
    root.innerHTML = `<div class="empty section">${icon('alert')} ${bn('লোড করতে ব্যর্থ হয়েছে।', 'Failed to load.')}</div>`;
    return;
  }

  root.innerHTML = `
    <div class="admin-hero"><div><h2>${esc(t('nidVerifications'))}</h2><p class="muted">${list.length} total</p></div></div>
    <div class="table-wrap panel">
      <table class="bh-table">
        <thead><tr><th>${esc(t('name'))}</th><th>${esc(t('phone'))}</th><th>NID</th><th>${esc(t('status'))}</th><th class="ta-r">${esc(t('action'))}</th></tr></thead>
        <tbody>
          ${list.length === 0
            ? `<tr><td colspan="5"><div class="empty sm">${icon('info')} ${bn('কোনো অনুরোধ নেই।', 'No requests yet.')}</div></td></tr>`
            : list.map(v => `
            <tr>
              <td class="bold">${esc(v.legal_name || '—')}</td>
              <td dir="ltr" class="mono">${esc((v.phone || v.user_phone || '')) || '—'}</td>
              <td class="mono">${esc((v.nid_number || '').slice(0, 4) + '••••')}</td>
              <td><span class="badge ${v.status === 'approved' ? 'green' : v.status === 'pending' ? 'amber' : 'red'}">${esc(v.status || 'pending')}</span></td>
              <td class="ta-r">${v.status === 'pending' ? `
                <button class="btn success sm" data-act="approved" data-id="${v.id}">${icon('check')} ${bn('অনুমোদন', 'Approve')}</button>
                <button class="btn danger-ghost sm" data-act="rejected" data-id="${v.id}">${icon('close')} ${bn('বাতিল', 'Reject')}</button>` : '—'}
              </td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
  root.querySelectorAll('[data-act]').forEach(b => b.addEventListener('click', async () => {
    try {
      await api.patch(`/admin/nid-verifications/${b.dataset.id}/status`, { status: b.dataset.act });
      toast(bn('রিভিউ সম্পন্ন', 'Review complete'), 'success');
      renderAdminVerifications(root);
    } catch (err) {
      toast(err.message || 'Failed', 'error');
    }
  }));
}