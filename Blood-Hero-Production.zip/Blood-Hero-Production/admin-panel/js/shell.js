// Admin panel shell helpers: theme toggle, language toggle, nav translations.
import { lang, setLang } from '../../js/i18n.js';

const THEME_KEY = 'bh_admin_theme';

export function getTheme() {
  return localStorage.getItem(THEME_KEY) || 'dark';
}

export function applyTheme() {
  const saved = getTheme();
  const theme = saved === 'system'
    ? (window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark')
    : saved;
  document.documentElement.setAttribute('data-theme', theme);
}

export function themeToggleHtml() {
  const dark = getTheme() === 'dark';
  return `<button class="btn light sm admin-toggle" id="themeToggle" title="Toggle theme">${dark ? '☀️' : '🌙'}</button>`;
}

export function bindThemeToggle() {
  document.getElementById('themeToggle')?.addEventListener('click', () => {
    const next = getTheme() === 'dark' ? 'light' : 'dark';
    localStorage.setItem(THEME_KEY, next);
    applyTheme();
    const btn = document.getElementById('themeToggle');
    if (btn) btn.textContent = next === 'dark' ? '☀️' : '🌙';
  });
}

export function langToggleHtml() {
  return `<button class="btn light sm admin-toggle" id="langToggle" title="Language">${lang() === 'bn' ? 'EN' : 'বাং'}</button>`;
}

export function bindLangToggle(reRender) {
  document.getElementById('langToggle')?.addEventListener('click', () => {
    setLang(lang() === 'bn' ? 'en' : 'bn');
    reRender();
  });
}

const NAV_BN = {
  'Admin Management': 'অ্যাডমিন ম্যানেজমেন্ট',
  'Sub-admins': 'সাব-অ্যাডমিন',
  'Security Events': 'সিকিউরিটি ইভেন্ট',
  'Login History': 'লগইন ইতিহাস',
  'Roles & Permissions': 'ভূমিকা ও অনুমতি',
  'permissions': 'টি অনুমতি',
};

export function navLabel(label) {
  if (lang() === 'bn') return NAV_BN[label] || label;
  return label;
}

export function adminThemeInit() {
  applyTheme();
  window.matchMedia('(prefers-color-scheme: light)').addEventListener?.('change', () => {
    if (getTheme() === 'system') applyTheme();
  });
}