# Blood Hero — Integrations

This file documents exactly what is real, what is stubbed, and what is not yet implemented.

## Real / Shipped

| Integration | Status | Notes |
|-------------|--------|-------|
| Firebase Auth (Phone OTP) | **Real** | Client-side only. Firestore Security Rules enforce admin checks. |
| Firebase Firestore | **Real** | Online mode. Falls back to localStorage demo data if unreachable. |
| Firebase Hosting / PWA | **Real** | Manifest + service worker registered. Offline shell caching enabled. |
| i18n (EN/BN) | **Real** | Full bilingual dictionary with Bangla default. |

## Stubbed / Behind Config Flag

| Integration | Status | Notes |
|-------------|--------|-------|
| `SmsProvider` | **Stubbed** | Interface exists in code (`NotificationChannel` pattern). Default driver logs to console. Swap in Twilio / BdNIC SMS when contract is ready. |
| `EmailProvider` | **Stubbed** | Interface exists. No real SMTP/transactional email wired. |
| `PaymentProvider` (bKash / Nagad / Rocket) | **Stubbed** | Interface + sandbox stub only. No real money movement. |
| `KycProvider` (NID/OTP identity) | **Stubbed** | Default path is `ManualReviewDriver` — admin verifies documents by hand in the admin panel. |

## Not Yet Implemented

| Feature | Status | Notes |
|---------|--------|-------|
| Web Push (VAPID) | **Not started** | Service worker supports push events, but no subscription flow or VAPID key pair generated yet. |
| NationalRegistryClient | **Not started** | Outbound API blueprint documented. Aggregate-only data export with API-key auth planned. |
| Demand prediction | **Not started** | Moving-average baseline over historical requests. Clearly labelled as estimate. |
| WhatsApp / USSD bot | **Out of scope** | PWA share links available instead. |

## Security Notes

- Firebase public API keys are **client identifiers** and are safe to expose per Firebase documentation. Access is controlled by Firestore Security Rules + App Check.
- Admin access is granted by creating a document in the `admins` collection (see `deploy/firebase-setup.md`).
- All PII masks happen client-side; in production, move PII redaction to a Cloud Function or trusted backend.
