# Blood Hero — Security Audit

Scope: authentication, authorization/RBAC, password handling, JWT/session, CORS,
CSRF, XSS, SQL injection, file upload, path traversal, rate limiting, input
validation, security headers, secrets management, error handling, logging,
database security, admin API protection, and private-document (NID) protection.

Findings are classified **CRITICAL / HIGH / MEDIUM / LOW**. Status refers to this
production copy. Where a fix is "open", it is documented here and must be resolved
in a controlled change cycle before a public production launch.

---

## CRITICAL

### C1 — Missing authorization on request-status changes
`PATCH /api/requests/:id/status` (`backend/routes/requests.js`) changes any
request's status without verifying that the caller owns the request or holds an
admin permission. Any authenticated user can cancel/accept/reject other people's
blood requests.
**Fix:** require `created_by === caller.id` OR `permissions.requests.approve/manage`.

### C2 — Repository-root static exposure (dev / `SERVE_STATIC=true`)
The single-server static mount served `express.static(path.join(__dirname, '..'))`,
exposing `backend/blood_hero.db`, `node_modules/`, `.env`, and source when the
backend runs in non-production mode or with `SERVE_STATIC=true`.
**Status: FIXED in this copy** — `backend/server.js` now installs a deny-list
middleware that returns 403 for `/backend`, `/node_modules`, `/.env`, `/docs`, and
any `*.db*`/`*.sqlite*` path before the static mount.

### C3 — Admin suspend/activate writes invalid status values
`backend/routes/hierarchy.js` suspend/activate writes the raw `action` string
(`'suspend'`/`'activate'`) into `users.status` and `admin_accounts.status` instead
of the computed `newStatus` (`'suspended'`/`'active'`), and never sets
`suspended_at`/`disabled_at`/`revoked_at`. Because admin login requires
`status === 'active'`, this can lock admins out.
**Fix:** map `action` → canonical status and set the corresponding timestamp column.

### C4 — Firestore rules allow privilege escalation and PII reads
Documented rules (`deploy/firebase-setup.md`) allow a `donors` document to
self-update its `role` field (role escalation) and allow any authenticated user to
read the `donors` collection (phone, emergency contact, address, weight, age).
**Fix:** deny `role` writes to non-superusers; restrict `donors` reads to the
owner or verified admins; prefer server-side RBAC over client rules.

### C5 — Forgeable client verification token
`js/db.js` generates a "verification token" by base64-encoding an object with a
hardcoded shared secret (`APP_SECRET`), which is not an HMAC and ships in the
client bundle — trivially forgeable.
**Fix:** issue random, expiring tokens server-side; verify with the backend.

---

## HIGH

### H1 — PII leaks on list endpoints
- `GET /api/donations` and `GET /api/donations/:id` return other users' donations
  with no ownership filter.
- `GET /api/requests` returns requester contact numbers for every request.
- `GET /api/admin/nid-verifications` and `/:id` return **full NID numbers**.
**Fix:** filter by ownership; mask NID server-side (return last 4 digits); require
`verification.nid` permission and redact on the API, not just the UI.

### H2 — Broken upload plumbing
`POST /api/donations/submit` and `POST /api/users/profile/picture` read
`req.file`/`req.files` but mount no `multer` middleware, so uploads via these
routes always fail (or fall back to Firestore base64, exceeding doc limits).
**Fix:** mount the existing `upload` middleware on these routes; keep file sizes
under limits; store in cloud object storage.

### H3 — Upload validation is mimetype-only
`backend/middleware/upload.js` checks Content-Type and extension only — no
magic-byte verification, and no content scanning. No cleanup on failure.
**Fix:** verify magic bytes; limit extensions; delete partial uploads on error;
reject executable MIME types; store private files with random names in private
object storage (never public).

### H4 — OTP bridge auto-provisions accounts
`/api/auth/otp/verify` creates a `users` row for any phone that verifies an OTP —
an open account-creation vector for spam/DB growth.
**Fix:** require an explicit signup step, or rate-limit provisioned accounts
strictly and verify ownership before activation.

### H5 — Production OTP fails closed without a real provider
`backend/services/sms-provider.js` throws in production when `SMS_PROVIDER=log`,
so OTP flows (login bridge, sub-admin two-step) are non-functional until a real
provider (Twilio) is configured.
**Fix:** configure Twilio env vars in production; keep fail-closed behavior.

### H6 — No production deployment configuration existed
There was no `vercel.json`, `render.yaml`, or equivalent, and production CORS
defaults to `origin: false`. Now added in `deploy/` (see `deploy/README.md`).
**Status: FIXED in this copy** (config only; deployment not performed).

### H7 — JWT in localStorage, no revocation on password change
Tokens live in `localStorage` (XSS-readable) and remain valid after a password
change (7-day expiry). Admin sessions store JWTs in `sessionStorage`.
**Fix:** prefer short-lived access tokens + rotation; invalidate issued tokens for
a user on password change (token version).

---

## MEDIUM

- **M1 — Hardcoded default super-admin phone**: `backend/middleware/auth.js`
  falls back to `01835038064`/`+8801712345678` for super-admin checks in dev.
  Seeding is dev-only (`NODE_ENV !== 'production'`), but the default should not be
  present in prod. → Remove dev-only seeding path in production.
- **M2 — In-memory per-process rate limiting**: `rate-limit` works per Render
  instance only; multiple instances share no bucket. → Use a shared store
  (Redis/Postgres) or keep a single instance.
- **M3 — Missing security headers**: no CSP, HSTS, or `Cache-Control` on the
  backend (Helmet-style headers are present: nosniff, frame-ancestors, referrer).
  → Add CSP for admin-panel assets; HSTS is handled at Render/Vercel edge.
- **M4 — Minimal input validation**: phone format, field lengths, and some body
  fields are not validated server-side. → Validate phone/email/blood-group/NID
  fields with a schema (see `backend/middleware/`).
- **M5 — Fire-and-forget DB writes + `foreign_keys = OFF`**: several `db.run`
  calls are not awaited and FK enforcement is disabled. → Await writes, enable
  FKs in PostgreSQL.
- **M6 — Donation-approval reward logic duplicated**: reward granting exists in
  both `admin.js` and `donations.js` (race-prone). → Single service.
- **M7 — Fabricated impact stat**: `totalLives = donations * 3` in
  `impact.js`. → Compute from verified donations only.
- **M8 — Demo mode grants admin UI**: localStorage demo fallback seeds
  `role: 'admin'` donors. → Never enable demo in production.
- **M9 — Broken/obsolete test artifacts**: `test_security.js`, `test-server.js`
  and root `test-*.js/html` were not runnable or obsolete; archived under
  `docs/archive/`. → Replace with real tests.
- **M10 — Repo hygiene / leak surface**: `node_modules/` present in the original
  folder; Firebase public keys + creator contact info in `js/config.js`.
  → Public keys are fine to commit, but creator PII should be reviewed.

---

## LOW

- `PRAGMA foreign_keys = OFF` — re-enable after audit of cascades.
- No DB backup automation configured (see `docs/DATABASE-BACKUP-AND-RECOVERY.md`).
- `express.json({ limit: '1mb' })` — fine, keep.
- `GET /api/admin/stats` requires `audit.view` — verify it's intentional for
  sub-admins.
- Legacy `admin_otp` rows compare against a hashed code — ensure no plaintext rows.
- `sw.js` correctly excludes `/api/`, `/uploads/`, `/admin-panel/` from caching.
- XSS: `esc()` helper used for user content (`js/ui.js`); one
  `document.write` in `profile.js` escapes its input — audit on change.
- Firebase SDK loaded from CDN without SRI — add SRI once pins chosen.
- No structured logging / alerting — add request logging and error alerting.

---

## Recommendations summary (priority order)

1. Fix C1, C3 (authorization/status integrity), verify C2 fix.
2. Fix C4, C5 (client-side trust boundaries).
3. Fix H1 (mask NID; ownership filters), H2, H3 (upload security).
4. Fix H4, H5 (OTP provisioning + real provider).
5. H6/H7 + M-items (deployment config is done; add token versioning, CSP, shared
   rate limiting, validation).
6. Cleanup: remove dev-only seeding path, M7 stat, M9 artifacts (archived),
   M10 PII review, add logging/alerting.

## Verified-good practices (preserved)
- Passwords bcrypt-hashed (cost 12); no plaintext storage.
- JWT production secret fail-closed (≥32 chars).
- Admin RBAC enforced server-side per route.
- Error handler never leaks stack traces/paths to clients.
- Service worker never caches private/API responses.
- CORS locked down in production (empty `CORS_ORIGIN` → same-origin only).
- `uploads/` ignored by Git; DB files ignored by Git.