# Blood Hero — Environment Variables

Complete reference for every environment variable used by the project.
**Never commit real secrets.** Copy `.env.example` → `.env` and fill in real values.

---

## Backend (`backend/`)

Loaded by `dotenv` from `backend/.env`. Reference file: `backend/.env.example`.

| Variable | Purpose | Required | Development | Production |
|---|---|---|---|---|
| `PORT` | HTTP listen port | No (default `3000`) | `3000` | Render assigns `PORT` automatically |
| `HOST` | Bind host | No (default `0.0.0.0`) | `0.0.0.0` | `0.0.0.0` (containers) |
| `NODE_ENV` | `development` / `production` | **Yes** | `development` | `production` |
| `TRUST_PROXY` | Trust `X-Forwarded-*` (needed behind Render's TLS proxy) | No | `false` | `true` |
| `JWT_SECRET` | JWT signing secret. **Fail-closed: server refuses to boot in production with a default/weak value (< 32 chars)** | **Yes (prod)** | any value | Random, ≥32 chars, kept secret |
| `DB_PATH` | SQLite database file path | No | `./blood_hero.db` | Absolute path on persistent disk (Render) |
| `DATABASE_URL` | Managed PostgreSQL connection string | **Yes (after PG migration)** | — | `postgres://user:pass@host:5432/db` (secrets via Render, never in repo) |
| `CORS_ORIGIN` | Comma-separated allowed cross-origin callers | No | empty (allow all in dev) | Your frontend origin(s), or leave empty for same-origin Vercel proxy |
| `ADMIN_INIT_PHONE` | Bootstrap the first production super-admin | No | — | Super-admin phone (set once) |
| `ADMIN_INIT_PASSWORD` | Bootstrap super-admin password | No | — | Strong password (set once) |
| `ADMIN_INIT_NAME` | Bootstrap super-admin display name | No | — | Optional |
| `SMS_PROVIDER` | `log` (dev) or a real provider | No (default `log`) | `log` | Real provider name |
| `TWILIO_SID` | Twilio Account SID | No | — | Yes (if using Twilio) |
| `TWILIO_AUTH_TOKEN` | Twilio Auth Token | No | — | Yes (if using Twilio) |
| `TWILIO_FROM` | Twilio sender number | No | — | Yes (if using Twilio) |
| `OTP_EXPIRY_SECONDS` | OTP validity | No (default `300`) | `300` | Tune as needed |
| `OTP_MAX_ATTEMPTS` | Max OTP verify attempts | No (default `3`) | `3` | Tune as needed |
| `OTP_RATE_LIMIT_WINDOW` | OTP request rate window (ms) | No (default `60000`) | `60000` | Tune |
| `OTP_RATE_LIMIT_MAX` | Max OTP requests per window | No (default `3`) | `3` | Tune |

### Where to configure (production)
- **Render**: dashboard → Service → Environment. Never put values in `render.yaml` if secret.
- **Local**: `backend/.env` (git-ignored).

---

## Frontend (static, no build step)

This static app resolves its backend URL at runtime through `shared/js/api-config.js`
(single source of truth). Resolution order:

1. `window.__CONFIG__.API_BASE` — injected at deploy time
2. `process.env.API_BASE` — build-time (only if you add a build step)
3. `'/api'` — same-origin default (Vercel proxies `/api/*` to Render via `vercel.json`)

### Reference file: `.env.example`

| Variable | Purpose | Required | Development | Production |
|---|---|---|---|---|
| `API_BASE` | Absolute backend URL | No (default `/api`) | `http://localhost:3000` via `__CONFIG__` | `https://api.YOUR-DOMAIN` via `__CONFIG__` |
| `VITE_APP_VERSION` | Informational version string | No | `2.0.0` | `2.0.0` |
| `FIREBASE_CONFIG` (via `__CONFIG__`) | Override Firebase public client config (defaults in `js/config.js`) | No | default | default or override |

### How to inject `__CONFIG__` (Vercel)
Add an inline script to `index.html` before the app bundle, or use a Vercel edge
middleware to inject it. Example:

```html
<script>
  window.__CONFIG__ = { API_BASE: 'https://api.YOUR-DOMAIN' };
</script>
```

Alternatively, keep `API_BASE` unset and let `vercel.json` proxy `/api/*` to the
backend (recommended — keeps the backend hostname out of the client).

---

## Never commit
- `.env`, `.env.local`, `.env.production`, any `.env.*` except `.env.example`
- Real `JWT_SECRET`, Twilio credentials, PostgreSQL credentials, API keys