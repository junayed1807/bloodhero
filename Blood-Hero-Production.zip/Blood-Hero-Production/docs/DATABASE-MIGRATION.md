# Blood Hero — Database Migration (SQLite → Managed PostgreSQL)

This document describes the current SQLite database and the path to managed
PostgreSQL. The reference SQLite database is **never** modified, moved, or
committed to the repository. Migration is a separate, controlled operation.

---

## 1. Current storage

- Engine: SQLite 3 via the native `sqlite3` Node package.
- File: `backend/blood_hero.db` (+ `-wal`, `-shm` when in WAL mode).
- Journal mode: `WAL` (`PRAGMA journal_mode = WAL` in `backend/database.js`).
- Foreign keys: currently `PRAGMA foreign_keys = OFF` (enforced in app logic).
- Timestamps: Unix epoch seconds stored as `INTEGER` (e.g. `created_at`).
- The database is recreated on boot: every table uses
  `CREATE TABLE IF NOT EXISTS`, and admin roles / permissions / badges are
  re-seeded idempotently with `INSERT OR IGNORE`.

## 2. Schema (tables, columns, keys)

All tables use a `TEXT` primary key (`uuid`). Timestamps default to
`strftime('%s','now')`.

| Table | Key columns | Notes |
|---|---|---|
| `users` | `id` PK, `phone` UNIQUE, `name`, `email`, `blood_group`, `district`, `upazila`, `union_area`, `age`, `weight`, `gender`, `address`, `emergency_contact`, `photo_url`, `role` (default `donor`), `last_donation`, `total_donations`, `points`, `stars`, `level`, `nid_status`, `is_available`, `is_verified`, `password_hash`, `created_at`, `updated_at` | Central identity table |
| `blood_requests` | `id` PK, `donor_id`, `patient_name`, `blood_group` NOT NULL, `component`, `units`, `urgency`, `hospital`, `district`, `upazila`, `union_area`, `contact` NOT NULL, `note`, `status` (default `pending`), `needed_by`, `accepted_by`, `created_by` → `users(id)`, `created_at`, `updated_at` | FK: created_by |
| `donations` | `id` PK, `request_id` → `blood_requests(id)`, `donor_id` → `users(id)`, `recipient_id`, `blood_group`, `hospital`, `donation_date`, `location`, `proof_url`, `status` (default `pending_verification`), `rejection_reason`, `reviewed_by`, `reviewed_at`, `admin_note`, `created_at` | FKs: donor, request |
| `reward_ledger` | `id` PK, `user_id` → `users(id)`, `donation_id` → `donations(id)`, `points`, `type`, `reason`, `created_at` | `UNIQUE(donation_id, user_id)` |
| `badges` | `id` PK, `name`, `description`, `icon`, `requirement_type`, `requirement_value` | Seeded 6 badge tiers |
| `user_badges` | `id` PK, `user_id` → `users(id)`, `badge_id` → `badges(id)`, `earned_at` | `UNIQUE(user_id, badge_id)` |
| `notifications` | `id` PK, `user_id` → `users(id)`, `type`, `title`, `body`, `data`, `read` | FK: user |
| `audit_logs` | `id` PK, `admin_id`, `action`, `target_type`, `target_id`, `description`, `metadata`, `ip_address`, `user_agent`, `created_at` | + migrated cols `actor_role`, `audit_scope`, `session_id` |
| `audit_logs_enhanced` | `id` PK, `admin_id` NOT NULL, `actor_role` NOT NULL, `audit_scope` NOT NULL, `action`, `target_type`, `target_id`, `description`, `metadata`, `ip_address`, `user_agent`, `session_id`, `created_at` | Visibility-isolated audit |
| `login_history` | `id` PK, `user_id` → `users(id)`, `phone`, `ip_address`, `user_agent`, `login_method`, `role`, `admin_role`, `success`, `failure_reason`, `session_id`, `created_at` | FK: user |
| `security_events` | `id` PK, `actor_id` → `users(id)`, `actor_role`, `event_type`, `target_type`, `target_id`, `description`, `ip_address`, `user_agent`, `severity`, `resolved`, `created_at` | FK: actor |
| `nid_verifications` | `id` PK, `user_id` → `users(id)`, `nid_number` NOT NULL, `dob`, `legal_name`, `status` (default `pending`), `reviewed_by`, `reviewed_at`, `rejection_reason`, `created_at` | **Contains full NID — treat as sensitive** |
| `request_matches` | `id` PK, `request_id` → `blood_requests(id)`, `donor_id` → `users(id)`, `score`, `status`, `notified_at`, `viewed_at`, `responded_at` | `UNIQUE(request_id, donor_id)` |
| `health_declarations` | `id` PK, `user_id` → `users(id)`, `score`, `eligible`, `reason`, `retry_date`, `valid_until`, `created_at` | FK: user |
| `referral_codes` | `id` PK, `user_id` → `users(id)`, `code` UNIQUE, `used_count` | FK: user |
| `conversion_events` | `id` PK, `user_id` → `users(id)`, `event_type`, `request_id`, `metadata` | FK: user |
| `donation_programs` | `id` PK, `recipient_id` → `users(id)`, `name`, `blood_group`, `interval_days`, `preferred_centre`, `preferred_donor_pool`, `next_request_date`, `active` | FK: recipient |
| `family_members` | `id` PK, `user_id` → `users(id)`, `name`, `blood_group`, `relation`, `phone`, `notes` | FK: user |
| `centers` | `id` PK, `name`, `type`, `district`, `upazila`, `address`, `phone`, `email`, `website`, `latitude`, `longitude`, `verified` | Location data |
| `ambulances` | `id` PK, `name`, `provider`, `phone`, `district`, `upazila`, `service_area`, `availability_status`, `is_verified`, `last_verified_at`, `notes` | Directory |
| `articles` | `id` PK, `title_bn`, `title_en`, `body_bn`, `body_en`, `slug` UNIQUE, `published` | Bilingual content |
| `areas` | `id` PK, `division`, `district`, `upazila`, `union_area`, `name_bn`, `name_en` | Location pickers |
| `settings` | `key` PK, `value`, `updated_at` | Key/value store |
| `super_admins` | `id` PK, `user_id` → `users(id)` | Links to `users` |
| `admin_roles` | `id` PK, `name`, `display_name`, `description`, `level`, `can_manage_admins`, `can_manage_sub_admins`, `can_view_super_admin_audit`, `can_assign_permissions` | 3 seeded roles |
| `permissions` | `id` PK, `code` UNIQUE, `name`, `module` | ~24 seeded perms |
| `role_permissions` | `id` PK, `role_id` → `admin_roles(id)`, `permission_id` → `permissions(id)` | `UNIQUE(role_id, permission_id)` |
| `admin_accounts` | `id` PK, `user_id` → `users(id)`, `role_id` → `admin_roles(id)`, `status` (default `pending_verification`), `invited_by`, `verified_at`, `suspended_at`, `disabled_at`, `revoked_at` | FKs: user, role, invited_by |
| `admin_invitations` | `id` PK, `phone`, `role_id` → `admin_roles(id)`, `invited_by`, `verification_code`, `code_expires_at`, `attempts`, `max_attempts`, `status` | FK: role, invited_by |
| `admin_otp` | `id` PK, `phone`, `admin_account_id` → `admin_accounts(id)`, `invited_by`, `role_id`, `step`, `otp_code` (hashed), `otp_expires_at`, `attempts`, `max_attempts`, `consumed` | Two-step OTP |
| `user_otp` | `id` PK, `phone`, `otp_hash`, `otp_expires_at`, `attempts`, `max_attempts`, `consumed` | Public app OTP bridge |

### Relationships (reference only)
- `users 1—N blood_requests (created_by)`, `users 1—N donations (donor_id)`
- `blood_requests 1—N donations`, `blood_requests 1—N request_matches`
- `users 1—N nid_verifications`, `users 1—N login_history`, `users 1—N audit_logs`
- `admin_roles N—N permissions` via `role_permissions`
- `admin_roles 1—N admin_accounts 1—1 users`, `super_admins 1—1 users`

### Indexes
- Unique indexes (implicit from `PRIMARY KEY`/`UNIQUE`): `users.phone`,
  `referral_codes.code`, `permissions.code`, `articles.slug`, `settings.key`,
  `reward_ledger(donation_id,user_id)`, `user_badges(user_id,badge_id)`,
  `request_matches(request_id,donor_id)`, `role_permissions(role_id,permission_id)`.
- No additional explicit secondary indexes are created; most lookups are by PK or
  by the `user_id`/`request_id` foreign-key columns (worth adding as indexes in
  PostgreSQL).

## 3. Existing data

The reference database file(s) hold application data (users, requests, audits,
verification records). They remain in the original project only. **Do not commit
them**; `*.db*` is git-ignored. For data parity checks during migration, use the
read-only exporter in `backend/scripts/migrate-sqlite-to-postgres.js`.

## 4. Migration strategy

The current backend is tightly coupled to the SQLite **callback API**
(`db.get`, `db.all`, `db.run`). PostgreSQL support requires one of:

- **Option A (recommended, minimal change):** introduce a small data-access layer
  (`backend/db/`) exposing `get/all/run` with the same signatures, backed by the
  `pg` pool in production and `sqlite3` in dev. Routes keep their logic; only the
  driver changes.
- **Option B:** full rewrite to `pg` promises + a query builder (larger change,
  higher risk).
- **Option C:** keep SQLite in production for the MVP (it is already in WAL mode)
  and migrate later behind a feature flag. Simplest first step; documented here so
  the decision is conscious.

### Recommended step order
1. Freeze schema: capture `backend/database.js` CREATE statements as the source of
   truth.
2. Create the PostgreSQL schema (translated DDL; see generator notes below).
3. Dry-run the read-only exporter to validate row counts and key invariants.
4. Migrate data in a transaction, mapping types:
   - `INTEGER` unix timestamps → `BIGINT` (keep epoch seconds to avoid churn)
   - `TEXT` PKs → `UUID` or `TEXT` (keep `TEXT` for zero-churn parity)
   - `REAL` → `NUMERIC`/`DOUBLE PRECISION`
5. Switch backend to `DATABASE_URL`; keep the existing app data intact.
6. Enable `foreign_keys` enforcement in PostgreSQL from day one.

### What the provided script does (and does not do)
`backend/scripts/migrate-sqlite-to-postgres.js`:
- Opens the SQLite database **read-only** (via a read-only connection).
- Exports every table's schema (DDL) and data (JSON + optional SQL) into
  `backend/scripts/output/`.
- Generates a translated PostgreSQL schema file (`postgres-schema.sql`) for the
  main application tables.
- **Does not** connect to any PostgreSQL instance and **does not** modify the
  SQLite file. Run it only when you want a snapshot for planning.

## 5. Backup strategy

See `docs/DATABASE-BACKUP-AND-RECOVERY.md` for the operational plan. Summary:
- SQLite: online backup via the `sqlite3` `.backup` command or the
  `VACUUM INTO`/`sqlite3_backup` API — do not copy `-wal`/`-shm` files manually.
- PostgreSQL: `pg_dump` (daily) + WAL/PITR at the provider level (Render Neon
  scale plans, etc.).

## 6. Data integrity checks

- Row counts per table must match between source and target.
- Key invariants:
  - every `user_id`/`donor_id`/`recipient_id` references an existing `users.id`
  - `UNIQUE(phone)` in `users` preserved
  - `UNIQUE(request_id, donor_id)` in `request_matches` preserved
  - audit/security rows keep `actor_role`/`audit_scope`
  - OTP hashes migrate as-is (never decrypt)
- Password hashes (bcrypt) and JWT behavior are unaffected by storage changes.