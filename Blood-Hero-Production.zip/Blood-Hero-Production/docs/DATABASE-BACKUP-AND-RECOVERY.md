# Blood Hero — Database Backup and Recovery

Operational plan for protecting application data. This is a **plan**, not an
automated system — no automatic backups are configured by this repository.

---

## 1. Current state (SQLite)

- Database: `backend/blood_hero.db` (WAL mode → `blood_hero.db-wal`, `blood_hero.db-shm`).
- Location: backend working directory (configurable via `DB_PATH`).
- The database is excluded from the repository and from any Git operations.

### Important
- **Never** copy a live SQLite file while the server is writing (WAL). Use the
  online backup mechanism instead:
  - CLI: `sqlite3 blood_hero.db ".backup backup\blood_hero-YYYYMMDD.db"`
  - Node (when the server is stopped or via the backup API):
    ```js
    const db = require('sqlite3');
    const src = new db.Database('blood_hero.db');
    src.backup('backup/blood_hero-YYYYMMDD.db').then(() => src.close());
    ```
- If you copy the file manually, stop the backend first and copy
  `blood_hero.db` **plus** `-wal` and `-shm` together, then restore the set.

## 2. Backup strategy

### SQLite (current)
| Cadence | Action | Retention |
|---|---|---|
| Daily | Online backup to `backup/blood_hero-YYYYMMDD.db` (cron / scheduled task) | 7 days |
| Weekly | Backup + verify integrity (`PRAGMA integrity_check`) | 4 weeks |
| Pre-migration | One-off full backup before any PostgreSQL migration | Indefinite (archive) |

### PostgreSQL (after migration)
| Cadence | Action | Retention |
|---|---|---|
| Daily | `pg_dump` (plain or custom format) to cloud object storage | 14 days |
| Continuous | Provider-managed WAL archive / PITR (Neon, RDS, Render scale) | Per provider |
| Weekly | Full logical dump + restore dry-run on a scratch instance | 4 weeks |

## 3. Restore procedure

### SQLite
1. Stop the backend (graceful shutdown via `SIGTERM`).
2. Replace `blood_hero.db` with the backup file.
3. Delete stale `blood_hero.db-wal` / `blood_hero.db-shm` (they belong to the old file).
4. Start the backend and run `PRAGMA integrity_check`.

### PostgreSQL
1. Create a target database.
2. `pg_restore -d <target> <dumpfile>` (custom format) or `psql -f dump.sql`.
3. Verify row counts against the documented integrity checks
   (`docs/DATABASE-MIGRATION.md` section 6).
4. Repoint `DATABASE_URL` to the restored database; redeploy.

## 4. Disaster recovery

1. Restore the most recent good backup.
2. Re-apply any cloud object-storage documents (NID/proof uploads live separately
   from the database in production; restore them from the storage provider's
   snapshots/versioning).
3. Smoke-test: `/health`, admin login, one user login, one blood-request read.

## 5. Migration rollback

- If a PostgreSQL migration fails: **stop, do not continue**. Restore the SQLite
  backup (section 3) and keep the backend pointed at `DB_PATH`.
- Keep the old SQLite backup for at least two full release cycles after a
  successful migration.
- Maintain the source-of-truth schema copy (`backend/database.js`) alongside any
  PostgreSQL DDL so a rollback can reconstruct the SQLite file if ever needed.

## 6. Verification checklist

- [ ] Backups are stored outside the application filesystem (separate disk/object storage).
- [ ] Restore has been exercised at least once against a scratch environment.
- [ ] `PRAGMA integrity_check` / `pg_dump --verify` passes on every backup.
- [ ] Backups never contain plaintext passwords or OTP codes.
- [ ] Backup access is restricted (IAM/service-account least privilege).