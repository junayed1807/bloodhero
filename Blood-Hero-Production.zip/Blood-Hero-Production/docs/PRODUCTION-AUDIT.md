# Blood Hero — Production Audit

Audit performed against the original reference project, then re-verified on this
production copy. The reference project is **unchanged**; this document describes
the audited architecture, its production blockers, and the fixes that are required
or already applied in this copy.

---

## 1. Current architecture

### Frontend (user app)
- **Static SPA** — plain HTML/CSS/JavaScript (ES modules). No build step, no framework.
- Entry: `index.html` → `js/app.js` (auth gate + shell) and `js/fx/init.js`.
- Pages live in `js/pages/*.js`, driven by a lightweight hash router in `js/app.js`.
- i18n (Bangla/English) via `js/i18n.js`; theme (dark/light) via `localStorage` (`bh_theme`).
- Primary data layer: **Firebase Firestore** (`js/db.js`) with a `localStorage` demo
  fallback. Backend (OTP-bridge) integration via `shared/js/backend-api.js`.
- PWA: `sw.js` + `manifest.webmanifest`. The service worker deliberately never
  caches `/api/`, `/uploads/`, or `/admin-panel/` responses.

### Admin panel
- Separate static SPA: `admin-panel/index.html` + `admin-panel/js/*`.
- Talks **directly to the backend API** via `admin-panel/js/api-client.js`
  (no Firestore). Features: Super Admin / Admin / Sub-admin hierarchy, user and
  donor management, NID verification, donation verification, audit logs, login
  history, security events, roles & permissions, settings, dark mode, Bangla/English.

### Backend
- **Express 4.18.2** Node.js API (`backend/server.js`).
- **SQLite 3** via the native `sqlite3` package (`backend/database.js`, ~35 tables).
- Auth: `bcryptjs` password hashing + `jsonwebtoken` bearer tokens.
- RBAC: 3 admin roles (`super_admin`, `admin`, `sub_admin`) and ~24 granular
  permissions, enforced per-route in `backend/middleware/auth.js`.
- Middleware: `auth`, `audit`, `rate-limit`, `upload` (multer).
- Routes: `auth, users, requests, donations, upload, admin, centers,
  notifications, nid-verifications, impact, recipient-programs, ambulances,
  conversion, hierarchy`.
- SMS OTP via `backend/services/sms-provider.js` (log provider in dev; **fails
  closed in production** until a real provider is configured).

### Data flow in production
```
User app (Vercel)  ── /api/* ──(vercel.json proxy or API_BASE)──▶  Backend (Render)  ──▶ DB
Admin panel (Vercel) ───────────────▶ same proxy/API_BASE ───────▶  Backend (Render)  ──▶ DB
```

---

## 2. Dependencies (backend)

From `backend/package.json`:

| Package | Version | Purpose |
|---|---|---|
| express | ^4.18.2 | HTTP framework |
| sqlite3 | ^5.1.6 | SQLite database driver (native) |
| bcryptjs | ^2.4.3 | Password hashing |
| jsonwebtoken | ^9.0.2 | JWT signing/verification |
| multer | ^1.4.5-lts.1 | Multipart upload parsing |
| cors | ^2.8.5 | CORS handling |
| dotenv | ^16.3.1 | Environment variables |
| uuid | ^9.0.0 | ID generation |

`package-lock.json` is tracked for reproducible installs. `node_modules/` is
excluded from the repository.

---

## 3. API endpoints (backend)

### Public / low-auth
| Method | Path | Auth | Notes |
|---|---|---|---|
| GET | `/health`, `/api/health` | none | Liveness; includes `service: blood-hero-api` |
| POST | `/api/auth/register` | none | Register with phone + password |
| POST | `/api/auth/login` | none | Login (password) |
| POST | `/api/auth/otp/request` | none | Request phone OTP |
| POST | `/api/auth/otp/verify` | none | Verify OTP (auto-provisions user) |
| POST | `/api/auth/otp/bridge` | none | OTP bridge login for the user app |
| GET | `/api/public-profile/:id` | none | Public role badge |
| GET | `/api/centers` | none | Blood centers / hospitals |
| GET | `/api/ambulances` | none | Ambulance directory |

### Authenticated (bearer token)
| Method | Path | Notes |
|---|---|---|
| GET/PUT | `/api/users/me`, `/api/users/me/profile` | Own profile |
| PATCH | `/api/users/me/password` | Password change |
| POST | `/api/users/profile/picture` | Profile picture (upload plumbing broken — see audit) |
| GET | `/api/requests` | Blood requests (returns requester contacts — PII risk) |
| POST | `/api/requests` | Create blood request |
| PATCH | `/api/requests/:id/status` | Change request status (**no ownership/admin check — CRITICAL**) |
| GET | `/api/donations` | Donation history (**cross-user leak**) |
| POST | `/api/donations/submit` | Submit donation (`req.file` read but no multer — broken) |
| POST | `/api/upload/profile`, `/api/upload/proof` | Upload endpoints |
| POST | `/api/admin/...` | Admin CRUD (users, donations, requests, verification) |
| GET | `/api/admin/nid-verifications/:id` | **Returns full NID number — CRITICAL PII** |
| GET | `/api/hierarchy/...` | Admin hierarchy management |
| GET | `/api/impact` | Impact stats (note: `totalLives = donations * 3` is fabricated) |

Full route inventory: `backend/routes/*.js`.

---

## 4. Database (SQLite) — table inventory

~35 tables created in `backend/database.js`. Core application tables:

- `users` (donors/recipients/admins; `role` ∈ donor/admin/sub_admin/super_admin)
- `blood_requests`, `donations`, `request_matches`
- `reward_ledger`, `badges`, `user_badges`
- `notifications`, `audit_logs`, `audit_logs_enhanced`, `login_history`, `security_events`
- `nid_verifications`, `health_declarations`, `referral_codes`, `conversion_events`
- `donation_programs`, `family_members`
- `centers`, `ambulances`, `articles`, `areas`, `settings`
- RBAC: `super_admins`, `admin_roles`, `permissions`, `role_permissions`,
  `admin_accounts`, `admin_invitations`, `admin_otp`
- `user_otp` (OTP login bridge)

See `docs/DATABASE-MIGRATION.md` for schema, relationships, and the PostgreSQL plan.

---

## 5. Authentication & authorization

- **User app**: Firebase client-side auth (Firestore users + `localStorage` demo
  fallback) OR the phone-OTP bridge to the backend (`user_otp` + `users` rows).
  Backend issues JWTs (7-day expiry) stored in `localStorage`.
- **Admin panel**: password login (`POST /api/auth/login`) → JWT. RBAC enforced
  server-side per-route in `backend/middleware/auth.js`.
- **JWT secret**: production refuses weak/default secrets (fail-closed, ≥32 chars).
- **Passwords**: bcrypt (cost 12). No plaintext passwords stored. Legacy OTP rows
  in `admin_otp` compare against a hashed value.
- **Password reset**: not fully implemented (no email/SMS reset flow). Admin can
  reset user passwords server-side.

---

## 6. Upload system

- Location: `backend/uploads/profiles` and `backend/uploads/proofs` (local disk).
- Validated by `backend/middleware/upload.js` (mimetype allow-list, 2 MB limit,
  random filenames, extension check). No magic-byte verification.
- **Broken plumbing**: `POST /api/donations/submit` and
  `POST /api/users/profile/picture` read `req.file` but mount **no multer**
  middleware, so uploads through those routes always fail (or are stored as
  base64 in Firestore, which exceeds the ~1 MiB document limit).
- Cloud storage abstraction is documented but not wired (see DEPLOYMENT.md).

---

## 7. Security findings

Classified in `docs/SECURITY-AUDIT.md`. Summary of the items that **must** be
fixed before a public production launch (identified in this audit):

1. **CRITICAL — Missing authorization on request-status changes**
   `PATCH /api/requests/:id/status` has no ownership/admin check; any
   authenticated user can alter any request's status.
2. **CRITICAL — Repository-root static exposure (dev mode / SERVE_STATIC=true)**
   The backend's single-server static mount served the project root (leaking
   `blood_hero.db`, `node_modules`, `.env`). **Fixed in this copy** by a
   deny-list middleware in `backend/server.js`.
3. **CRITICAL — Admin suspend/activate writes invalid status values**
   `backend/routes/hierarchy.js` binds the raw `action` string
   (`'suspend'`/`'activate'`) to `users.status` and `admin_accounts.status`
   instead of the computed `newStatus` (`'suspended'`/`'active'`), and never sets
   `suspended_at`/`disabled_at`/`revoked_at`. Because admin login requires
   `status === 'active'`, this can lock admins out.
4. **CRITICAL — Firestore rules allow privilege escalation / PII reads**
   Documented rules (`deploy/firebase-setup.md`) allow donors to self-update
   `role` and allow `donors` collection to be read by any authenticated user
   (full PII incl. phone, address, emergency contact).
5. **CRITICAL — Forgeable client verification token**
   `js/db.js` generates a "verification token" from a hardcoded client secret
   using base64 (not an HMAC). Replace with server-issued tokens.
6. **HIGH — PII leaks on list endpoints**: `GET /api/donations`,
   `GET /api/requests`, `GET /api/admin/nid-verifications/:id` return full NID
   numbers and requester/donor contacts without ownership filtering.
7. **HIGH — OTP auto-provisions accounts**: verifying any phone's OTP creates a
   user row (spam/DB-growth vector).
8. **HIGH — No production deployment config existed** (now added in `deploy/`).
9. **MEDIUM — In-memory per-process rate limiting**, no shared store across
   Render instances.
10. **MEDIUM — Missing security headers** (CSP, HSTS, Cache-Control) on the backend.

---

## 8. Production blockers (action required before public launch)

| # | Blocker | Severity | Status |
|---|---|---|---|
| B1 | `PATCH /api/requests/:id/status` authorization | CRITICAL | Open (code) |
| B2 | Admin suspend/activate status mapping | CRITICAL | Open (code) |
| B3 | Firestore rules (`role` self-update; `donors` read) | CRITICAL | Open (Firebase) |
| B4 | Forgeable client token | CRITICAL | Open (code) |
| B5 | NID / PII exposure on list endpoints | HIGH | Open (code) |
| B6 | Broken upload plumbing (`req.file` without multer) | HIGH | Open (code) |
| B7 | OTP provider fail-closed in production | HIGH | Config (Twilio) |
| B8 | Password reset flow missing | MEDIUM | Open |
| B9 | Rate limiting not shared across instances | MEDIUM | Open |
| B10 | Repository-root static exposure | CRITICAL | **Fixed in this copy** |

> The production copy preserves the reference implementation byte-for-byte except
> where noted (`server.js` health response + static deny-list). Code fixes for
> B1–B9 are intentionally left to a controlled change cycle with tests, per the
> "preserve working functionality" rule.

---

## 9. Required environment variables

See `docs/ENVIRONMENT-VARIABLES.md` for the full table. Backend:

```
PORT, HOST, NODE_ENV, TRUST_PROXY,
JWT_SECRET (required, ≥32 chars in production),
DB_PATH (SQLite path), DATABASE_URL (future PostgreSQL),
CORS_ORIGIN (comma-separated),
ADMIN_INIT_PHONE, ADMIN_INIT_PASSWORD, ADMIN_INIT_NAME,
SMS_PROVIDER, TWILIO_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM,
OTP_EXPIRY_SECONDS, OTP_MAX_ATTEMPTS, OTP_RATE_LIMIT_WINDOW, OTP_RATE_LIMIT_MAX
```

Frontend (runtime, injected via `window.__CONFIG__`): `API_BASE`.

---

## 10. Deployment requirements

- **Frontend**: static files → Vercel. `vercel.json` proxies `/api/*` to the
  Render backend (or set `__CONFIG__.API_BASE`).
- **Backend**: Express → Render. `npm start`. Requires `NODE_ENV=production`,
  a strong `JWT_SECRET`, `TRUST_PROXY=true`, and `DB_PATH` (SQLite) or a
  PostgreSQL `DATABASE_URL` after migration.
- **Database**: SQLite today; managed PostgreSQL is the target (see
  `docs/DATABASE-MIGRATION.md`).
- **Storage**: local disk today; secure cloud object storage is the target
  (private, signed URLs only — never public).
- **HTTPS**: terminate at Vercel and Render; backend must trust the proxy.
- **Domain**: placeholder `https://YOUR-DOMAIN` / `https://api.YOUR-DOMAIN`.

See `DEPLOYMENT.md` (root) for the step-by-step guide.