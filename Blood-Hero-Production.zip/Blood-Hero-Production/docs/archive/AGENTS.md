# Blood Hero — Development Guide

## Project Structure
- `backend/` — Express + SQLite3 + JWT backend
- `js/` — Shared frontend modules (ESM)
- `shared/js/` — Shared API client
- `admin-panel/` — Admin panel (vanilla ESM PWA)

## Backend Verification
```bash
# Start server (auto-seeds DB)
cd backend && node server.js

# Verify modules load
node -e "require('./database.js'); require('./middleware/auth.js'); require('./middleware/audit.js'); require('./routes/hierarchy.js'); console.log('OK')"

# Test login (Super Admin)
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"phone":"01835038064","password":"admin123"}'
```

## Lint / Typecheck
No external linter is configured. Verify via Node's built-in syntax check:
```bash
node --check backend/server.js
node --check backend/routes/*.js
node --check backend/middleware/*.js
```
