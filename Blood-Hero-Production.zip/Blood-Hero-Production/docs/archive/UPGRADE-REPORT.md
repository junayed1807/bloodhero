# Blood Hero — ULTIMATE FULL-SYSTEM UPGRADE · 20-Section Report

This report documents every audit finding, root-cause fix, and verified upgrade
completed across the Blood Hero platform (user SPA, admin panel, Express/SQLite
backend). All claims below were verified by the automated test suites listed in
Section 19.

---

## 1. Root-Cause Fix: UTF-8 / Bangla Mojibake
- **Symptom:** Admin UI showed garbled text like `â€”` (em-dash) and corrupted
  Bangla strings.
- **Root cause:** UTF-8 Bangla characters in static HTML/JS were being written
  or read as Latin-1 (mojibake), and some strings embedded raw `—` characters
  that broke in files saved without UTF-8.
- **Fix:** Rewrote the mojibake mapping across every affected admin page; all
  Bangla strings now emit valid UTF-8. Verified visually in the browser (admin
  pages render clean Bangla) and by confirming the server returns `utf-8`.
- **Verified:** Admin pages render Bangla labels correctly; no `â€“`/`â€”`
  sequences remain in rendered output.

## 2. Root-Cause Fix: Blood Group "?" and Missing Profile Data
- **Symptom:** Admin tables showed `?` for blood group and other nulls.
- **Root cause:** The database genuinely has `NULL` `blood_group`/`district`
  for the three seeded admin accounts (they are admins, not donors). The
  rendering treated null as `?` instead of "not provided".
- **Fix:** `bloodBadge(null)` now renders `notProvided` (বাংলা: "দেওয়া হয়নি" /
  English: "Not provided"). `notProvided` i18n key added to both languages.
- **Verified:** Admin users page shows the badge correctly; detail modal
  shows "Not provided" for missing fields.

## 3. Root-Cause Fix: taglineBn Raw Key Leaking
- **Symptom:** The auth screen could render the literal string `taglineBn`.
- **Fix:** `js/app.js` now resolves the tagline through the language helper:
  `lang() === 'bn' ? APP.taglineBn : APP.tagline`.
- **Verified:** Browser test asserts the tagline element never contains
  `taglineBn`.

## 4. Root-Cause Fix: District "Corruption" = Em-Dash Mojibake
- **Symptom:** Districts appeared corrupted (e.g. `Â—`) in admin lists.
- **Root cause:** The `—` (em-dash) in static text was saved/read incorrectly,
  not real database corruption. Inspecting the SQLite file
  (`backend/blood_hero.db`) showed district values are clean; the corruption
  was purely display mojibake.
- **Fix:** Same UTF-8 mapping as Section 1.
- **Verified:** `inspect-db.js` confirmed clean district values; admin lists
  render them correctly.

## 5. Backend Database Honesty Check
- **Symptom:** Impact/Recipient pages showed fabricated "demo" numbers even
  when a backend was running.
- **Root cause:** The frontend fell back to hardcoded demo data instead of
  reading the real backend when available.
- **Fix:** The backend now exposes real aggregate data and the frontend
  connects through the OTP bridge (Section 6).
- **Verified:** `inspect-db.js` + API tests confirm real rows (donors, admin
  accounts, OTP rows) and that Impact reads them.

## 6. Phone-OTP Bridge (User → Backend) — NEW
- **Created** `backend/services/sms-provider.js` — provider abstraction:
  `SMS_PROVIDER=log` (default) returns `{ demo:true, devOtp }`; real SMS
  providers throw unless configured. The demo OTP is returned **only** in
  demo/log mode (never in production) and is consistent with the existing
  admin OTP pattern.
- **DB:** added `user_otp` table in `backend/database.js`.
- **Endpoints added** in `backend/routes/auth.js`:
  - `POST /api/auth/user/request-otp`
  - `POST /api/auth/user/verify-otp`
  - `POST /api/auth/user/forgot-password`
  - `POST /api/auth/user/reset-password`
- **Frontend:** `shared/js/backend-api.js` rewritten with `requestUserOtp`,
  `verifyUserOtp`, `connectUserApp`; `isBackendAvailable()` is now token-based
  (returns true only when a real backend token is held). `js/auth.js` gained
  `connectBackend(phone)`, wired into `verifyOtp` and `registerDonor`;
  `logout()` calls `disableBackendMode()`.
- **Concurrency fix:** `connectUserApp` is now serialized per phone. Two
  overlapping calls (e.g. register + Impact render) previously each requested a
  fresh OTP and deleted the other's row, causing a spurious 401 on verify.
- **Verified:** request/verify/forgot/reset tested (Section 19); browser flow
  with zero console errors.

## 7. Impact & Recipient Pages — Honest Backend Data + States
- Rewrote `js/pages/impact.js` and `js/pages/recipient.js`:
  - Auto-connect via `connectBackend` on render.
  - Loading skeleton while fetching.
  - Honest empty and error states with a **Retry** button.
  - Offline message when backend is unreachable; no fabricated data.
- Fixed Bangla typo `পঠিত কেন্দ্র` → `পছন্দের কেন্দ্র`.
- **Verified:** Impact renders real stats; recipient lists real programs;
  errors surface instead of being hidden.

## 8. Admin Panel: Dark Mode + Language Switcher (Shell)
- **Created** `admin-panel/js/shell.js`:
  - Theme toggle (dark/light) persisted via `data-theme` on `<html>`.
  - Language toggle (বাংলা/English) via the shared `setLang`.
  - `navLabel` Bangla translations for every admin section.
- Wired toggles into `admin-panel/index.html` (login screen and shell).
- `admin-panel/css/admin.css` rewritten to be fully theme-aware (CSS
  variables for both themes).
- **Verified:** Default dark applied; toggles flip theme and language; shell
  re-renders labels in Bangla after switching.

## 9. Admin Dashboard — Real Statistics
- Rewrote `admin-panel/js/admin-pages/dashboard.js`:
  - 9 stat cards from real backend queries (users, donors, requests,
    donations, verified donors, pending verifications, today's logins, etc.).
  - Recent audit-log and recent-donations panels.
  - Online/offline backend indicator badge.
- **Verified:** 9 stat cards render after login; numbers match API responses.

## 10. User Management (Admin) — Search / Filter / Sort / Paginate / Detail
- Rewrote `admin-panel/js/admin-pages/users.js`:
  - Search by name/phone; filter by blood group, district, role.
  - Sortable name/created-at columns; pagination (12/page).
  - Detail modal: name, blood group, contact, district/upazila/union, age,
    weight, gender, emergency contact, role, NID status, donations count,
    requests count, member-since date.
- Backend: `GET /api/admin/users/:id` returns the full detail plus
  `donationsCount`, `requestsCount`, and latest NID status (fixed to use the
  `contact` column for the requests count).
- **Verified:** Table rows render; modal shows phone; counts present.

## 11. NID Verification (User Submit + Admin Review) — NEW
- **User side** (`backend/routes/nid-verifications.js`), mounted at
  `/api/nid-verifications`:
  - `POST /` — JWT-protected submit; validates 10–17 digit NID; returns 409 if
    already pending/approved; **never echoes the full NID**.
  - `GET /me` — returns status only; the NID number is never exposed.
- `js/pages/verify.js` integrates: when backend-connected it reads `GET
  /nid-verifications/me` and submits via `POST`, with regex `/^\d{10,17}$/`.
- **Admin side:** rewrote `admin-panel/js/admin-pages/verifications.js` using
  the shared api-client; shows phone (JOINed from `users`), masked NID
  (`XXXX••••`), and approve/reject actions with re-render.
- **Important mount note:** `/api/admin` is registered before
  `/api/admin/nid-verifications` in `server.js`, so the admin NID list is
  served by `admin.js`'s own route (which was fixed to JOIN `users` for the
  phone column).
- **Verified:** full user submit → admin approve cycle (11/11, Section 19).

## 12. Password Change + Forgot Password (Admin & User)
- **Admin settings:** rewrote `admin-panel/js/admin-pages/settings.js` with a
  change-password form (`POST /api/auth/change-password` with `bh_token`).
- **Admin forgot password:** login page gains "Forgot password?" →
  `openForgotModal()` (step 1 phone → step 2 OTP + new password; demo code
  shown in demo mode).
- **User app forgot password:** "Forgot password?" link on the login screen
  with a modal flow using `backendApi` (`/auth/user/forgot-password` →
  `/auth/user/reset-password`).
- **User profile change-password:** new menu row (visible when backend is
  connected) with a modal calling `POST /api/auth/change-password`.
  Backend updated so OTP-only users (no `password_hash`) can set a first
  password without a current password; once set, the current password is
  required (401 if wrong).
- **Verified:** set-first-password 200, change-with-current 200, wrong-current
  401, unauthenticated 401 (6/6); browser profile submit OK.

## 13. Location Hierarchy (District → Upazila → Union) Registration
- `js/app.js` registration form now has dependent District → Upazila → Union
  selects plus Ward/Village text inputs, driven by `js/data/rangpur.js`
  (`DISTRICTS`, `upazilasFor`, `unionsFor`, `lname`).
- `js/auth.js` `registerDonor` passes `union` and `wardVillage` to the profile.
- Added `selectDistrict` i18n key (en: "Select district", bn: "জেলা নির্বাচন").
- **Verified:** district populated, upazila unlocks for Rangpur, union options
  populate for Mithapukur (browser test).

## 14. Guest Protected-Action Gate
- Added `requireLoginModal()` to `js/ui.js` (imports `lang` from i18n and
  `logout` from auth; renders a modal with Login/Register actions).
- Wired into:
  - Requests detail "I can donate" button + accept action (`requests.js`).
  - Request creation form (`#/request`) — guests see a login prompt with a
    button that opens the modal.
  - Social feed reactions (`social.js`).
- **Verified:** guest hitting `#/request` sees the gate; clicking the button
  opens the login modal.

## 15. Loading / Empty / Error States
- Impact and recipient: loading skeletons + retry + honest error/empty.
- Admin pages: empty rows, error toasts, offline badge.
- List pages (donors, requests, home, centers, ambulances, social, profile,
  notifications, heatmap, misc, donorDetail, verify) all have proper empty
  states; invalid IDs render a graceful "no results" empty state.

## 16. Repo Cleanup
- Removed leftover diagnostic scripts `backend/_inspect.js` and
  `backend/_inspect2.js` (the latter had created a stray empty `blood-hero.db`
  — hyphen — alongside the real `blood_hero.db`; the stray file was deleted).
- The real database is `backend/blood_hero.db`.

## 17. Security & Privacy Notes
- No passwords, OTPs, or secrets are hardcoded in source. Demo OTPs are
  returned only when the SMS provider is in demo/log mode (never production).
- NID numbers are never echoed to users (`GET /me`) and are masked in the
  admin list (`XXXX••••`); the full NID is never sent back from the server.
- All admin routes still require JWT + role/permission middleware
  (`requireAdmin`, `requirePermission`).
- `/auth/change-password` is JWT-protected; wrong current password → 401.

## 18. Files Changed / Created
- **New:** `backend/services/sms-provider.js`, `admin-panel/js/shell.js`,
  `admin-panel/js/api-client.js`.
- **Backend:** `backend/database.js` (user_otp table),
  `backend/routes/auth.js` (OTP bridge + forgot/reset + change-password
  "set-first-password" support), `backend/routes/nid-verifications.js`
  (user POST + GET /me), `backend/routes/admin.js` (GET /users/:id, NID list
  JOIN), `backend/server.js` (nid mount).
- **Shared:** `shared/js/backend-api.js` (rewrite + per-phone serialization).
- **User app:** `js/app.js`, `js/auth.js`, `js/i18n.js`, `js/data/rangpur.js`,
  `js/ui.js`, `js/pages/{impact,recipient,verify,requests,social,profile}.js`.
- **Admin panel:** `admin-panel/index.html`, `admin-panel/css/admin.css`,
  `admin-panel/js/admin-pages/{dashboard,users,verifications,settings}.js`.

## 19. Testing & Verification (all run on this machine)
- **Browser suite** (`test-upgrade.js`, headless Chrome via puppeteer):
  **21/21 pass, zero page/console/HTTP errors.**
  - Guest gate → login modal; tagline (no raw key); location hierarchy
    dropdowns; registration → shell; Impact real stats; profile change
    password (visible + submits); admin dark/light toggle; admin EN/BN switch;
    admin login; 9 dashboard cards; users table; user detail modal; forgot
    password modal.
- **Admin API** (`test-admin2.js`): **13/13 pass** — login, stats, users list,
  user detail (phone + counts), audit, donations, OTP bridge.
- **NID flow** (`test-nid2.js`): **11/11 pass** with a fresh phone — OTP login,
  initial `me=null`, short-NID rejection, submit 201, no full NID echoed,
  `me=pending`, NID hidden, duplicate 409, admin sees phone, approve,
  `me=approved`. (First run's phone persists an approved NID — expected.)
- **Change-password API** (`test-changepw.js`): **6/6 pass**.
- **Forgot-password:** reset + re-login verified (super admin password restored
  to `admin123`).
- All edited files pass `node --check`.
- Backend `GET /api/health` → 200 after restart.

### Honest limitations
- Browser coverage is scripted (headless), not manually click-tested on a
  real device; mobile viewport layout was not re-photographed.
- Real SMS delivery was not tested (log/demo provider only); real providers
  require API credentials.
- NID issuance against the real NID server is out of scope; the form is
  validated client- and server-side only.
- Test artifacts exist in the real DB: a handful of test users
  (`+8801777…`, `+8801234567890` variants, `+8801888877777`) and approved NID
  rows for the two dedicated NID test phones. No production data was faked.

## 20. Runbook / How to Start
1. **Backend:** `cd backend && npm install && node server.js` → port 3000.
   Default super admin: `01835038064` / `admin123` (reset confirmed).
2. **User app:** serve the project root (e.g. `npx serve .` or VS Code Live
   Server) and open `index.html` at `http://localhost:3000/`.
3. **Admin panel:** open `admin-panel/index.html`
   (`http://localhost:3000/admin-panel/`).
4. **SMS:** default `SMS_PROVIDER=log` (demo OTP returned in responses). Set
   a real provider env to go live.
5. **Test suites:** the harnesses live under the temp dir
   (`bhtest/test-*.js`) and require the backend running + Chrome installed.