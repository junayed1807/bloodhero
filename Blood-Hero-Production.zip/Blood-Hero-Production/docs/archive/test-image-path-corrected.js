const fs = require('fs');
const path = require('path');

// Test the corrected image path from js/components directory
const logoPath = path.join(__dirname, '..', 'assets', 'images', 'logo.svg');
console.log('Testing image path:', logoPath);
console.log('File exists:', fs.existsSync(logoPath));

if (fs.existsSync(logoPath)) {
  const data = fs.readFileSync(logoPath, 'utf8');
  console.log('Image file size:', data.length, 'bytes');
  console.log('Image file content preview:', data.substring(0, 100));
} else {
  console.log('ERROR: Image file not found!');
}