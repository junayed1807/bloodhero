# Blood Hero Backend

Node.js/Express backend with SQLite database for Blood Hero.

## Setup

```bash
cd backend
npm install
cp .env.example .env
npm start
```

Server runs on `http://localhost:3000`.

## API Endpoints

### Authentication
- `POST /api/auth/register` — Register new user
- `POST /api/auth/login` — Login
- `GET /api/auth/me` — Current user

### Users
- `GET /api/users/profile` — Get profile
- `PUT /api/users/profile` — Update profile
- `POST /api/users/profile/picture` — Upload profile picture
- `GET /api/users/donation-history` — User's donation history
- `GET /api/users/stats` — User statistics

### Blood Requests
- `GET /api/requests` — List requests
- `GET /api/requests/:id` — Get request
- `POST /api/requests` — Create request
- `POST /api/requests/:id/accept` — Accept request
- `PATCH /api/requests/:id/status` — Update status
- `DELETE /api/requests/:id` — Delete request

### Donations (Verified Workflow)
- `POST /api/donations/submit` — Submit donation proof (requires file upload)
- `POST /api/donations/:id/approve` — Approve donation (admin only)
- `POST /api/donations/:id/reject` — Reject donation (admin only)
- `GET /api/donations` — List donations

### Upload
- `POST /api/upload/profile-picture` — Upload profile picture
- `POST /api/upload/donation-proof` — Upload donation proof

### Admin
- `GET /api/admin/stats` — Dashboard statistics
- `GET /api/admin/users` — List all users
- `PATCH /api/admin/users/:id/suspend` — Suspend/activate user
- `GET /api/admin/donations` — List all donations
- `POST /api/admin/donations/:id/approve` — Approve donation
- `POST /api/admin/donations/:id/reject` — Reject donation
- `GET /api/admin/audit-logs` — View audit logs

## Authentication

All protected endpoints require a Bearer token in the Authorization header:
```
Authorization: Bearer <jwt_token>
```

## Role-Based Access

- `donor` — Regular user
- `admin` — Can manage requests, review donations
- `super_admin` — Full access

## Verified Donation Workflow

```
1. Donor accepts request → status: "accepted"
2. Donor submits proof → status: "pending_verification"
3. Admin approves → status: "verified" + points/stars awarded
4. Admin rejects → status: "rejected" + reason stored
```

## Database

SQLite database file: `blood_hero.db` (created automatically).

Tables: users, blood_requests, donations, reward_ledger, badges, user_badges, notifications, audit_logs, nid_verifications, request_matches, health_declarations, referral_codes, donation_programs, family_members, centers, articles, areas, settings, super_admins.

## Security

- JWT authentication
- Role-based access control
- File upload validation (JPG/PNG/WEBP, max 5MB)
- SQL injection protection (parameterized queries)
- Audit logging for admin actions
- Duplicate donation protection

## Frontend Integration

The frontend should use `shared/js/api.js` for all API calls.

Example:
```javascript
import { api, setToken } from '../../shared/js/api.js';

// Login
const res = await api.post('/auth/login', { phone, password });
setToken(res.token);

// Get profile
const profile = await api.get('/users/profile');
```
