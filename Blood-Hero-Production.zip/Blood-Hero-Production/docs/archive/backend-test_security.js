const express = require('express');
const { getDb } = require('../database');
const {
  loadAdminContext, requireAdmin, requirePermission,
} = require('../middleware/auth');
const { auditLog, AUDIT_ACTIONS, getClientIp } = require('../middleware/audit');

const router = express.Router();

// Test 1: Super Admin login
console.log('=== TEST 1: Super Admin login ===');
const superLoginResponse = await fetch('http://localhost:3000/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ phone: '01835038064', password: 'admin123' })
});
const superResult = await superLogin.json();
console.log('Super Admin login:', superLogin.success ? 'SUCCESS' : 'FAILED');
console.log('Super Admin role:', superLogin.adminContext?.role);
console.log('Super Admin audit scope:', superLogin.adminContext?.auditScope);

// Test 2: Admin login
console.log('\n=== TEST 2: Admin login ===');
const adminLogin = await fetch('http://localhost:3000/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ phone: '+8801812345678', password: 'admin123' })
});
const adminResult = await adminLogin.json();
console.log('Admin login successful:', adminLogin.success);
console.log('Admin role:', adminResult.role);
console.log('Admin audit scope:', adminResult.adminContext?.auditScope);

// TEST 3: Admin can access protected routes
console.log('\n=== TEST 3: Admin can access protected routes ===');
const adminContext = await loadAdminContext(req, res);
if (req.adminContext) {
  console.log('Admin has valid context');
  // Test permission requirement
  try {
    await requirePermission('audit.view')(req, res, () => {});
    console.log('Admin has required permission');
  } catch (err) {
    console.log('Permission check failed:', err.message);
  }
}

console.log('\nAll backend security tests completed successfully!');