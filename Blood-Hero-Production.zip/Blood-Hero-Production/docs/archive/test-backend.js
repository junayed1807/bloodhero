const http = require('http');

const testServerUrl = 'http://localhost:3001/test-app';
const request = require('http').get(testServerUrl, (res) => {
  let data = '';
  res.on('data', chunk => data += chunk);
  res.on('end', () => {
    console.log('Received from test server:');
    console.log(data.substring(0, 200));
  });
});

request.on('error', (e) => {
  console.error('Error:', e.message);
});