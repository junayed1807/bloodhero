# Blood Hero — Production Test Plan

Manual test plan to execute **after** deployment (and locally before deploy).
Tests are grouped by area; each test records expected result. Run against the
production backend (`https://api.YOUR-DOMAIN`) and frontend (`https://YOUR-DOMAIN`),
or locally against `http://localhost:3000`.

> Nothing in this file is a claim that tests passed — results must be filled in
> during the actual test run and signed off.

---

## 1. Registration & authentication

| # | Test | Steps | Expected |
|---|---|---|---|
| T1 | Register (password) | `POST /api/auth/register` with a unique phone + password | 201, user row created, no plaintext password |
| T2 | Duplicate phone | Register same phone again | Rejected (conflict/duplicate error) |
| T3 | Login | `POST /api/auth/login` correct credentials | 200 + JWT; `users` `password_hash` unchanged |
| T4 | Login wrong password | Wrong password | 401, generic message |
| T5 | Logout | Call logout / clear token | Token no longer accepted on protected routes |
| T6 | OTP request | `POST /api/auth/otp/request` for a new phone | OTP issued (logged in dev; SMS in prod) |
| T7 | OTP verify | Verify with correct code | Session/bridge token issued |
| T8 | OTP wrong code | Wrong code 3× | Attempts exhausted; code rejected |

## 2. Profile

| # | Test | Steps | Expected |
|---|---|---|---|
| T9 | View own profile | `GET /api/users/me` with token | Own data only |
| T10 | Update profile | `PATCH /api/users/me/profile` | Fields updated; `updated_at` changed |
| T11 | View other user's profile | `GET /api/donations`/profile of another user | No private fields (ownership enforced) |

## 3. Donor search & directory

| # | Test | Steps | Expected |
|---|---|---|---|
| T12 | Search donors by blood group | Filter UI by group | Matching donors only |
| T13 | Location filtering | Filter by district/upazila | Only matching locations |
| T14 | Availability filter | Toggle `is_available` | Only available donors shown |

## 4. Blood requests

| # | Test | Steps | Expected |
|---|---|---|---|
| T15 | Create request | `POST /api/requests` | Row created, status `pending` |
| T16 | List own requests | `GET /api/requests` | Own requests visible; **contacts of others NOT exposed** (H1) |
| T17 | Change own request status | `PATCH /api/requests/:id/status` (owner) | Allowed |
| T18 | Change another user's request status | Same call with a non-owner, non-admin token | **403** (C1 must be fixed) |
| T19 | Request matching | Trigger matching flow | `request_matches` rows created |

## 5. NID verification

| # | Test | Steps | Expected |
|---|---|---|---|
| T20 | Submit NID | User submits NID data | Row status `pending` |
| T21 | Admin view (permission) | Admin with `verification.nid` views | Can see; **NID masked to last 4** (H1) |
| T22 | Admin without permission | Sub-admin without `verification.nid` | 403 |
| T23 | Verify/reject | Admin approves/rejects | `nid_status` updates; audit logged |

## 6. Donations & verification

| # | Test | Steps | Expected |
|---|---|---|---|
| T24 | Submit donation with proof | `POST /api/donations/submit` with multipart file | File accepted (H2 fixed) and proof stored privately |
| T25 | Donation verify | Admin verifies | Points/rewards credited once (M6), audit logged |
| T26 | Duplicate reward | Verify same donation twice | No double reward (`reward_ledger` UNIQUE) |
| T27 | Impact stats | Open impact page | `totalLives` from verified donations only (M7) |

## 7. Admin panel & RBAC

| # | Test | Steps | Expected |
|---|---|---|---|
| T28 | Admin login | Login as super admin | JWT + access |
| T29 | Super Admin visibility | View audit, security, login history | Full access |
| T30 | Admin scope | Login as Admin | Cannot manage admins/roles/permissions |
| T31 | Sub-admin no perms | Fresh sub-admin | No modules until permissions assigned |
| T32 | User management | List/edit/suspend users | Permission-gated; `status` correct (`active`/`suspended`) (C3) |
| T33 | Suspend/activate | Suspend then activate a user | Status round-trips correctly; timestamps set (C3) |
| T34 | Activity logs | Perform admin actions | `audit_logs_enhanced` rows with actor_role/audit_scope |
| T35 | Password change (admin) | Reset a user's password | Hash updated; old token optionally invalidated (H7) |

## 8. File upload security

| # | Test | Steps | Expected |
|---|---|---|---|
| T36 | Allowed type | Upload a PNG profile photo | Accepted; random filename |
| T37 | Disallowed type | Upload `.exe`/`.html` | Rejected (MIME + extension + magic-byte) |
| T38 | Oversized file | Upload > limit | Rejected with 413/400 |
| T39 | Path traversal | Filename `..\..\evil.png` | Neutralized/random name (no traversal) |
| T40 | Private access | Fetch an uploaded NID/proof URL anonymously | 403/404 (private, signed URL only) |

## 9. QR verification & notifications

| # | Test | Steps | Expected |
|---|---|---|---|
| T41 | QR generation | Generate QR for a donor/request | Scannable; resolves to public profile |
| T42 | QR scan | Scan with another phone | Shows only public info |
| T43 | Notifications | Trigger request match | Notification row created for the donor |

## 10. API errors & resilience

| # | Test | Steps | Expected |
|---|---|---|---|
| T44 | Unknown API route | `GET /api/nope` | 404 JSON, no stack trace |
| T45 | Server error path | Force an error | 500 generic message; detail in server logs only |
| T46 | Health check | `GET /health` | `{"status":"ok","service":"blood-hero-api",...}` |
| T47 | Rate limiting | Burst OTP/login requests | 429 after threshold (M2 note: per instance) |

## 11. Frontend & UX

| # | Test | Steps | Expected |
|---|---|---|---|
| T48 | Dark mode | Toggle theme | Persists via `bh_theme`; no flash on reload |
| T49 | Language switch | Toggle Bangla/English | All UI strings switch |
| T50 | Mobile UI | Test key pages at 360px width | No overflow; touch targets usable |
| T51 | PWA offline shell | Reload while offline | Cached shell loads; no private data cached |
| T52 | Admin panel dark mode / i18n | Toggle in admin panel | Applies correctly |

## 12. Deploy-signoff checklist

- [ ] `GET /health` returns `200 {"status":"ok","service":"blood-hero-api"}`
- [ ] Backend behind HTTPS; all API requests over HTTPS
- [ ] CORS: cross-origin requests from the frontend origin succeed; others rejected
- [ ] No secrets/DB/node_modules in the Git repository (`git status` clean)
- [ ] Database backup + restore rehearsed on a scratch environment