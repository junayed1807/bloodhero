// Blood Hero — Role-Based Access Control
// Roles are resolved SERVER-SIDE. Client-side only as UX fallback.
import { LS } from './config.js';
import { online, Donors, Audit } from './db.js';

export const ROLES = {
  GUEST: 'guest',
  DONOR: 'donor',
  SEEKER: 'seeker',
  COORDINATOR: 'coordinator',
  ORG_STAFF: 'org_staff',
  ORG_ADMIN: 'org_admin',
  ADMIN: 'admin',
  SUPER_ADMIN: 'super_admin',
  SUB_ADMIN: 'sub_admin',
};

export const ADMIN_ROLES = {
  SUPER_ADMIN: 'super_admin',
  ADMIN: 'admin',
  SUB_ADMIN: 'sub_admin',
};

export const ROLE_LEVELS = {
  [ROLES.SUPER_ADMIN]: 3,
  [ROLES.ADMIN]: 2,
  [ROLES.SUB_ADMIN]: 1,
};

export const AUDIT_SCOPE = {
  SYSTEM: 'SYSTEM',
  ADMIN: 'ADMIN',
  SUB_ADMIN: 'SUB_ADMIN',
  NONE: 'NONE',
};

export function auditScopeFor(role) {
  if (role === ROLES.SUPER_ADMIN) return AUDIT_SCOPE.SYSTEM;
  if (role === ROLES.ADMIN) return AUDIT_SCOPE.ADMIN;
  if (role === ROLES.SUB_ADMIN) return AUDIT_SCOPE.SUB_ADMIN;
  return AUDIT_SCOPE.NONE;
}

export function canViewAuditScope(actorScope, targetScope) {
  if (actorScope === AUDIT_SCOPE.SYSTEM) return true;
  if (actorScope === AUDIT_SCOPE.ADMIN) {
    return targetScope === AUDIT_SCOPE.ADMIN || targetScope === AUDIT_SCOPE.SUB_ADMIN;
  }
  if (actorScope === AUDIT_SCOPE.SUB_ADMIN) {
    return targetScope === AUDIT_SCOPE.SUB_ADMIN;
  }
  return false;
}

const CAPABILITIES = {
  [ROLES.GUEST]: ['read_public'],
  [ROLES.DONOR]: ['read_public', 'write_own', 'donate'],
  [ROLES.SEEKER]: ['read_public', 'write_own', 'request_blood'],
  [ROLES.COORDINATOR]: ['read_public', 'write_own', 'donate', 'moderate_local', 'verify_local'],
  [ROLES.ORG_STAFF]: ['read_public', 'write_own', 'manage_inventory', 'issue_blood'],
  [ROLES.ORG_ADMIN]: ['read_public', 'write_own', 'manage_branch', 'manage_staff', 'manage_inventory'],
  [ROLES.ADMIN]: ['read_public', 'write_own', 'moderate', 'manage_users', 'manage_requests', 'view_audit', 'manage_content', 'manage_sub_admins', 'donor_verification', 'nid_verification', 'user_management'],
  [ROLES.SUPER_ADMIN]: ['*'],
  [ROLES.SUB_ADMIN]: [],
};

export function roleOf(user) {
  if (!user) return ROLES.GUEST;
  if (user.adminRole) {
    return user.adminRole;
  }
  return user.role && CAPABILITIES[user.role] ? user.role : ROLES.GUEST;
}

export function isSuperAdmin(user) { return roleOf(user) === ROLES.SUPER_ADMIN; }
export function isAdmin(user) {
  const r = roleOf(user);
  return r === ROLES.SUPER_ADMIN || r === ROLES.ADMIN || r === ROLES.ORG_ADMIN;
}
export function isSubAdmin(user) {
  const r = roleOf(user);
  return r === ROLES.SUB_ADMIN || r === ROLES.ADMIN || r === ROLES.SUPER_ADMIN;
}
export function isPrivileged(user) {
  const r = roleOf(user);
  return [ROLES.SUPER_ADMIN, ROLES.ADMIN, ROLES.ORG_ADMIN, ROLES.SUB_ADMIN, ROLES.COORDINATOR, ROLES.ORG_STAFF].includes(r);
}
export function hasCapability(user, cap) {
  const caps = CAPABILITIES[roleOf(user)] || [];
  return caps.includes('*') || caps.includes(cap);
}
export function requireRole(user, ...roles) {
  const r = roleOf(user);
  if (!roles.includes(r)) throw new Error('Forbidden: role ' + r);
  return user;
}
export function assertCap(user, cap) {
  if (!hasCapability(user, cap)) throw new Error('Forbidden: ' + cap);
}

// --- Role badge helpers for public profiles ---
export function roleBadgeFor(role, adminRole) {
  const r = adminRole || role;
  if (r === ROLES.SUPER_ADMIN) return { role: 'super_admin', label: 'Super Admin', icon: '🛡️', color: 'red' };
  if (r === ROLES.ADMIN) return { role: 'admin', label: 'Admin', icon: '🔵', color: 'blue' };
  if (r === ROLES.SUB_ADMIN) return { role: 'sub_admin', label: 'Sub-admin', icon: '🟢', color: 'green' };
  return null;
}

export function publicProfile(donor, viewer) {
  if (!donor) return null;
  const own = viewer && (viewer.uid === donor.id || viewer.phone === donor.phone);
  const admin = isPrivileged(viewer);
  const p = { id: donor.id, name: donor.name, bloodGroup: donor.bloodGroup, district: donor.district, upazila: donor.available && donor.upazila ? donor.upazila : undefined,
    available: !!donor.available, totalDonations: donor.totalDonations || 0, nidStatus: donor.nidStatus || 'not_submitted', createdAt: donor.createdAt };
  if (own || admin) {
    p.phone = donor.phone;
    p.emergencyContact = donor.emergencyContact;
    p.lastDonation = donor.lastDonation;
    p.weight = donor.weight;
    p.age = donor.age;
    p.gender = donor.gender;
    p.address = donor.address;
  }
  // Only expose the role badge — NOT permissions or internal security info
  if (donor.adminRole || donor.role === 'super_admin' || donor.role === 'admin' || donor.role === 'sub_admin') {
    p.roleBadge = roleBadgeFor(donor.role, donor.adminRole);
  }
  return p;
}

export function publicDonorCard(donor) {
  if (!donor) return null;
  return {
    id: donor.id,
    name: donor.name,
    bloodGroup: donor.bloodGroup,
    district: donor.district,
    upazila: donor.available && donor.upazila ? donor.upazila : undefined,
    available: !!donor.available,
    totalDonations: donor.totalDonations || 0,
    verified: donor.nidStatus === 'approved',
    roleBadge: roleBadgeFor(donor.role, donor.adminRole),
  };
}

// Donation status lifecycle per spec
export const DONATION_STATUS = {
  DRAFT: 'draft', SUBMITTED: 'submitted', IN_REVIEW: 'in_review',
  AWAITING_RECIPIENT: 'awaiting_recipient', RECIPIENT_CONFIRMED: 'recipient_confirmed',
  ADMIN_APPROVED: 'admin_approved', VERIFIED: 'verified', REJECTED: 'rejected', CANCELLED: 'cancelled',
};
export const NID_STATUS = { NOT_SUBMITTED: 'not_submitted', PENDING: 'pending', APPROVED: 'approved', REJECTED: 'rejected' };
export function donationIsVerified(d) { return d && d.status === DONATION_STATUS.VERIFIED; }

export async function verifiedCountFor(userId, Donations) {
  const all = await Donations.list();
  return all.filter(d => d.donorId === userId && donationIsVerified(d)).length;
}

export { ROLES as RH_ROLES };
