// Blood Hero — Logo component.
// Renders the brand logo as an inline element with responsive sizing (sm / md / lg).
// The image path is relative to this file's location (js/components -> ../../assets/images/logo.svg).
// In the browser, relative srcs resolve against the document, which sits at the app root,
// so this reliably points to /assets/images/logo.svg for both the user app and admin panel.

const escAlt = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export function Logo({ size = 'md', alt = 'Blood Hero' } = {}) {
  const cls = size === 'sm' ? 'bh-logo-sm' : size === 'lg' ? 'bh-logo-lg' : 'bh-logo-md';
  const label = escAlt(alt);
  return `<span class="bh-logo ${cls}" role="img" aria-label="${label}"><img src="../../assets/images/logo.svg" alt="${label}" loading="eager" /></span>`;
}