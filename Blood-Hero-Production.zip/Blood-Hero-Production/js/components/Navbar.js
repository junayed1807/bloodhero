// Blood Hero — Top Navigation Bar (public + authenticated)
// Responsive: desktop horizontal links + mobile hamburger slide-down menu.
// Highlights active route, shows Login/Register for guests, Profile for logged-in.
import { t, lang, setLang } from '../i18n.js';
import { currentUser } from '../auth.js';
import { esc, icon } from '../ui.js';
import { Logo } from './Logo.js';

const PUBLIC_LINKS = [
  ['', 'home', 'home'],
  ['find-blood', 'search', 'findDonor'],
  ['request', 'plus', 'needBlood'],
  ['awareness', 'heart', 'awareness'],
  ['about', 'info', 'about'],
  ['contact', 'phone', 'contactUs'],
];

const AUTH_LINKS = [
  ['', 'home', 'dashboard'],
  ['donors', 'search', 'findDonor'],
  ['request', 'plus', 'needBlood'],
  ['awareness', 'heart', 'awareness'],
  ['impact', 'activity', 'impactTracking'],
];

export function renderNavbar() {
  const user = currentUser();
  const isAuth = user && !user.guest;
  const bn = lang() === 'bn';
  const links = isAuth ? AUTH_LINKS : PUBLIC_LINKS;
  const currentHash = (location.hash || '#/').replace(/^#\/?/, '').split('/')[0];
  const isDark = document.documentElement.getAttribute('data-theme') !== 'light';

  return `
    <header class="top-nav" id="topNav">
      <div class="nav-inner">
        <a href="#/" class="nav-brand" aria-label="Blood Hero Home">
          ${Logo({ size: 'sm', alt: 'Blood Hero' })}
          <span class="nav-brand-text">
            <strong>Blood Hero</strong>
            <small>${bn ? 'ব্লাড হিরো' : 'Every Drop Saves a Life'}</small>
          </span>
        </a>

        <nav class="nav-links" id="navLinks" aria-label="Main navigation">
          ${links.map(([route, ic, key]) => {
            const active = currentHash === route || (currentHash === '' && route === '');
            const href = route === '' ? '#/' : `#/${route}`;
            return `<a href="${href}" class="nav-link ${active ? 'active' : ''}">${icon(ic)} ${esc(t(key))}</a>`;
          }).join('')}
          ${!isAuth ? `
            <a href="#/gallery" class="nav-link ${currentHash === 'gallery' ? 'active' : ''}">${icon('camera')} ${esc(bn ? 'গ্যালারি' : 'Gallery')}</a>
            <a href="#/news" class="nav-link ${currentHash === 'news' ? 'active' : ''}">${icon('bell')} ${esc(bn ? 'সংবাদ' : 'News')}</a>
          ` : ''}
        </nav>

        <div class="nav-actions">
          <button class="nav-action-btn" id="navLangToggle" title="${bn ? 'Switch to English' : 'বাংলায় দেখুন'}" aria-label="${bn ? 'Switch to English' : 'Switch to Bangla'}">
            ${bn ? 'EN' : 'বাং'}
          </button>
          <button class="nav-action-btn" id="navThemeToggle" title="${bn ? 'থিম পরিবর্তন' : 'Toggle theme'}" aria-label="Toggle theme">
            ${icon(isDark ? 'sun' : 'moon')}
          </button>
          ${isAuth ? `
            <a href="#/profile" class="nav-profile-btn" title="${esc(t('profile'))}">
              <span class="nav-avatar">${esc((user.name || 'U').charAt(0).toUpperCase())}</span>
            </a>
          ` : `
            <a href="#/login" class="btn primary sm nav-auth-btn" id="navLoginBtn">${esc(t('login'))}</a>
          `}
          <button class="nav-hamburger" id="navHamburger" aria-label="Menu" aria-expanded="false">
            <span></span><span></span><span></span>
          </button>
        </div>
      </div>

      <div class="nav-mobile-menu" id="navMobileMenu" aria-hidden="true">
        <div class="nav-mobile-inner">
          ${links.map(([route, ic, key]) => {
            const active = currentHash === route || (currentHash === '' && route === '');
            const href = route === '' ? '#/' : `#/${route}`;
            return `<a href="${href}" class="nav-mobile-link ${active ? 'active' : ''}">${icon(ic)} ${esc(t(key))}</a>`;
          }).join('')}
          ${!isAuth ? `
            <a href="#/gallery" class="nav-mobile-link">${icon('camera')} ${esc(bn ? 'গ্যালারি' : 'Gallery')}</a>
            <a href="#/news" class="nav-mobile-link">${icon('bell')} ${esc(bn ? 'সংবাদ' : 'News')}</a>
            <a href="#/campaigns" class="nav-mobile-link">${icon('trophy')} ${esc(bn ? 'অভিযান' : 'Campaigns')}</a>
            <a href="#/camps" class="nav-mobile-link">${icon('calendar')} ${esc(bn ? 'রক্তদান ক্যাম্প' : 'Blood Camps')}</a>
            <a href="#/transparency" class="nav-mobile-link">${icon('activity')} ${esc(bn ? 'স্বচ্ছতা' : 'Transparency')}</a>
            <a href="#/downloads" class="nav-mobile-link">${icon('download')} ${esc(bn ? 'ডাউনলোড' : 'Downloads')}</a>
            <a href="#/volunteers-page" class="nav-mobile-link">${icon('volunteer')} ${esc(bn ? 'স্বেচ্ছাসেবী' : 'Volunteers')}</a>
            <a href="#/success-stories" class="nav-mobile-link">${icon('trophy')} ${esc(bn ? 'সাফল্যের গল্প' : 'Success Stories')}</a>
            <a href="#/faq" class="nav-mobile-link">${icon('info')} ${esc(bn ? 'প্রশ্নোত্তর' : 'FAQ')}</a>
          ` : `
            <a href="#/rewards" class="nav-mobile-link">${icon('award')} ${esc(t('rewards'))}</a>
            <a href="#/leaderboard" class="nav-mobile-link">${icon('trophy')} ${esc(bn ? 'লিডারবোর্ড' : 'Leaderboard')}</a>
            <a href="#/profile" class="nav-mobile-link">${icon('user')} ${esc(t('profile'))}</a>
          `}
          <hr class="nav-mobile-divider" />
          ${!isAuth ? `
            <a href="#/login" class="btn primary lg nav-mobile-cta">${esc(t('login'))}</a>
            <a href="#/register" class="btn ghost lg nav-mobile-cta">${esc(t('register'))}</a>
          ` : ''}
        </div>
      </div>
    </header>`;
}

export function initNavbarEvents() {
  const hamburger = document.getElementById('navHamburger');
  const mobileMenu = document.getElementById('navMobileMenu');
  const langToggle = document.getElementById('navLangToggle');
  const themeToggle = document.getElementById('navThemeToggle');

  if (hamburger && mobileMenu) {
    hamburger.addEventListener('click', () => {
      const isOpen = hamburger.classList.toggle('open');
      mobileMenu.classList.toggle('open', isOpen);
      hamburger.setAttribute('aria-expanded', isOpen);
      mobileMenu.setAttribute('aria-hidden', !isOpen);
      document.body.classList.toggle('nav-open', isOpen);
    });

    // Close menu when a link is clicked
    mobileMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        hamburger.classList.remove('open');
        mobileMenu.classList.remove('open');
        hamburger.setAttribute('aria-expanded', 'false');
        mobileMenu.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('nav-open');
      });
    });
  }

  if (langToggle) {
    langToggle.addEventListener('click', () => {
      const next = lang() === 'bn' ? 'en' : 'bn';
      setLang(next);
      document.documentElement.lang = next;
      location.reload();
    });
  }

  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      const isLight = document.documentElement.getAttribute('data-theme') === 'light';
      const next = isLight ? 'dark' : 'light';
      document.documentElement.setAttribute('data-theme', next);
      try { localStorage.setItem('bh_theme', next); } catch {}
      try {
        document.querySelector('meta[name="theme-color"]').content = next === 'light' ? '#f9fafb' : '#0a0c14';
      } catch {}
      // Update icon without full reload
      themeToggle.innerHTML = icon(next === 'dark' ? 'sun' : 'moon');
    });
  }
}
