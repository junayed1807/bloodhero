// Blood Hero — Professional Footer Component
// Displays brand info, quick links, resources, contact, and social links.
import { t, lang } from '../i18n.js';
import { esc, icon } from '../ui.js';
import { APP } from '../config.js';
import { Logo } from './Logo.js';

export function renderFooter() {
  const bn = lang() === 'bn';
  const year = new Date().getFullYear();

  return `
    <footer class="site-footer" id="siteFooter">
      <div class="footer-wave">
        <svg viewBox="0 0 1440 100" preserveAspectRatio="none" aria-hidden="true">
          <path d="M0,60 C360,10 720,90 1080,40 C1260,15 1380,50 1440,30 L1440,100 L0,100 Z" fill="currentColor"/>
        </svg>
      </div>
      <div class="footer-inner">
        <div class="footer-grid">
          <div class="footer-col footer-brand-col">
            <div class="footer-brand">
              ${Logo({ size: 'sm', alt: 'Blood Hero' })}
              <div>
                <strong>Blood Hero</strong>
                <small>${bn ? 'ব্লাড হিরো' : 'Every Drop Saves a Life'}</small>
              </div>
            </div>
            <p class="footer-desc">${esc(bn
              ? 'রক্তদাতা ও রক্তগ্রহীতার মধ্যে দ্রুত সংযোগ স্থাপনকারী বাংলাদেশের প্ল্যাটফর্ম।'
              : 'Bangladesh\'s platform connecting blood donors with patients in need — fast, trusted, and localized.')}</p>
            <div class="footer-social">
              <a href="${APP.facebookUrl || '#'}" target="_blank" rel="noopener noreferrer" aria-label="Facebook" class="social-icon">${icon('share')}</a>
            </div>
          </div>

          <div class="footer-col">
            <h4>${esc(bn ? 'দ্রুত লিংক' : 'Quick Links')}</h4>
            <ul>
              <li><a href="#/">${esc(t('home'))}</a></li>
              <li><a href="#/find-blood">${esc(t('findDonor'))}</a></li>
              <li><a href="#/request">${esc(t('needBlood'))}</a></li>
              <li><a href="#/awareness">${esc(bn ? 'সচেতনতা' : 'Awareness')}</a></li>
              <li><a href="#/about">${esc(t('about'))}</a></li>
            </ul>
          </div>

          <div class="footer-col">
            <h4>${esc(bn ? 'রিসোর্স' : 'Resources')}</h4>
            <ul>
              <li><a href="#/faq">${esc(bn ? 'প্রশ্নোত্তর' : 'FAQ')}</a></li>
              <li><a href="#/gallery">${esc(bn ? 'গ্যালারি' : 'Gallery')}</a></li>
              <li><a href="#/news">${esc(bn ? 'সংবাদ' : 'News & Updates')}</a></li>
              <li><a href="#/campaigns">${esc(bn ? 'অভিযান' : 'Campaigns')}</a></li>
              <li><a href="#/camps">${esc(bn ? 'রক্তদান ক্যাম্প' : 'Blood Camps')}</a></li>
              <li><a href="#/transparency">${esc(bn ? 'স্বচ্ছতা' : 'Transparency')}</a></li>
              <li><a href="#/downloads">${esc(bn ? 'ডাউনলোড' : 'Downloads')}</a></li>
              <li><a href="#/volunteers-page">${esc(bn ? 'স্বেচ্ছাসেবী' : 'Volunteers')}</a></li>
              <li><a href="#/success-stories">${esc(bn ? 'সাফল্যের গল্প' : 'Success Stories')}</a></li>
            </ul>
          </div>

          <div class="footer-col">
            <h4>${esc(t('contactUs'))}</h4>
            <ul class="footer-contact">
              <li>${icon('phone')} <span>+880 XXXX XXXXXX</span></li>
              <li>${icon('location')} <span>${esc(bn ? 'বাংলাদেশ' : 'Bangladesh')}</span></li>
            </ul>
            <a href="#/contact" class="btn ghost sm footer-contact-btn">${esc(t('sendMessage'))}</a>
          </div>
        </div>

        <div class="footer-bottom">
          <p>© ${year} Blood Hero — ${esc(bn ? 'ব্লাড হিরো' : APP.name)}. ${esc(t('rights'))}</p>
          <p class="footer-dev">${esc(t('developedBy'))} <strong>${esc(APP.creatorFull)}</strong></p>
        </div>
      </div>
    </footer>`;
}
