// Blood Hero — Authentication: Firebase Phone OTP + guest mode + role-based admin.
// Sessions are persisted locally; roles come from Firestore `users` (or demo data).
import { FIREBASE_CONFIG, LS } from './config.js';
import { online, Donors } from './db.js';
import { roleOf, ROLES } from './rbac.js';
import { rateLimit } from './lib/rateLimit.js';
import { connectUserApp, disableBackendMode } from '../shared/js/backend-api.js';

let auth = null;
let confirmationResult = null;
let recaptchaVerifier = null;

async function ensureAuth() {
  if (auth || !online) return auth;
  try {
    const appMod = await import('https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js');
    const authMod = await import('https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js');
    const app = appMod.getApps?.().length ? appMod.getApp() : appMod.initializeApp(FIREBASE_CONFIG);
    auth = authMod.getAuth(app);
    auth.languageCode = 'bn';
    window.__authMod = authMod;
  } catch (e) { console.warn('[BloodHero] Auth unavailable:', e.message || e); }
  return auth;
}

// ---------- session ----------
export function currentUser() {
  try { return JSON.parse(localStorage.getItem(LS.session)); } catch { return null; }
}
export function saveSession(user) {
  const clean = { ...user };
  delete clean.token;
  delete clean.refreshToken;
  localStorage.setItem(LS.session, JSON.stringify(clean));
}
export function logout() {
  localStorage.removeItem(LS.session);
  disableBackendMode();
  if (auth) window.__authMod?.signOut(auth).catch(() => {});
  location.hash = '#/';
  location.reload();
}

// Connect the user-app session to the backend via the phone-OTP bridge so
// pages like Impact and Recipient read real backend data. Non-fatal.
export async function connectBackend(phone) {
  if (!phone) return { status: 'skipped' };
  try {
    return await connectUserApp(phone);
  } catch (err) {
    console.warn('[BloodHero] Backend connect skipped:', err.message || err);
    return { status: 'unavailable' };
  }
}

export function isAdmin(user) {
  const u = user || currentUser();
  const r = roleOf(u);
  return r === ROLES.ADMIN || r === ROLES.SUPER_ADMIN || r === ROLES.ORG_ADMIN;
}

// look up role from donors/users collection by phone
async function resolveRole(phone) {
  try {
    const arr = await Donors.list();
    const found = arr.find(d => d.phone === phone);
    if (found) return found;
  } catch { /* ignore */ }
  return null;
}

// ---------- OTP flow ----------
export async function sendOtp(phone) {
  if (!rateLimit('otp_' + phone, 3, 60000)) throw new Error('Too many OTP requests. Wait a minute.');
  await ensureAuth();
  if (!auth) {
    // offline/demo mode: pretend OTP sent, accept any code
    confirmationResult = { confirm: async (code) => { if (!/^\d{4,6}$/.test(code)) throw new Error('bad code'); return { user: { uid: 'demo_' + phone.slice(-4) } }; } };
    return { demo: true };
  }
  const authMod = window.__authMod;
  if (!recaptchaVerifier) {
    recaptchaVerifier = new authMod.RecaptchaVerifier(auth, 'recaptcha-container', { size: 'invisible' });
  }
  confirmationResult = await authMod.signInWithPhoneNumber(auth, phone, recaptchaVerifier);
  return { demo: false };
}

export async function verifyOtp(code, profile = {}) {
  if (!confirmationResult) throw new Error('OTP not requested');
  const res = await confirmationResult.confirm(code);
  const phone = profile.phone || document.getElementById('phoneInput')?.value || '';
  const existing = phone ? await resolveRole(phone) : null;
  const user = {
    uid: res.user.uid,
    phone,
    name: profile.name || existing?.name || 'Blood Hero User',
    bloodGroup: profile.bloodGroup || existing?.bloodGroup || '',
    district: profile.district || existing?.district || '',
    upazila: profile.upazila || existing?.upazila || '',
    role: roleOf(existing),
    guest: false,
    lastDonation: existing?.lastDonation || null,
    totalDonations: existing?.totalDonations || 0,
    livesSaved: existing?.livesSaved || 0,
    loggedAt: Date.now(),
  };
  saveSession(user);
  connectBackend(phone);
  return user;
}

export async function guestLogin() {
  const user = {
    uid: 'guest', phone: '', name: 'Guest Hero', bloodGroup: '', district: '', upazila: '',
    role: ROLES.GUEST, guest: true, totalDonations: 0, livesSaved: 0, loggedAt: Date.now(),
  };
  saveSession(user);
  return user;
}

// register: create donor record + session
export async function registerDonor(profile) {
  const rec = await Donors.add({
    name: profile.name, bloodGroup: profile.bloodGroup, phone: profile.phone,
    district: profile.district || '', upazila: profile.upazila || '',
    union: profile.union || '', wardVillage: profile.wardVillage || '',
    age: profile.age || null, weight: profile.weight || null, emergencyContact: profile.emergencyContact || '',
    available: profile.available !== false, lastDonation: profile.lastDonation || null,
    totalDonations: 0, livesSaved: 0, role: ROLES.DONOR,
  });
  const user = {
    uid: rec.id, phone: profile.phone, name: profile.name, bloodGroup: profile.bloodGroup,
    district: rec.district, upazila: rec.upazila, union: rec.union, wardVillage: rec.wardVillage,
    role: ROLES.DONOR, guest: false,
    age: profile.age || null, weight: profile.weight || null, emergencyContact: profile.emergencyContact || '',
    lastDonation: rec.lastDonation, totalDonations: 0, livesSaved: 0, loggedAt: Date.now(),
  };
  saveSession(user);
  connectBackend(profile.phone);
  return user;
}