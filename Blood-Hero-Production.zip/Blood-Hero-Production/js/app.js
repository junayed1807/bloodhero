// Blood Hero — SPA entry: splash, auth gate, public pages, router, nav, language, back nav.
// v3.0: Public-first architecture — homepage and key pages accessible without login.
import { APP } from './config.js';
import { initDb } from './db.js';
import { t, lang, setLang } from './i18n.js';
import { currentUser, sendOtp, verifyOtp, guestLogin, registerDonor } from './auth.js';
import { esc, icon, toast, openModal, closeModal } from './ui.js';
import { Logo } from './components/Logo.js';
import { renderNavbar, initNavbarEvents } from './components/Navbar.js';
import { renderFooter } from './components/Footer.js';
import { renderHome } from './pages/home.js';
import { renderPublicHome } from './pages/publicHome.js';
import { renderDonors } from './pages/donors.js';
import { renderRequests, renderRequestForm, renderRequestDetail } from './pages/requests.js';
import { renderProfile } from './pages/profile.js';
import { renderEmergency, renderRewards, renderVolunteer, renderHealth, renderNotifications } from './pages/misc.js';
import { renderSupport, renderAbout } from './pages/support.js';
import { renderTracking } from './pages/tracking.js';
import { renderImpact } from './pages/impact.js';
import { renderRecipient } from './pages/recipient.js';
import { renderAmbulances } from './pages/ambulances.js';
import { renderScreening } from './pages/screening.js';
import { renderLeaderboard } from './pages/leaderboard.js';
import { renderCenters } from './pages/centers.js';
import { renderSocial } from './pages/social.js';
import { renderVerify } from './pages/verify.js';
import { renderDirectory } from './pages/directory.js';
import { renderNeed } from './pages/need.js';
import { renderDonorDetail } from './pages/donorDetail.js';
import { renderHeatmap } from './pages/heatmap.js';
import { renderAwareness } from './pages/awareness.js';
import { renderGallery, renderGalleryDetail, renderNews, renderNewsDetail, renderTransparency, renderDownloads, renderCampaigns, renderCampaignDetail, renderCamps, renderVolunteersPage, renderSuccessStories, renderContact, renderFaq } from './pages/public-pages.js';
import { renderAdmin } from './admin/admin.js';
import { DISTRICTS, upazilasFor, unionsFor, lname } from './data/rangpur.js';
import { verifyToken } from './db.js';
import { backendApi } from '../shared/js/backend-api.js';

const $ = s => document.querySelector(s);

// ---------- PUBLIC PAGES (no auth required) ----------
const PUBLIC_ROUTES = new Set([
  '', 'find-blood', 'about', 'contact', 'awareness', 'faq',
  'gallery', 'news', 'transparency', 'downloads', 'campaigns',
  'camps', 'volunteers-page', 'success-stories', 'login', 'register',
  'social', 'verify',
]);

// ---------- splash (1.8s -> app) ----------
function runSplash(done) {
  const sp = $('#splash');
  setTimeout(() => {
    sp.classList.add('out');
    setTimeout(() => { sp.remove(); done(); }, 450);
  }, 1800);
}

// ---------- auth screen ----------
function renderAuth() {
  // Hide navbar/footer for auth page
  const navC = $('#navContainer');
  const footC = $('#footerContainer');
  if (navC) navC.innerHTML = '';
  if (footC) footC.innerHTML = '';

  $('#authPage').innerHTML = `
    <div class="auth-inner">
      <div class="auth-logo">${Logo({ size: 'md', alt: APP.name })}</div>
      <h1>${esc(t('appName'))}</h1>
      <p class="auth-tag">${esc(lang() === 'bn' ? APP.taglineBn : APP.tagline)}</p>

      <div class="auth-tabs">
        <button class="auth-tab active" data-m="login">${esc(t('login'))}</button>
        <button class="auth-tab" data-m="register">${esc(t('register'))}</button>
      </div>

      <form id="loginForm" class="form-card flat">
        <label class="field-row"><span>${esc(t('phone'))}</span>
          <input class="field" id="phoneInput" type="tel" value="+880" required /></label>
        <div id="otpSection" class="hidden">
          <label class="field-row"><span>${esc(t('otpCode'))}</span>
            <input class="field" id="otpInput" inputmode="numeric" placeholder="123456" /></label>
          <button type="button" id="verifyBtn" class="btn primary">${esc(t('verifyLogin'))}</button>
        </div>
        <button type="submit" id="sendOtpBtn" class="btn primary lg">${esc(t('sendOtp'))}</button>
      </form>
      <button id="forgotPwdBtn" class="link muted-link" style="margin-top:-4px;">${lang() === 'bn' ? 'পাসওয়ার্ড ভুলে গেছেন?' : 'Forgot password?'}</button>

      <form id="regForm" class="form-card flat hidden">
        <label class="field-row"><span>${esc(t('name'))} *</span><input class="field" name="name" required /></label>
        <label class="field-row"><span>${esc(t('phone'))} *</span><input class="field" name="phone" type="tel" value="+880" required /></label>
        <div class="grid-2">
          <label class="field-row"><span>${esc(t('bloodGroup'))} *</span>
            <select class="field" name="bloodGroup">${['A+','A-','B+','B-','O+','O-','AB+','AB-'].map(g => `<option>${g}</option>`).join('')}</select></label>
          <label class="field-row"><span>${esc(t('lastDonation'))}</span><input class="field" type="date" name="lastDonation" /></label>
        </div>
        <div class="grid-2">
          <label class="field-row"><span>${esc(t('district'))} *</span>
            <select class="field" name="district" id="regDistrict" required><option value="">${esc(t('selectDistrict'))}</option></select></label>
          <label class="field-row"><span>${esc(t('upazila'))} *</span>
            <select class="field" name="upazila" id="regUpazila" required disabled><option value="">${esc(t('selectUpazila'))}</option></select></label>
        </div>
        <div class="grid-2">
          <label class="field-row"><span>${esc(t('selectUnion'))}</span>
            <select class="field" name="union" id="regUnion" disabled><option value="">${esc(t('selectUnion'))}</option></select></label>
          <label class="field-row"><span>${lang() === 'bn' ? 'ওয়ার্ড / গ্রাম' : 'Ward / Village'}</span>
            <input class="field" name="wardVillage" placeholder="${lang() === 'bn' ? 'যেমন: ৩ নং ওয়ার্ড' : 'e.g. Ward 3'}" /></label>
        </div>
        <div class="grid-2">
          <label class="field-row"><span>${esc(t('age'))} *</span><input class="field" name="age" type="number" min="18" max="65" required /></label>
          <label class="field-row"><span>${esc(t('weight'))} *</span><input class="field" name="weight" type="number" min="45" step="0.5" required /></label>
        </div>
        <label class="field-row"><span>${esc(t('emergencyContact'))}</span>
          <input class="field" name="emergencyContact" type="tel" placeholder="+8801XXXXXXXXX" /></label>
        <button class="btn primary lg" type="submit">${esc(t('register'))}</button>
      </form>

        <button id="guestBtn" class="link muted-link">${esc(t('guest'))}</button>
<div class="auth-links">
          <a href="#/" class="link mini-link">${lang() === 'bn' ? 'হোম পেজ' : 'Back to Home'}</a>
          <span class="dot-sep">·</span>
          <a href="#/social" class="link mini-link">${lang() === 'bn' ? 'কমিউনিটি ফিড' : 'Community Feed'}</a>
          <span class="dot-sep">·</span>
          <a href="#/verify" class="link mini-link">${lang() === 'bn' ? 'ভেরিফিকেশন' : 'Verify'}</a>
        </div>
      <div id="recaptcha-container" class="recap"></div>

      <footer class="auth-foot">
        <p class="dev-mini">${esc(t('developedBy'))} <strong>${esc(APP.creatorFull)}</strong></p>
        <a class="fb-mini" href="${APP.facebookUrl}" target="_blank" rel="noopener noreferrer">f Facebook</a>
      </footer>
    </div>`;

  const auth = $('#authPage');
  auth.classList.add('active');
  $('#appShell').classList.add('hidden');

  // location hierarchy (District -> Upazila -> Union), real Rangpur data
  const distSel = $('#regDistrict');
  if (distSel) {
    distSel.innerHTML = `<option value="">${esc(t('selectDistrict'))}</option>` +
      DISTRICTS.map(d => `<option value="${d}">${d}</option>`).join('');
    distSel.addEventListener('change', () => {
      const up = $('#regUpazila');
      const un = $('#regUnion');
      up.innerHTML = `<option value="">${esc(t('selectUpazila'))}</option>`;
      un.innerHTML = `<option value="">${esc(t('selectUnion'))}</option>`;
      un.disabled = true;
      const ups = upazilasFor(distSel.value);
      up.disabled = ups.length === 0;
      ups.forEach(u => up.appendChild(new Option(lname(u), lname(u))));
      un.disabled = ups.length === 0;
    });
    const upSel = $('#regUpazila');
    upSel.addEventListener('change', () => {
      const un = $('#regUnion');
      un.innerHTML = `<option value="">${esc(t('selectUnion'))}</option>`;
      const uns = unionsFor(distSel.value, upSel.value);
      un.disabled = uns.length === 0;
      uns.forEach(u => un.appendChild(new Option(lname(u), lname(u))));
    });
  }

  // tabs
  auth.querySelectorAll('.auth-tab').forEach(b => b.addEventListener('click', () => {
    auth.querySelectorAll('.auth-tab').forEach(x => x.classList.toggle('active', x === b));
    const reg = b.dataset.m === 'register';
    $('#loginForm').classList.toggle('hidden', reg);
    $('#regForm').classList.toggle('hidden', !reg);
  }));

  // OTP login
  $('#loginForm').addEventListener('submit', async e => {
    e.preventDefault();
    const btn = $('#sendOtpBtn');
    btn.disabled = true;
    try {
      const r = await sendOtp($('#phoneInput').value.trim());
      $('#otpSection').classList.remove('hidden');
      btn.classList.add('hidden');
      toast(r.demo ? (lang() === 'bn' ? 'ডেমো মোড: যেকোনো ৪-৬ সংখ্যার কোড দিন' : 'Demo mode: enter any 4-6 digit code') : (t('sendOtp') + ' ✓'), 'success');
    } catch (err) { toast(err.message, 'error'); btn.disabled = false; }
  });

  $('#forgotPwdBtn').addEventListener('click', () => {
    openModal(`
      <h3 class="modal-title">${lang() === 'bn' ? 'পাসওয়ার্ড রিসেট' : 'Reset Password'}</h3>
      <form id="fpForm" class="form-card flat">
        <label class="field-row"><span>${esc(t('phone'))}</span>
          <input class="field" name="phone" type="tel" value="+880" required /></label>
        <label class="field-row hidden" id="fpOtpRow"><span>OTP</span>
          <input class="field" name="otp" inputmode="numeric" /></label>
        <label class="field-row hidden" id="fpPwdRow"><span>${lang() === 'bn' ? 'নতুন পাসওয়ার্ড' : 'New password'}</span>
          <input class="field" name="newPassword" type="password" minlength="6" /></label>
        <p class="muted" id="fpMsg" style="font-size:.72rem;"></p>
        <button class="btn primary" type="submit">${lang() === 'bn' ? 'এগিয়ে যান' : 'Continue'}</button>
      </form>`);
    document.getElementById('fpForm').addEventListener('submit', async e => {
      e.preventDefault();
      const f = e.target;
      const phone = f.phone.value.trim();
      const msg = document.getElementById('fpMsg');
      if (!f.otp.value) {
        msg.textContent = lang() === 'bn' ? 'OTP পাঠানো হচ্ছে…' : 'Sending OTP…';
        try {
          const res = await backendApi.post('/auth/user/forgot-password', { phone });
          document.getElementById('fpOtpRow').classList.remove('hidden');
          document.getElementById('fpPwdRow').classList.remove('hidden');
          msg.textContent = lang() === 'bn'
            ? (res.demo ? 'ডেমো কোড: ' + res.devOtp : 'OTP পাঠানো হয়েছে।')
            : (res.demo ? 'Demo code: ' + res.devOtp : 'OTP sent.');
        } catch (err) { msg.textContent = err.message || 'Failed'; }
      } else {
        try {
          await backendApi.post('/auth/user/reset-password', { phone, otp: f.otp.value.trim(), newPassword: f.newPassword.value.trim() });
          toast(lang() === 'bn' ? 'পাসওয়ার্ড রিসেট হয়েছে' : 'Password reset', 'success');
          closeModal();
        } catch (err) { msg.textContent = err.message || 'Failed'; }
      }
    });
  });
  $('#verifyBtn').addEventListener('click', async () => {
    try { await verifyOtp($('#otpInput').value.trim()); enterApp(); }
    catch (err) { toast(lang() === 'bn' ? 'ভুল OTP' : 'Wrong OTP', 'error'); }
  });

  // register
  $('#regForm').addEventListener('submit', async e => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.target).entries());
    try { await registerDonor(data); toast(t('register') + ' ✓', 'success'); enterApp(); }
    catch (err) { toast(err.message, 'error'); }
  });

  // guest
  $('#guestBtn').addEventListener('click', async () => { await guestLogin(); enterApp(); });
}

// ---------- AUTHENTICATED app shell + bottom nav ----------
const NAV = [
  ['home', 'home', 'home'],
  ['donors', 'search', 'findDonor'],
  ['request', 'plus', 'needBlood'],
  ['ambulances', 'emergency', 'ambulanceDirectory'],
  ['social', 'heart', 'social'],
  ['impact', 'activity', 'impactTracking'],
  ['recipient', 'users', 'regularRecipient'],
  ['profile', 'user', 'profile'],
];

function renderShell(isPublic = false) {
  const shell = $('#appShell');
  shell.classList.remove('hidden');
  shell.className = isPublic ? 'public-shell' : '';

  if (isPublic) {
    shell.innerHTML = `<div id="main" class="page" role="main"></div>`;
  } else {
    shell.innerHTML = `
      <div id="main" class="page" role="main"></div>
      <nav class="bottom-nav" aria-label="primary">
        ${NAV.map(([route, ic, key], i) => `
          <a href="#/${route === 'home' ? '' : route}" data-r="${route}" class="bn-item ${i === 2 ? 'cta' : ''}">
            ${icon(ic)}<span>${esc(t(key))}</span></a>`).join('')}
      </nav>`;
  }
}

function highlightNav(route) {
  document.querySelectorAll('.bn-item').forEach(a => {
    a.classList.toggle('active', a.dataset.r === route || (route === '' && a.dataset.r === 'home'));
  });
}

function updateNavbar() {
  const navC = $('#navContainer');
  if (navC) {
    navC.innerHTML = renderNavbar();
    initNavbarEvents();
    // Scroll shadow
    const topNav = document.getElementById('topNav');
    if (topNav) {
      let ticking = false;
      window.addEventListener('scroll', () => {
        if (!ticking) {
          requestAnimationFrame(() => {
            topNav.classList.toggle('scrolled', window.scrollY > 10);
            ticking = false;
          });
          ticking = true;
        }
      });
    }
  }
}

function updateFooter(show = true) {
  const footC = $('#footerContainer');
  if (footC) {
    footC.innerHTML = show ? renderFooter() : '';
  }
}

// ---------- router ----------
const authRoutes = {
  '': renderHome, donors: renderDonors, alerts: renderEmergency,
  requests: renderRequests, request: renderRequestForm,
  rewards: renderRewards, volunteer: renderVolunteer, health: renderHealth,
  notifications: renderNotifications, profile: renderProfile,
  support: renderSupport, about: renderAbout,
  track: renderTracking, impact: renderImpact, recipient: renderRecipient, ambulances: renderAmbulances, screening: renderScreening, leaderboard: renderLeaderboard,
  centers: renderCenters, social: renderSocial, verify: renderVerify,
  directory: renderDirectory, need: renderNeed,
  heatmap: renderHeatmap, awareness: renderAwareness,
};

// Public routes (accessible without login)
const publicRoutes = {
  '': renderPublicHome,
  'find-blood': renderDonors,
  about: renderAbout,
  awareness: renderAwareness,
  social: renderSocial,
  verify: renderVerify,
  gallery: renderGallery,
  news: renderNews,
  transparency: renderTransparency,
  downloads: renderDownloads,
  campaigns: renderCampaigns,
  camps: renderCamps,
  'volunteers-page': renderVolunteersPage,
  'success-stories': renderSuccessStories,
  contact: renderContact,
  faq: renderFaq,
};

async function route() {
  const hash = location.hash.replace(/^#\/?/, '');
  const [path, arg] = hash.split('/');
  const user = currentUser();
  const isAuth = user && !user.guest;

  // Login/Register: show auth screen
  if (path === 'login' || path === 'register') {
    renderAuth();
    if (path === 'register') {
      // Auto-switch to register tab
      setTimeout(() => {
        const regTab = document.querySelector('.auth-tab[data-m="register"]');
        if (regTab) regTab.click();
      }, 100);
    }
    return;
  }

  // Admin redirect
  if (path === 'admin') { location.href = '../admin-panel/'; return; }

  // If NOT authenticated and route is NOT public, show public homepage or redirect to login
  if (!isAuth && !PUBLIC_ROUTES.has(path)) {
    // For protected routes, redirect to login
    location.hash = '#/login';
    return;
  }

  // Determine if showing public or auth view
  const isPublic = !isAuth;
  const page = $('#main');

  // Ensure shell is rendered (may need to switch between public/auth modes)
  const shell = $('#appShell');
  if (shell.classList.contains('hidden') || (isPublic && !shell.classList.contains('public-shell')) || (!isPublic && shell.classList.contains('public-shell'))) {
    renderShell(isPublic);
    updateNavbar();
    updateFooter(true);
  }

  // Hide auth page if visible
  const authPage = $('#authPage');
  if (authPage) {
    authPage.classList.remove('active');
    authPage.innerHTML = '';
  }

  const mainEl = $('#main');
  if (!mainEl) return;

  // Handle detail routes
  if (path === 'request' && arg !== undefined) {
    await renderRequestDetail(mainEl, decodeURIComponent(arg));
    highlightNav('');
    return;
  }
  if (path === 'donor' && arg !== undefined) {
    await renderDonorDetail(mainEl, decodeURIComponent(arg));
    highlightNav('');
    return;
  }
  if (path === 'verify' && arg !== undefined) {
    await renderVerifyToken(mainEl, decodeURIComponent(arg));
    highlightNav('');
    return;
  }
  if (path === 'gallery' && arg !== undefined) {
    await renderGalleryDetail(mainEl, decodeURIComponent(arg));
    highlightNav('gallery');
    return;
  }
  if (path === 'news' && arg !== undefined) {
    await renderNewsDetail(mainEl, decodeURIComponent(arg));
    highlightNav('news');
    return;
  }
  if (path === 'campaigns' && arg !== undefined) {
    await renderCampaignDetail(mainEl, decodeURIComponent(arg));
    highlightNav('campaigns');
    return;
  }

  // Choose the right route map
  const routeMap = isAuth ? authRoutes : publicRoutes;
  const fn = routeMap[path] || routeMap[''];

  try { await fn(mainEl); }
  catch (e) { console.error(e); mainEl.innerHTML = `<div class="empty section">${icon('alert')} Error loading page</div>`; }

  highlightNav(path);
  mainEl.scrollTo?.(0, 0);
  window.scrollTo(0, 0);

  // Update navbar active state
  updateNavbar();
}

function enterApp() {
  $('#authPage').classList.remove('active');
  $('#authPage').innerHTML = '';
  renderShell(false);
  updateNavbar();
  updateFooter(true);
  if (!location.hash || location.hash === '#/login' || location.hash === '#/register') location.hash = '#/';
  route();
}

async function renderVerifyToken(root, token) {
  const payload = verifyToken(token);
  if (!payload) {
    root.innerHTML = `<section class="section narrow"><div class="empty"><h3>${esc('Invalid or expired token')}</h3><p class="muted">${esc('Ask the donor to refresh their QR code.')}</p></div></section>`;
    return;
  }
  root.innerHTML = `<section class="section narrow">
    <div class="q-card"><div class="q-ic ok">${icon('check')}</div>
      <h3>${esc('Verified Donor Token')}</h3>
      <p class="muted">${esc('Donor ID: BH-')}${esc(String(payload.sub || '').slice(-6).toUpperCase())}</p>
      <p class="muted">${esc('Expires:')} ${esc(new Date(payload.exp).toLocaleTimeString())}</p>
      <p class="muted" style="font-size:.7rem; margin-top:8px;">${esc(t('finalDisclaimerBn'))}</p>
    </div>
  </section>`;
}

// ---------- boot ----------
window.addEventListener('hashchange', route);
document.addEventListener('DOMContentLoaded', async () => {
  document.documentElement.lang = lang();
  setLang(lang());
  window.__dbReady = initDb(); // background: demo fallback handles failures
  runSplash(async () => {
    await (window.__dbReady || Promise.resolve());
    const user = currentUser();
    if (user && !user.guest) {
      enterApp();
    } else {
      // Show public homepage (no login forced!)
      renderShell(true);
      updateNavbar();
      updateFooter(true);
      route();
    }
  });
});
