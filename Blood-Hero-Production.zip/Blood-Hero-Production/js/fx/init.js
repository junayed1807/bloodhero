// Blood Hero FX — bootstrap (visual layer only; zero app-logic coupling)
// • Applies saved theme (LS key 'bh_theme' — pre-existing, unused by app logic)
// • Injects ambient background layers (#bg-glow, #bg-grid)
// • Re-runs cosmetic enhancers after every hash route render
// • Lazy-loads js/fx/anim.js; hard-fails silently if anything breaks
const FX_KEY = 'bh_fx_off';

function fxDisabled() {
  try { return localStorage.getItem(FX_KEY) === '1'; } catch { return false; }
}

function applyTheme() {
  try {
    const t = localStorage.getItem('bh_theme');
    if (t === 'light') document.documentElement.setAttribute('data-theme', 'light');
    else document.documentElement.removeAttribute('data-theme'); // default dark
  } catch { /* storage unavailable — keep default */ }
}

function mountScene() {
  if (document.getElementById('bg-glow')) return;
  const glow = document.createElement('div');
  glow.id = 'bg-glow';
  glow.setAttribute('aria-hidden', 'true');
  const grid = document.createElement('div');
  grid.id = 'bg-grid';
  grid.setAttribute('aria-hidden', 'true');
  document.body.prepend(glow, grid);
}

function init() {
  if (fxDisabled()) { document.documentElement.classList.add('fx-off'); applyTheme(); return; }
  document.documentElement.classList.add('fx');
  applyTheme();
  mountScene();

  import('./anim.js').then(m => {
    m.initFx();
    // Theme toggle re-check (storage events fire cross-tab; profile toggle reloads anyway)
    window.addEventListener('storage', e => { if (e.key === 'bh_theme') applyTheme(); });
  }).catch(err => console.warn('[BloodHero FX] animation layer unavailable', err));

  // 3D field after first paint / when the browser is idle — never blocks the splash or auth.
  const boot3D = () => import('./bg3d.js').then(m => m.init3D()).catch(() => {});
  if ('requestIdleCallback' in window) requestIdleCallback(boot3D, { timeout: 3200 });
  else window.addEventListener('load', () => setTimeout(boot3D, 1200), { once: true });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init, { once: true });
} else {
  init();
}
