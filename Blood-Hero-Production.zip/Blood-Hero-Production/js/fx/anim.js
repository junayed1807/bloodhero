// Blood Hero FX — cosmetic enhancers (reveal, count-up, page transitions).
// Loaded by init.js. Never touches data, auth, or event handlers owned by pages.

const DUR = 850;

function easeOutCubic(x) { return 1 - Math.pow(1 - x, 3); }

function animateCount(el) {
  const target = parseFloat(el.dataset.countTo);
  if (!isFinite(target)) { el.removeAttribute('data-counting'); return; }
  const suffix = el.dataset.suffix || '';
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const dec = target % 1 ? 1 : 0;
  const render = v => { el.firstChild.nodeValue = (dec ? v.toFixed(dec) : Math.round(v).toString()) + suffix; };
  if (reduce) { render(target); el.removeAttribute('data-counting'); return; }
  const t0 = performance.now();
  const tick = now => {
    const p = Math.min(1, (now - t0) / DUR);
    render(target * easeOutCubic(p));
    if (p < 1) requestAnimationFrame(tick);
    else el.removeAttribute('data-counting');
  };
  requestAnimationFrame(tick);
}

// Prime [data-countup] elements inside root: stash value, zero out, start when visible.
export function primeCounters(root) {
  if (!root || !root.querySelectorAll) return;
  root.querySelectorAll('[data-countup]:not([data-counting])').forEach(el => {
    const raw = (el.textContent || '').trim();
    if (!el.firstChild || el.firstChild.nodeType !== 3) return; // needs leading text node
    const m = raw.match(/^(-?[\d.,]+)(.*)$/);
    if (!m) return;
    const num = parseFloat(m[1].replace(/,/g, ''));
    if (!isFinite(num)) return;
    el.dataset.counting = '1';
    el.dataset.countTo = String(num);
    el.dataset.suffix = m[2] || '';
    el.firstChild.nodeValue = '0' + el.dataset.suffix;
    countersObserver?.observe(el);
  });
}

// Wrap a numeric page-section in a reveal container (rebound to our IO).
// .reveal elements that belong to main.css-designed flow stay untouched.
export function revealPage(root) {
  if (!root || !root.querySelectorAll) return;
  const sections = root.querySelectorAll('.page > section, .page > article, .admin-shell > *');
  let i = 0;
  sections.forEach(sec => {
    if (sec.classList.contains('reveal')) return;
    sec.classList.add('reveal');
    sec.style.setProperty('--d', `${Math.min(i, 6) * 70}ms`);
    i++;
    revealObserver?.observe(sec);
  });
}

// Observed elements get .in (reveal) or counted (counters).
const revealObserver = ('IntersectionObserver' in window) ? new IntersectionObserver(entries => {
  entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); revealObserver.unobserve(e.target); } });
}, { threshold: .12, rootMargin: '0px 0px -6% 0px' }) : null;

const countersObserver = ('IntersectionObserver' in window) ? new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) { countersObserver.unobserve(e.target); animateCount(e.target); }
  });
}, { threshold: .4 }) : null;

// Route-aware post-render hook. Called by app.js? No — called via the
// 'bhf:route' custom event dispatched from init.js' hashchange listener,
// so app.js needs no edits beyond loading this module.
export function postRender() {
  const page = document.getElementById('page');
  if (!page) return;
  revealPage(page);
  primeCounters(page);
}

function initTilt() {
  if (!window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  document.addEventListener('pointermove', throttle(e => {
    const card = e.target.closest?.('[data-tilt]');
    if (!card) return;
    const r = card.getBoundingClientRect();
    const rx = ((e.clientY - r.top) / r.height - .5) * -6;
    const ry = ((e.clientX - r.left) / r.width - .5) * 7;
    card.style.transform = `perspective(900px) rotateX(${rx.toFixed(2)}deg) rotateY(${ry.toFixed(2)}deg)`;
  }, 16));
  document.addEventListener('pointerout', e => {
    const card = e.target.closest?.('[data-tilt]');
    if (card) card.style.transform = '';
  });
}

function throttle(fn, ms) {
  let last = 0, queued = null;
  return (...args) => {
    const now = performance.now();
    if (now - last >= ms) { last = now; fn(...args); }
    else { clearTimeout(queued); queued = setTimeout(() => { last = performance.now(); fn(...args); }, ms - (now - last)); }
  };
}

function initRipple() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  document.addEventListener('pointerdown', e => {
    const host = e.target.closest?.('.btn, .quick-card, .chip, .menu-row, .bn-item');
    if (!host) return;
    const r = host.getBoundingClientRect();
    const d = Math.max(r.width, r.height);
    const s = document.createElement('span');
    s.className = 'bh-ripple';
    s.style.width = s.style.height = d + 'px';
    s.style.left = (e.clientX - r.left - d / 2) + 'px';
    s.style.top = (e.clientY - r.top - d / 2) + 'px';
    host.appendChild(s);
    setTimeout(() => s.remove(), 600);
  }, { passive: true });
}

let started = false;
export function initFx() {
  if (started) return;
  started = true;
  const run = () => postRender();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run, { once: true });
  else run();
  let t;
  window.addEventListener('hashchange', () => { clearTimeout(t); t = setTimeout(run, 30); });
  initTilt();
  initRipple();
}
