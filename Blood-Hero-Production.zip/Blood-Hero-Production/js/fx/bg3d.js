// Blood Hero FX — ambient particle field (three.js over CDN; lazy, optional, pause-aware).
// Rendered into a fixed canvas behind the app shell. No interaction, no data, no layout impact.
// Falls back silently to the CSS glow scene whenever WebGL or the CDN is unavailable.
const reduced = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

export async function init3D() {
  if (reduced()) return false;
  if (document.documentElement.classList.contains('fx-off')) return false;

  const canvas = document.createElement('canvas');
  canvas.className = 'fx-canvas';
  canvas.setAttribute('aria-hidden', 'true');
  document.body.appendChild(canvas);

  let renderer = null, raf = 0, points = null, clock = null, cleanup = null;
  try {
    const THREE = await import('https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js');

    // Capacity scales down for modest devices without any detectable data on this browser.
    const cores = navigator.hardwareConcurrency || 4;
    const mem = navigator.deviceMemory || 4;
    const COUNT = (cores < 4 || mem < 4) ? 60 : 180;
    const DPR = Math.min(window.devicePixelRatio || 1, 1.5);

    renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: false, powerPreference: 'low-power' });
    renderer.setPixelRatio(DPR);
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(62, 1, .1, 60);
    camera.position.z = 14;

    // Blood-bokeh particles: soft red dots on a CanvasTexture — no image fetches.
    const size = 64;
    const cv = document.createElement('canvas');
    cv.width = cv.height = size;
    const g = cv.getContext('2d');
    const grad = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
    grad.addColorStop(0, 'rgba(255,120,130,1)');
    grad.addColorStop(.45, 'rgba(240,70,85,.5)');
    grad.addColorStop(1, 'rgba(240,70,85,0)');
    g.fillStyle = grad;
    g.fillRect(0, 0, size, size);
    const tex = new THREE.CanvasTexture(cv);

    const geo = new THREE.BufferGeometry();
    const pos = new Float32Array(COUNT * 3);
    const phase = new Float32Array(COUNT);
    for (let i = 0; i < COUNT; i++) {
      // Denser band across the hero region (upper third) — the rest of the field stays sparse.
      pos[i * 3] = (Math.random() - .5) * 26;
      pos[i * 3 + 1] = Math.random() < .28 ? Math.random() * 7 + 1.5 : (Math.random() - .5) * 18;
      pos[i * 3 + 2] = (Math.random() - .5) * 8 - 2;
      phase[i] = Math.random() * Math.PI * 2;
    }
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const mat = new THREE.PointsMaterial({
      size: .55, map: tex, transparent: true, opacity: .62,
      depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true,
    });
    points = new THREE.Points(geo, mat);
    scene.add(points);

    const resize = () => {
      const w = window.innerWidth, h = window.innerHeight;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    window.addEventListener('resize', resize, { passive: true });
    resize();

    clock = new THREE.Clock();
    let mx = 0, my = 0;
    if (window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
      window.addEventListener('pointermove', e => {
        mx = (e.clientX / window.innerWidth - .5) * 2;
        my = (e.clientY / window.innerHeight - .5) * 2;
      }, { passive: true });
    }

    const tick = () => {
      raf = requestAnimationFrame(tick);
      const el = clock.getElapsedTime();
      const p = geo.attributes.position.array;
      for (let i = 0; i < COUNT; i++) {
        p[i * 3 + 1] += Math.sin(el * .35 + phase[i]) * .0022;
        p[i * 3] += Math.cos(el * .22 + phase[i]) * .0011;
        if (p[i * 3 + 1] > 10) p[i * 3 + 1] = -10;
        if (p[i * 3 + 1] < -10) p[i * 3 + 1] = 10;
      }
      geo.attributes.position.needsUpdate = true;
      points.rotation.z = el * .015;
      camera.position.x += (mx * .4 - camera.position.x) * .02;
      camera.position.y += (-my * .3 - camera.position.y) * .02;
      camera.lookAt(0, 0, 0);
      renderer.render(scene, camera);
    };
    raf = requestAnimationFrame(tick);

    const onVis = () => {
      if (document.hidden) { cancelAnimationFrame(raf); raf = 0; }
      else if (!raf) { clock.getDelta(); raf = requestAnimationFrame(tick); }
    };
    document.addEventListener('visibilitychange', onVis);

    cleanup = () => {
      cancelAnimationFrame(raf);
      document.removeEventListener('visibilitychange', onVis);
      window.removeEventListener('resize', resize);
      tex.dispose(); geo.dispose(); mat.dispose();
      renderer.dispose();
      canvas.remove();
    };
  } catch (err) {
    console.warn('[BloodHero FX] 3D scene disabled:', err.message || err);
    cleanup?.();
    return false;
  }

  requestAnimationFrame(() => canvas.classList.add('on'));
  return true;
}
