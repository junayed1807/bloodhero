// Regular Recipient Mode — recurring blood requirement management
import { t, lang } from '../i18n.js';
import { currentUser, connectBackend } from '../auth.js';
import { esc, icon, toast } from '../ui.js';
import { backendApi, isBackendAvailable } from '../../shared/js/backend-api.js';

const bn = (b, e) => lang() === 'bn' ? b : e;

export async function renderRecipient(root) {
  const u = currentUser() || {};
  root.innerHTML = `
    <section class="section narrow">
      <div class="page-head"><h2>${bn('নিয়মিত রক্ত প্রাপ্তকারী', 'Regular Recipient Mode')}</h2>
        <p class="muted">${bn('থ্যালাসেমিয়া বা নিয়মিত রক্তচাহিদা ব্যবস্থাপনা', 'Manage recurring blood requirements')}</p></div>
      <div id="programList" class="card-list"><div class="empty">${icon('loader')} ${bn('লোড হচ্ছে…', 'Loading…')}</div></div>
      <button class="btn primary" id="addProgramBtn" style="margin-top:14px;">${icon('plus')} ${bn('নতুন প্রোগ্রাম', 'New Program')}</button>
    </section>`;

  if (!isBackendAvailable()) {
    const phone = u.phone;
    if (phone) {
      const res = await connectBackend(phone);
      if (res.status !== 'connected') {
        renderOffline();
        return;
      }
    } else {
      renderOffline();
      return;
    }
  }

  await loadPrograms();

  root.querySelector('#addProgramBtn').addEventListener('click', () => {
    import('../ui.js').then(({ openModal, closeModal }) => {
      openModal(`
        <h3 class="modal-title">${lang() === 'bn' ? 'নিয়মিত রক্ত প্রোগ্রাম' : 'New Recipient Program'}</h3>
        <form id="recipientForm" class="form-card flat">
          <label class="field-row"><span>${esc(t('name'))}</span>
            <input class="field" name="name" required placeholder="${lang() === 'bn' ? 'যেমন: মোহাম্মদ রফিক' : 'e.g. Mohammad Rafi'}" /></label>
          <label class="field-row"><span>${esc(t('bloodGroup'))} *</span>
            <select class="field" name="blood_group">${['A+','A-','B+','B-','O+','O-','AB+','AB-'].map(g => `<option>${g}</option>`).join('')}</select></label>
          <label class="field-row"><span>${lang() === 'bn' ? 'ইন্টারভাল (দিন)' : 'Interval (days)'}</span>
            <input class="field" name="interval_days" type="number" value="14" min="7" max="60" /></label>
          <label class="field-row"><span>${bn('পছন্দের কেন্দ্র', 'Preferred Centre')}</span>
            <input class="field" name="preferred_centre" placeholder="${lang() === 'bn' ? 'যেমন: রংপুর ব্লাড ব্যাংক' : 'e.g. Rangpur Blood Bank'}" /></label>
          <label class="field-row"><span>${bn('পছন্দের ডোনার পুল', 'Preferred Donor Pool')}</span>
            <input class="field" name="preferred_donor_pool" placeholder="${lang() === 'bn' ? 'বিশেষজ্ঞ ডোনারদের তালিকা' : 'List of regular donors'}" /></label>
          <button class="btn primary" type="submit">${icon('check')} ${esc(t('submit'))}</button>
        </form>
      `);
      document.getElementById('recipientForm').addEventListener('submit', async e => {
        e.preventDefault();
        const data = Object.fromEntries(new FormData(e.target).entries());
        try {
          await backendApi.post('/recipient-programs', data);
          toast(lang() === 'bn' ? 'প্রোগ্রাম তৈরি হয়েছে' : 'Program created', 'success');
          closeModal();
          loadPrograms();
        } catch (err) {
          toast(err.message || 'Failed', 'error');
        }
      });
    });
  });

  async function loadPrograms() {
    try {
      const programs = await backendApi.get('/recipient-programs');
      const list = root.querySelector('#programList');
      list.innerHTML = programs.length === 0
        ? `<div class="empty">${icon('info')} ${bn('কোনো প্রোগ্রাম নেই।', 'No programs yet.')}</div>`
        : programs.map(p => `
          <article class="panel">
            <div class="panel-head"><h3>${esc(p.name)}</h3>
              <span class="badge ${p.active ? 'green' : 'gray'}">${p.active ? bn('সক্রিয়', 'Active') : bn('নিষ্ক্রিয়', 'Inactive')}</span></div>
            <div class="mini-row"><span>${esc(t('bloodGroup'))}</span><strong>${esc(p.blood_group)}</strong></div>
            <div class="mini-row"><span>${bn('ইন্টারভাল', 'Interval')}</span><strong>${p.interval_days} ${bn('দিন', 'days')}</strong></div>
            <div class="mini-row"><span>${bn('পছন্দের কেন্দ্র', 'Preferred Centre')}</span><strong>${esc(p.preferred_centre || '—')}</strong></div>
            ${p.next_request_date ? `<div class="mini-row"><span>${bn('পরবর্তী রিকোয়েস্ট', 'Next Request')}</span><strong>${new Date(p.next_request_date * 1000).toLocaleDateString(lang() === 'bn' ? 'bn-BD' : 'en-GB')}</strong></div>` : ''}
          </article>
        `).join('');
    } catch (err) {
      console.error('Failed to load programs:', err);
      root.querySelector('#programList').innerHTML =
        `<div class="empty">${icon('alert')} ${bn('ডেটা লোড করতে ব্যর্থ হয়েছে।', 'Failed to load programs.')}</div>`;
    }
  }

  function renderOffline() {
    const list = root.querySelector('#programList');
    if (!list) return;
    list.innerHTML = `
      <div class="empty">${icon('info')}
        ${bn('ব্যাকএন্ড সার্ভার অফলাইন — পুনরায় চেষ্টা করুন।', 'Backend server offline — please retry.')}
        <button class="btn primary sm" id="recipientRetry" style="margin-top:8px;">${bn('আবার চেষ্টা করুন', 'Retry')}</button>
      </div>`;
    document.getElementById('recipientRetry')?.addEventListener('click', () => location.reload());
  }
}
