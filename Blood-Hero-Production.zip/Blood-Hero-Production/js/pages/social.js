// Social Feed (verified donation posts + Love reactions) — humanitarian community
import { t, lang } from '../i18n.js';
import { Reviews, Donors, Donations, Audit } from '../db.js';
import { currentUser, saveSession } from '../auth.js';
import { esc, icon, toast, requireLoginModal } from '../ui.js';

export async function renderSocial(root) {
  const u = currentUser() || {};
  const [reviews, donors] = await Promise.all([Reviews.list(), Donors.list()]);
  const donorById = Object.fromEntries(donors.map(d => [d.id, d]));

  root.innerHTML = `
    <section class="section">
      <div class="page-head row">
        <div><h2>${lang() === 'bn' ? 'কমিউনিটি ফিড' : 'Community Feed'}</h2>
          <p class="muted">${lang() === 'bn' ? 'শুধু verified দান এখানে দেখায়' : 'Only verified donations appear here'}</p></div>
      </div>

      ${u.guest ? `<div class="tip-card">${icon('info')}<p>${lang() === 'bn' ? 'Verified দান শেয়ার করতে লগইন করুন।' : 'Log in to share your verified donation.'}</p></div>` :
        (await Donations.forDonor(u.uid)).filter(d => d.status === 'verified').length > 0 ? `
        <form id="postForm" class="post-composer">
          <textarea class="field" rows="2" maxlength="280" placeholder="${lang() === 'bn' ? 'আপনার দান-অভিজ্ঞতা লিখুন… (শুধু verified দান)' : 'Share your verified donation experience…'}" required></textarea>
          <button class="btn primary">${icon('gift')} ${lang() === 'bn' ? 'পোস্ট' : 'Post'}</button>
        </form>` : `<div class="tip-card">${icon('info')}<p>${lang() === 'bn' ? 'পোস্ট করতে কমপক্ষে একটি Verified দান লাগবে।' : 'You need at least one Verified donation to post.'}</p></div>`}

      <div class="card-list feed">
        ${reviews.filter(r => r.verified).map(r => {
          const d = donorById[r.donorId] || {};
          const me = u.uid;
          const reacted = (r.love || []).includes(me);
          return `
            <article class="post-card">
              <div class="post-head">
                <span class="blood-badge">${esc(d.bloodGroup || '?')}</span>
                <div>
                  <h4>${esc(d.name || 'Hero')}</h4>
                  <p class="muted">${esc(d.district || '')} · ${new Date(r.createdAt).toLocaleDateString(lang() === 'bn' ? 'bn-BD' : 'en-GB')}</p>
                </div>
                <span class="badge green verified">✅ ${lang() === 'bn' ? 'Verified দান' : 'Verified Donation'}</span>
              </div>
              <p class="post-text">${esc(r.text)}</p>
              ${r.photoUrl ? `<img class="post-img" src="${esc(r.photoUrl)}" alt="Donation photo" loading="lazy" />` : ''}
              <div class="post-acts">
                <button class="reaction ${reacted ? 'loved' : ''}" data-id="${esc(r.id)}">${icon('heart')} <span>${(r.love || []).length}</span></button>
                <button class="reaction share" data-id="${esc(r.id)}">${icon('share')} ${lang() === 'bn' ? 'শেয়ার' : 'Share'}</button>
              </div>
            </article>`;
        }).join('') || `<div class="empty">${icon('heart')} ${lang() === 'bn' ? 'এখনো কোনো verified দান নেই — আপনিই প্রথম হতে পারেন।' : 'No verified donations yet — you could be first.'}</div>`}
      </div>
    </section>`;

  root.querySelectorAll('.reaction:not(.share)').forEach(b => b.addEventListener('click', async () => {
    if (u.guest) { requireLoginModal(); return; }
    const res = await Reviews.react(b.dataset.id, u.uid);
    b.classList.toggle('loved', res.loved);
    const countEl = b.querySelector('span'); if (countEl) countEl.textContent = +(countEl.textContent || 0) + (res.loved ? 1 : -1);
  }));

  root.querySelectorAll('.reaction.share').forEach(b => b.addEventListener('click', () => {
    const url = location.origin + location.pathname + '#/social';
    const text = lang() === 'bn' ? 'Blood Hero — একটি verified দান দেখুন!' : 'See this verified donation on Blood Hero!';
    if (navigator.share) { navigator.share({ title: 'Blood Hero', text, url }).catch(() => {}); return; }
    navigator.clipboard?.writeText(url).then(() => toast(lang() === 'bn' ? 'লিংক কপি হয়েছে' : 'Link copied', 'success'));
  }));

  const pf = root.querySelector('#postForm');
  if (pf) pf.addEventListener('submit', async e => {
    e.preventDefault();
    const text = pf.querySelector('textarea').value.trim();
    if (!text) return;
    // user's donations must be verified to post publicly
    const myDonations = (await import('../db.js')).then(m => m.Donations.forDonor(u.uid));
    const myVerified = (await myDonations).filter(d => d.status === 'verified');
    if (!myVerified.length) { toast(lang() === 'bn' ? 'কেবল verified দান শেয়ার করা যায়' : 'Only verified donations can be posted', 'error'); return; }
    await Reviews.add({ donorId: u.uid, text, verified: true, donationId: myVerified[0].id, createdAt: Date.now() });
    Audit.log(u.name || 'user', 'post_review', 'social');
    toast(lang() === 'bn' ? 'পোস্ট হয়েছে!' : 'Posted!', 'success');
    renderSocial(root);
  });
}
