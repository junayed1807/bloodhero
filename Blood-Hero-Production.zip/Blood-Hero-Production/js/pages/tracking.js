// Donation tracking — 5-step journey (from 100+ project: Track Donation screen)
import { t, lang } from '../i18n.js';
import { esc, icon, toast } from '../ui.js';

export async function renderTracking(root) {
  const steps = lang() === 'bn'
    ? ['সংগ্রহ সম্পন্ন', 'ল্যাব পরীক্ষা', 'কম্পোনেন্ট প্রসেসিং', 'পরিবহন চলমান', 'জীবন বাঁচবে']
    : ['Collected', 'Lab Testing', 'Component Processing', 'In Transport', 'Saving a Life'];
  const current = 3;
  root.innerHTML = `
    <section class="section narrow">
      <div class="page-head row">
        <h2>${esc(t('track'))}</h2><span class="badge red">VP-29384</span>
      </div>
      <div class="track-card">
        <div class="track-map">
          <div class="map-grid"></div>
          <div class="map-pin pulsing-pin">${icon('location')}</div>
          <span class="map-dest">Dhaka Medical College</span>
        </div>
        <ol class="steps">
          ${steps.map((s, i) => `
            <li class="${i < current ? 'done' : i === current ? 'now' : ''}">
              <span class="dot">${i < current ? icon('check') : ''}</span>
              <span>${esc(s)}</span>
            </li>`).join('')}
        </ol>
      </div>
      <div class="tip-card">${icon('heart')}<div><h4>O- ${lang() === 'bn' ? 'হাই ডিমান্ড' : 'High Demand'}</h4><p>${esc(t('yourImpact'))}</p></div></div>
      <button class="btn primary lg" id="shareImpactBtn">${icon('share')} ${esc(t('shareImpact'))}</button>
    </section>`;

  root.querySelector('#shareImpactBtn').addEventListener('click', async () => {
    const text = lang() === 'bn' ? 'আমি Blood Hero দিয়ে রক্ত দিয়ে ৩টি জীবন বাঁচালাম!' : 'I just saved 3 lives with Blood Hero!';
    if (navigator.share) {
      try { await navigator.share({ title: 'Blood Hero', text }); return; } catch { /* user dismissed */ }
    }
    try {
      await navigator.clipboard.writeText(text);
      toast(lang() === 'bn' ? 'কপি হয়েছে — শেয়ার করুন!' : 'Copied — share it!', 'success');
    } catch {
      toast(text, 'info');
    }
  });
}
