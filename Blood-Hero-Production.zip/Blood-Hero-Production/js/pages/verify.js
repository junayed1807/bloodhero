// User Verification Center — NID submit + Donation proof + Recipient confirm queue
import { t, lang } from '../i18n.js';
import { NidVerifications, Donations, Audit, Notifications } from '../db.js';
import { currentUser, saveSession } from '../auth.js';
import { DONATION_STATUS, NID_STATUS } from '../rbac.js';
import { esc, icon, toast } from '../ui.js';
import { backendApi, isBackendAvailable } from '../../shared/js/backend-api.js';
import { validateImageFile, fileToBase64, saveDonationProof } from '../../shared/js/storage.js';

const bn = (b, e) => lang() === 'bn' ? b : e;

export async function renderVerify(root) {
  const u = currentUser() || {};
  if (!u.uid || u.guest) {
    root.innerHTML = `<div class="section narrow empty">${icon('shield')}<p>${bn('ভেরিফিকেশনের জন্য লগইন করুন।', 'Log in for verification.')}</p></div>`;
    return;
  }
  const backendOn = isBackendAvailable();
  let myNid = null;
  try {
    myNid = backendOn
      ? await backendApi.get('/nid-verifications/me')
      : await NidVerifications.forUser(u.uid);
  } catch { myNid = null; }
  const myDonations = await Donations.forDonor(u.uid);
  const pending = myDonations.filter(d => d.status === 'pending_verification' || d.status === 'submitted');
  const verified = myDonations.filter(d => d.status === DONATION_STATUS.VERIFIED);
  const rejected = myDonations.filter(d => d.status === 'rejected');

  root.innerHTML = `
    <section class="section narrow">
      <div class="page-head"><h2>${lang() === 'bn' ? 'ভেরিফিকেশন সেন্টার' : 'Verification Center'}</h2></div>

      <!-- NID -->
      <div class="verify-block">
        <div class="verify-title">${icon('shield')} <h3>NID ${lang() === 'bn' ? 'ভেরিফিকেশন' : 'verification'}</h3>
          <span class="badge ${myNid?.status === 'approved' ? 'green' : myNid?.status === 'pending' ? 'amber' : 'gray'}">
            ${myNid?.status === 'approved' ? (lang() === 'bn' ? '✅ Verified' : '✅ Verified')
              : myNid?.status === 'pending' ? (lang() === 'bn' ? '🟡 Pending' : '🟡 Pending')
              : (lang() === 'bn' ? '⚪ Not verified' : '⚪ Not verified')}</span></div>
        ${myNid?.status === 'approved' ? `<p class="muted">${lang() === 'bn' ? 'আপনার NID অনুমোদিত — ডোনার প্রোফাইলে ব্যাজ দেখা যাবে।' : 'Your NID is approved — badge visible on your donor profile.'}</p>` : `
          <form id="nidForm" class="form-card flat">
            <label class="field-row"><span>NID ${lang() === 'bn' ? 'নম্বর' : 'number'} *</span>
              <input class="field" name="nidNumber" required pattern="\\d{10,17}" maxlength="17" placeholder="${lang() === 'bn' ? '১০–১৭ সংখ্যা' : '10–17 digits'}" /></label>
            <label class="field-row"><span>${lang() === 'bn' ? 'জন্ম তারিখ (NID অনুযায়ী)' : 'Date of birth (as on NID)'} *</span>
              <input class="field" name="dob" type="date" required /></label>
            <label class="field-row"><span>${lang() === 'bn' ? 'নাম (NID অনুযায়ী)' : 'Name (as on NID)'} *</span>
              <input class="field" name="legalName" required maxlength="80" /></label>
            <button class="btn primary">${icon('check')} ${lang() === 'bn' ? 'জমা দিন' : 'Submit for review'}</button>
          </form>`}
        <p class="conf">${icon('shield')} ${lang() === 'bn' ? 'NID নম্বর কখনো পাবলিক করা হয় না — শুধু ✅ ব্যাজ দেখা যায়।' : 'Your NID number is never public — only the ✅ badge is shown.'}</p>
      </div>

      <!-- Donation proof -->
      <div class="verify-block">
        <div class="verify-title">${icon('drop')} <h3>${lang() === 'bn' ? 'দান প্রমাণ জমা দিন' : 'Submit donation proof'}</h3></div>
        <form id="donForm" class="form-card flat">
          <div class="grid-2">
            <label class="field-row"><span>${esc(t('hospital'))} *</span><input class="field" name="hospital" required maxlength="120" /></label>
            <label class="field-row"><span>${esc(t('bloodGroup'))} *</span>
              <select class="field" name="bloodGroup">${['A+','A-','B+','B-','O+','O-','AB+','AB-'].map(g => `<option>${g}</option>`).join('')}</select></label>
          </div>
          <label class="field-row"><span>${lang() === 'bn' ? 'রিসিপিয়েন্ট ফোন (সে-ই কনফার্ম করবে)' : 'Recipient phone (they will confirm)'} *</span>
            <input class="field" name="recipientPhone" required type="tel" placeholder="+8801XXXXXXXXX" /></label>
          <label class="field-row"><span>${lang() === 'bn' ? 'প্রমাণ ছবি (হাসপাতালের ফর্ম)' : 'Proof photo (hospital form)'} *</span>
            <input class="field" name="proofFile" type="file" accept="image/jpeg,image/png,image/webp" required /></label>
          <p class="muted" style="font-size:.7rem; margin-bottom:10px;">${esc(t('finalDisclaimerBn'))}</p>
          <button class="btn primary">${icon('drop')} ${lang() === 'bn' ? 'দান জমা দিন' : 'Submit donation'}</button>
        </form>
      </div>

      <!-- My donation statuses -->
      <div class="verify-block">
        <div class="verify-title">${icon('history')} <h3>${lang() === 'bn' ? 'আমার দানসমূহ' : 'My donations'}</h3></div>
        ${pending.map(d => `
          <div class="donation-row pending">
            <div><strong>${esc(d.hospital)}</strong> <span class="badge amber">${esc(d.status)}</span></div>
            <small>${esc(d.bloodGroup)} · ${lang() === 'bn' ? 'অ্যাডমিন রিভিউয়ের জন্য অপেক্ষা করছে' : 'Waiting for admin review'}</small>
          </div>`).join('')}
        ${verified.map(d => `
          <div class="donation-row verified">
            <div><strong>${esc(d.hospital)}</strong> <span class="badge green">✅ ${esc(t('verifiedDonor'))}</span></div>
            <small>${esc(d.bloodGroup)} · ${new Date(d.createdAt).toLocaleDateString(lang() === 'bn' ? 'bn-BD' : 'en-GB')}</small>
          </div>`).join('')}
        ${rejected.map(d => `
          <div class="donation-row rejected">
            <div><strong>${esc(d.hospital)}</strong> <span class="badge red">${esc(t('rejected'))}</span></div>
            <small>${esc(d.bloodGroup)} · ${lang() === 'bn' ? 'প্রমাণ অস্বীকার করা হয়েছে' : 'Proof rejected'}</small>
          </div>`).join('')}
        ${pending.length + verified.length + rejected.length === 0 ? `<div class="empty">${icon('info')} ${lang() === 'bn' ? 'এখনো কোনো দান জমা হয়নি।' : 'No donations yet.'}</div>` : ''}
      </div>
    </section>`;

  const nidForm = root.querySelector('#nidForm');
  if (nidForm) nidForm.addEventListener('submit', async e => {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(nidForm).entries());
    if (!/^\d{10,17}$/.test(d.nidNumber)) { toast(bn('সঠিক NID নম্বর দিন', 'Enter a valid NID number'), 'error'); return; }
    try {
      if (backendOn) {
        await backendApi.post('/nid-verifications', { nidNumber: d.nidNumber, dob: d.dob, legalName: d.legalName });
      } else {
        await NidVerifications.add({ userId: u.uid, nidNumber: d.nidNumber, dob: d.dob, legalName: d.legalName, createdAt: Date.now() });
        Audit.log(u.name || 'user', 'nid_submit', 'self');
      }
      const nu = { ...u, nidStatus: 'pending' }; saveSession(nu);
      toast(bn('জমা হয়েছে — অ্যাডমিন রিভিউ করবে।', 'Submitted — admin will review.'), 'success');
      renderVerify(root);
    } catch (err) {
      toast(err.message || bn('জমা দিতে ব্যর্থ হয়েছে', 'Submission failed'), 'error');
    }
  });

  const donForm = root.querySelector('#donForm');
  if (donForm) donForm.addEventListener('submit', async e => {
    e.preventDefault();
    const d = Object.fromEntries(new FormData(e.target).entries());
    const donorPhone = u.phone || '';
    if (d.recipientPhone === donorPhone) { toast(lang() === 'bn' ? 'নিজেকে রিসিপিয়েন্ট করা যাবে না' : 'You cannot be your own recipient', 'error'); return; }
    const fileInput = root.querySelector('#donForm input[name="proofFile"]');
    const file = fileInput?.files?.[0];
    if (!file) { toast(lang() === 'bn' ? 'প্রমাণ ছবি Required' : 'Proof photo required', 'error'); return; }
    const validation = validateImageFile(file);
    if (!validation.valid) { toast(validation.error, 'error'); return; }
    try {
      const proofBase64 = await fileToBase64(file);
      const rec = await Donations.add({
        donorId: u.uid,
        hospital: d.hospital.trim(),
        bloodGroup: d.bloodGroup,
        recipientPhone: d.recipientPhone,
        proofUrl: proofBase64,
        status: 'pending_verification',
        createdAt: Date.now(),
      });
      saveDonationProof(rec.id, proofBase64);
      await Notifications.add({ type: 'emergency', textKey: 'notifNewRequest', body: `${u.name || 'A donor'} submitted donation proof — verify in Admin Panel`, target: 'admin', donationId: rec.id });
      Audit.log(u.name || 'user', 'donation_submit', d.hospital);
      toast(lang() === 'bn' ? 'দান প্রমাণ জমা হয়েছে — অ্যাডমিন রিভিউ করবে।' : 'Donation proof submitted — pending admin verification.', 'success');
      renderVerify(root);
    } catch (err) {
      console.error(err);
      toast(lang() === 'bn' ? 'জমা দিতে ব্যর্থ হয়েছে' : 'Submission failed', 'error');
    }
  });
}
