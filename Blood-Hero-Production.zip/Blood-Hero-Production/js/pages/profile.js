// Profile — donor card (ID/QR-style), stats, settings, edit, language, logout
import { t, lang, setLang } from '../i18n.js';
import { currentUser, saveSession, logout } from '../auth.js';
import { LS, APP, BLOOD_GROUPS } from '../config.js';
import { Donors, Donations, daysUntilEligible, nextEligibleDate, generateVerifyToken } from '../db.js';
import { esc, icon, bloodBadge, toast } from '../ui.js';
import { Logo } from '../components/Logo.js';
import { DISTRICTS, upazilasFor, unionsFor, lname } from '../data/rangpur.js';
import { saveProfilePicture, getProfilePicture, removeProfilePicture, validateImageFile, fileToBase64 } from '../../shared/js/storage.js';
import { backendApi, isBackendAvailable } from '../../shared/js/backend-api.js';

const BADGES = n => [
  ['First Drop', 'badgeFirst', n >= 1],
  ['Iron Heart', 'badgeBronze', n >= 25],
  ['Life Saver', 'badgeSilver', n >= 50],
  ['Century Hero', 'badgeGold', n >= 100],
];

export async function renderProfile(root) {
  const u = currentUser() || { name: 'Guest', guest: true };
  const bn = lang() === 'bn';
  const isVerified = u.nidStatus === 'approved';
  const days = daysUntilEligible(u.lastDonation, u.gender);
  const history = u.uid && !u.guest ? (await Donations.forDonor(u.uid)) : [];
  const verifiedCount = u.uid && !u.guest ? (await Donations.verifiedCount(u.uid)) : 0;
  const badgeList = BADGES(verifiedCount).filter(b => b[2]);
  const donorId = 'BH-' + String(u.uid || 'guest').slice(-6).toUpperCase();
  const fmtDate = d => {
    const dt = new Date(d);
    return isNaN(dt) ? t('notProvided') : dt.toLocaleDateString(bn ? 'bn-BD' : 'en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  };
  const lastDonationLabel = u.lastDonation ? fmtDate(u.lastDonation) : t('notProvided');
  const nextDate = nextEligibleDate(u.lastDonation, u.gender);
  const nextEligibleLabel = nextDate ? (days > 0 ? fmtDate(nextDate) : (bn ? 'প্রস্তুত' : 'Ready')) : (bn ? 'প্রস্তুত' : 'Ready');
  const totalDonations = verifiedCount > 0 ? verifiedCount : (u.totalDonations || 0);
  const status = u.guest
    ? { key: 'gray', icon: 'user', label: bn ? 'গেস্ট' : 'Guest' }
    : u.available && days === 0
      ? { key: 'green', icon: 'check', label: bn ? 'রক্তদানে প্রস্তুত' : 'Available to Donate' }
      : u.available && days > 0
        ? { key: 'amber', icon: 'clock', label: bn ? 'সম্প্রতি রক্তদান করেছেন' : 'Recently Donated' }
        : { key: 'gray', icon: 'bell', label: bn ? 'বর্তমানে অনুপলব্ধ' : 'Currently Unavailable' };
  root.innerHTML = `
    <section class="section narrow">
      <div class="id-card">
        <div class="id-top">
          <div class="id-brandrow">
            <div class="id-brandlogo">${Logo({ size: 'sm', alt: APP.name })}</div>
            <div class="id-brandtxt"><strong>${APP.name.toUpperCase()}</strong><span>${bn ? 'অফিসিয়াল ডোনার আইডেন্টিটি' : 'OFFICIAL DONOR IDENTITY'}</span></div>
            ${isVerified ? `<span class="id-verify" role="status">${icon('check')} ${esc(t('verifiedDonor'))}</span>` : ''}
          </div>
          <div class="id-body">
            <div class="id-avatar" id="profilePicArea">
              <img id="profilePicImg" src="" alt="${esc(u.name)}" style="display:none;" />
              <span id="profilePicPlaceholder" aria-hidden="true">${esc((u.name || 'B').trim().charAt(0).toUpperCase())}</span>
              <button type="button" class="id-cam" id="profilePicChange" title="${bn ? 'ছবি পরিবর্তন' : 'Change photo'}" aria-label="${bn ? 'প্রোফাইল ছবি পরিবর্তন' : 'Change profile photo'}">${icon('camera')}</button>
            </div>
            <div class="id-main">
              <h2>${esc(u.name)}</h2>
              <p class="id-donorid"><span>${esc(t('donorId'))}</span><strong>${esc(donorId)}</strong></p>
              <p class="id-loc">${icon('location')}<span>${esc(u.district || (bn ? 'বাংলাদেশ' : 'Bangladesh'))}${u.upazila ? ' · ' + esc(u.upazila) : ''}</span></p>
            </div>
            <div class="id-blood"><span>${esc(t('bloodGroup'))}</span><strong>${esc(u.bloodGroup || '—')}</strong></div>
          </div>
          <div class="id-status-row">
            <span class="status-pill ${status.key}">${icon(status.icon)} <span>${esc(status.label)}</span></span>
          </div>
          <div class="id-stats">
            <div class="id-stat"><strong>${totalDonations}</strong><span>${esc(t('totalDonations'))}</span></div>
            <div class="id-stat"><strong>${u.livesSaved || 0}</strong><span>${esc(t('livesSaved'))}</span></div>
            <div class="id-stat"><strong>${esc(lastDonationLabel)}</strong><span>${esc(t('lastDonation'))}</span></div>
            <div class="id-stat"><strong>${esc(nextEligibleLabel)}</strong><span>${esc(t('nextEligible'))}</span></div>
          </div>
          <div class="id-foot">
            <button type="button" class="id-scanbtn" id="cardQrBtn">${icon('qr')} <span>${bn ? 'স্ক্যান করে যাচাই করুন' : 'SCAN TO VERIFY'}</span></button>
            <span class="id-serno">${esc(donorId)}</span>
          </div>
        </div>
      </div>
      <input type="file" id="profilePicInput" accept="image/jpeg,image/png,image/webp" style="display:none;" />

      <div class="detail-card compact">
        <div class="kv"><span>${esc(t('emergencyContact'))}</span><strong dir="ltr">${esc(u.emergencyContact || '—')}</strong></div>
        <div class="kv"><span>${esc(t('age'))}</span><strong>${u.age ? esc(u.age) : '—'}</strong></div>
        <div class="kv"><span>${esc(t('weight'))}</span><strong>${u.weight ? esc(u.weight) + ' kg' : '—'}</strong></div>
      </div>

      ${verifiedCount > 0 ? `
      <div class="section-head"><h3>${esc(t('milestoneBadges'))}</h3></div>
      <div class="badge-grid">
        ${badgeList.map(b => `<div class="badge-card earned"><span class="b-ic">${icon(b[2] && b[0] === 'First Drop' ? 'drop' : 'award')}</span><strong>${esc(t(b[1]))}</strong></div>`).join('')}
        ${BADGES(verifiedCount).filter(b => !b[2]).map(b => `<div class="badge-card locked"><span class="b-ic">${icon('lock')}</span><strong>${esc(t(b[1]))}</strong></div>`).join('')}
      </div>` : ''}

      <div class="section-head"><h3>${esc(t('donationHistory'))}</h3>
        <button class="link" id="certBtn">${icon('award')} ${esc(t('donationCertificate'))}</button>
        <button class="link" id="qrBtn" style="margin-left:8px;">${icon('qr')} ${esc(t('donorId'))}</button></div>
      <div class="card-list" id="historyList">
        ${history.length === 0 ? `<div class="empty">${icon('info')} ${esc(t('noHistory'))}</div>` :
          history.map(d => `
            <article class="donation-row">
              <div>${bloodBadge(d.bloodGroup || u.bloodGroup)}</div>
              <div><strong>${esc(d.hospital || (lang() === 'bn' ? 'রক্তদান' : 'Donation'))}</strong>
                <small>${esc(new Date(d.createdAt).toLocaleDateString(lang() === 'bn' ? 'bn-BD' : 'en-GB'))} · ${esc(d.status)}</small></div>
              ${d.status === 'verified' ? `<span class="badge green">✓ ${esc(t('verifiedDonor'))}</span>` : ''}
            </article>`).join('')}
      </div>

      <div class="menu-card">
        <button class="menu-row" id="editBtn">${icon('user')}<span>${esc(t('editProfile'))}</span>${icon('back', 'flip')}</button>
        <div class="menu-row toggle"><span class="row-ic">${icon('moon')}</span><span>${esc(t('darkMode'))}</span>
          <label class="switch-inline"><input type="checkbox" id="swTheme" ${document.documentElement.getAttribute('data-theme') !== 'light' ? 'checked' : ''} /><span class="switch"></span></label></div>
        <div class="menu-row toggle"><span class="row-ic">${icon('bell')}</span><span>${esc(t('pushNotif'))}</span>
          <label class="switch-inline"><input type="checkbox" id="swNotif" checked /><span class="switch"></span></label></div>
        <div class="menu-row toggle"><span class="row-ic">${icon('shield')}</span><span>${esc(t('biometric'))}</span>
          <label class="switch-inline"><input type="checkbox" id="swBio" /><span class="switch"></span></label></div>
        <button class="menu-row" id="langBtn">${icon('lang')}<span>${esc(t('language'))}: ${lang() === 'bn' ? 'বাংলা' : 'English'}</span><span class="chev">EN/বাং</span></button>
        ${isBackendAvailable() ? `<button class="menu-row" id="passBtn">${icon('shield')}<span>${lang() === 'bn' ? 'পাসওয়ার্ড পরিবর্তন' : 'Change Password'}</span><span class="chev">›</span></button>` : ''}
        <a class="menu-row" href="#/support">${icon('support')}<span>${esc(t('helpCenter'))}</span><span class="chev">›</span></a>
      <a class="menu-row" href="#/about">${icon('info')}<span>${esc(t('about'))}</span><span class="chev">›</span></a>
      <button class="menu-row" id="familyBtn">${icon('users')}<span>${lang() === 'bn' ? 'পরিবারের রক্ত গ্রুপ' : 'Family Blood Groups'}</span><span class="chev">›</span></button>
      <button class="menu-row danger" id="logoutBtn">${icon('logout')}<span>${esc(t('logout'))}</span></button>
      </div>
      <p class="version-note">Blood Hero v1.0.0 · ${esc(t('developedBy'))} Junayed</p>
    </section>`;

  root.querySelector('#logoutBtn').addEventListener('click', logout);

  // Profile picture upload
  const existingPic = getProfilePicture(u.uid || 'guest');
  const profilePicImg = root.querySelector('#profilePicImg');
  const profilePicPlaceholder = root.querySelector('#profilePicPlaceholder');
  if (existingPic && profilePicImg) {
    profilePicImg.src = existingPic;
    profilePicImg.style.display = 'block';
    profilePicPlaceholder.style.display = 'none';
  }
  root.querySelector('#profilePicChange')?.addEventListener('click', () => root.querySelector('#profilePicInput')?.click());

  root.querySelector('#profilePicInput')?.addEventListener('change', async e => {
    const file = e.target.files[0];
    if (!file) return;
    const validation = validateImageFile(file);
    if (!validation.valid) { toast(validation.error, 'error'); return; }
    try {
      const base64 = await fileToBase64(file);
      saveProfilePicture(u.uid || 'guest', base64);
      if (profilePicImg) {
        profilePicImg.src = base64;
        profilePicImg.style.display = 'block';
        profilePicPlaceholder.style.display = 'none';
      }
      toast(lang() === 'bn' ? 'প্রফাইল ছবি আপলোড হয়েছে' : 'Profile picture updated', 'success');
    } catch (err) {
      toast(lang() === 'bn' ? 'আপলোড ব্যর্থ হয়েছে' : 'Upload failed', 'error');
    }
  });

  root.querySelector('#certBtn')?.addEventListener('click', () => {
    import('../ui.js').then(({ openModal }) => {
      openModal(`
        <div class="certificate">
          <div class="cert-band">${icon('award')} ${esc(t('certOfHonor'))}</div>
          <p class="cert-line">${esc(t('thisCertifies'))}</p>
          <h2 class="cert-name">${esc(u.name)}</h2>
          <p class="cert-line">${esc(t('hasDonated'))} <strong>${verifiedCount}</strong> ${esc(t('times'))} (${esc(u.bloodGroup || '—')})</p>
          <p class="cert-note">${esc(t('donatedFor'))}</p>
          <div class="cert-foot"><span>Blood Hero</span><span>${esc(new Date().toLocaleDateString(lang() === 'bn' ? 'bn-BD' : 'en-GB'))}</span></div>
        </div>
        <button class="btn primary lg" id="printCert" style="margin-top:14px">${icon('share')} ${lang() === 'bn' ? 'প্রিন্ট' : 'Print'}</button>`);
      document.getElementById('printCert').addEventListener('click', () => {
        const w = window.open('', '_blank', 'width=600,height=800');
        w.document.write(`<html><head><title>${esc(u.name)} — Certificate</title>
          <style>body{font-family:Georgia,serif;text-align:center;padding:60px 40px;color:#111}
          .cert-band{font-size:18px;letter-spacing:3px;border:2px solid #c00;display:inline-block;padding:6px 18px;border-radius:40px;color:#c00;font-weight:bold}
          .cert-name{font-size:38px;margin:24px 0 8px}.cert-line{font-size:16px;margin:6px 0}.cert-note{max-width:420px;margin:22px auto;color:#444}
          .cert-foot{display:flex;justify-content:space-between;margin-top:70px;padding:0 30px;font-size:14px;border-top:1px solid #ccc;padding-top:12px}</style></head>
          <body><div class="cert-band">${esc(t('certOfHonor'))}</div>
          <p class="cert-line">${esc(t('thisCertifies'))}</p>
          <h1 class="cert-name">${esc(u.name)}</h1>
          <p class="cert-line">${esc(t('hasDonated'))} <strong>${verifiedCount}</strong> ${esc(t('times'))} (${esc(u.bloodGroup || '—')})</p>
          <p class="cert-note">${esc(t('donatedFor'))}</p>
          <div class="cert-foot"><span>Blood Hero</span><span>${esc(new Date().toLocaleDateString())}</span></div>
          <script>window.onload=function(){setTimeout(function(){window.print()},400)}<\/script></body></html>`);
        w.document.close();
      });
    });
  });

  const openQrModal = () => {
    import('../ui.js').then(({ openModal }) => {
      const token = generateVerifyToken(u.uid || 'guest');
      const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(location.origin + location.pathname + '#/verify/' + token)}`;
      openModal(`
        <h3 class="modal-title">${esc(t('donorId'))}</h3>
        <p class="muted" style="margin-bottom:10px">BH-${esc(String(u.uid || 'guest').slice(-6).toUpperCase())}</p>
        <div style="text-align:center; margin:14px 0;">
          <img src="${qrUrl}" alt="QR" style="width:200px; height:200px; border-radius:12px; border:1px solid var(--line);" loading="lazy" />
        </div>
        <p class="muted" style="text-align:center; font-size:.72rem;">${esc(t('finalDisclaimerBn'))}</p>
        <button class="btn primary lg" id="downloadQr">${icon('share')} ${lang() === 'bn' ? 'ডাউনলোড' : 'Download'}</button>
      `);
      document.getElementById('downloadQr').addEventListener('click', () => {
        const a = document.createElement('a');
        a.href = qrUrl;
        a.download = 'blood-hero-qr.png';
        a.click();
        toast(lang() === 'bn' ? 'ডাউনলোড হয়েছে' : 'Downloaded', 'success');
      });
    });
  };
  root.querySelector('#cardQrBtn')?.addEventListener('click', openQrModal);
  root.querySelector('#qrBtn')?.addEventListener('click', openQrModal);

  root.querySelector('#swTheme').addEventListener('change', e => {
    try { localStorage.setItem(LS.theme, e.target.checked ? 'dark' : 'light'); } catch { /* storage unavailable */ }
    location.reload();
  });
  root.querySelector('#langBtn').addEventListener('click', () => {
    setLang(lang() === 'bn' ? 'en' : 'bn');
    location.reload();
  });
  root.querySelector('#passBtn')?.addEventListener('click', () => {
    const bn = lang() === 'bn';
    import('../ui.js').then(({ openModal, closeModal }) => {
      openModal(`
        <h3 class="modal-title">${bn ? 'পাসওয়ার্ড পরিবর্তন' : 'Change Password'}</h3>
        <form id="passForm" class="form-card flat">
          <label class="field-row"><span>${bn ? 'বর্তমান পাসওয়ার্ড' : 'Current Password'}</span>
            <input class="field" type="password" name="current" placeholder="${bn ? 'OTP লগইন হলে ফাঁকা রাখুন' : 'Leave blank if you use OTP login'}" autocomplete="current-password" /></label>
          <label class="field-row"><span>${bn ? 'নতুন পাসওয়ার্ড' : 'New Password'} *</span>
            <input class="field" type="password" name="new" required minlength="6" autocomplete="new-password" /></label>
          <label class="field-row"><span>${bn ? 'নতুন পাসওয়ার্ড আবার' : 'Confirm New Password'} *</span>
            <input class="field" type="password" name="confirm" required minlength="6" autocomplete="new-password" /></label>
          <p class="muted" style="font-size:.72rem;">${bn ? 'অন্তত ৬ অক্ষর' : 'At least 6 characters'}</p>
          <button class="btn primary" type="submit">${bn ? 'আপডেট করুন' : 'Update Password'}</button>
        </form>`);
      document.getElementById('passForm').addEventListener('submit', async e => {
        e.preventDefault();
        const f = Object.fromEntries(new FormData(e.target).entries());
        if (f.new !== f.confirm) { toast(bn ? 'নতুন পাসওয়ার্ড মিলছে না' : 'Passwords do not match', 'error'); return; }
        try {
          await backendApi.post('/auth/change-password', {
            currentPassword: f.current || undefined,
            newPassword: f.new,
          });
          closeModal();
          toast(bn ? 'পাসওয়ার্ড আপডেট হয়েছে' : 'Password updated', 'success');
        } catch (err) {
          toast(err.message || bn ? 'ব্যর্থ হয়েছে' : 'Failed', 'error');
        }
      });
    });
  });
  root.querySelector('#editBtn').addEventListener('click', () => {
    import('../ui.js').then(({ openModal, closeModal }) => {
      const curPic = getProfilePicture(u.uid || 'guest');
      const selD = DISTRICTS.includes(u.district) ? u.district : '';
      const selU = selD === 'Rangpur' && upazilasFor('Rangpur').some(x => lname(x) === u.upazila) ? u.upazila : '';
      const selN = selU && unionsFor('Rangpur', selU).some(x => lname(x) === u.union) ? u.union : '';
      const optDistrict = () => `<option value="">${bn ? '— জেলা নির্বাচন করুন —' : '— Select district —'}</option>` + DISTRICTS.map(d => `<option value="${esc(d)}" ${d === selD ? 'selected' : ''}>${esc(d)}</option>`).join('');
      const optUpazila = () => (selD === 'Rangpur' ? upazilasFor('Rangpur') : []).map(x => `<option value="${esc(lname(x))}" ${lname(x) === selU ? 'selected' : ''}>${esc(lname(x))}</option>`).join('');
      const optUnion = () => (selU ? unionsFor('Rangpur', selU) : []).map(x => `<option value="${esc(lname(x))}" ${lname(x) === selN ? 'selected' : ''}>${esc(lname(x))}</option>`).join('');
      const genderOpts = [['male', bn ? 'পুরুষ' : 'Male'], ['female', bn ? 'নারী' : 'Female'], ['other', bn ? 'অন্যান্য' : 'Other']]
        .map(([v, l]) => `<option value="${v}" ${u.gender === v ? 'selected' : ''}>${esc(l)}</option>`).join('');
      const contactMethods = [['phone', bn ? 'ফোন কল' : 'Phone call'], ['sms', bn ? 'এসএমএস' : 'SMS'], ['whatsapp', bn ? 'হোয়াটসঅ্যাপ' : 'WhatsApp'], ['email', bn ? 'ইমেইল' : 'Email']]
        .map(([v, l]) => `<option value="${v}" ${(u.contactMethod || 'phone') === v ? 'selected' : ''}>${esc(l)}</option>`).join('');
      const todayMax = new Date().toISOString().slice(0, 10);
      const privSwitch = (k, [title, desc]) => `
        <label class="ef-switch">
          <span class="ef-switch-txt"><strong>${bn ? title[0] : title[1]}</strong><small>${bn ? desc[0] : desc[1]}</small></span>
          <span class="switch-inline"><input type="checkbox" name="${k}" ${u[k] !== false ? 'checked' : ''} /><span class="switch"></span></span>
        </label>`;

      openModal(`
        <div class="ef-head">
          <h3 class="modal-title">${icon('user')} ${esc(t('editProfile'))}</h3>
          <p class="muted" style="font-size:.72rem;">${bn ? 'নিচের তথ্যগুলো আপডেট করুন — পরিবর্তনগুলো আপনার ডোনার কার্ডে প্রতিফলিত হবে।' : 'Update the details below — changes reflect on your donor card.'}</p>
        </div>
        <form id="editForm" class="ef-form" novalidate>
          <div class="ef-section">
            <h4 class="ef-sec-head">${bn ? 'ব্যক্তিগত তথ্য' : 'Personal'}</h4>
            <div class="grid-2">
              <label class="field-row"><span>${bn ? 'পুরো নাম' : 'Full Name'} *</span>
                <input class="field" name="name" value="${esc(u.name)}" maxlength="60" />
                <em class="ferr" data-ferr="name"></em></label>
              <label class="field-row"><span>${bn ? 'জন্ম তারিখ' : 'Date of Birth'}</span>
                <input class="field" type="date" name="dob" value="${esc(u.dob || '')}" max="${todayMax}" />
                <em class="ferr" data-ferr="dob"></em></label>
            </div>
            <div class="grid-2">
              <label class="field-row"><span>${bn ? 'লিঙ্গ' : 'Gender'}</span>
                <select class="field" name="gender"><option value="">${bn ? '— নির্বাচন করুন —' : '— Select —'}</option>${genderOpts}</select></label>
              <label class="field-row"><span>${bn ? 'ইমেইল' : 'Email'}</span>
                <input class="field" type="email" name="email" value="${esc(u.email || '')}" maxlength="80" autocomplete="email" />
                <em class="ferr" data-ferr="email"></em></label>
            </div>
            <label class="field-row"><span>${bn ? 'ফোন (লগইন নম্বর)' : 'Phone (login)'}</span>
              <input class="field" value="${esc(u.phone || '')}" disabled dir="ltr" /></label>
            <div class="ef-photo">
              <div class="ef-photo-prev" id="editPhotoPreview">${curPic ? `<img src="${curPic}" alt="" />` : `<span>${icon('user')}</span>`}</div>
              <div class="ef-photo-actions">
                <button type="button" class="btn ghost sm" id="editPhotoBtn">${icon('camera')} ${bn ? 'ছবি আপলোড' : 'Upload photo'}</button>
                <button type="button" class="btn danger-ghost sm" id="editPhotoRemove" ${curPic ? '' : 'disabled'}>${icon('close')} ${bn ? 'মুছুন' : 'Remove'}</button>
                <p class="muted" style="font-size:.7rem;">JPG/PNG/WEBP · ${bn ? 'সর্বোচ্চ ৫MB' : 'max 5MB'}</p>
              </div>
              <input type="file" id="editPhotoInput" accept="image/jpeg,image/png,image/webp" style="display:none;" />
            </div>
          </div>

          <div class="ef-section">
            <h4 class="ef-sec-head">${bn ? 'রক্ত ও ডোনার' : 'Blood & Donor'}</h4>
            <div class="grid-2">
              <label class="field-row"><span>${esc(t('bloodGroup'))} *</span>
                <select class="field" name="bloodGroup">${BLOOD_GROUPS.map(g => `<option ${g === u.bloodGroup ? 'selected' : ''}>${g}</option>`).join('')}</select>
                <em class="ferr" data-ferr="bloodGroup"></em></label>
              <label class="field-row"><span>${esc(t('lastDonation'))}</span>
                <input class="field" type="date" name="lastDonation" value="${esc(u.lastDonation || '')}" max="${todayMax}" />
                <em class="ferr" data-ferr="lastDonation"></em></label>
            </div>
            <div class="ef-system">
              <span><small>${esc(t('totalDonations'))}</small><strong>${verifiedCount > 0 ? verifiedCount : (u.totalDonations || 0)}</strong></span>
              <span><small>${esc(t('livesSaved'))}</small><strong>${u.livesSaved || 0}</strong></span>
              <span><small>${esc(t('verifiedDonor'))}</small><strong>${isVerified ? '✓' : '—'}</strong></span>
            </div>
            <p class="muted" style="font-size:.7rem;">${bn ? 'এই পরিসংখ্যান সিস্টেম-নির্ধারিত — সম্পাদনা করা যায় না।' : 'These stats are system-generated and cannot be edited.'}</p>
          </div>

          <div class="ef-section">
            <h4 class="ef-sec-head">${bn ? 'অবস্থান' : 'Location'}</h4>
            <label class="field-row"><span>${esc(t('district'))} *</span>
              <select class="field" name="district" id="efDistrict">${optDistrict()}</select>
              <em class="ferr" data-ferr="district"></em></label>
            <div class="grid-2">
              <label class="field-row"><span>${esc(t('upazila'))}</span>
                <select class="field" name="upazila" id="efUpazila">${optUpazila()}</select></label>
              <label class="field-row"><span>${esc(t('union'))}</span>
                <select class="field" name="union" id="efUnion">${optUnion()}</select></label>
            </div>
            <label class="field-row"><span>${bn ? 'এলাকা/গ্রাম' : 'Area / Village'}</span>
              <input class="field" name="wardVillage" value="${esc(u.wardVillage || '')}" maxlength="80" /></label>
          </div>

          <div class="ef-section">
            <h4 class="ef-sec-head">${bn ? 'রক্তদানের প্রস্তুতি' : 'Availability'}</h4>
            ${privSwitch('available', [bn ? 'রক্তদানে প্রস্তুত' : 'Available for Blood Donation', bn ? 'এটি আপনার ব্যক্তিগত প্রস্তুতির সূচক — যোগ্যতার হিসাব সিস্টেম নিজেই করবে।' : 'Your personal availability signal — eligibility is still checked by the system.'])}
          </div>

          <div class="ef-section">
            <h4 class="ef-sec-head">${bn ? 'জরুরি যোগাযোগ' : 'Emergency Contact'}</h4>
            <div class="grid-2">
              <label class="field-row"><span>${bn ? 'যোগাযোগের নাম' : 'Contact name'}</span>
                <input class="field" name="emergencyContactName" value="${esc(u.emergencyContactName || '')}" maxlength="60" /></label>
              <label class="field-row"><span>${bn ? 'যোগাযোগের নম্বর' : 'Contact number'}</span>
                <input class="field" type="tel" name="emergencyContact" value="${esc(u.emergencyContact || '')}" dir="ltr" placeholder="+8801XXXXXXXXX" />
                <em class="ferr" data-ferr="emergencyContact"></em></label>
            </div>
            <label class="field-row"><span>${bn ? 'পছন্দের যোগাযোগ মাধ্যম' : 'Preferred contact method'}</span>
              <select class="field" name="contactMethod">${contactMethods}</select></label>
            <p class="muted" style="font-size:.7rem;">${bn ? 'শুধুমাত্র জরুরি প্রয়োজনে ব্যবহৃত হবে — পাবলিক প্রোফাইলে দেখানো হয় না।' : 'Used only in emergencies — never shown on your public profile.'}</p>
          </div>

          <div class="ef-section">
            <h4 class="ef-sec-head">${bn ? 'বায়ো' : 'Bio'}</h4>
            <label class="field-row"><span>${bn ? 'আপনার সম্পর্কে' : 'About you'}</span>
              <textarea class="field" name="bio" id="efBio" rows="3" maxlength="250" placeholder="${bn ? 'যেমন: নিয়মিত রক্তদাতা, ১২+ বার রক্ত দিয়েছি…' : 'e.g. Regular donor, donated 12+ times…'}">${esc(u.bio || '')}</textarea></label>
            <div class="ef-charcount"><span class="muted" id="efBioCount">${(u.bio || '').length}/250</span><span class="muted">${bn ? 'পরামর্শ: ১৫০–২৫০ অক্ষর' : 'Recommended: 150–250 characters'}</span></div>
          </div>

          <div class="ef-section">
            <h4 class="ef-sec-head">${bn ? 'গোপনীয়তা' : 'Privacy'}</h4>
            ${privSwitch('showInSearch', [bn ? 'ডোনার খুঁজে পাওয়ার অনুমতি' : 'Show in donor search', bn ? 'অফ করলে আপনি ডোনার ডিরেক্টরিতে দেখা যাবেন না।' : 'Turn off to hide from the donor directory.'])}
            ${privSwitch('showPhone', [bn ? 'যোগাযোগ নম্বর দেখানো' : 'Show phone number', bn ? 'অন্যদের কাছে নম্বর দেখানোর অনুমতি।' : 'Allow others to see your contact number.'])}
            ${privSwitch('showLocation', [bn ? 'অবস্থান দেখানো' : 'Show location', bn ? 'পাবলিক প্রোফাইলে জেলা/উপজেলা দেখানো হবে কিনা।' : 'Show your district/upazila on your public profile.'])}
            ${privSwitch('allowBloodRequests', [bn ? 'রক্তের প্রয়োজনে যোগাযোগ' : 'Allow blood-request contact', bn ? 'ম্যাচিং সিস্টেমে অটো-ম্যাচ হয়ে অনুরোধের জন্য যোগাযোগ করা যাবে।' : 'Allow auto-matching for blood requests.'])}
          </div>
        </form>
        <div class="ef-foot">
          <button type="button" class="btn ghost lg" id="editCancel">${esc(t('cancel'))}</button>
          <button type="submit" class="btn primary lg" id="editSave" form="editForm">${icon('check')} ${esc(t('save'))}</button>
        </div>
      `, { wide: true });

      const form = document.getElementById('editForm');
      const setErr = (name, msg) => {
        const field = form.elements[name];
        if (field) field.classList.add('err');
        const el = form.querySelector(`[data-ferr="${name}"]`);
        if (el) { el.textContent = msg || ''; el.style.display = msg ? 'block' : 'none'; }
      };
      const clearErrs = () => {
        form.querySelectorAll('.err').forEach(x => x.classList.remove('err'));
        form.querySelectorAll('[data-ferr]').forEach(el => { el.textContent = ''; el.style.display = 'none'; });
      };

      // location cascading selects
      const upSel = form.elements.upazila, unSel = form.elements.union, dSel = form.elements.district;
      const repopulateUnion = () => {
        const uns = upSel.value && dSel.value === 'Rangpur' ? unionsFor('Rangpur', upSel.value) : [];
        unSel.innerHTML = `<option value="">${bn ? '— ইউনিয়ন —' : '— Union —'}</option>` + uns.map(x => `<option value="${esc(lname(x))}">${esc(lname(x))}</option>`).join('');
        unSel.disabled = uns.length === 0;
      };
      dSel.addEventListener('change', () => {
        const ups = dSel.value === 'Rangpur' ? upazilasFor('Rangpur') : [];
        upSel.innerHTML = `<option value="">${bn ? '— উপজেলা —' : '— Upazila —'}</option>` + ups.map(x => `<option value="${esc(lname(x))}">${esc(lname(x))}</option>`).join('');
        upSel.disabled = ups.length === 0;
        repopulateUnion();
      });
      upSel.addEventListener('change', repopulateUnion);
      upSel.disabled = dSel.value !== 'Rangpur' || upSel.options.length <= 1;
      repopulateUnion();

      // photo
      let photoDraft = null, photoRemove = false;
      const preview = document.getElementById('editPhotoPreview');
      const rmBtn = document.getElementById('editPhotoRemove');
      document.getElementById('editPhotoBtn').addEventListener('click', () => document.getElementById('editPhotoInput').click());
      document.getElementById('editPhotoInput').addEventListener('change', async e => {
        const f = e.target.files[0];
        if (!f) return;
        const v = validateImageFile(f);
        if (!v.valid) { toast(v.error, 'error'); e.target.value = ''; return; }
        photoDraft = await fileToBase64(f);
        photoRemove = false;
        preview.innerHTML = `<img src="${photoDraft}" alt="" />`;
        rmBtn.disabled = false;
      });
      rmBtn.addEventListener('click', () => {
        photoDraft = null; photoRemove = true;
        preview.innerHTML = `<span>${icon('user')}</span>`;
        rmBtn.disabled = true;
      });

      // bio counter
      const bio = document.getElementById('efBio');
      const count = document.getElementById('efBioCount');
      bio.addEventListener('input', () => { count.textContent = bio.value.length + '/250'; });

      document.getElementById('editCancel').addEventListener('click', closeModal);

      form.addEventListener('submit', async e => {
        e.preventDefault();
        clearErrs();
        const data = Object.fromEntries(new FormData(form).entries());
        ['available', 'showInSearch', 'showPhone', 'showLocation', 'allowBloodRequests'].forEach(k => data[k] = form.elements[k].checked);
        data.name = String(data.name || '').trim();
        data.email = String(data.email || '').trim();
        const errors = {};
        if (data.name.length < 2) errors.name = bn ? 'নাম দিন (অন্তত ২ অক্ষর)' : 'Enter a name (min 2 characters)';
        if (!BLOOD_GROUPS.includes(data.bloodGroup)) errors.bloodGroup = bn ? 'রক্তের গ্রুপ বেছে নিন' : 'Select a blood group';
        if (!data.district) errors.district = bn ? 'জেলা বেছে নিন' : 'Select a district';
        if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) errors.email = bn ? 'সঠিক ইমেইল দিন' : 'Enter a valid email';
        if (data.dob && (isNaN(new Date(data.dob)) || new Date(data.dob) > new Date())) errors.dob = bn ? 'ভবিষ্যতের তারিখ নয়' : 'Date cannot be in the future';
        if (data.lastDonation && (isNaN(new Date(data.lastDonation)) || new Date(data.lastDonation) > new Date())) errors.lastDonation = bn ? 'ভবিষ্যতের তারিখ নয়' : 'Date cannot be in the future';
        if (data.emergencyContact && !/^\+?[0-9]{6,15}$/.test(String(data.emergencyContact).replace(/[\s-]/g, ''))) errors.emergencyContact = bn ? 'সঠিক নম্বর দিন' : 'Enter a valid phone number';
        const firstErr = Object.keys(errors)[0];
        if (firstErr) {
          Object.entries(errors).forEach(([k, m]) => setErr(k, m));
          form.elements[firstErr].focus();
          return;
        }
        let age = u.age || null;
        if (data.dob) {
          const a = Math.floor((Date.now() - new Date(data.dob).getTime()) / 31536000000);
          if (a >= 0 && a <= 120) age = a;
        }
        data.age = age;
        const nu = { ...u, ...data };
        const saveBtn = document.getElementById('editSave');
        saveBtn.disabled = true;
        saveBtn.innerHTML = `${icon('loading')} ${bn ? 'সংরক্ষণ হচ্ছে…' : 'Saving…'}`;
        try {
          if (!u.guest && u.uid) await Donors.update(u.uid, data);
          saveSession(nu);
          try {
            if (photoDraft) saveProfilePicture(u.uid || 'guest', photoDraft);
            else if (photoRemove) removeProfilePicture(u.uid || 'guest');
          } catch { /* storage unavailable */ }
          closeModal();
          toast(bn ? 'প্রোফাইল আপডেট হয়েছে' : 'Profile updated', 'success');
          renderProfile(root);
        } catch (err) {
          saveBtn.disabled = false;
          saveBtn.innerHTML = `${icon('check')} ${esc(t('save'))}`;
          toast(err.message || (bn ? 'সংরক্ষণ ব্যর্থ হয়েছে' : 'Save failed'), 'error');
        }
      });
    });
  });

  // Family blood group profile
  root.querySelector('#familyBtn').addEventListener('click', () => {
    import('../ui.js').then(({ openModal, closeModal }) => {
      const LS_KEY = 'bh_family_' + (u.uid || 'guest');
      const getFamily = () => { try { return JSON.parse(localStorage.getItem(LS_KEY)) || []; } catch { return []; } };
      const setFamily = arr => { try { localStorage.setItem(LS_KEY, JSON.stringify(arr)); } catch {} };
      const renderFamily = () => {
        const fam = getFamily();
        return fam.length === 0
          ? `<div class="empty">${icon('info')} ${lang() === 'bn' ? 'এখনো কোনো সদস্য যোগ হয়নি' : 'No family members added yet'}</div>`
          : fam.map((m, i) => `
              <div class="mini-row">
                <span><strong>${esc(m.name)}</strong> <span class="badge ${m.blood ? 'red' : 'gray'}">${esc(m.blood || '—')}</span> <small>${esc(m.relation || '')}</small></span>
                <button class="btn danger-ghost sm" data-rm="${i}">${icon('close')}</button>
              </div>`).join('');
      };
      openModal(`
        <h3 class="modal-title">${lang() === 'bn' ? 'পরিবারের রক্ত গ্রুপ' : 'Family Blood Groups'}</h3>
        <p class="muted" style="margin-bottom:10px">${lang() === 'bn' ? 'জরুরী প্রয়োজনে ত্বরান্বিত করা যায়' : 'Quick access during emergencies'}</p>
        <form id="famForm" class="form-card flat">
          <div class="grid-2">
            <label class="field-row"><span>${esc(t('name'))} *</span><input class="field" name="fname" required maxlength="60" /></label>
            <label class="field-row"><span>${esc(t('bloodGroup'))} *</span>
              <select class="field" name="fblood">${['A+','A-','B+','B-','O+','O-','AB+','AB-','?'].map(g => `<option>${g}</option>`).join('')}</select></label>
          </div>
          <label class="field-row"><span>${lang() === 'bn' ? 'সম্পর্ক' : 'Relation'}</span><input class="field" name="frel" maxlength="40" placeholder="${lang() === 'bn' ? 'যেমন: পিতা, মাতা, ভাই' : 'e.g. Father, Mother, Brother'}" /></label>
          <label class="field-row"><span>${esc(t('contact'))}</span><input class="field" name="fphone" type="tel" placeholder="+8801XXXXXXXXX" /></label>
          <button class="btn primary" type="submit">${icon('plus')} ${lang() === 'bn' ? 'যোগ করুন' : 'Add Member'}</button>
        </form>
        <div style="margin-top:14px; display:flex; flex-direction:column; gap:6px;" id="famList">${renderFamily()}</div>
      `);
      const modal = document.getElementById('bh-modal');
      document.getElementById('famForm').addEventListener('submit', e => {
        e.preventDefault();
        const d = Object.fromEntries(new FormData(e.target).entries());
        const fam = getFamily();
        fam.push({ name: d.fname.trim(), blood: d.fblood, relation: d.frel?.trim() || '', phone: d.fphone?.trim() || '', addedAt: Date.now() });
        setFamily(fam);
        toast(lang() === 'bn' ? 'যোগ করা হয়েছে' : 'Added', 'success');
        document.getElementById('famList').innerHTML = renderFamily();
        e.target.reset();
        bindRemove();
      });
      const bindRemove = () => {
        modal.querySelectorAll('[data-rm]').forEach(b => b.addEventListener('click', () => {
          const fam = getFamily(); fam.splice(+b.dataset.rm, 1); setFamily(fam);
          document.getElementById('famList').innerHTML = renderFamily();
          bindRemove();
        }));
      };
      bindRemove();
    });
  });
}
