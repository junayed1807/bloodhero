// Need Dashboard — public shortage map (need vs collection) per blood group.
// Estimated live from pending requests and available donors (v2 spec §12).
import { t, lang } from '../i18n.js';
import { Requests, Donors, BLOOD_GROUPS } from '../db.js';
import { esc, icon, bloodBadge } from '../ui.js';

const URG_WEIGHT = { normal: 1, urgent: 2, critical: 4 };

export async function renderNeed(root) {
  const [requests, donors] = await Promise.all([Requests.list(), Donors.list()]);
  const pending = requests.filter(r => r.status === 'pending');
  const rows = BLOOD_GROUPS.map(g => {
    const reqs = pending.filter(r => r.bloodGroup === g);
    const needed = reqs.reduce((s, r) => s + (r.units || 1) * (URG_WEIGHT[r.urgency] || 1), 0);
    const ready = donors.filter(d => d.bloodGroup === g && d.available).length;
    let level, pct;
    if (needed === 0) { level = 'ok'; pct = 100; }
    else if (ready === 0) { level = 'crit'; pct = 8; }
    else if (ready * 1.5 < needed) { level = 'low'; pct = 30; }
    else { level = 'ok'; pct = 82; }
    return { g, needed, ready, level, pct };
  }).sort((a, b) => (b.level === 'crit') - (a.level === 'crit') || b.needed - a.needed);

  root.innerHTML = `
    <section class="section">
      <div class="page-head">
        <h2>${icon('activity')} ${esc(t('needDashboard'))}</h2>
        <p class="muted">${esc(t('needIntro'))}</p>
      </div>
      <div class="need-grid">
        ${rows.map(r => `
          <div class="need-card lv-${r.level}">
            <div class="need-head">${bloodBadge(r.g)}
              <span class="need-state">${esc(r.level === 'crit' ? t('veryLow') : r.level === 'low' ? t('low') : t('sufficient'))}</span>
            </div>
            <div class="need-bar"><span style="width:${r.pct}%"></span></div>
            <div class="need-meta">
              <span><strong>${r.needed}</strong> ${esc(t('activeRequests'))}</span>
              <span><strong>${r.ready}</strong> ${esc(t('donorsAvailable'))}</span>
            </div>
          </div>`).join('')}
      </div>
      <div class="tip-card">${icon('info')}<div><h4>${esc(t('demandAlerts'))}</h4><p>${esc(t('needNote'))}</p></div></div>
      <p class="muted" style="text-align:center; margin-top:12px; font-size:.7rem;">${esc(t('finalDisclaimerBn'))}</p>
    </section>`;
}