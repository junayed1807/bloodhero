// Awareness — health awareness content, religious/social clarification, blog-style
import { t, lang } from '../i18n.js';
import { esc, icon } from '../ui.js';

const CONTENT_BN = [
  { title: 'রক্তদান একটি দান — কোনো ধর্ম বা জাতির বিচার নয়', body: 'ইসলাম, হিন্দুধর্ম, খ্রিস্টান ধর্ম — সব ধর্মেই রক্তদানকে পবিত্র দান হিসেবে গণ্য করা হয়। রক্ত বাঁচাতে কোনো ধর্মীয় বা সামাজিক বাধামুক্ত।', icon: 'heart' },
  { title: 'মিথ্যা ধারণা: রক্তদান করে শারীরিক দুর্বলতা হয়?', body: 'বাস্তবে এটা অসম্ভব। WHO অনুসরণে ৩ মাস অন্তর এক ইউনিট রক্তদান করলে শরীর ২৪-৪৮ ঘণ্টায় স্বাভাবিক হয়। রক্তদানকারীর স্বাস্থ্য পরীক্ষা হয় তাই এটা সম্পূর্ণ নিরাপদ।', icon: 'health' },
  { title: 'নারী রক্তদাতা — সচেতনতা বাড়ানো দরকার', body: 'বাংলাদেশে ডোনারদের ৭০-৭২% পুরুষ, ২৮-৩০% নারী। অনেক নারী ভুল ধারণায় রক্তদান থেকে বিরত থাকেন। এটা একটি ভিত্তিক সমস্যা — সচেতনতা বাড়ালেই বদলে যাবে।', icon: 'users' },
  { title: 'থ্যালাসেমিয়া রোগীর প্রতি ২-৪ সপ্তাহে রক্তচাহিদা', body: 'বাংলাদেশে ৬০-৭০ হাজার থ্যালাসেমিয়া রোগী রয়েছে। তাদের প্রতি ২-৪ সপ্তাহে রক্ত ট্রান্সফিউজন লাগে। আপনি রক্ত দিলে এরা বড় হয়।', icon: 'drop' },
  { title: 'রক্তদানের পরে কী করা উচিত?', body: '২৪ ঘণ্টা ভারী ব্যায়াম এড়িয়ে চলুন। পর্যাপ্ত পানি ও লবণযুক্ত খাবার খান। ৪৮ ঘণ্টায় স্বাভাবিক কাজে ফিরে যাওয়া যায়।', icon: 'activity' },
  { title: 'রক্তপ্রয়োগের সময়সীমা', body: 'RBC-এর শেলফ লাইফ ৩৫-৪২ দিন। তাই প্রতিদিন ব্লাড ব্যাংক চেক করে নেয়। expired রক্ত কখনো ব্যবহার করা হয় না। এটা আমাদের স্ক্রিনিং সিস্টেম নিশ্চিত করে।', icon: 'clock' },
];

const CONTENT_EN = [
  { title: 'Blood donation is a gift — no religion, no caste', body: 'Islam, Hinduism, Christianity — all faiths recognize blood donation as a sacred gift. Saving a life has no religious or social barrier.', icon: 'heart' },
  { title: 'Myth: donation makes you weak?', body: 'False. WHO guidelines confirm one unit every 3 months is completely safe. Your body replenishes within 24-48 hours. Pre-donation screening ensures donor safety.', icon: 'health' },
  { title: 'Women donors — awareness is key', body: 'In Bangladesh, 70-72% of donors are male, 28-30% female. Many women stay away due to myths. Awareness campaigns can close this gender gap.', icon: 'users' },
  { title: 'Thalassemia patients need blood every 2-4 weeks', body: 'Bangladesh has 60-70K thalassemia patients requiring regular transfusions. Your donation helps them grow. Be a regular hero.', icon: 'drop' },
  { title: 'Post-donation care', body: 'Avoid heavy exercise for 24 hours. Drink plenty of water and eat salty food. You can return to normal work within 48 hours.', icon: 'activity' },
  { title: 'Blood shelf-life matters', body: 'RBC shelf life is 35-42 days. Blood banks track expiry strictly. Expired blood is never used — our screening system guarantees this.', icon: 'clock' },
];

export async function renderAwareness(root) {
  const items = lang() === 'bn' ? CONTENT_BN : CONTENT_EN;
  root.innerHTML = `
    <section class="section narrow">
      <div class="page-head"><h2>${lang() === 'bn' ? 'সচেতনতা' : 'Awareness'}</h2>
        <p class="muted">${lang() === 'bn' ? 'রক্তদানের বাস্তব তথ্য ও মিথ্যা ধারণা ভঙ্গ' : 'Facts and myth-busting about blood donation'}</p></div>
      <div class="card-list">
        ${items.map((it, i) => `
          <article class="tip-row ${i === 0 ? 'featured' : ''}">${icon(it.icon)}<div>
            <h4>${esc(it.title)}</h4>
            <p>${esc(it.body)}</p>
          </div></article>`).join('')}
      </div>
      <div class="panel" style="margin-top:18px; padding:18px; text-align:center;">
        <h3 style="margin-bottom:8px;">${lang() === 'bn' ? 'রক্তদান করুন — জীবন বাঁচান' : 'Donate Blood — Save Lives'}</h3>
        <p class="muted" style="margin-bottom:12px">${lang() === 'bn' ? 'আপনার এক ইউনিট রক্ত তিনটি জীবন বাঁচাতে পারে' : 'One unit of blood can save up to three lives'}</p>
        <a href="#/centers" class="btn primary">${icon('drop')} ${lang() === 'bn' ? 'নিকটস্থ কেন্দ্র খুঁজুন' : 'Find Nearby Center'}</a>
      </div>
    </section>`;
}