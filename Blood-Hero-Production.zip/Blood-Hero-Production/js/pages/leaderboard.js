// Impact leaderboard — verified donations only
import { t, lang } from '../i18n.js';
import { Donors, Donations } from '../db.js';
import { currentUser } from '../auth.js';
import { esc, icon, bloodBadge } from '../ui.js';
import { getProfilePicture } from '../../shared/js/storage.js';

export async function renderLeaderboard(root) {
  const donors = await Donors.list();
  const withVerified = await Promise.all(donors.map(async d => {
    const count = await Donations.verifiedCount(d.id);
    return { ...d, verifiedCount: count };
  }));
  withVerified.sort((a, b) => (b.verifiedCount || 0) - (a.verifiedCount || 0));
  const u = currentUser() || {};
  const myRank = Math.max(1, withVerified.findIndex(d => d.phone === u.phone) + 1);
  const myCount = u.uid ? await Donations.verifiedCount(u.uid) : 0;
  const top3 = withVerified.slice(0, 3);
  const rest = withVerified.slice(3, 10);
  root.innerHTML = `
    <section class="section">
      <div class="page-head"><h2>${icon('trophy')} ${lang() === 'bn' ? 'ইমপ্যাক্ট লিডারবোর্ড' : 'Impact Leaderboard'}</h2></div>
      <div class="my-rank">
        <span class="rank-badge">#${myRank}</span>
        <div><strong>${esc(u.name || 'Hero')}</strong><p class="muted">${myCount} ${esc(t('totalDonations'))}</p></div>
        ${bloodBadge(u.bloodGroup)}
      </div>
      <div class="podium">
        ${top3.map((d, i) => {
          const pic = getProfilePicture(d.id);
          return `
          <div class="podium-card p${i + 1}">
            <span class="medal">${['🥇', '🥈', '🥉'][i]}</span>
            <div class="podium-avatar">${pic ? `<img src="${pic}" alt="" style="width:100%;height:100%;object-fit:cover;border-radius:50%;" />` : icon('user')}</div>
            <strong>${esc(d.name)}</strong>
            <p>${d.verifiedCount || 0} ${esc(t('totalDonations'))}</p>
            ${bloodBadge(d.bloodGroup)}
          </div>`;
        }).join('')}
      </div>
      ${rest.map((d, i) => {
        const pic = getProfilePicture(d.id);
        return `
        <div class="rank-row"><span class="rank-n">#${i + 4}</span>
          <div class="rank-mid"><strong>${esc(d.name)}</strong><small>${esc(d.district || '')}</small></div>
          <span class="rank-lives">${d.verifiedCount || 0} ✅</span></div>`;
      }).join('')}
    </section>`;
}
