// Home — dashboard: greeting, blood card, eligibility, quick actions, urgent requests
import { t, lang } from '../i18n.js';
import { Requests, daysUntilEligible, Donations } from '../db.js';
import { currentUser } from '../auth.js';
import { esc, icon, bloodBadge, timeAgo } from '../ui.js';

const urgKey = u => u === 'critical' ? 'critical' : u === 'urgent' ? 'urgent' : 'normal';
const urgBadge = u => `<span class="badge ${u === 'critical' ? 'red' : u === 'urgent' ? 'amber' : 'gray'}">${esc(t(urgKey(u)))}</span>`;

export async function renderHome(root) {
  const u = currentUser() || {};
  const days = u.lastDonation ? daysUntilEligible(u.lastDonation, u.gender) : 0;
  const eligible = days === 0;
  const requests = (await Requests.list()).filter(r => r.status === 'pending').slice(0, 5);
  const verifiedCount = u.uid && !u.guest ? (await Donations.verifiedCount(u.uid)) : 0;

  root.innerHTML = `
    <section class="hero-card" data-tilt>
      <div class="hero-top">
        <div>
          <p class="hero-hello">${esc(t('welcome'))},</p>
          <h2 class="hero-name">${esc(u.name || 'Hero')}</h2>
          <p class="hero-loc">${icon('location')} ${esc(u.upazila || '')}${u.upazila && u.district ? ', ' : ''}${esc(u.district || 'Bangladesh')}</p>
        </div>
        <div class="hero-group">
          <span class="hg-label">${esc(t('bloodGroup'))}</span>
          <span class="hg-value">${esc(u.bloodGroup || '—')}</span>
        </div>
      </div>
      <div class="hero-stats">
        <div class="hs"><span class="hs-l">${esc(t('totalDonations'))}</span><strong data-countup>${verifiedCount}</strong></div>
        <div class="hs"><span class="hs-l">${esc(t('livesSaved'))}</span><strong data-countup>${u.livesSaved || 0}</strong></div>
        <div class="hs"><span class="hs-l">${esc(t('nextEligible'))}</span>
          <strong class="${eligible ? 'ok' : 'wait'}">${eligible ? (lang() === 'bn' ? 'এখনই যোগ্য' : 'Ready') : days + 'd'}</strong>
        </div>
      </div>
      <div class="elig-ring" style="--p:${eligible ? 100 : Math.round((1 - days / 90) * 100)}">
        <div class="ring"><span>${eligible ? '✓' : days}</span></div>
        <p>${eligible ? (lang() === 'bn' ? 'আপনি এখন রক্তদান করতে পারেন' : 'You can donate today') : (lang() === 'bn' ? `দিন বাকি` : 'days until eligible')}</p>
      </div>
      ${!eligible ? `<p class="muted" style="margin-top:8px; font-size:.72rem; text-align:center;">${esc(t('finalDisclaimerBn'))}</p>` : ''}
    </section>

    <section class="quick-grid">
      <a href="#/request" class="quick-card red">${icon('drop')}<span>${esc(t('needBlood'))}</span></a>
      <a href="#/donors" class="quick-card blue">${icon('search')}<span>${esc(t('findDonor'))}</span></a>
      <a href="#/alerts" class="quick-card amber">${icon('emergency')}<span>${esc(t('alerts'))}</span></a>
      <a href="#/rewards" class="quick-card purple">${icon('gift')}<span>${esc(t('rewards'))}</span></a>
      <a href="#/heatmap" class="quick-card blue">${icon('activity')}<span>${lang() === 'bn' ? 'শর্টেজ মানচিত্র' : 'Shortage Map'}</span></a>
      <a href="#/awareness" class="quick-card green">${icon('heart')}<span>${lang() === 'bn' ? 'সচেতনতা' : 'Awareness'}</span></a>
    </section>

    <section class="section">
      <div class="section-head">
        <h3>${esc(t('urgentRequests'))}</h3>
        <a href="#/requests" class="link">${esc(t('viewAll'))}</a>
      </div>
      <div class="card-list" id="homeRequests">
        ${requests.length === 0 ? `<div class="empty">${icon('info')} ${esc(t('noResults'))}</div>` :
          requests.map(r => `
            <article class="req-card ${r.emergency ? 'emg' : ''}">
              ${r.emergency ? `<span class="ribbon">${esc(t('emergencyRequest'))}</span>` : ''}
              <div class="req-main">
                ${bloodBadge(r.bloodGroup)}
                <div class="req-info">
                  <h4>${esc(r.hospital)}</h4>
                  <p>${esc(t('patientName'))}: ${esc(r.patientName)} · ${r.units} ${esc(t('units'))} · ${urgBadge(r.urgency)}</p>
                  <p class="loc">${icon('location')} ${esc([r.upazila, r.district].filter(Boolean).join(', ') || 'Bangladesh')} · ${timeAgo(r.createdAt, lang() === 'bn')}</p>
                </div>
              </div>
              <div class="req-actions">
                <a class="btn ghost sm" href="#/request/${encodeURIComponent(r.id)}">${esc(t('details'))}</a>
                <a class="btn primary sm" href="tel:${esc(r.contact ? String(r.contact).replace(/[^0-9+]/g, '') : '')}">${icon('phone')} ${esc(t('callNow'))}</a>
              </div>
            </article>`).join('')}
      </div>
    </section>

    <section class="tip-card">
      ${icon('health')}
      <div>
        <h4>${esc(t('health'))}</h4>
        <p>${lang() === 'bn' ? 'দানের ২৪ ঘণ্টা আগে পর্যাপ্ত পানি পান করুন ও আয়রনসমৃদ্ধ খাবার খান।' : 'Hydrate well 24h before donation and eat iron-rich food.'}</p>
      </div>
    </section>
    <p class="muted" style="text-align:center; margin-top:12px; font-size:.7rem;">${esc(t('finalDisclaimerBn'))}</p>`;
}
