// Shortage Heatmap — shows blood group demand vs supply by district
import { t, lang } from '../i18n.js';
import { Requests, Donors, BLOOD_GROUPS } from '../db.js';
import { esc, icon, bloodBadge, toast } from '../ui.js';

const DISTRICTS = ['Dhaka', 'Chattogram', 'Rangpur', 'Khulna', 'Sylhet', 'Rajshahi', 'Barishal', 'Mymensingh'];

export async function renderHeatmap(root) {
  const [requests, donors] = await Promise.all([Requests.list(), Donors.list()]);
  const pending = requests.filter(r => r.status === 'pending');
  
  const demand = {};
  const supply = {};
  DISTRICTS.forEach(d => {
    demand[d] = {};
    supply[d] = {};
    BLOOD_GROUPS.forEach(g => {
      demand[d][g] = pending.filter(r => r.district === d && r.bloodGroup === g).reduce((s, r) => s + (r.units || 0), 0);
      supply[d][g] = donors.filter(donor => donor.district === d && donor.bloodGroup === g && donor.available).length;
    });
  });

  root.innerHTML = `
    <section class="section">
      <div class="page-head"><h2>${lang() === 'bn' ? 'রক্তের শর্টেজ হিটম্যাপ' : 'Blood Shortage Heatmap'}</h2>
        <p class="muted">${lang() === 'bn' ? 'এলাকাভিত্তিক রক্তের চাহিদা ও সাপ্লাই' : 'Area-wise blood demand vs supply'}</p></div>
      <div class="chip-row" id="heatFilter" style="margin-bottom:14px">
        ${BLOOD_GROUPS.map(g => `<button class="chip blood" data-g="${g}">${g}</button>`).join('')}
        <button class="chip active" data-g="__all">${esc(t('all'))}</button>
      </div>
      <div class="card-list" id="heatList"></div>
    </section>`;

  const paint = (filter = '__all') => {
    const list = DISTRICTS.map(d => {
      const items = filter === '__all' ? BLOOD_GROUPS : [filter];
      const rows = items.map(g => {
        const dmg = demand[d][g] || 0;
        const sup = supply[d][g] || 0;
        const gap = dmg - sup;
        const statusText = gap > 2 ? (lang() === 'bn' ? '🔴 অত্যন্ত সঙ্কট' : '🔴 Critical')
          : gap > 0 ? (lang() === 'bn' ? '🟡 সংকট' : '🟡 Shortage')
          : (lang() === 'bn' ? '✅ পর্যাপ্ত' : '✅ Sufficient');
        const statusCls = gap > 2 ? 'red' : gap > 0 ? 'amber' : 'green';
        return { group: g, demand: dmg, supply: sup, gap, statusText, statusCls };
      }).filter(r => filter === '__all' ? (r.demand > 0 || r.supply > 0) : true);
      return { district: d, rows };
    }).filter(d => d.rows.length > 0);

    const container = root.querySelector('#heatList');
    container.innerHTML = list.length === 0
      ? `<div class="empty">${icon('check')} ${lang() === 'bn' ? 'সব এলাকায় পর্যাপ্ত রক্ত আছে' : 'Sufficient blood across all areas'}</div>`
      : list.map(d => `
          <article class="panel">
            <div class="panel-head"><h3>${icon('location')} ${esc(d.district)}</h3></div>
            <div style="display:flex; flex-direction:column; gap:8px;">
              ${d.rows.map(r => `
                <div class="mini-row">
                  <span>${bloodBadge(r.group)} ${esc(r.statusText)}</span>
                  <span class="muted">${lang() === 'bn' ? 'চাহিদা' : 'Demand'}: ${r.demand} · ${lang() === 'bn' ? 'সাপ্লাই' : 'Supply'}: ${r.supply} · ${lang() === 'bn' ? 'গ্যাপ' : 'Gap'}: <strong class="${r.statusCls}">${r.gap > 0 ? '+' : ''}${r.gap}</strong></span>
                </div>`).join('')}
            </div>
          </article>`).join('');
  };

  root.querySelector('#heatFilter').addEventListener('click', e => {
    const b = e.target.closest('.chip'); if (!b) return;
    root.querySelectorAll('#heatFilter .chip').forEach(c => c.classList.toggle('active', c === b));
    paint(b.dataset.g);
  });

  paint('__all');
}
