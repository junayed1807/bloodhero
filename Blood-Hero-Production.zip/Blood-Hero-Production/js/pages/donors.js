// Find Donors — search & filter (blood group, district, upazila, availability, text)
// v2.1: cascading Rangpur district→upazila→union selects + verified badges + profile links.
import { t, lang } from '../i18n.js';
import { Donors, BLOOD_GROUPS, daysUntilEligible, publicProfile } from '../db.js';
import { currentUser } from '../auth.js';
import { esc, icon, bloodBadge, safeTel } from '../ui.js';
import { DISTRICTS, upazilasFor, unionsFor, lname } from '../data/rangpur.js';
import { getProfilePicture } from '../../shared/js/storage.js';

export async function renderDonors(root) {
  root.innerHTML = `
    <section class="section">
      <div class="page-head">
        <h2>${esc(t('findDonor'))}</h2>
        <p class="muted">${esc(t('search'))} — ${esc(t('bloodGroup'))}, ${esc(t('district'))}, ${esc(t('upazila'))}</p>
      </div>
      <div class="filter-card">
        <div class="search-row">
          ${icon('search')}
          <input id="dQ" type="search" placeholder="${esc(t('search'))}..." />
        </div>
        <div class="chip-row" id="groupChips">
          <button class="chip active" data-g="">${esc(t('all'))}</button>
          ${BLOOD_GROUPS.map(g => `<button class="chip blood" data-g="${g}">${g}</button>`).join('')}
        </div>
        <div class="grid-3">
          <select id="dDistrict" class="field">
            <option value="">${esc(t('district'))} — ${esc(t('all'))}</option>
            ${DISTRICTS.map(d => `<option>${d}</option>`).join('')}
          </select>
          <span id="dUpazilaWrap"><input id="dUpazila" class="field" placeholder="${esc(t('upazila'))}" /></span>
          <span id="dUnionWrap"></span>
        </div>
        <label class="switch-row"><input type="checkbox" id="dAvail" /><span class="switch"></span> ${esc(t('availability'))}</label>
      </div>
      <p class="result-count" id="dCount"></p>
      <div class="card-list" id="donorList"></div>
    </section>`;

  const $ = s => root.querySelector(s);
  let group = '';
  const readLoc = () => ({ district: $('#dDistrict').value.trim(), upazila: ($('#dUpazilaSel')?.value || $('#dUpazila')?.value || '').trim(), union: $('#dUnionSel')?.value?.trim() || '' });

  const paintLoc = () => {
    const district = $('#dDistrict').value;
    const uz = upazilasFor(district);
    $('#dUpazilaWrap').innerHTML = uz.length
      ? `<select id="dUpazilaSel" class="field"><option value="">${esc(t('selectUpazila'))}</option>${uz.map(u => `<option>${lname(u)}</option>`).join('')}</select>`
      : `<input id="dUpazila" class="field" placeholder="${esc(t('upazila'))}" />`;
    $('#dUnionWrap').innerHTML = '';
    $('#dUpazilaSel')?.addEventListener('change', paintUnion);
  };
  const paintUnion = () => {
    const uz = $('#dUpazilaSel')?.value || '';
    const un = unionsFor($('#dDistrict').value, uz);
    $('#dUnionWrap').innerHTML = un.length
      ? `<select id="dUnionSel" class="field"><option value="">${esc(t('union'))} — ${esc(t('all'))}</option>${un.map(x => `<option>${lname(x)}</option>`).join('')}</select>`
      : '';
  };
  $('#dDistrict').addEventListener('change', () => { paintLoc(); search(); });

  const viewer = currentUser();
  const search = async () => {
    const loc = readLoc();
    const list = await Donors.search({
      group, district: loc.district, upazila: loc.upazila,
      availableOnly: $('#dAvail').checked, q: $('#dQ').value.trim(),
    });
    const filtered = loc.union ? list.filter(d => (d.union || '').toLowerCase() === loc.union.toLowerCase()) : list;
    const sanitized = filtered.map(d => publicProfile(d, viewer)).filter(Boolean);
    $('#dCount').textContent = `${sanitized.length} ${t('donorFound')}`;
    $('#donorList').innerHTML = sanitized.length === 0
      ? `<div class="empty">${icon('search')} ${esc(t('noResults'))}</div>`
      : sanitized.map(d => {
          const days = daysUntilEligible(d.lastDonation, d.gender);
          const verified = d.nidStatus === 'approved' || (d.totalDonations || 0) >= 5;
          const profilePic = getProfilePicture(d.id);
          return `
          <article class="donor-card">
            <div class="donor-left">
              <div class="donor-avatar-sm">
                ${profilePic ? `<img src="${profilePic}" alt="${esc(d.name)}" style="width:100%; height:100%; object-fit:cover; border-radius:50%;" />` : icon('user')}
              </div>
              ${bloodBadge(d.bloodGroup)}
            </div>
            <div class="donor-mid">
              <h4><a href="#/donor/${encodeURIComponent(d.id)}" class="link">${esc(d.name)}</a>
                ${verified ? `<span class="badge green">✓ ${esc(t('verifiedDonor'))}</span>` : ''}</h4>
              <p class="loc">${icon('location')} ${esc([d.union, d.upazila, d.district].filter(Boolean).join(', '))}</p>
              <p class="meta">${d.totalDonations || 0} ${esc(t('totalDonations')).toLowerCase?.() || 'donations'} · ${days === 0 ? (lang() === 'bn' ? 'এখন যোগ্য' : 'Eligible now') : days + 'd'}</p>
            </div>
            <div class="donor-right">
              <span class="dot ${d.available ? 'on' : 'off'}" title="${esc(t('availability'))}"></span>
              <a class="btn primary sm" href="#/donor/${encodeURIComponent(d.id)}">${icon('user')}</a>
            </div>
          </article>`;
        }).join('');
  };

  $('#groupChips').addEventListener('click', e => {
    const b = e.target.closest('.chip'); if (!b) return;
    group = b.dataset.g;
    root.querySelectorAll('#groupChips .chip').forEach(c => c.classList.toggle('active', c === b));
    search();
  });
  ['input', 'change'].forEach(ev => {
    $('#dQ').addEventListener(ev, search);
    $('#dUpazila')?.addEventListener(ev, search);
    $('#dAvail').addEventListener(ev, search);
  });
  paintLoc();
  await search();
}