// Blood Hero — Public Website Pages
// Professional pages inspired by the benchmark product structure:
// Gallery, News, Transparency, Downloads, Campaigns, Blood Camps, Volunteers,
// Success Stories, Contact, FAQ. All data is REAL backend data with graceful
// empty states — never fabricated.
import { t, lang } from '../i18n.js';
import { esc, icon } from '../ui.js';
import { backendApi } from '../../shared/js/backend-api.js';

const BN = () => lang() === 'bn';

// ---------- helpers ----------
async function fetchPublic(path, fallback) {
  try {
    const data = await backendApi.get(path);
    return Array.isArray(data) ? data : (data || fallback);
  } catch {
    return fallback;
  }
}

function pageHead(root, title, subtitle, iconName) {
  root.innerHTML = `
    <section class="about-hero">
      <h1>${icon(iconName)} ${esc(title)}</h1>
      <p>${esc(subtitle)}</p>
    </section>`;
}

function emptyState(msg, sub) {
  return `<div class="empty section"><h3>${esc(msg)}</h3><p class="muted">${esc(sub)}</p></div>`;
}

function imgOrPlaceholder(url, cls, alt, ic = 'camera') {
  if (url) return `<img class="${cls}" src="${esc(url)}" alt="${esc(alt)}" loading="lazy" />`;
  return `<div class="${cls} pub-img-ph" role="img" aria-label="${esc(alt)}">${icon(ic)}</div>`;
}

function fmtDate(v) {
  if (!v) return '';
  let d;
  if (typeof v === 'number') d = new Date(v * 1000);
  else if (typeof v === 'string' && /^\d+$/.test(v)) d = new Date(Number(v) * 1000);
  else d = new Date(v);
  if (isNaN(d)) return String(v);
  return BN() ? d.toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', year: 'numeric' })
              : d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}

function bindAccordions(root) {
  root.querySelectorAll('.faq-question').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.closest('.faq-item');
      const wasOpen = item.classList.contains('open');
      root.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
      if (!wasOpen) item.classList.add('open');
    });
  });
}

// ---------- GALLERY ----------
export async function renderGallery(root) {
  pageHead(root,
    BN() ? 'গ্যালারি ও ইভেন্ট' : 'Gallery & Events',
    BN() ? 'আমাদের রক্তদান ক্যাম্প ও কমিউনিটি ইভেন্টের মুহূর্তগুলো।' : 'Moments from our blood donation camps and community events.',
    'camera');
  const albums = await fetchPublic('/public/gallery', []);
  if (!albums.length) {
    root.insertAdjacentHTML('beforeend', emptyState(
      BN() ? 'কোনো অ্যালবাম নেই' : 'No albums yet',
      BN() ? 'ক্যাম্প চলাকালীন এখানে ছবি যোগ করা হবে।' : 'Photos will appear here as camps take place.'));
    return;
  }
  root.insertAdjacentHTML('beforeend', `
    <section class="gallery-grid">
      ${albums.map(a => `
        <a href="#/gallery/${encodeURIComponent(a.id)}" class="gallery-card">
          ${imgOrPlaceholder(a.cover_url, 'gallery-card-img', a.title)}
          <div class="gallery-card-body">
            <h3>${esc(a.title)}</h3>
            <p>${esc(a.category || '')}${a.image_count ? ` · ${esc(a.image_count)} ${BN() ? 'ছবি' : 'photos'}` : ''}</p>
            ${a.event_date ? `<p>${esc(fmtDate(a.event_date))}</p>` : ''}
          </div>
        </a>`).join('')}
    </section>`);
}

export async function renderGalleryDetail(root, id) {
  let data = null;
  try { data = await backendApi.get(`/public/gallery/${encodeURIComponent(id)}`); } catch {}
  if (!data) {
    root.innerHTML = emptyState(BN() ? 'অ্যালবাম পাওয়া যায়নি' : 'Album not found', '');
    return;
  }
  root.innerHTML = `
    <section class="about-hero">
      <h1>${icon('camera')} ${esc(data.album.title)}</h1>
      ${data.album.description ? `<p>${esc(data.album.description)}</p>` : ''}
      ${data.album.event_date ? `<p>${esc(fmtDate(data.album.event_date))}</p>` : ''}
    </section>
    <a href="#/gallery" class="link">← ${esc(t('back'))}</a>
    <section class="gallery-grid">
      ${(data.images || []).map(im => `
        <figure class="gallery-card">
          ${imgOrPlaceholder(im.url, 'gallery-card-img', im.caption || data.album.title)}
          ${im.caption ? `<figcaption class="gallery-card-body"><p>${esc(im.caption)}</p></figcaption>` : ''}
        </figure>`).join('')}
    </section>`;
}

// ---------- NEWS / UPDATES ----------
export async function renderNews(root) {
  pageHead(root,
    BN() ? 'সংবাদ ও আপডেট' : 'News & Updates',
    BN() ? 'ক্যাম্প, অভিযান ও কমিউনিটি আপডেট — সর্বশেষ সংবাদ।' : 'Latest updates from our camps, campaigns and community.',
    'bell');
  const articles = await fetchPublic('/public/articles?limit=30', []);
  if (!articles.length) {
    root.insertAdjacentHTML('beforeend', emptyState(
      BN() ? 'কোনো সংবাদ নেই' : 'No news yet',
      BN() ? 'আপডেট আসলে এখানে প্রকাশ করা হবে।' : 'Updates will be published here when available.'));
    return;
  }
  root.insertAdjacentHTML('beforeend', `
    <section class="news-grid">
      ${articles.map(a => `
        <a href="#/news/${encodeURIComponent(a.slug)}" class="news-card">
          ${imgOrPlaceholder(a.image_url, 'news-card-img', a.title_en || a.title_bn, 'file')}
          <div class="news-card-body">
            <h3>${esc(BN() ? (a.title_bn || a.title_en) : (a.title_en || a.title_bn))}</h3>
            <p>${esc(BN() ? (a.excerpt_bn || a.excerpt_en || '') : (a.excerpt_en || a.excerpt_bn || ''))}</p>
            <div class="news-card-meta">
              <span>${icon('calendar')} ${esc(fmtDate(a.published_at || a.created_at))}</span>
              ${a.category ? `<span class="campaign-status active">${esc(a.category)}</span>` : ''}
            </div>
          </div>
        </a>`).join('')}
    </section>`);
}

export async function renderNewsDetail(root, slug) {
  let article = null;
  try { article = await backendApi.get(`/public/articles/${encodeURIComponent(slug)}`); } catch {}
  if (!article) {
    root.innerHTML = emptyState(BN() ? 'সংবাদটি পাওয়া যায়নি' : 'Article not found', '');
    return;
  }
  const title = BN() ? (article.title_bn || article.title_en) : (article.title_en || article.title_bn);
  const body = BN() ? (article.body_bn || article.body_en) : (article.body_en || article.body_bn);
  root.innerHTML = `
    <a href="#/news" class="link">← ${esc(t('back'))}</a>
    <section class="about-hero">
      <h1>${esc(title)}</h1>
      <p>${esc(fmtDate(article.published_at || article.created_at))}${article.author_name ? ' · ' + esc(article.author_name) : ''}</p>
    </section>
    <section class="pub-blood-search" style="text-align:left;">
      ${imgOrPlaceholder(article.image_url, 'gallery-card-img', title)}
      <article class="news-body" style="line-height:1.8; font-size:.92rem; margin-top:16px;">${esc(body).replace(/\n/g, '<br/>')}</article>
    </section>`;
}

// ---------- TRANSPARENCY ----------
export async function renderTransparency(root) {
  pageHead(root,
    BN() ? 'স্বচ্ছতা ও প্রভাব' : 'Transparency & Impact',
    BN() ? 'আমাদের অগ্রগতি — প্রকৃত ডেটা থেকে, কখনো মিথ্যা নয়।' : 'Our progress — from real platform data, never fabricated.',
    'activity');
  const stats = await fetchPublic('/public/stats', { donors: 0, verifiedDonors: 0, requests: 0, fulfilled: 0, verifiedDonations: 0, camps: 0, volunteers: 0, centers: 0, ambulances: 0, lives: 0 });
  const cards = [
    ['users', BN() ? 'নিবন্ধিত ব্যবহারকারী' : 'Registered Users', stats.donors],
    ['check', BN() ? 'ভেরিফাইড ডোনার' : 'Verified Donors', stats.verifiedDonors],
    ['list', BN() ? 'মোট রক্তের অনুরোধ' : 'Total Blood Requests', stats.requests],
    ['heart', BN() ? 'পূরণকৃত অনুরোধ' : 'Requests Fulfilled', stats.fulfilled],
    ['drop', BN() ? 'যাচাইকৃত রক্তদান' : 'Verified Donations', stats.verifiedDonations],
    ['calendar', BN() ? 'রক্তদান ক্যাম্প' : 'Blood Camps', stats.camps],
    ['volunteer', BN() ? 'স্বেচ্ছাসেবী' : 'Volunteers', stats.volunteers],
    ['health', BN() ? 'রক্তকেন্দ্র' : 'Blood Centers', stats.centers],
    ['emergency', BN() ? 'অ্যাম্বুলেন্স' : 'Ambulances', stats.ambulances],
    ['trophy', BN() ? 'জীবন রক্ষিত' : 'Lives (est.)', stats.lives],
  ];
  root.insertAdjacentHTML('beforeend', `
    <section class="transparency-stats">
      ${cards.map(([ic, label, val]) => `
        <div class="transparency-card">
          <div class="pub-stat-icon red" style="margin:0 auto 10px;">${icon(ic)}</div>
          <div class="stat-value">${esc((val || 0).toLocaleString())}</div>
          <div class="stat-label">${esc(label)}</div>
        </div>`).join('')}
    </section>
    <section class="pub-blood-search" style="text-align:left;">
      <h3>${BN() ? 'আমরা যা বিশ্বাস করি' : 'What we stand for'}</h3>
      <p class="muted" style="line-height:1.8; margin-top:10px;">${esc(BN()
        ? 'রক্ত হিরো বিশ্বাস করে — কোনো রোগী যেন অবস্থান বা সামর্থ্যের কারণে রক্ত না পেয়ে পিছিয়ে না পড়ে। স্বেচ্ছায় রক্তদান, সচেতনতা এবং কমিউনিটি উদ্যোগের মাধ্যমে আমরা এগিয়ে যাই। প্রতিটি সংখ্যা এই প্ল্যাটফর্মের প্রকৃত ডেটা থেকে আসে।'
        : 'Blood Hero believes no patient should be left without blood because of where they live or what they can afford. Through voluntary donation, awareness and community action we move forward. Every number here comes from real platform data.')}</p>
    </section>`);
}

// ---------- DOWNLOADS ----------
export async function renderDownloads(root) {
  pageHead(root,
    BN() ? 'ডাউনলোড ও রিসোর্স' : 'Downloads & Resources',
    BN() ? 'রক্তদান গাইড, সচেতনতা উপকরণ ও সংগঠন নথি।' : 'Donor guides, awareness materials and organization documents.',
    'download');
  const items = await fetchPublic('/public/downloads', []);
  if (!items.length) {
    root.insertAdjacentHTML('beforeend', emptyState(
      BN() ? 'কোনো ডাউনলোড নেই' : 'No downloads yet',
      BN() ? 'রক্তদান গাইড ও উপকরণ এখানে যোগ করা হবে।' : 'Donor guides and materials will be added here.'));
    return;
  }
  root.insertAdjacentHTML('beforeend', `
    <section class="download-list">
      ${items.map(d => `
        <div class="download-item">
          <div class="download-icon">${icon('file')}</div>
          <div class="download-info">
            <h4>${esc(d.title)}</h4>
            <p>${esc(d.description || '')}${d.file_size ? ` · ${esc(d.file_size)}` : ''}</p>
          </div>
          ${d.file_url ? `<a class="btn ghost sm" href="${esc(d.file_url)}" target="_blank" rel="noopener noreferrer">${icon('download')} ${esc(t('download'))}</a>` : ''}
        </div>`).join('')}
    </section>`);
}

// ---------- CAMPAIGNS ----------
export async function renderCampaigns(root) {
  pageHead(root,
    BN() ? 'অভিযানসমূহ' : 'Campaigns',
    BN() ? 'রক্তদান, জরুরি, সচেতনতা ও কমিউনিটি অভিযান।' : 'Blood donation, emergency, awareness and community campaigns.',
    'trophy');
  const campaigns = await fetchPublic('/public/campaigns', []);
  if (!campaigns.length) {
    root.insertAdjacentHTML('beforeend', emptyState(
      BN() ? 'কোনো অভিযান নেই' : 'No campaigns yet',
      BN() ? 'চলমান ও আসন্ন অভিযান এখানে দেখা যাবে।' : 'Ongoing and upcoming campaigns will appear here.'));
    return;
  }
  root.insertAdjacentHTML('beforeend', `
    <section class="campaign-grid">
      ${campaigns.map(c => `
        <a href="#/campaigns/${encodeURIComponent(c.id)}" class="campaign-card">
          ${imgOrPlaceholder(c.banner_url, 'gallery-card-img', c.title, 'trophy')}
          <div class="campaign-card-body">
            <span class="campaign-status ${esc(c.status)}">${esc(statusLabel(c.status))}</span>
            <h3 style="margin:8px 0 6px;">${esc(c.title)}</h3>
            <p class="muted" style="font-size:.8rem;">${esc(c.description || '').slice(0, 120)}</p>
            <div class="news-card-meta">
              <span>${icon('calendar')} ${esc(c.start_date || '')}</span>
              ${c.goal ? `<span>${icon('drop')} ${esc((c.achieved || 0))}/${esc(c.goal)}</span>` : ''}
            </div>
          </div>
        </a>`).join('')}
    </section>`);
}

export async function renderCampaignDetail(root, id) {
  let c = null;
  try { c = await backendApi.get(`/public/campaigns/${encodeURIComponent(id)}`); } catch {}
  if (!c) { root.innerHTML = emptyState(BN() ? 'অভিযান পাওয়া যায়নি' : 'Campaign not found', ''); return; }
  root.innerHTML = `
    <a href="#/campaigns" class="link">← ${esc(t('back'))}</a>
    <section class="about-hero">
      <h1>${esc(c.title)}</h1>
      <p>${esc(fmtDate(c.start_date))}${c.end_date ? ' — ' + esc(fmtDate(c.end_date)) : ''}</p>
      <p><span class="campaign-status ${esc(c.status)}">${esc(statusLabel(c.status))}</span></p>
    </section>
    <section class="pub-blood-search" style="text-align:left;">
      ${imgOrPlaceholder(c.banner_url, 'gallery-card-img', c.title, 'trophy')}
      <p class="muted" style="line-height:1.8; margin-top:14px;">${esc(c.description || '')}</p>
      ${c.goal ? `<div style="margin-top:16px;">
        <div class="progress"><span style="width:${Math.min(100, Math.round(((c.achieved||0)/c.goal)*100))}%;"></span></div>
        <p class="muted" style="font-size:.78rem; margin-top:6px;">${esc((c.achieved||0))} / ${esc(c.goal)} ${BN() ? 'ইউনিট' : 'units'}</p>
      </div>` : ''}
      <a href="#/register" class="btn primary" style="margin-top:16px;">${icon('heart')} ${BN() ? 'অভিযানে অংশ নিন' : 'Join this campaign'}</a>
    </section>`;
}

// ---------- BLOOD CAMPS ----------
export async function renderCamps(root) {
  pageHead(root,
    BN() ? 'রক্তদান ক্যাম্প' : 'Blood Camps',
    BN() ? 'আসন্ন ও চলমান রক্তদান ক্যাম্পে অংশ নিন।' : 'Join our upcoming and ongoing voluntary blood donation camps.',
    'calendar');
  const camps = await fetchPublic('/public/camps?limit=40', []);
  if (!camps.length) {
    root.insertAdjacentHTML('beforeend', emptyState(
      BN() ? 'কোনো ক্যাম্প নেই' : 'No camps scheduled yet',
      BN() ? 'ক্যাম্প নির্ধারিত হলে এখানে প্রকাশ করা হবে।' : 'Camps will be published here when scheduled.'));
    return;
  }
  root.insertAdjacentHTML('beforeend', `
    <section class="campaign-grid">
      ${camps.map(c => `
        <div class="campaign-card">
          ${imgOrPlaceholder(c.banner_url, 'gallery-card-img', c.title, 'calendar')}
          <div class="campaign-card-body">
            <span class="campaign-status ${esc(c.status)}">${esc(statusLabel(c.status))}</span>
            <h3 style="margin:8px 0 6px;">${esc(c.title)}</h3>
            <p class="muted" style="font-size:.8rem;">${esc(c.venue || c.description || '').slice(0, 120)}</p>
            <div class="news-card-meta" style="flex-wrap:wrap;">
              <span>${icon('calendar')} ${esc(c.date || '')}</span>
              ${c.start_time ? `<span>${icon('clock')} ${esc(c.start_time)}${c.end_time ? '–' + esc(c.end_time) : ''}</span>` : ''}
              ${c.district ? `<span>${icon('location')} ${esc(c.district)}${c.upazila ? ', ' + esc(c.upazila) : ''}</span>` : ''}
            </div>
            ${c.target_units ? `<div class="progress" style="margin-top:10px;"><span style="width:${Math.min(100, Math.round(((c.collected_units||0)/c.target_units)*100))}%;"></span></div>
            <p class="muted" style="font-size:.74rem; margin-top:4px;">${esc(c.collected_units||0)} / ${esc(c.target_units)} ${BN() ? 'ইউনিট' : 'units'}</p>` : ''}
            ${c.registration_open ? `<a href="#/register" class="btn primary sm" style="margin-top:12px;">${icon('plus')} ${BN() ? 'অংশগ্রহণ করুন' : 'Participate'}</a>` : ''}
          </div>
        </div>`).join('')}
    </section>`);
}

// ---------- VOLUNTEERS ----------
export async function renderVolunteersPage(root) {
  pageHead(root,
    BN() ? 'স্বেচ্ছাসেবী হোন' : 'Volunteers',
    BN() ? 'জীবন বাঁচানোর আন্দোলনের অংশ হোন — আজই স্বেচ্ছাসেবী হিসেবে নিবন্ধন করুন।' : 'Be part of the lifesaving movement — register as a volunteer today.',
    'volunteer');
  const volunteers = await fetchPublic('/public/volunteers', []);

  root.insertAdjacentHTML('beforeend', `
    <section class="contact-grid" style="margin-bottom:28px;">
      <div class="contact-info-card">
        <h3>${BN() ? 'স্বেচ্ছাসেবী নিবন্ধন' : 'Volunteer Registration'}</h3>
        <form id="volForm" class="form-card flat" style="background:transparent; box-shadow:none; padding:0;">
          <label class="field-row"><span>${esc(t('name'))} *</span>
            <input class="field" name="name" required /></label>
          <label class="field-row"><span>${esc(t('phone'))} *</span>
            <input class="field" name="phone" type="tel" placeholder="+8801XXXXXXXXX" required /></label>
          <label class="field-row"><span>${esc(t('email'))}</span>
            <input class="field" name="email" type="email" /></label>
          <div class="grid-2">
            <label class="field-row"><span>${esc(t('district'))}</span>
              <input class="field" name="district" /></label>
            <label class="field-row"><span>${esc(t('upazila'))}</span>
              <input class="field" name="upazila" /></label>
          </div>
          <label class="field-row"><span>${BN() ? 'দক্ষতা' : 'Skills'}</span>
            <input class="field" name="skills" placeholder="${BN() ? 'যেমন: প্রথম সহায়তা, ইভেন্ট' : 'e.g. first aid, events'}"/></label>
          <label class="field-row"><span>${BN() ? 'উপলব্ধতা' : 'Availability'}</span>
            <input class="field" name="availability" placeholder="${BN() ? 'যেমন: সপ্তাহান্তে' : 'e.g. weekends'}" /></label>
          <label class="field-row"><span>${BN() ? 'বার্তা' : 'Message'}</span>
            <textarea class="field" name="message" rows="3"></textarea></label>
          <button class="btn light lg" type="submit">${icon('volunteer')} ${BN() ? 'নিবন্ধন করুন' : 'Register'}</button>
          <p class="muted" id="volMsg" style="font-size:.72rem; margin-top:8px;"></p>
        </form>
      </div>
      <div class="pub-blood-search" style="text-align:left;">
        <h3>${BN() ? 'কীভাবে সাহায্য করবেন' : 'How you can help'}</h3>
        <ul class="muted" style="list-style:none; padding:0; line-height:2; font-size:.88rem;">
          <li>${icon('check')} ${BN() ? 'ক্যাম্প ও ইভেন্টে সহায়তা' : 'Help at camps and events'}</li>
          <li>${icon('check')} ${BN() ? 'জরুরি রক্তের সমন্বয়' : 'Coordinate emergency blood'}</li>
          <li>${icon('check')} ${BN() ? 'সচেতনতা প্রচারণা' : 'Run awareness campaigns'}</li>
          <li>${icon('check')} ${BN() ? 'ডোনার নেটওয়ার্ক গড়া' : 'Grow the donor network'}</li>
        </ul>
      </div>
    </section>`);

  const form = root.querySelector('#volForm');
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    const msg = root.querySelector('#volMsg');
    msg.textContent = BN() ? 'নিবন্ধন করা হচ্ছে…' : 'Registering…';
    try {
      await backendApi.post('/public/volunteers/register', data);
      msg.textContent = BN() ? '✓ সফল! অ্যাডমিন অনুমোদনের পর আপনি স্বেচ্ছাসেবী হবেন।' : '✓ Registered! You will be an approved volunteer after admin review.';
      form.reset();
    } catch (err) {
      msg.textContent = err.message || 'Failed';
    }
  });

  if (volunteers.length) {
    root.insertAdjacentHTML('beforeend', `
      <section class="pub-how">
        <div class="pub-section-head"><h2>${BN() ? 'আমাদের স্বেচ্ছাসেবীরা' : 'Our Volunteers'}</h2></div>
        <div class="pub-how-grid">
          ${volunteers.map(v => `
            <div class="pub-how-card" style="text-align:left;">
              <div class="pub-how-icon" style="margin:0 0 12px;">${icon('volunteer')}</div>
              <h3>${esc(v.name)}</h3>
              <p>${esc(v.district || '')}${v.upazila ? ', ' + esc(v.upazila) : ''}</p>
              ${v.skills ? `<p style="font-size:.72rem; color:var(--green);">${esc(v.skills)}</p>` : ''}
            </div>`).join('')}
        </div>
      </section>`);
  }
}

// ---------- SUCCESS STORIES ----------
export async function renderSuccessStories(root) {
  pageHead(root,
    BN() ? 'সাফল্যের গল্প' : 'Success Stories',
    BN() ? 'যে গল্পগুলো আমাদের এগিয়ে নিয়ে যায় — সত্য ঘটনা থেকে।' : 'Stories that drive us forward — from real events.',
    'trophy');
  const stories = await fetchPublic('/public/success-stories', []);
  if (!stories.length) {
    root.insertAdjacentHTML('beforeend', emptyState(
      BN() ? 'এখনো কোনো গল্প নেই' : 'No stories yet',
      BN() ? 'প্রথম সাফল্যের গল্প এখানে প্রকাশিত হবে।' : 'The first success story will be published here.'));
    return;
  }
  root.insertAdjacentHTML('beforeend', `
    <section class="news-grid">
      ${stories.map(s => `
        <article class="news-card">
          ${imgOrPlaceholder(s.image_url, 'news-card-img', s.title, 'heart')}
          <div class="news-card-body">
            <h3>${esc(s.title)}</h3>
            <p>${esc(s.content || '').slice(0, 180)}${(s.content || '').length > 180 ? '…' : ''}</p>
            <div class="news-card-meta">
              <span>${icon('calendar')} ${esc(fmtDate(s.created_at))}</span>
              ${s.author_name ? `<span>· ${esc(s.author_name)}</span>` : ''}
            </div>
          </div>
        </article>`).join('')}
    </section>`);
}

// ---------- CONTACT ----------
export async function renderContact(root) {
  pageHead(root,
    BN() ? 'যোগাযোগ' : 'Contact Us',
    BN() ? 'প্রশ্ন, পরামর্শ বা জরুরি প্রয়োজনে আমাদের সাথে যোগাযোগ করুন।' : 'Reach out with questions, feedback or emergency needs.',
    'mail');
  root.insertAdjacentHTML('beforeend', `
    <section class="contact-grid">
      <div>
        <div class="contact-info-card">
          <h3>${BN() ? 'যোগাযোগের তথ্য' : 'Contact Information'}</h3>
          <div class="contact-info-item">${icon('mail')}<span>${esc(BN() ? 'সাধারণ যোগাযোগ' : 'General')}: bloodhero.bd@gmail.com</span></div>
          <div class="contact-info-item">${icon('phone')}<span>${esc(BN() ? 'জরুরি রক্তের জন্য' : 'For emergency blood')}: +8801XXXXXXXXX</span></div>
          <div class="contact-info-item">${icon('location')}<span>${esc(BN() ? 'বাংলাদেশ' : 'Bangladesh')}</span></div>
          <div class="contact-info-item">${icon('heart')}<span>${esc(BN() ? 'রক্তদানে আগ্রহী? নিবন্ধন করুন এবং জীবন বাঁচান।' : 'Want to donate? Register and save lives.')}</span></div>
        </div>
        <section class="pub-blood-search" style="text-align:left; margin-top:16px;">
          <h3>${BN() ? 'জরুরি প্রয়োজনে' : 'In an emergency'}</h3>
          <p class="muted" style="line-height:1.8; font-size:.85rem;">${esc(BN()
            ? 'রক্তের জরুরি প্রয়োজনে দ্রুততম উপায় হলো একটি রক্তের অনুরোধ তৈরি করা — নিকটস্থ সামঞ্জস্যপূর্ণ ডোনারদের অবিলম্বে জানানো হবে।'
            : 'The fastest way to get blood in an emergency is to create a blood request — nearby compatible donors are notified immediately.')}</p>
          <a href="#/find-blood" class="btn primary sm">${icon('search')} ${BN() ? 'রক্তদাতা খুঁজুন' : 'Find Blood'}</a>
        </section>
      </div>
      <div class="pub-blood-search" style="text-align:left;">
        <h3>${esc(t('sendMessage'))}</h3>
        <form id="contactForm" class="form-card flat" style="box-shadow:none; padding:0; background:transparent;">
          <label class="field-row"><span>${esc(t('yourName'))} *</span>
            <input class="field" name="name" required /></label>
          <label class="field-row"><span>${esc(t('yourEmail'))}</span>
            <input class="field" name="email" type="email" /></label>
          <label class="field-row"><span>${esc(t('phone'))}</span>
            <input class="field" name="phone" type="tel" /></label>
          <label class="field-row"><span>${BN() ? 'বিষয়' : 'Subject'}</span>
            <input class="field" name="subject" /></label>
          <label class="field-row"><span>${esc(t('yourMessage'))} *</span>
            <textarea class="field" name="message" rows="4" required></textarea></label>
          <button class="btn primary lg" type="submit">${icon('mail')} ${esc(t('sendMessage'))}</button>
          <p class="muted" id="contactMsg" style="font-size:.72rem; margin-top:8px;"></p>
        </form>
      </div>
    </section>`);

  const form = root.querySelector('#contactForm');
  form.addEventListener('submit', async e => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(form).entries());
    const msg = root.querySelector('#contactMsg');
    msg.textContent = BN() ? 'পাঠানো হচ্ছে…' : 'Sending…';
    try {
      await backendApi.post('/public/contact', data);
      msg.textContent = esc(t('messageSent'));
      form.reset();
    } catch (err) {
      msg.textContent = err.message || 'Failed';
    }
  });
}

// ---------- FAQ ----------
export async function renderFaq(root) {
  pageHead(root,
    BN() ? 'সাধারণ প্রশ্ন' : 'FAQ',
    BN() ? 'রক্তদান, নিবন্ধন, অনুরোধ ও যাচাই নিয়ে সাধারণ প্রশ্নের উত্তর।' : 'Answers to common questions about donation, registration, requests and verification.',
    'info');
  const faqs = await fetchPublic('/public/faq', []);
  if (!faqs.length) {
    // Fallback: curated static content (safe, accurate, bilingual)
    root.insertAdjacentHTML('beforeend', `<section class="faq-list">${staticFaqs().join('')}</section>`);
    bindAccordions(root);
    return;
  }
  root.insertAdjacentHTML('beforeend', `
    <section class="faq-list">
      ${faqs.map(f => `
        <div class="faq-item">
          <button class="faq-question">${esc(BN() ? (f.question_bn || f.question_en) : f.question_en)} ${icon('chevron-down')}</button>
          <div class="faq-answer"><p>${esc(BN() ? (f.answer_bn || f.answer_en) : f.answer_en)}</p></div>
        </div>`).join('')}
    </section>`);
  bindAccordions(root);
}

function staticFaqs() {
  const bn = BN();
  const list = bn ? [
    { q: 'Blood Hero কী?', a: 'Blood Hero বাংলাদেশের বিশ্বস্ত রক্তদান প্ল্যাটফর্ম — যেখানে রক্তদাতা ও রক্তগ্রহীতার মধ্যে দ্রুত সংযোগ স্থাপন করা হয়।' },
    { q: 'কীভাবে রক্ত দেব?', a: 'ডোনার হিসেবে নিবন্ধন করুন, রক্তের গ্রুপ ও অবস্থান দিন। কেউ রক্ত চাইলে জানানো হবে।' },
    { q: 'জরুরি রক্তের অনুরোধ কীভাবে করব?', a: 'রক্তের অনুরোধ তৈরি করুন — রক্তের গ্রুপ, হাসপাতাল ও জরুরিতা উল্লেখ করুন। কাছের ডোনারদের জানানো হবে।' },
    { q: 'কারা রক্ত দিতে পারেন?', a: 'সাধারণত ১৮-৬৫ বছর বয়সী সুস্থ প্রাপ্তবয়স্ক (ওজন ≥৫০ কেজি)। পুরুষ ৩ মাসে একবার, নারী ৪ মাসে একবার।' },
  ] : [
    { q: 'What is Blood Hero?', a: 'Blood Hero is Bangladesh\'s trusted blood donation platform connecting donors with patients who need blood — fast and reliable.' },
    { q: 'How can I donate blood?', a: 'Register as a donor, set your blood group and location. You\'ll be notified when someone near you needs your group.' },
    { q: 'How do I request blood in an emergency?', a: 'Create a blood request specifying the blood group, hospital and urgency. Nearby compatible donors are notified immediately.' },
    { q: 'Who can donate blood?', a: 'Generally healthy adults aged 18-65 weighing at least 50 kg. Men every 3 months, women every 4 months.' },
  ];
  return list.map(f => `
    <div class="faq-item">
      <button class="faq-question">${esc(f.q)} ${icon('chevron-down')}</button>
      <div class="faq-answer"><p>${esc(f.a)}</p></div>
    </div>`);
}

function statusLabel(s) {
  const map = {
    upcoming: BN() ? 'আসন্ন' : 'Upcoming',
    ongoing: BN() ? 'চলমান' : 'Ongoing',
    active: BN() ? 'চলমান' : 'Active',
    completed: BN() ? 'সম্পন্ন' : 'Completed',
    cancelled: BN() ? 'বাতিল' : 'Cancelled',
    published: BN() ? 'প্রকাশিত' : 'Published',
    draft: BN() ? 'খসড়া' : 'Draft',
  };
  return map[s] || s;
}