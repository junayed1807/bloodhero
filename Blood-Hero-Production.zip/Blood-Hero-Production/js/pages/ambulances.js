// Ambulance Directory — emergency ambulance listings with verification
import { t, lang } from '../i18n.js';
import { esc, icon, safeTel, toast } from '../ui.js';
import { backendApi, isBackendAvailable } from '../../shared/js/backend-api.js';

export async function renderAmbulances(root) {
  root.innerHTML = `
    <section class="section narrow">
      <div class="page-head"><h2>${lang() === 'bn' ? 'অ্যাম্বুলেন্স ডিরেক্টরি' : 'Ambulance Directory'}</h2>
        <p class="muted">${lang() === 'bn' ? 'জরুরি অ্যাম্বুলেন্স — নিকটস্থ সেবা' : 'Emergency ambulances — nearby verified services'}</p></div>
      <div class="chip-row" id="ambFilter" style="margin-bottom:12px">
        <button class="chip active" data-f="all">${esc(t('all'))}</button>
        <button class="chip" data-f="available">${lang() === 'bn' ? 'উপলব্ধ' : 'Available'}</button>
        <button class="chip" data-f="verified">${lang() === 'bn' ? 'যাচাইকৃত' : 'Verified'}</button>
      </div>
      <div class="card-list" id="ambList"></div>
    </section>`;

  const paint = async (filter = 'all') => {
    let list = [];
    try {
      list = await backendApi.get('/ambulances');
    } catch {
      root.querySelector('#ambList').innerHTML = `<div class="empty">${icon('alert')} ${lang() === 'bn' ? 'ব্যাকএন্ড সংযোগ নেই' : 'Backend not connected'}</div>`;
      return;
    }

    if (filter === 'available') list = list.filter(a => a.availability_status === 'available');
    else if (filter === 'verified') list = list.filter(a => a.is_verified);

    const container = root.querySelector('#ambList');
    container.innerHTML = list.length === 0
      ? `<div class="empty">${icon('info')} ${lang() === 'bn' ? 'অ্যাম্বুলেন্স পাওয়া যায়নি।' : 'No ambulances found.'}</div>`
      : list.map(a => `
        <article class="ambulance-card ${a.is_verified ? 'verified' : ''}">
          <div class="ambulance-top">
            <div>
              <h4>${esc(a.name)}</h4>
              <p class="muted">${esc(a.provider || '—')}</p>
            </div>
            <span class="badge ${a.availability_status === 'available' ? 'green' : 'amber'}">${esc(a.availability_status || '—')}</span>
          </div>
          <div class="mini-row"><span>${icon('location')} ${esc([a.upazila, a.district].filter(Boolean).join(', ') || 'Bangladesh')}</span></div>
          <div class="mini-row"><span>${icon('phone')} <a href="tel:${safeTel(a.phone)}" class="link" dir="ltr">${esc(a.phone)}</a></span></div>
          ${a.is_verified ? `<span class="badge green">✓ ${lang() === 'bn' ? 'যাচাইকৃত' : 'Verified'}</span>` : ''}
          <div class="req-actions" style="margin-top:10px;">
            <a class="btn primary sm" href="tel:${safeTel(a.phone)}">${icon('phone')} ${esc(t('call'))}</a>
          </div>
        </article>
      `).join('');
  };

  root.querySelector('#ambFilter').addEventListener('click', e => {
    const b = e.target.closest('.chip'); if (!b) return;
    root.querySelectorAll('#ambFilter .chip').forEach(c => c.classList.toggle('active', c === b));
    paint(b.dataset.f);
  });

  await paint('all');
}
