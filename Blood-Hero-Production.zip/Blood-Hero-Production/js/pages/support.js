// Support (FAQ + contact) & About (brand + developer + Facebook) pages
import { t, lang } from '../i18n.js';
import { APP } from '../config.js';
import { esc, icon, toast } from '../ui.js';
import { Logo } from '../components/Logo.js';

const FAQS = {
  en: [
    ['Who can donate blood?', 'Healthy adults aged 18–65, weighing 50kg+, with hemoglobin in normal range.'],
    ['How often can I donate?', 'Whole blood: every 90 days. Plasma: every 28 days. Platelets: every 14 days.'],
    ['I traveled abroad recently — can I donate?', 'Some regions require a 28-day deferral. Use the screening flow before booking.'],
    ['Is my data safe?', 'Yes. Data is stored securely; contact details are visible only to matched request seekers.'],
  ],
  bn: [
    ['কে রক্ত দিতে পারবেন?', '১৮–৬৫ বছরের সুস্থ প্রাপ্তবয়স্ক, ওজন ৫০ কেজি+, হিমোগ্লোবিন স্বাভাবিক হলে।'],
    ['কত দিন পর পর রক্ত দেওয়া যায়?', 'সম্পূর্ণ রক্ত: প্রতি ৯০ দিন। প্লাজমা: ২৮ দিন। প্লাটিলেট: ১৪ দিন।'],
    ['সম্প্রতি বিদেশ ভ্রমণ করেছি — দিতে পারবো?', 'কিছু অঞ্চলে ২৮ দিন অপেক্ষা করতে হয়। বুকিং-এর আগে স্ক্রিনিং করুন।'],
    ['আমার তথ্য কি নিরাপদ?', 'হ্যাঁ। তথ্য নিরাপদে সংরক্ষিত; যোগাযোগ নম্বর শুধু মিলে যাওয়া অনুরোধকারী দেখতে পায়।'],
  ],
};

export async function renderSupport(root) {
  root.innerHTML = `
    <section class="section narrow">
      <div class="page-head"><h2>${esc(t('helpCenter'))}</h2>
        <p class="muted">${lang() === 'bn' ? 'কীভাবে সাহায্য করতে পারি?' : 'How can we help?'}</p></div>
      <div class="faq-list">
        ${(FAQS[lang()] || FAQS.en).map(([q, a]) => `
          <details class="faq"><summary>${esc(q)}</summary><p>${esc(a)}</p></details>`).join('')}
      </div>
      <form id="contactForm" class="form-card">
        <h3 class="modal-title">${esc(t('contactUs'))}</h3>
        <label class="field-row"><span>${esc(t('yourName'))}</span><input class="field" name="name" required maxlength="60" /></label>
        <label class="field-row"><span>${esc(t('yourEmail'))}</span><input class="field" type="email" name="email" required maxlength="80" /></label>
        <label class="field-row"><span>${esc(t('yourMessage'))}</span><textarea class="field" name="msg" rows="3" required maxlength="500"></textarea></label>
        <button class="btn primary">${icon('share')} ${esc(t('sendMessage'))}</button>
      </form>
      <div class="contact-cards">
        <a class="contact-card" href="mailto:${APP.creatorEmail}">${icon('support')}<span>Email</span></a>
        <a class="contact-card" href="${APP.facebookUrl}" target="_blank" rel="noopener noreferrer">${icon('fb')}<span>Facebook</span></a>
      </div>
    </section>`;
  root.querySelector('#contactForm').addEventListener('submit', e => {
    e.preventDefault();
    toast(t('messageSent'), 'success');
    e.target.reset();
  });
}

export async function renderAbout(root) {
  root.innerHTML = `
    <section class="section narrow about-page">
      <div class="about-logo">${Logo({ size: 'lg', alt: APP.name })}</div>
      <h1>${esc(APP.name)} <span class="bn">· ${esc(APP.nameBn)}</span></h1>
      <p class="tagline">${esc(APP.tagline)} — ${esc(APP.taglineBn)}</p>
      <p class="about-text">${esc(t('aboutText'))}</p>

      <div class="dev-card">
        <p class="dev-label">${esc(t('developedBy'))}</p>
        <h2 class="dev-name">${esc(APP.creatorFull)}</h2>
        <a class="btn fb" href="${APP.facebookUrl}" target="_blank" rel="noopener noreferrer">
          ${icon('fb')} ${esc(t('followFb'))}
        </a>
        <a class="mail-link" href="mailto:${APP.creatorEmail}">${esc(APP.creatorEmail)}</a>
      </div>

      <div class="about-meta">
        <span>${esc(t('version'))} ${APP.version}</span>
        <span>© 2026 ${esc(APP.name)} · ${esc(t('rights'))}</span>
      </div>
    </section>`;
}
