// Donor Profile — public donor view with PII masking, verification badges,
// reliability score and eligibility. Phone is masked unless the viewer owns it
// or is privileged.
import { t, lang } from '../i18n.js';
import { Donors, daysUntilEligible, Donations, publicProfile, maskPhone } from '../db.js';
import { currentUser, isAdmin } from '../auth.js';
import { esc, icon, bloodBadge } from '../ui.js';
import { getProfilePicture } from '../../shared/js/storage.js';

function reliabilityFor(d, verifiedCount) {
  return Math.min(100, Math.round(40 + (d.totalDonations || 0) * 5 + verifiedCount * 10));
}

export async function renderDonorDetail(root, id) {
  const list = await Donors.list();
  const d = list.find(x => x.id === id);
  if (!d) { root.innerHTML = `<div class="empty section">${icon('alert')} ${esc(t('noResults'))}</div>`; return; }
  const u = currentUser() || {};
  const verifiedCount = (await Donations.forDonor(d.id)).filter(x => x.status === 'verified').length;
  const reliability = reliabilityFor(d, verifiedCount);
  const isOwner = u.uid === d.id || (u.phone && u.phone === d.phone);
  const canSee = isOwner || isAdmin();
  const days = daysUntilEligible(d.lastDonation, d.gender);
  const badges = [];
  if (d.nidStatus === 'approved' || verifiedCount > 0) badges.push(t('verifiedDonor'));
  if (reliability >= 80) badges.push(t('reliableDonor'));
  const profilePic = getProfilePicture(d.id);

  const pub = publicProfile(d, u);
  root.innerHTML = `
    <section class="section narrow">
      <a href="#/donors" class="back-link">${icon('back')} ${esc(t('back'))}</a>
      <div class="donor-hero">
        <div class="donor-avatar">
          ${profilePic ? `<img src="${profilePic}" alt="${esc(pub.name)}" style="width:100%; height:100%; object-fit:cover; border-radius:50%;" />` : icon('user')}
        </div>
        <div class="donor-hero-mid">
          <h2>${esc(pub.name)}</h2>
          <p class="loc">${icon('location')} ${esc([pub.available ? pub.upazila : '', pub.district].filter(Boolean).join(', ') || 'Bangladesh')}</p>
          <div class="badge-row">
            ${badges.map(b => `<span class="badge green">✅ ${esc(b)}</span>`).join('') || `<span class="badge gray">${esc(t('donor'))}</span>`}
          </div>
        </div>
        <div class="donor-hero-blood">${bloodBadge(pub.bloodGroup)}</div>
      </div>

      <div class="stat-grid">
        <div class="stat">${icon('drop')}<strong>${verifiedCount}</strong><span>${esc(t('totalDonations'))}</span></div>
        <div class="stat">${icon('heart')}<strong>${d.livesSaved || 0}</strong><span>${esc(t('livesSaved'))}</span></div>
        <div class="stat">${icon('clock')}<strong>${days === 0 ? (lang() === 'bn' ? 'যোগ্য' : 'Ready') : days + 'd'}</strong><span>${esc(t('nextEligible'))}</span></div>
      </div>

      <div class="detail-card">
        <div class="reliability-head">
          <span class="rel-ring" style="--r:${reliability}"><b>${reliability}%</b></span>
          <div><h4>${esc(t('reliabilityScore'))}</h4><p class="muted">${esc(t('reliabilityNote'))}</p></div>
        </div>
        <div class="kv"><span>${esc(t('lastDonated'))}</span><strong>${d.lastDonation ? esc(new Date(d.lastDonation).toLocaleDateString(lang() === 'bn' ? 'bn-BD' : 'en-GB')) : '—'}</strong></div>
        <div class="kv"><span>${esc(t('memberSince'))}</span><strong>${esc(new Date(d.createdAt || Date.now()).toLocaleDateString(lang() === 'bn' ? 'bn-BD' : 'en-GB'))}</strong></div>
        <div class="kv"><span>${esc(t('donorId'))}</span><strong dir="ltr">BH-${esc(String(d.id).slice(-6).toUpperCase())}</strong></div>
        <div class="kv"><span>${esc(t('contact'))}</span><strong dir="ltr">${esc(canSee ? (pub.phone || maskPhone(d.phone)) : (d.showPhone === false ? (lang() === 'bn' ? 'যোগাযোগ লুকানো' : 'Contact hidden') : maskPhone(d.phone)))}</strong></div>
        ${!canSee ? `<p class="mask-note">${icon('shield')} ${esc(t('maskNote'))}</p>` : ''}
        ${canSee && d.phone ? `<a class="btn primary lg" href="tel:${pub.phone.replace(/[^0-9+]/g, '')}">${icon('phone')} ${esc(t('callNow'))}</a>` : ''}
      </div>
      <p class="muted" style="text-align:center; margin-top:10px; font-size:.7rem;">${esc(t('finalDisclaimerBn'))}</p>
    </section>`;
}