// Rewards / Volunteer / Health / Notifications / Emergency — consolidated section pages
import { t, lang } from '../i18n.js';
import { Requests, Notifications, daysUntilEligible } from '../db.js';
import { currentUser } from '../auth.js';
import { esc, icon, bloodBadge, timeAgo, toast } from '../ui.js';

// ---------- Emergency alerts ----------
export async function renderEmergency(root) {
  const list = (await Requests.list()).filter(r => r.emergency && r.status === 'pending');
  const [critical, ...rest] = list;
  root.innerHTML = `
    <section class="section">
      <div class="page-head alert-head">
        <h2>${icon('alert')} ${esc(t('alerts'))}</h2>
        <p class="muted">${lang() === 'bn' ? 'জরুরী প্রয়োজন — কাছাকাছি ডোনারদের কাছে পৌঁছে যাচ্ছে' : 'Critical needs — reaching nearby donors now'}</p>
      </div>
      <a class="btn ghost" href="#/directory" style="margin-bottom:16px">${icon('phone')} ${esc(t('emergencyDirectory'))}</a>
      ${critical ? `
        <article class="critical-card">
          <span class="critical-badge pulsing">${esc(t('emergencyRequest'))}</span>
          <div class="critical-group">${esc(critical.bloodGroup)}</div>
          <h3>${esc(critical.hospital)}</h3>
          <p>${icon('location')} ${esc([critical.upazila, critical.district].filter(Boolean).join(', '))} · ${timeAgo(critical.createdAt, lang() === 'bn')}</p>
          <div class="req-actions big">
            <a class="btn light lg" href="tel:${esc(String(critical.contact).replace(/[^0-9+]/g, ''))}">${icon('phone')} ${esc(t('respond'))}</a>
            <a class="btn ghost-light lg" href="#/request/${encodeURIComponent(critical.id)}">${esc(t('details'))}</a>
          </div>
        </article>` : `<div class="empty">${icon('check')} ${lang() === 'bn' ? 'এই মুহূর্তে কোনো জরুরী প্রয়োজন নেই' : 'No critical needs right now'}</div>`}
      ${rest.map(r => `
        <article class="req-card emg small">
          <div class="req-main">${bloodBadge(r.bloodGroup)}
            <div class="req-info"><h4>${esc(r.hospital)}</h4><p>${r.units} ${esc(t('units'))} · ${esc(r.district || '')}</p></div>
            <a class="btn primary sm" href="tel:${esc(String(r.contact).replace(/[^0-9+]/g, ''))}">${icon('phone')}</a>
          </div>
        </article>`).join('')}
    </section>`;
}

// ---------- Rewards ----------
const REWARDS = [
  { name: 'Smart Band', pts: 2500, icon: 'activity', cat: 'Wellness' },
  { name: lang() === 'bn' ? 'হেলথ চেক-আপ' : 'Health Check-up', pts: 1200, icon: 'health', cat: 'Wellness' },
  { name: lang() === 'bn' ? 'ব্র্যান্ডেড টি-শার্ট' : 'Hero T-Shirt', pts: 600, icon: 'gift', cat: 'Merch' },
  { name: lang() === 'bn' ? 'কফি ভাউচার' : 'Coffee Voucher', pts: 200, icon: 'gift', cat: 'Merch' },
];
export async function renderRewards(root) {
  const u = currentUser() || {};
  const pts = (u.totalDonations || 0) * 100 + (u.livesSaved || 0) * 25;
  root.innerHTML = `
    <section class="section">
      <div class="points-hero">
        <p>${esc(t('rewards'))}</p>
        <h2>${pts} <small>pts</small></h2>
        <div class="tier-bar"><span style="width:${Math.min(100, (pts / 3000) * 100)}%"></span></div>
        <small>${lang() === 'bn' ? 'পরবর্তী টিয়ার পর্যন্ত' : 'to next tier'}</small>
      </div>
      <div class="reward-grid">
        ${REWARDS.map(r => `
          <div class="reward-card">
            <div class="reward-ic">${icon(r.icon)}</div>
            <h4>${esc(r.name)}</h4>
            <p class="cat">${esc(r.cat)}</p>
            <button class="btn ${pts >= r.pts ? 'primary' : 'ghost'} sm redeem" data-pts="${r.pts}" data-name="${esc(r.name)}" ${pts >= r.pts ? '' : 'disabled'}>
              ${icon('gift')} ${r.pts} pts</button>
          </div>`).join('')}
      </div>
    </section>`;
  root.querySelectorAll('.redeem').forEach(b => b.addEventListener('click', () => {
    toast((lang() === 'bn' ? 'রিডিম সফল! ' : 'Redeemed! ') + b.dataset.name, 'success');
  }));
}

// ---------- Volunteer ----------
export async function renderVolunteer(root) {
  root.innerHTML = `
    <section class="section">
      <div class="points-hero vol">
        <p>${esc(t('volunteer'))}</p>
        <h2>${lang() === 'bn' ? '৩৪ ঘণ্টা' : '34 hrs'}</h2>
        <small>Silver Tier · 100 Hour Club ${lang() === 'bn' ? 'এ যোগ দিন' : 'next'}</small>
      </div>
      <div class="section-head"><h3>${lang() === 'bn' ? 'চলমান দায়িত্ব' : 'Active Shifts'}</h3></div>
      ${[
        { role: lang() === 'bn' ? 'ব্লাড ড্রাইভ সাপোর্ট' : 'Blood Drive Support', place: 'Dhaka Blood Center', when: lang() === 'bn' ? 'প্রতি মঙ্গলবার' : 'Weekly · Tue', ic: 'volunteer' },
        { role: lang() === 'bn' ? 'মোবাইল ইউনিট সহকারী' : 'Mobile Unit Assistant', place: 'Rangpur Division', when: lang() === 'bn' ? 'পাক্ষিক · শনি' : 'Bi-weekly · Sat', ic: 'location' },
      ].map(s => `
        <article class="shift-card">${icon(s.ic)}<div><h4>${esc(s.role)}</h4><p>${esc(s.place)} · ${esc(s.when)}</p></div><span class="badge green">Active</span></article>`).join('')}
      <form id="logHours" class="form-card">
        <h3 class="modal-title">${lang() === 'bn' ? 'ঘণ্টা লগ করুন' : 'Log Volunteer Hours'}</h3>
        <div class="grid-2">
          <label class="field-row"><span>${esc(t('selectDate') || 'Date')}</span><input class="field" type="date" name="date" required /></label>
          <label class="field-row"><span>${lang() === 'bn' ? 'ঘণ্টা' : 'Hours'}</span><input class="field" type="number" name="hours" min="1" max="12" value="2" required /></label>
        </div>
        <button class="btn primary">${icon('plus')} ${esc(t('submit'))}</button>
      </form>
    </section>`;
  root.querySelector('#logHours').addEventListener('submit', e => {
    e.preventDefault();
    toast(lang() === 'bn' ? 'ঘণ্টা জমা হয়েছে — যাচাইয়ের জন্য পাঠানো হয়েছে' : 'Hours submitted for verification', 'success');
    e.target.reset();
  });
}

// ---------- Health tips ----------
export async function renderHealth(root) {
  const tips = lang() === 'bn' ? [
    ['দানের আগে ২৪ ঘণ্টা যথেষ্ট পানি পান করুন (+৫০০ মি.লি.)।', 'drop'],
    ['আয়রনসমৃদ্ধ খাবার খান — পালং শাক, খেজুর, লাল মাংস।', 'health'],
    ['৭–৯ ঘণ্টা ঘুম নিশ্চিত করুন আগের রাতে।', 'clock'],
    ['দানের পর ১৫ মিনিট বিশ্রাম নিন ও জুস খান।', 'heart'],
    ['২৪ ঘণ্টা ভারী ব্যায়াম এড়িয়ে চলুন।', 'activity'],
  ] : [
    ['Hydrate well 24h before donation (+500ml water).', 'drop'],
    ['Eat iron-rich food — spinach, dates, red meat.', 'health'],
    ['Sleep 7–9 hours the night before.', 'clock'],
    ['Rest 15 minutes after donation and take juice.', 'heart'],
    ['Avoid heavy exercise for 24 hours.', 'activity'],
  ];
  root.innerHTML = `
    <section class="section narrow">
      <div class="page-head"><h2>${esc(t('health'))}</h2></div>
      ${tips.map(([txt, ic], i) => `
        <article class="tip-row ${i === 0 ? 'featured' : ''}">${icon(ic)}<p>${esc(txt)}</p></article>`).join('')}
    </section>`;
}

// ---------- Notifications ----------
export async function renderNotifications(root) {
  const list = await Notifications.list();
  root.innerHTML = `
    <section class="section narrow">
      <div class="page-head row">
        <h2>${esc(t('notifications'))} <span class="badge red" id="unreadN">${list.filter(n => !n.read).length}</span></h2>
        <button class="link" id="markAll">${esc(t('markAllRead'))}</button>
      </div>
      <div class="card-list">
        ${list.length === 0 ? `<div class="empty">${icon('bell')} ${esc(t('noNotif'))}</div>` :
          list.map(n => `
            <div class="notif-row ${n.read ? '' : 'unread'}">
              <span class="n-ic ${n.type}">${icon(n.type === 'emergency' ? 'emergency' : n.type === 'accepted' ? 'check' : 'bell')}</span>
              <div><p>${esc(t(n.textKey) || n.body || '')}</p>${n.body ? `<small>${esc(n.body)}</small>` : ''}<small>${timeAgo(n.createdAt, lang() === 'bn')}</small></div>
            </div>`).join('')}
      </div>
    </section>`;
  root.querySelector('#markAll').addEventListener('click', async () => {
    await Notifications.markAllRead();
    toast('✓', 'success');
    renderNotifications(root);
  });
}
