// Eligibility screening — bilingual questionnaire step
import { t, lang } from '../i18n.js';
import { esc, icon, toast } from '../ui.js';
import { isEligible, daysUntilEligible, MIN_AGE, MAX_AGE, MIN_WEIGHT_KG } from '../lib/eligibility.js';
import { HealthDeclarations } from '../db.js';
import { currentUser } from '../auth.js';

const QS = {
  en: [
    ['Are you aged between 18 and 65?', 'Donors must be within the eligible age range.'],
    ['Do you weigh at least 50kg?', 'Minimum weight ensures safe donation.'],
    ['Have you traveled outside the country in the last 28 days?', 'Some regions carry higher risk of blood-borne infections.'],
    ['Have you had a fever, infection, or antibiotics this week?', 'Active infections defer donation.'],
    ['Have you had a tattoo, piercing, or surgery in the last 4 months?', 'Recent procedures may require deferral.'],
    ['Have you donated blood in the last 90 days?', 'Wait at least 90 days between whole blood donations.'],
    ['Do you have any chronic condition (diabetes, heart disease, high BP)?', 'Some conditions require medical clearance.'],
    ['Are you pregnant or breastfeeding?', 'Pregnancy and breastfeeding temporarily defer donation.'],
    ['Have you been vaccinated in the last 14 days?', 'Live vaccines may require a waiting period.'],
  ],
  bn: [
    ['আপনার বয়স কি ১৮ থেকে ৬৫ এর মধ্যে?', 'দাতাকে যোগ্য বয়সসীমার মধ্যে থাকতে হবে।'],
    ['আপনার ওজন কি অন্তত ৫০ কেজি?', 'ন্যূনতম ওজন নিরাপদ দান নিশ্চিত করে।'],
    ['আপনি কি গত ২৮ দিনে দেশের বাইরে ভ্রমণ করেছেন?', 'কিছু অঞ্চল রক্তবাহিত সংক্রমণের উচ্চ ঝুঁকি বহন করে।'],
    ['এই সপ্তাহে জ্বর, সংক্রমণ বা অ্যান্টিবায়োটিক হয়েছে?', 'সক্রিয় সংক্রমণে রক্তদান স্থগিত হয়।'],
    ['গত ৪ মাসে ট্যাটু, পিয়ার্সিং বা অস্ত্রোপচার হয়েছে?', 'সাম্প্রতিক প্রক্রিয়া স্থগিতাদেশের কারণ হতে পারে।'],
    ['গত ৯০ দিনে রক্তদান করেছেন?', 'সম্পূর্ণ রক্তদানের মধ্যে অন্তত ৯০ দিনের ব্যবধান লাগে।'],
    ['কোনো ক্রনিক রোগ (ডায়াবেটিস, হার্ট ডিজিজ, উচ্চ BP)?', 'কিছু অবস্থা মেডিকেল ক্লিয়ারেন্স প্রয়োজন।'],
    ['আপনি currently গর্ভবতী বা স্তনপান দান করছেন?', 'গর্ভাবস্থা ও স্তনপান সাময়িকভাবে দান স্থগিত করে।'],
    ['গত ১৪ দিনে টিকা লাগিয়েছেন?', 'লাইভ টিকার জন্য কিছু অপেক্ষার সময় লাগতে পারে।'],
  ],
};

function deferReason(i) {
  const bn = ['বয়স সীমার বাইরে','ওজন কম','ভ্রমণ ইতিহাস','সংক্রমণ/অ্যান্টিবায়োটিক','সাম্প্রতিক শল্যকর্ম','৯০ দিনের ক্যোভার নয়','দীর্ঘমেয়াদী রোগ','গর্ভावস্থা/স্তনপান','টিকার সময়সীমা'];
  const en = ['Age out of range','Below minimum weight','Recent travel','Infection/antibiotics','Recent procedure','90-day window not met','Chronic condition','Pregnancy/breastfeeding','Vaccine waiting period'];
  return lang() === 'bn' ? bn[i] : en[i];
}
function retryDate(i) {
  const now = Date.now();
  const days = [0,0,28,7,120,90,0,0,14];
  const d = new Date(now + (days[i] || 0) * 86400000);
  return d.toLocaleDateString(lang() === 'bn' ? 'bn-BD' : 'en-GB');
}

export async function renderScreening(root) {
  const qs = QS[lang()] || QS.en;
  let i = 0, score = 0;
  const paint = () => {
    const [q, note] = qs[i];
    root.innerHTML = `
      <section class="section narrow screening">
        <div class="page-head row"><h2>${esc(t('screeningTitle'))}</h2><span class="badge red">${esc(t('question'))} ${i + 1} ${esc(t('of'))} ${qs.length}</span></div>
        <div class="progress"><span style="width:${Math.round((i / qs.length) * 100)}%"></span></div>
        <div class="q-card">
          <div class="q-ic">${icon('health')}</div>
          <h3>${esc(q)}</h3>
          <p>${esc(note)}</p>
          <div class="q-actions">
            <button class="btn success lg" id="qYes">${icon('check')} ${esc(t('yes'))}</button>
            <button class="btn ghost lg" id="qNo">${icon('close')} ${esc(t('no'))}</button>
          </div>
        </div>
        <p class="conf">${icon('shield')} ${esc(t('confidentiality'))}</p>
      </section>`;
    const answer = (v) => {
      if ((i < 2 && v) || (i >= 2 && !v)) score++;
      i++;
      if (i < qs.length) paint();
      else {
        const ok = score >= 4;
        const defer = !ok;
        const u = currentUser();
        if (u && !u.guest) {
          HealthDeclarations.add({ userId: u.uid, score, eligible: ok, reason: defer ? deferReason(i-1) : null, retryDate: defer ? retryDate(i-1) : null }).catch(() => {});
        }
        root.innerHTML = `
          <section class="section narrow screening result">
            <div class="q-card">
              <div class="q-ic ${ok ? 'ok' : 'warn'}">${icon(ok ? 'check' : 'alert')}</div>
              <h3>${ok ? (lang() === 'bn' ? 'আপনি সম্ভবত যোগ্য!' : 'You are likely eligible!') : (lang() === 'bn' ? 'এখনই দান করা যাবে না' : 'Not eligible right now')}</h3>
              <p>${ok ? (lang() === 'bn' ? 'সুস্থ থাকুন — নিকটস্থ সেন্টারে অ্যাপয়েন্টমেন্ট নিন।' : 'Stay healthy — book an appointment at a nearby center.') : (lang() === 'bn' ? `কিছুদিন পর আবার চেষ্টা করুন। কারণ: ${deferReason(i-1)}` : `Try again later. Reason: ${deferReason(i-1)}`)}</p>
              ${defer ? `<p class="muted">${lang() === 'bn' ? 'পুনরায় যাচাই: ' : 'Retry after: '} ${retryDate(i-1)}</p>` : ''}
              <p class="conf">${icon('shield')} ${esc(t('confidentiality'))}</p>
              <p class="muted" style="font-size:.7rem; margin-top:8px; text-align:center;">${esc(t('finalDisclaimerBn'))}</p>
              <a class="btn primary lg" href="#/">${icon('home')} ${esc(t('home'))}</a>
            </div>
          </section>`;
        if (ok) toast(lang() === 'bn' ? 'যোগ্যতা যাচাই সম্পন্ন' : 'Screening complete', 'success');
      }
    };
    root.querySelector('#qYes').addEventListener('click', () => answer(true));
    root.querySelector('#qNo').addEventListener('click', () => answer(false));
  };
  paint();
}