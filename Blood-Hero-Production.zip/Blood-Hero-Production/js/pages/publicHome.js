// Blood Hero — Public Homepage (visible without login)
// Hero section, impact stats, how-it-works, blood group search, urgent requests, awareness, CTA
import { t, lang } from '../i18n.js';
import { esc, icon, bloodBadge, timeAgo } from '../ui.js';
import { Logo } from '../components/Logo.js';
import { BLOOD_GROUPS } from '../config.js';
import { backendApi } from '../../shared/js/backend-api.js';

const BN = () => lang() === 'bn';

// Attempt to load public stats from backend, fallback to placeholder
async function loadPublicStats() {
  try {
    const data = await backendApi.get('/public/stats');
    return data;
  } catch {
    return { donors: 0, requests: 0, fulfilled: 0, lives: 0 };
  }
}

export async function renderPublicHome(root) {
  const bn = BN();
  const stats = await loadPublicStats();

  root.innerHTML = `
    <!-- Hero Section -->
    <section class="pub-hero">
      <div class="pub-hero-content">
        <span class="pub-hero-badge">${bn ? '🩸 বাংলাদেশের রক্তদান প্ল্যাটফর্ম' : '🩸 BANGLADESH\'S BLOOD DONATION PLATFORM'}</span>
        <h1>${bn ? 'প্রতিটি <span class="accent">ফোঁটা</span> বাঁচায় একটি জীবন' : 'Every <span class="accent">Drop</span> Saves a Life'}</h1>
        <p class="pub-hero-sub">${bn
          ? 'Blood Hero বাংলাদেশের বিশ্বস্ত রক্তদান প্ল্যাটফর্ম — যেখানে রক্তদাতা ও রক্তগ্রহীতার মধ্যে দ্রুত সংযোগ স্থাপন করা হয়। দ্রুত, নির্ভরযোগ্য এবং স্থানীয়ভাবে পরিচালিত।'
          : 'Blood Hero connects blood donors with people who need blood across Bangladesh — fast, trusted, and localized. Register as a donor or request blood in minutes.'}</p>
        <div class="pub-hero-actions">
          <a href="#/find-blood" class="btn primary">${icon('search')} ${bn ? 'রক্তদাতা খুঁজুন' : 'Find Blood Donor'}</a>
          <a href="#/register" class="btn ghost-light">${icon('plus')} ${bn ? 'ডোনার হিসেবে যোগ দিন' : 'Become a Donor'}</a>
        </div>
      </div>
    </section>

    <!-- Impact Stats -->
    <section class="pub-stats">
      <div class="pub-stat-card">
        <div class="pub-stat-icon red">${icon('users')}</div>
        <div class="pub-stat-value" data-count="${stats.donors || 0}">${animNum(stats.donors || 0)}</div>
        <div class="pub-stat-label">${bn ? 'নিবন্ধিত ডোনার' : 'Registered Donors'}</div>
      </div>
      <div class="pub-stat-card">
        <div class="pub-stat-icon green">${icon('check')}</div>
        <div class="pub-stat-value" data-count="${stats.fulfilled || 0}">${animNum(stats.fulfilled || 0)}</div>
        <div class="pub-stat-label">${bn ? 'পূরণকৃত অনুরোধ' : 'Requests Fulfilled'}</div>
      </div>
      <div class="pub-stat-card">
        <div class="pub-stat-icon blue">${icon('heart')}</div>
        <div class="pub-stat-value" data-count="${stats.lives || 0}">${animNum(stats.lives || 0)}</div>
        <div class="pub-stat-label">${bn ? 'জীবন রক্ষিত' : 'Lives Saved'}</div>
      </div>
      <div class="pub-stat-card">
        <div class="pub-stat-icon amber">${icon('location')}</div>
        <div class="pub-stat-value">64</div>
        <div class="pub-stat-label">${bn ? 'জেলা কভারেজ' : 'Districts Covered'}</div>
      </div>
    </section>

    <!-- How It Works -->
    <section class="pub-how">
      <div class="pub-how-title">
        <h2>${bn ? 'কীভাবে কাজ করে' : 'How It Works'}</h2>
        <p class="muted">${bn ? 'তিনটি সহজ ধাপে রক্ত খুঁজুন বা দান করুন' : 'Find or donate blood in three simple steps'}</p>
      </div>
      <div class="pub-how-grid">
        <div class="pub-how-card">
          <span class="pub-how-step">1</span>
          <div class="pub-how-icon">${icon('user')}</div>
          <h3>${bn ? 'নিবন্ধন করুন' : 'Register'}</h3>
          <p>${bn ? 'আপনার রক্তের গ্রুপ, অবস্থান এবং তথ্য দিয়ে ফ্রিতে ডোনার হিসেবে নিবন্ধন করুন।' : 'Sign up as a donor with your blood group, location, and contact info — completely free.'}</p>
        </div>
        <div class="pub-how-card">
          <span class="pub-how-step">2</span>
          <div class="pub-how-icon">${icon('search')}</div>
          <h3>${bn ? 'খুঁজুন বা অনুরোধ করুন' : 'Search or Request'}</h3>
          <p>${bn ? 'রক্তের গ্রুপ ও অবস্থান দিয়ে ডোনার খুঁজুন, অথবা রক্তের অনুরোধ তৈরি করুন।' : 'Search for matching donors by blood group and location, or create a blood request with urgency level.'}</p>
        </div>
        <div class="pub-how-card">
          <span class="pub-how-step">3</span>
          <div class="pub-how-icon">${icon('heart')}</div>
          <h3>${bn ? 'জীবন বাঁচান' : 'Save Lives'}</h3>
          <p>${bn ? 'সরাসরি ডোনারের সাথে যোগাযোগ করুন এবং মিলিত রক্ত পান। প্রতিটি দান তিনটি জীবন বাঁচাতে পারে।' : 'Connect directly with matching donors. Every donation can save up to three lives. Be a hero.'}</p>
        </div>
      </div>
    </section>

    <!-- Blood Group Quick Search -->
    <section class="pub-blood-search">
      <h2>${bn ? '🩸 রক্তের গ্রুপ দিয়ে খুঁজুন' : '🩸 Search by Blood Group'}</h2>
      <p class="muted">${bn ? 'যেকোনো গ্রুপে ক্লিক করুন — নিকটতম ডোনার দেখুন' : 'Click any group to find the nearest available donors'}</p>
      <div class="pub-blood-grid">
        ${['A+','A-','B+','B-','O+','O-','AB+','AB-'].map(g => `
          <a href="#/find-blood?group=${encodeURIComponent(g)}" class="pub-blood-btn">${g}</a>
        `).join('')}
      </div>
    </section>

    <!-- Awareness Highlights -->
    <section class="pub-how" style="margin-bottom: 32px;">
      <div class="pub-section-head">
        <h2>${bn ? 'সচেতনতা' : 'Awareness'}</h2>
        <a href="#/awareness" class="link">${esc(t('viewAll'))} →</a>
      </div>
      <div class="pub-how-grid">
        <div class="pub-how-card" style="text-align:left;">
          <div class="pub-how-icon" style="background:var(--green-soft); color:var(--green); margin:0 0 12px;">${icon('heart')}</div>
          <h3>${bn ? 'রক্তদান সম্পূর্ণ নিরাপদ' : 'Blood donation is completely safe'}</h3>
          <p>${bn ? 'WHO নির্দেশনা অনুযায়ী ৩ মাস অন্তর রক্তদান নিরাপদ। শরীর ২৪-৪৮ ঘণ্টায় স্বাভাবিক হয়।' : 'WHO guidelines confirm donating every 3 months is safe. Your body replenishes within 24-48 hours.'}</p>
        </div>
        <div class="pub-how-card" style="text-align:left;">
          <div class="pub-how-icon" style="background:var(--blue-soft); color:var(--blue); margin:0 0 12px;">${icon('users')}</div>
          <h3>${bn ? 'থ্যালাসেমিয়া সচেতনতা' : 'Thalassemia awareness'}</h3>
          <p>${bn ? 'বাংলাদেশে ৬০-৭০ হাজার থ্যালাসেমিয়া রোগীর নিয়মিত রক্ত প্রয়োজন। আপনার দান তাদের বাঁচায়।' : 'Bangladesh has 60-70K thalassemia patients requiring regular transfusions. Your donation keeps them alive.'}</p>
        </div>
        <div class="pub-how-card" style="text-align:left;">
          <div class="pub-how-icon" style="background:var(--amber-soft); color:var(--amber); margin:0 0 12px;">${icon('info')}</div>
          <h3>${bn ? 'এক ইউনিট, তিনটি জীবন' : 'One unit, three lives'}</h3>
          <p>${bn ? 'আপনার এক ইউনিট রক্ত RBC, Plasma এবং Platelets-এ ভেঙে তিনজনকে বাঁচাতে পারে।' : 'One unit of blood can be separated into RBC, Plasma, and Platelets — saving up to three patients.'}</p>
        </div>
      </div>
    </section>

    <!-- CTA Banner -->
    <section class="pub-cta">
      <div class="pub-cta-content">
        <h2>${bn ? '🩸 আজই একজন ব্লাড হিরো হোন' : '🩸 Become a Blood Hero Today'}</h2>
        <p>${bn ? 'নিবন্ধন করুন, আপনার অবস্থান সেট করুন, এবং যখন কারো প্রয়োজন হবে তখন বিজ্ঞপ্তি পান।' : 'Register, set your location, and get notified when someone nearby needs your blood group. It\'s free.'}</p>
        <a href="#/register" class="btn light">${icon('user')} ${bn ? 'এখনই নিবন্ধন করুন' : 'Register Now'}</a>
      </div>
    </section>

    <!-- FAQ Preview -->
    <section class="pub-how" style="margin-bottom: 0;">
      <div class="pub-section-head">
        <h2>${bn ? 'প্রায়শ জিজ্ঞাসিত প্রশ্ন' : 'Frequently Asked Questions'}</h2>
        <a href="#/faq" class="link">${esc(t('viewAll'))} →</a>
      </div>
      <div class="faq-list">
        ${faqPreview(bn)}
      </div>
    </section>
  `;

  // FAQ accordion toggle
  root.querySelectorAll('.faq-question').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.closest('.faq-item');
      const wasOpen = item.classList.contains('open');
      root.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
      if (!wasOpen) item.classList.add('open');
    });
  });

  // Real-data previews: urgent requests, news, camps, stories/transparency
  const [urgent, articles, camps] = await Promise.all([
    fetchPreview('/public/requests/urgent', []),
    fetchPreview('/public/articles?limit=3', []),
    fetchPreview('/public/camps?limit=6', []),
  ]);
  const upcomingCamps = (camps || []).filter(c => c.status === 'ongoing' || c.status === 'upcoming').slice(0, 3);
  const searchSec = root.querySelector('.pub-blood-search');
  if (searchSec) {
    searchSec.insertAdjacentHTML('afterend',
      previewUrgent(urgent, bn) + previewNews(articles, bn) + previewCamps(upcomingCamps, bn) + previewStoriesTeaser(bn));
  }
}

async function fetchPreview(path, fallback) {
  try {
    const data = await backendApi.get(path);
    return Array.isArray(data) ? data : (data || fallback);
  } catch { return fallback; }
}

function previewUrgent(list, bn) {
  if (!list || !list.length) return '';
  return `
    <section class="pub-urgent">
      <div class="pub-section-head">
        <h2>${bn ? '🚨 জরুরি রক্তের প্রয়োজন' : '🚨 Urgent Blood Needed'}</h2>
        <a href="#/find-blood" class="link">${esc(t('viewAll'))} →</a>
      </div>
      <div class="pub-urgent-list">
        ${list.map(r => `
          <div class="campaign-card">
            <div class="campaign-card-header">
              <span class="blood-badge">${esc(r.bloodGroup)}</span>
              <span class="campaign-status active" style="float:right;">${bn ? 'জরুরি' : 'URGENT'}</span>
            </div>
            <div class="campaign-card-body">
              <h3 style="font-size:.92rem;">${esc(r.hospital || '')}</h3>
              <p class="muted" style="font-size:.78rem;">${icon('location')} ${esc(r.district || '')}${r.upazila ? ', ' + esc(r.upazila) : ''}${r.units ? ' · ' + esc(r.units) + ' ' + (bn ? 'ইউনিট' : 'units') : ''}</p>
              <a href="#/find-blood?group=${encodeURIComponent(r.bloodGroup)}" class="btn primary sm" style="margin-top:10px;">${icon('search')} ${bn ? 'ডোনার খুঁজুন' : 'Find Donor'}</a>
            </div>
          </div>`).join('')}
      </div>
    </section>`;
}

function previewNews(list, bn) {
  if (!list || !list.length) return '';
  return `
    <section class="pub-how">
      <div class="pub-section-head">
        <h2>${bn ? '📰 সর্বশেষ সংবাদ' : '📰 Latest News'}</h2>
        <a href="#/news" class="link">${esc(t('viewAll'))} →</a>
      </div>
      <div class="news-grid">
        ${list.map(a => `
          <a href="#/news/${encodeURIComponent(a.slug)}" class="news-card">
            ${a.image_url ? `<img class="news-card-img" src="${esc(a.image_url)}" alt="${esc(a.title_en || a.title_bn)}" loading="lazy"/>` : `<div class="news-card-img pub-img-ph">${icon('file')}</div>`}
            <div class="news-card-body">
              <h3>${esc(bn ? (a.title_bn || a.title_en) : (a.title_en || a.title_bn))}</h3>
              <p>${esc(bn ? (a.excerpt_bn || a.excerpt_en || '') : (a.excerpt_en || a.excerpt_bn || '')).slice(0, 110)}</p>
            </div>
          </a>`).join('')}
      </div>
    </section>`;
}

function previewCamps(list, bn) {
  if (!list || !list.length) return '';
  return `
    <section class="pub-how">
      <div class="pub-section-head">
        <h2>${bn ? '🩸 আসন্ন রক্তদান ক্যাম্প' : '🩸 Upcoming Blood Camps'}</h2>
        <a href="#/camps" class="link">${esc(t('viewAll'))} →</a>
      </div>
      <div class="campaign-grid">
        ${list.map(c => `
          <div class="campaign-card">
            ${c.banner_url ? `<img class="gallery-card-img" src="${esc(c.banner_url)}" alt="${esc(c.title)}" loading="lazy"/>` : `<div class="gallery-card-img pub-img-ph">${icon('calendar')}</div>`}
            <div class="campaign-card-body">
              <span class="campaign-status ${esc(c.status)}">${esc(c.status === 'ongoing' ? (bn ? 'চলমান' : 'Ongoing') : (bn ? 'আসন্ন' : 'Upcoming'))}</span>
              <h3 style="margin:8px 0 6px;">${esc(c.title)}</h3>
              <div class="news-card-meta" style="flex-wrap:wrap;">
                <span>${icon('calendar')} ${esc(c.date || '')}</span>
                ${c.district ? `<span>${icon('location')} ${esc(c.district)}${c.upazila ? ', ' + esc(c.upazila) : ''}</span>` : ''}
              </div>
              ${c.registration_open ? `<a href="#/register" class="btn primary sm" style="margin-top:10px;">${icon('plus')} ${bn ? 'অংশগ্রহণ করুন' : 'Participate'}</a>` : ''}
            </div>
          </div>`).join('')}
      </div>
    </section>`;
}

function previewStoriesTeaser(bn) {
  return `
    <section class="pub-blood-search">
      <div class="pub-section-head" style="margin-bottom:12px;">
        <h2>${bn ? '🏆 আমাদের সাফল্য ও স্বচ্ছতা' : '🏆 Our Impact & Transparency'}</h2>
        <a href="#/success-stories" class="link">${bn ? 'সাফল্যের গল্প' : 'Success Stories'} →</a>
      </div>
      <div class="pub-how-grid" style="margin-bottom:14px;">
        <div class="pub-how-card" style="text-align:left;">
          <div class="pub-how-icon" style="background:var(--green-soft); color:var(--green); margin:0 0 12px;">${icon('trophy')}</div>
          <h3>${bn ? 'সাফল্যের গল্প' : 'Success Stories'}</h3>
          <p>${bn ? 'জরুরি প্রয়োজনে রক্ত পেয়ে বেঁচে যাওয়া রোগীদের প্রকৃত গল্প।' : 'Real stories of patients who got blood when it mattered most.'}</p>
        </div>
        <div class="pub-how-card" style="text-align:left;">
          <div class="pub-how-icon" style="background:var(--blue-soft); color:var(--blue); margin:0 0 12px;">${icon('activity')}</div>
          <h3>${bn ? 'স্বচ্ছ পরিসংখ্যান' : 'Transparent Numbers'}</h3>
          <p>${bn ? 'ডোনার, অনুরোধ, দান ও ক্যাম্পের প্রকৃত সংখ্যা — সবসময় হালনাগাদ।' : 'Real, up-to-date counts of donors, requests, donations and camps.'}</p>
        </div>
        <div class="pub-how-card" style="text-align:left;">
          <div class="pub-how-icon" style="background:var(--amber-soft); color:var(--amber); margin:0 0 12px;">${icon('volunteer')}</div>
          <h3>${bn ? 'স্বেচ্ছাসেবী হোন' : 'Become a Volunteer'}</h3>
          <p>${bn ? 'ক্যাম্প, সমন্বয় ও সচেতনতায় আপনার ভূমিকা রাখুন।' : 'Contribute to camps, coordination and awareness.'}</p>
        </div>
      </div>
      <div style="display:flex; gap:12px; justify-content:center; flex-wrap:wrap;">
        <a href="#/transparency" class="btn ghost">${icon('activity')} ${bn ? 'স্বচ্ছতা দেখুন' : 'View Transparency'}</a>
        <a href="#/volunteers-page" class="btn primary">${icon('volunteer')} ${bn ? 'ভলান্টিয়ার হোন' : 'Become a Volunteer'}</a>
      </div>
    </section>`;
}

function animNum(n) {
  return n > 0 ? n.toLocaleString() : '—';
}

function faqPreview(bn) {
  const faqs = bn ? [
    { q: 'Blood Hero কী?', a: 'Blood Hero বাংলাদেশের বিশ্বস্ত রক্তদান প্ল্যাটফর্ম — যেখানে রক্তদাতা ও রক্তগ্রহীতার মধ্যে দ্রুত সংযোগ স্থাপন করা হয়।' },
    { q: 'কীভাবে রক্ত দেব?', a: 'Blood Hero-তে ডোনার হিসেবে নিবন্ধন করুন, আপনার রক্তের গ্রুপ ও অবস্থান সেট করুন। কেউ রক্ত চাইলে আপনাকে জানানো হবে।' },
    { q: 'জরুরি রক্তের অনুরোধ কীভাবে করব?', a: 'Blood Hero-তে একটি রক্তের অনুরোধ তৈরি করুন — রক্তের গ্রুপ, হাসপাতাল এবং জরুরিতার মাত্রা উল্লেখ করুন। কাছের সামঞ্জস্যপূর্ণ ডোনারদের জানানো হবে।' },
    { q: 'কারা রক্ত দিতে পারেন?', a: 'সাধারণত ১৮-৬৫ বছর বয়সী সুস্থ প্রাপ্তবয়স্করা, যাদের ওজন কমপক্ষে ৫০ কেজি। পুরুষ ৩ মাসে একবার, নারী ৪ মাসে একবার দিতে পারেন।' },
  ] : [
    { q: 'What is Blood Hero?', a: 'Blood Hero is Bangladesh\'s trusted blood donation platform connecting donors with patients who need blood — fast, reliable, and locally managed.' },
    { q: 'How can I donate blood?', a: 'Register as a donor on Blood Hero, set your blood group and location. You\'ll be notified when someone near you needs your blood group.' },
    { q: 'How do I request blood in an emergency?', a: 'Create a blood request on Blood Hero specifying the blood group, hospital, and urgency level. Nearby compatible donors will be notified immediately.' },
    { q: 'Who can donate blood?', a: 'Generally, healthy adults aged 18-65 weighing at least 50 kg. Men can donate every 3 months and women every 4 months.' },
  ];

  return faqs.map(f => `
    <div class="faq-item">
      <button class="faq-question">${esc(f.q)} ${icon('chevron-down')}</button>
      <div class="faq-answer"><p>${esc(f.a)}</p></div>
    </div>
  `).join('');
}
