// Impact Tracking — privacy-safe donation journey timeline
import { t, lang } from '../i18n.js';
import { currentUser, connectBackend } from '../auth.js';
import { esc, icon } from '../ui.js';
import { backendApi, isBackendAvailable } from '../../shared/js/backend-api.js';

const IMPACT_STEPS = [
  { key: 'donation', icon: 'drop', bn: 'রক্তদান সম্পূর্ণ', en: 'Donation Completed' },
  { key: 'processing', icon: 'activity', bn: 'প্রসেসিং', en: 'Processing' },
  { key: 'blood_bank', icon: 'heart', bn: 'ব্লাড ব্যাংক', en: 'Blood Bank' },
  { key: 'hospital', icon: 'health', bn: 'হাসপাতাল', en: 'Hospital' },
  { key: 'delivered', icon: 'check', bn: 'ডেলিভারি সম্পূর্ণ', en: 'Delivered' },
];

const bn = (b, e) => lang() === 'bn' ? b : e;

export async function renderImpact(root) {
  const u = currentUser() || {};
  root.innerHTML = `
    <section class="section narrow">
      <div class="page-head"><h2>${bn('আপনার প্রভাব', 'Your Impact')}</h2>
        <p class="muted">${bn('রক্তদানের গোপনীয়তাসম্মত যাত্রা', 'Privacy-safe donation journey')}</p></div>
      <div id="impactStatus" class="empty" style="display:none;"></div>
      <div id="impactStats" class="stat-grid">${loadingSkeleton()}</div>
      <div id="impactTimeline" class="timeline"></div>
    </section>`;

  if (!isBackendAvailable()) {
    const phone = u.phone;
    if (phone) {
      const res = await connectBackend(phone);
      if (res.status !== 'connected') {
        renderOffline(phone);
        return;
      }
    } else {
      renderOffline('');
      return;
    }
  }

  await loadImpact();

  async function loadImpact() {
    try {
      const impact = await backendApi.get('/impact/my-impact');
      renderStats(impact);
      renderTimeline(impact.recentDonations || []);
    } catch (err) {
      console.error('Impact fetch error:', err);
      root.querySelector('#impactStats').innerHTML =
        `<div class="empty">${icon('alert')} ${bn('ডেটা লোড করতে ব্যর্থ হয়েছে।', 'Failed to load impact data.')}</div>`;
    }
  }
}

function renderOffline(phone) {
  const status = document.getElementById('impactStatus');
  if (!status) return;
  status.style.display = '';
  status.innerHTML = `
    ${icon('info')}
    ${phone
      ? bn('ব্যাকএন্ড সার্ভার অফলাইন — পুনরায় চেষ্টা করুন।', 'Backend server offline — please retry.')
      : bn('লগইন করলে আপনার প্রভাব ট্র্যাক করা যাবে।', 'Sign in to track your impact.')}
    <button class="btn primary sm" id="impactRetry" style="margin-top:8px;">${bn('আবার চেষ্টা করুন', 'Retry')}</button>`;
  document.getElementById('impactRetry')?.addEventListener('click', () => location.reload());
}

function loadingSkeleton() {
  return `<div class="stat"><strong>…</strong><span>${bn('মোট দান', 'Total Donations')}</span></div>
    <div class="stat"><strong>…</strong><span>${bn('জীবন বাঁচিয়েছেন', 'Lives Saved')}</span></div>
    <div class="stat"><strong>…</strong><span>${bn('সাম্প্রতিক', 'Recent')}</span></div>`;
}

function renderStats(impact) {
  const stats = document.getElementById('impactStats');
  if (!stats) return;
  stats.innerHTML = `
    <div class="stat">${icon('drop')}<strong>${impact.totalDonations}</strong><span>${esc(t('totalDonations'))}</span></div>
    <div class="stat">${icon('heart')}<strong>${impact.totalLives}</strong><span>${bn('জীবন বাঁচিয়েছেন', 'Lives Saved')}</span></div>
    <div class="stat">${icon('check')}<strong>${impact.recentDonations.length}</strong><span>${bn('সাম্প্রতিক', 'Recent')}</span></div>`;
}

function renderTimeline(recent) {
  const timeline = document.getElementById('impactTimeline');
  if (!timeline) return;
  if (recent.length === 0) {
    timeline.innerHTML = `<div class="empty">${icon('info')} ${bn('এখনো কোনো verified দান নেই।', 'No verified donations yet.')}</div>`;
    return;
  }
  timeline.innerHTML = recent.map((d) => {
    const steps = IMPACT_STEPS.map((step, idx) => {
      const isLast = idx === IMPACT_STEPS.length - 1;
      const isActive = d.status === 'verified' && idx <= 2;
      return `
        <div class="timeline-step ${isActive ? 'active' : ''} ${isLast ? 'last' : ''}">
          <div class="step-dot">${icon(step.icon)}</div>
          <div class="step-content">
            <h4>${bn(step.bn, step.en)}</h4>
            <p class="muted">${esc(d.hospital || d.request_hospital || 'Blood Hero Center')}</p>
          </div>
        </div>`;
    }).join('');
    return `
      <div class="impact-card">
        <div class="impact-header">
          <span class="badge green">${esc(t('verifiedDonor'))}</span>
          <small>${new Date(d.created_at * 1000).toLocaleDateString(lang() === 'bn' ? 'bn-BD' : 'en-GB')}</small>
        </div>
        <div class="timeline-track">${steps}</div>
      </div>`;
  }).join('');
}