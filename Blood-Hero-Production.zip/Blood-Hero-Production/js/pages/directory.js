// Emergency Directory — national emergency numbers + hospitals/clinics/labs
// Real Rangpur facility data from the project requirement files.
import { t, lang } from '../i18n.js';
import { DIRECTORY, EMERGENCY_NUMBERS, BLOOD_BANK_NUMBERS, lname } from '../data/rangpur.js';
import { esc, icon, safeTel } from '../ui.js';

const TYPE_KEYS = { govt: 'hospitals', hospital: 'hospitals', clinic: 'clinics', lab: 'labs' };

export async function renderDirectory(root) {
  const byType = Object.entries(TYPE_KEYS).reduce((m, [type, key]) => (m[key] = (m[key] || 0) + DIRECTORY.filter(e => e.type === type).length, m), {});
  const filters = [['', t('allTypes')], ['govt', t('hospitals')], ['hospital', t('hospitals')], ['clinic', t('clinics')], ['lab', t('labs')]];

  root.innerHTML = `
    <section class="section">
      <div class="page-head">
        <h2>${icon('emergency')} ${esc(t('emergencyDirectory'))}</h2>
        <p class="muted">${lang() === 'bn' ? 'জরুরি নম্বর + রংপুরের হাসপাতাল/ক্লিনিক/ল্যাব ডিরেক্টরি' : 'Emergency numbers + Rangpur hospitals, clinics & labs'}</p>
      </div>

      <div class="emg-num-grid">
        ${EMERGENCY_NUMBERS.map(n => `
          <a class="emg-num" href="tel:${safeTel(n.phone)}">
            <span class="emg-num-ic">${icon(n.icon)}</span>
            <div><strong dir="ltr">${esc(n.phone)}</strong><small>${esc(lang() === 'bn' ? n.labelBn : n.label)}</small></div>
          </a>`).join('')}
      </div>

      <div class="verify-block">
        <div class="verify-title">${icon('drop')} <h3>${esc(t('bloodBanks'))}</h3></div>
        ${BLOOD_BANK_NUMBERS.map(b => `
          <div class="donation-row">
            <div><strong>${esc(lang() === 'bn' ? b.nameBn : b.name)}</strong>
              <a class="link" href="tel:${safeTel(b.phone)}">${icon('phone')} <span dir="ltr">${esc(b.phone)}</span></a></div>
            <small>${lang() === 'bn' ? 'কম্পোনেন্ট বিভাজন সুবিধা আছে' : 'Component-separation capable'}</small>
          </div>`).join('')}
      </div>

      <div class="chip-row" id="dirFilter">
        ${filters.map(([v, label], i) => `<button class="chip ${i === 0 ? 'active' : ''}" data-f="${v}">${label}</button>`).join('')}
      </div>
      <p class="result-count" id="dirCount"></p>
      <div class="card-list" id="dirList"></div>
    </section>`;

  const paint = (f = '') => {
    let arr = DIRECTORY;
    if (f) arr = arr.filter(e => e.type === f);
    const list = root.querySelector('#dirList');
    root.querySelector('#dirCount').textContent = `${arr.length} ${lang() === 'bn' ? 'টি প্রতিষ্ঠান' : 'facilities'}`;
    list.innerHTML = arr.map(e => `
      <article class="dir-entry">
        <div class="dir-type">${esc(t(TYPE_KEYS[e.type] || 'hospitals'))}</div>
        <h4>${esc(lang() === 'bn' ? e.name : e.nameEn || e.name)}</h4>
        <p class="loc">${icon('location')} ${esc(lang() === 'bn' ? e.areaBn : e.area)} · ${esc(e.address)}</p>
        <div class="req-actions">
          ${e.phones.length ? e.phones.map(p => `<a class="btn primary sm" href="tel:${safeTel(p)}">${icon('phone')} <span dir="ltr">${esc(p)}</span></a>`).join('') : `<span class="badge gray">${lang() === 'bn' ? 'ফোন নেই' : 'No phone'}</span>`}
        </div>
      </article>`).join('');
  };
  root.querySelector('#dirFilter').addEventListener('click', e => {
    const b = e.target.closest('.chip'); if (!b) return;
    root.querySelectorAll('#dirFilter .chip').forEach(c => c.classList.toggle('active', c === b));
    paint(b.dataset.f);
  });
  paint();
}