// Nearby centers + appointment scheduling (from 100+ project: find-center code(28)/(90) + schedule code(73))
import { t, lang } from '../i18n.js';
import { Centers } from '../db.js';
import { esc, icon, toast } from '../ui.js';

export async function renderCenters(root) {
  const centers = await Centers.list();
  root.innerHTML = `
    <section class="section">
      <div class="page-head"><h2>${esc(t('nearbyCenters'))}</h2>
        <p class="muted">${lang() === 'bn' ? 'রক্তদান কেন্দ্র, হাসপাতাল ও ডায়াগনস্টিক সেন্টার' : 'Blood centers, hospitals & diagnostic centers'}</p></div>
      <div class="chip-row" id="centerFilter" style="margin-bottom:12px">
        <button class="chip active" data-f="all">${esc(t('all'))}</button>
        <button class="chip" data-f="blood_center">${lang() === 'bn' ? 'রক্ত কেন্দ্র' : 'Blood Centers'}</button>
        <button class="chip" data-f="hospital">${lang() === 'bn' ? 'হাসপাতাল' : 'Hospitals'}</button>
        <button class="chip" data-f="diagnostic">${lang() === 'bn' ? 'ডায়াগনস্টিক' : 'Diagnostics'}</button>
      </div>
      <div class="mini-map">
        <div class="map-grid"></div>
        <div class="map-pin pulsing-pin" style="top:38%;left:34%">${icon('location')}</div>
        <div class="map-pin" style="top:56%;left:62%;color:var(--blue)">${icon('location')}</div>
        <div class="map-pin" style="top:24%;left:70%;color:var(--purple)">${icon('location')}</div>
      </div>
      <div class="card-list" id="centerList"></div>
    </section>`;

  const paint = (filter = 'all') => {
    let list = centers;
    if (filter !== 'all') list = list.filter(c => c.type === filter);
    const container = root.querySelector('#centerList');
    container.innerHTML = list.length === 0
      ? `<div class="empty">${icon('info')} ${esc(t('noResults'))}</div>`
      : list.map((c, i) => {
          const isBlood = c.type === 'blood_center';
          const typeLabel = isBlood ? (lang() === 'bn' ? 'রক্ত দান কেন্দ্র' : 'Blood Center')
            : c.type === 'hospital' ? (lang() === 'bn' ? 'হাসপাতাল' : 'Hospital')
            : (lang() === 'bn' ? 'ডায়াগনস্টিক' : 'Diagnostic');
          const typeBadge = isBlood ? 'red' : c.type === 'hospital' ? 'green' : 'blue';
          return `
          <article class="center-card ${i === 0 && isBlood ? 'featured' : ''}">
            <div class="center-top">
              <div>
                <h4>${esc(c.name)}</h4>
                <p class="loc">${icon('location')} ${esc(c.upazila || '')}, ${esc(c.district || '')}</p>
              </div>
              <span class="badge ${typeBadge}">${esc(typeLabel)}</span>
            </div>
            <div class="center-meta">
              ${c.team ? `<span>${icon('health')} ${lang() === 'bn' ? 'বিশেষজ্ঞ টিম আছে' : 'Expert medical team'}</span>` : ''}
              <span>${icon('clock')} ${esc(t('nextSlot'))}: ${esc(c.nextSlot || '—')}</span>
              ${c.phone ? `<span>${icon('phone')} ${esc(c.phone)}</span>` : ''}
            </div>
            ${isBlood ? `<button class="btn primary book" data-c="${esc(c.name)}">${icon('calendar')} ${esc(t('bookAppointment'))}</button>` : ''}
          </article>`;
        }).join('');
  };

  root.querySelector('#centerFilter').addEventListener('click', e => {
    const b = e.target.closest('.chip'); if (!b) return;
    root.querySelectorAll('#centerFilter .chip').forEach(c => c.classList.toggle('active', c === b));
    paint(b.dataset.f);
  });

  paint('all');
  root.querySelectorAll('.book').forEach(b => b.addEventListener('click', () => openBooking(root, b.dataset.c)));
}

function openBooking(pageRoot, centerName) {
  import('../ui.js').then(({ openModal, closeModal }) => {
    const days = [...Array(7)].map((_, i) => {
      const d = new Date(Date.now() + i * 86400000);
      return { iso: d.toISOString().slice(0, 10), label: d.toLocaleDateString(lang() === 'bn' ? 'bn-BD' : 'en-GB', { weekday: 'short', day: 'numeric' }) };
    });
    const slots = ['9:00 AM', '10:30 AM', '1:00 PM', '2:30 PM', '4:00 PM'];
    openModal(`
      <h3 class="modal-title">${esc(t('bookAppointment'))}</h3>
      <p class="muted" style="margin-bottom:10px">${esc(centerName)}</p>
      <form id="bookForm" class="form-card flat">
        <span class="field-row"><span>${esc(t('donationType'))}</span>
          <div class="chip-row">
            ${['wholeBlood', 'plasma', 'platelets'].map((k, i) => `<button type="button" class="chip type ${i === 0 ? 'active' : ''}" data-v="${esc(t(k))}">${esc(t(k))}</button>`).join('')}
          </div></span>
        <span class="field-row"><span>${esc(t('selectDate'))}</span>
          <div class="chip-row days">${days.map((d, i) => `<button type="button" class="chip day ${i === 1 ? 'active' : ''}" data-v="${d.iso}">${esc(d.label)}</button>`).join('')}</div></span>
        <span class="field-row"><span>${esc(t('selectTime'))}</span>
          <div class="chip-row slots">${slots.map((s, i) => `<button type="button" class="chip slot ${i === 1 ? 'active' : ''}" data-v="${s}">${s}</button>`).join('')}</div></span>
        <button class="btn primary lg" type="submit">${icon('check')} ${esc(t('confirmAppointment'))}</button>
        <p class="conf">${icon('heart')} ${esc(t('yourImpact'))}</p>
      </form>`);
    const doc = document;
    dayPick(doc); function dayPick(d) {
      d.querySelectorAll('.chip-row .chip').forEach(c => c.addEventListener('click', () => {
        c.parentElement.querySelectorAll('.chip').forEach(x => x.classList.remove('active'));
        c.classList.add('active');
      }));
    }
    doc.getElementById('bookForm').addEventListener('submit', e => {
      e.preventDefault();
      const pick = sel => doc.querySelector(sel)?.dataset.v || '';
      toast((lang() === 'bn' ? 'অ্যাপয়েন্টমেন্ট বুক হয়েছে — ' : 'Booked — ') + centerName + ' · ' + pick('.chip.day.active') + ' ' + pick('.chip.slot.active'), 'success');
      closeModal();
    });
  });
}
