// Blood Requests — list, create (normal/urgent/critical + component), detail
// with one-tap "I can donate" responses and emergency SOS.
import { t, lang } from '../i18n.js';
import { Requests, Responses, BLOOD_GROUPS, Audit, Notifications, RequestMatches, Donors, compatibleGroups, createMatchesForRequest, publicProfile, maskPhone } from '../db.js';
import { currentUser } from '../auth.js';
import { esc, icon, bloodBadge, timeAgo, statusBadge, toast, requireLoginModal } from '../ui.js';
import { rateLimit } from '../lib/rateLimit.js';
import { DISTRICTS, upazilasFor, unionsFor, lname } from '../data/rangpur.js';
import { backendApi, isBackendAvailable } from '../../shared/js/backend-api.js';

const URGENCY = ['normal', 'urgent', 'critical'];
const COMPONENTS = ['Whole Blood', 'Plasma', 'Platelets', 'RBC'];
const urgKey = u => u === 'critical' ? 'critical' : u === 'urgent' ? 'urgent' : 'normal';
const urgBadge = u => `<span class="badge ${u === 'critical' ? 'red' : u === 'urgent' ? 'amber' : 'gray'}">${esc(t(urgKey(u)))}</span>`;

export async function renderRequests(root) {
  const list = await Requests.list();
  root.innerHTML = `
    <section class="section">
      <div class="page-head row">
        <div><h2>${esc(t('requests'))}</h2><p class="muted">${list.filter(r => r.status === 'pending').length} ${esc(t('statusPending'))}</p></div>
        <a href="#/request" class="btn primary">${icon('plus')} ${esc(t('createRequest'))}</a>
      </div>
      <div class="chip-row" id="rqFilter">
        <button class="chip active" data-f="">${esc(t('all'))}</button>
        ${BLOOD_GROUPS.map(g => `<button class="chip blood" data-f="${g}">${g}</button>`).join('')}
        <button class="chip emg" data-f="__emg">${icon('emergency')} SOS</button>
      </div>
      <div class="card-list" id="reqList"></div>
    </section>`;

  const paint = (filter = '') => {
    let arr = list;
    if (filter === '__emg') arr = list.filter(r => r.emergency || r.urgency === 'critical');
    else if (filter) arr = list.filter(r => r.bloodGroup === filter);
    root.querySelector('#reqList').innerHTML = arr.length === 0
      ? `<div class="empty">${icon('info')} ${esc(t('noResults'))}</div>`
      : arr.map(r => `
        <article class="req-card ${(r.emergency || r.urgency === 'critical') ? 'emg' : ''}">
          ${(r.emergency || r.urgency === 'critical') ? `<span class="ribbon pulsing">${icon('emergency')} ${esc(t('emergencyRequest'))}</span>` : ''}
          <div class="req-main">
            ${bloodBadge(r.bloodGroup)}
            <div class="req-info">
              <h4>${esc(r.hospital)}</h4>
              <p>${esc(r.patientName)} · ${r.units} ${esc(t('units'))} · ${urgBadge(r.urgency)} ${statusBadge(r.status)}</p>
              <p class="loc">${icon('location')} ${esc([r.upazila, r.district].filter(Boolean).join(', ') || '—')} · ${timeAgo(r.createdAt || Date.now(), lang() === 'bn')}</p>
              ${r.component ? `<p class="comp">${icon('drop')} ${esc(r.component)}</p>` : ''}
            </div>
          </div>
          <div class="req-actions">
            <a class="btn ghost sm" href="#/request/${encodeURIComponent(r.id)}">${esc(t('details'))}</a>
            ${r.status === 'pending' ? `<a class="btn primary sm" href="tel:${esc(String(r.contact || '').replace(/[^0-9+]/g, ''))}">${icon('phone')} ${esc(t('respond'))}</a>` : ''}
          </div>
        </article>`).join('');
  };
  root.querySelector('#rqFilter').addEventListener('click', e => {
    const b = e.target.closest('.chip'); if (!b) return;
    root.querySelectorAll('#rqFilter .chip').forEach(c => c.classList.toggle('active', c === b));
    paint(b.dataset.f);
  });
  paint();
}

export async function renderRequestForm(root) {
  const u0 = currentUser();
  if (u0?.guest) {
    root.innerHTML = `<div class="section narrow empty">${icon('lock')}<p>${lang() === 'bn' ? 'অনুরোধ তৈরি করতে লগইন করুন।' : 'Log in to create a request.'}</p>
      <button class="btn primary" id="reqLoginGo">${esc(t('login'))}</button></div>`;
    root.querySelector('#reqLoginGo').addEventListener('click', requireLoginModal);
    return;
  }
  const districtOpts = DISTRICTS.map(d => `<option ${d === 'Rangpur' ? 'selected' : ''}>${d}</option>`).join('');
  root.innerHTML = `
    <section class="section narrow">
      <div class="page-head"><h2>${esc(t('createRequest'))}</h2>
      <p class="muted">${lang() === 'bn' ? 'তথ্য দিন — কাছাকাছি ডোনাররা জানতে পারবে' : 'Fill in details — nearby donors will be notified'}</p></div>
      <form id="rqForm" class="form-card" novalidate>
        <label class="field-row"><span>${esc(t('patientName'))} *</span>
          <input class="field" name="patientName" required maxlength="80" /></label>
        <div class="grid-2">
          <label class="field-row"><span>${esc(t('bloodGroup'))} *</span>
            <select class="field" name="bloodGroup" required>${BLOOD_GROUPS.map(g => `<option>${g}</option>`).join('')}</select></label>
          <label class="field-row"><span>${esc(t('units'))} *</span>
            <input class="field" name="units" type="number" min="1" max="8" value="1" required /></label>
        </div>
        <label class="field-row"><span>${esc(t('urgency'))} *</span>
          <div class="chip-row" id="urgChips">
            ${URGENCY.map((u, i) => `<button type="button" class="chip urg ${i === 0 ? 'active' : ''}" data-v="${u}">${esc(t(urgKey(u)))}</button>`).join('')}
          </div></label>
        <label class="field-row"><span>${esc(t('component'))} *</span>
          <div class="chip-row" id="compChips">
            ${COMPONENTS.map((c, i) => `<button type="button" class="chip comp ${i === 0 ? 'active' : ''}" data-v="${c}">${esc(c)}</button>`).join('')}
          </div>
          <small class="muted">${esc(t('componentNote'))}</small></label>
        <label class="field-row"><span>${esc(t('hospital'))} *</span>
          <input class="field" name="hospital" required maxlength="120" /></label>
        <label class="field-row"><span>${esc(t('district'))} *</span>
          <select class="field" name="district" id="rqDistrict">${districtOpts}</select></label>
        <div id="rqUpazila"></div>
        <div id="rqUnion"></div>
        <label class="field-row"><span>${esc(t('contact'))} *</span>
          <input class="field" name="contact" type="tel" required pattern="[+0-9][0-9+\\-]{7,16}" placeholder="+8801XXXXXXXXX" /></label>
        <label class="field-row"><span>${esc(t('neededDate'))}</span>
          <input class="field" name="neededDate" type="datetime-local" /></label>
        <label class="field-row"><span>${esc(t('reason'))}</span>
          <textarea class="field" name="note" rows="2" maxlength="300"></textarea></label>
        <button class="btn primary lg" type="submit">${icon('drop')} ${esc(t('submit'))}</button>
        <p class="muted" style="font-size:.72rem; text-align:center;">${esc(t('finalDisclaimerBn'))}</p>
      </form>
    </section>`;

  const $ = s => root.querySelector(s);
  // cascading location selects (real Rangpur data; other districts → text)
  const paintLoc = () => {
    const district = $('#rqDistrict').value;
    const uz = upazilasFor(district);
    $('#rqUpazila').innerHTML = uz.length
      ? `<label class="field-row"><span>${esc(t('upazila'))} *</span>
          <select class="field" name="upazila" id="rqUpazilaSel"><option value="">${esc(t('selectUpazila'))}</option>${uz.map(u => `<option>${lname(u)}</option>`).join('')}</select></label>`
      : `<label class="field-row"><span>${esc(t('upazila'))}</span><input class="field" name="upazila" maxlength="60" /></label>`;
    $('#rqUpazilaSel')?.addEventListener('change', paintUnion);
    paintUnion();
  };
  const paintUnion = () => {
    const uz = $('#rqUpazilaSel')?.value || '';
    const un = unionsFor($('#rqDistrict').value, uz);
    $('#rqUnion').innerHTML = un.length
      ? `<label class="field-row"><span>${esc(t('union'))}</span>
          <select class="field" name="union"><option value="">${esc(t('selectUnion'))}</option>${un.map(x => `<option>${lname(x)}</option>`).join('')}</select></label>`
      : '';
  };
  $('#rqDistrict').addEventListener('change', paintLoc);
  paintLoc();

  // chip pickers (urgency / component)
  const chipPick = (rowId) => $(rowId).addEventListener('click', e => {
    const c = e.target.closest('.chip'); if (!c) return;
    $(rowId).querySelectorAll('.chip').forEach(x => x.classList.toggle('active', x === c));
  });
  chipPick('#urgChips');
  chipPick('#compChips');

  $('#rqForm').addEventListener('submit', async e => {
    e.preventDefault();
    const f = e.target;
    if (!f.checkValidity()) { f.reportValidity(); return; }
    const u = currentUser();
    if (!rateLimit('req_' + (u?.uid || 'anon'), 3, 3600000)) {
      toast(lang() === 'bn' ? 'অনুরোধ সীমা অতিক্রম হয়েছে' : 'Request limit reached', 'error');
      return;
    }
    const data = Object.fromEntries(new FormData(f).entries());
    const urgency = $('#urgChips .chip.active')?.dataset.v || 'normal';
    const component = $('#compChips .chip.active')?.dataset.v || 'Whole Blood';
    try {
      const rec = await Requests.add({
        patientName: data.patientName.trim(), bloodGroup: data.bloodGroup, units: +data.units,
        urgency, component,
        hospital: data.hospital.trim(), district: data.district, upazila: data.upazila?.trim() || '',
        union: data.union?.trim() || '',
        contact: data.contact.trim(), note: data.note?.trim() || '',
        emergency: urgency === 'critical',
        neededDate: data.neededDate || null, createdBy: u?.uid || 'anon',
      });
      createMatchesForRequest(rec).catch(() => {});
      Audit.log(u?.name || 'anon', 'create_request', data.bloodGroup + '/' + urgency);
      toast(t('requestSent'), 'success');
      location.hash = '#/requests';
    } catch (err) {
      console.error(err);
      toast(t('requestFailed'), 'error');
    }
  });
}

export async function renderRequestDetail(root, id) {
  const [list, responses, matches, donors] = await Promise.all([Requests.list(), Responses.forRequest(id), RequestMatches.forRequest(id), Donors.list()]);
  const r = list.find(x => x.id === id);
  if (!r) { root.innerHTML = `<div class="empty section">${icon('alert')} ${esc(t('noResults'))}</div>`; return; }
  const u = currentUser() || {};
  const iResponded = responses.some(x => x.donorId === u.uid);
  const donorMap = Object.fromEntries(donors.map(d => [d.id, d]));
  const topMatches = matches.sort((a, b) => (b.score || 0) - (a.score || 0)).slice(0, 5);
  root.innerHTML = `
    <section class="section narrow">
      <a href="#/requests" class="back-link">${icon('back')} ${esc(t('back'))}</a>
      <article class="detail-card ${(r.emergency || r.urgency === 'critical') ? 'emg' : ''}">
        <div class="detail-head">
          ${bloodBadge(r.bloodGroup)}
          <div>
            <h2>${esc(t('bloodNeeded'))}: ${esc(r.bloodGroup)}</h2>
            <p class="muted">${esc(r.units)} ${esc(t('units'))} · ${urgBadge(r.urgency)} ${statusBadge(r.status)}</p>
          </div>
        </div>
        <div class="kv"><span>${esc(t('patientName'))}</span><strong>${esc(r.patientName)}</strong></div>
        <div class="kv"><span>${esc(t('hospital'))}</span><strong>${esc(r.hospital)}</strong></div>
        <div class="kv"><span>${esc(t('component'))}</span><strong>${esc(r.component || 'Whole Blood')}</strong></div>
        <div class="kv"><span>${lang() === 'bn' ? 'অবস্থান' : 'Location'}</span><strong>${esc([r.union, r.upazila, r.district].filter(Boolean).join(', ') || '—')}</strong></div>
        <div class="kv"><span>${esc(t('contact'))}</span><strong dir="ltr">${esc(r.createdBy === (u?.uid || 'anon') ? r.contact : maskPhone(r.contact))}</strong></div>
        <div class="kv"><span>${esc(t('neededDate'))}</span><strong>${r.neededDate ? esc(new Date(r.neededDate).toLocaleString()) : '—'}</strong></div>
        ${r.note ? `<div class="note-box">${esc(r.note)}</div>` : ''}
        <p class="muted" style="font-size:.72rem; text-align:center; margin-top:8px;">${esc(t('finalDisclaimerBn'))}</p>
        <div class="req-actions big">
          <a class="btn primary lg" href="tel:${esc(String(r.contact || '').replace(/[^0-9+]/g, ''))}">${icon('phone')} ${esc(t('callNow'))}</a>
          ${r.status === 'pending' ? `
            <button class="btn ${iResponded ? 'success' : 'ghost'} lg" id="canDonateBtn" ${iResponded ? 'disabled' : ''}>
              ${icon('check')} ${iResponded ? esc(t('alreadyResponded')) : esc(t('iCanDonate'))}</button>` : ''}
          ${r.status === 'pending' ? `<button class="btn success lg" id="acceptBtn">${icon('check')} ${esc(t('respond'))}</button>` : ''}
        </div>
        ${r.acceptedBy ? `<p class="accepted-by">${icon('check')} ${esc(t('statusAccepted'))}: ${esc(r.acceptedBy)}</p>` : ''}
        <div class="resp-box">
          <h4>${icon('heart')} ${esc(t('donorResponses'))} (${responses.length})</h4>
          ${responses.length === 0 ? `<p class="muted">${esc(t('noResponses'))}</p>` : responses.map(x => `
            <div class="resp-row"><strong>${esc(x.name)}</strong><small>${timeAgo(x.at || x.createdAt || Date.now(), lang() === 'bn')}</small></div>`).join('')}
        </div>
        ${topMatches.length > 0 ? `
        <div class="resp-box">
          <h4>${icon('search')} ${lang() === 'bn' ? 'শীর্ষ ম্যাচ' : 'Top Matches'}</h4>
          ${topMatches.map(m => {
            const d = donorMap[m.donorId];
            if (!d) return '';
            const pub = publicProfile(d, u);
            return `<div class="resp-row"><span>${esc(pub.name)} <span class="badge green">${esc(pub.bloodGroup)}</span></span><small>${lang() === 'bn' ? 'স্কোর' : 'Score'}: ${m.score}</small></div>`;
          }).join('')}
        </div>` : ''}
        ${r.status === 'fulfilled' && r.createdBy === (u?.uid || 'anon') ? `
        <div class="conversion-card">
          <h4>${icon('heart')} ${lang() === 'bn' ? 'রক্তদানে আপনিও যোগ দিন!' : 'Become a Voluntary Donor!'}</h4>
          <p class="muted">${lang() === 'bn' ? 'এইবার রক্ত পেলেন — এবার অন্যকে দান করুন। রক্তদান একটি দান।' : 'You received blood — now give back. Donation is a gift.'}</p>
          <button class="btn primary sm" id="becomeVolunteerBtn">${icon('user')} ${lang() === 'bn' ? 'স্বেচ্ছাশীল ডোনার হিসেবে রেজিস্ট্রার' : 'Register as Voluntary Donor'}</button>
        </div>` : ''}
      </article>
    </section>`;
  root.querySelector('#canDonateBtn')?.addEventListener('click', async () => {
    if (u.guest) { requireLoginModal(); return; }
    await Responses.add({ requestId: id, donorId: u.uid, name: u.name || 'Hero', phone: u.phone || '', at: Date.now() });
    await Notifications.add({ type: 'accepted', textKey: 'notifAccepted', body: `${u.name} can donate for ${r.bloodGroup} at ${r.hospital}` });
    Audit.log(u.name || 'user', 'donor_response', r.bloodGroup);
    toast(t('iCanDonate') + ' ✓', 'success');
    renderRequestDetail(root, id);
  });
  root.querySelector('#acceptBtn')?.addEventListener('click', async () => {
    const uu = currentUser();
    if (uu?.guest) { requireLoginModal(); return; }
    await Requests.setStatus(id, 'accepted', { acceptedBy: uu?.name || 'Anonymous Hero' });
    toast(t('statusAccepted') + ' ✓', 'success');
    renderRequestDetail(root, id);
  });

  root.querySelector('#becomeVolunteerBtn')?.addEventListener('click', async () => {
    if (!isBackendAvailable()) {
      toast(lang() === 'bn' ? 'ব্যাকএন্ড সংযোগ নেই' : 'Backend not connected', 'error');
      return;
    }
    try {
      await backendApi.post('/conversion/track', { event_type: 'cta_shown', request_id: id, metadata: { source: 'request_detail' } });
      location.hash = '#/profile';
      toast(lang() === 'bn' ? 'প্রোফাইল এডিট করুন — ডোনার হিসেবে সদস্যতা নিন।' : 'Edit profile — register as donor.', 'info');
    } catch (err) {
      toast(err.message || 'Failed', 'error');
    }
  });
}