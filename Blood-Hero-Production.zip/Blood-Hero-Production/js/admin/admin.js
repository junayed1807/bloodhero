// Admin — role-gated admin suite: overview, users, requests, settings.
// Normal users (role != admin) NEVER see this UI — the router blocks them.
import { t, lang } from '../i18n.js';
import { Donors, Requests, Audit, Notifications, NidVerifications, Donations, maskPhone } from '../db.js';
import { currentUser, logout } from '../auth.js';
import { esc, icon, bloodBadge, timeAgo, statusBadge, toast } from '../ui.js';
import { NID_STATUS, DONATION_STATUS } from '../rbac.js';

const BLOOD_GROUPS = ['A+','A-','B+','B-','O+','O-','AB+','AB-'];

async function renderAdminOverview(root) {
  const [donors, requests, audit] = await Promise.all([Donors.list(), Requests.list(), Audit.list()]);
  const pending = requests.filter(r => r.status === 'pending');
  const emergency = requests.filter(r => (r.emergency || r.urgency === 'critical') && r.status === 'pending');
  root.innerHTML = `
    <div class="admin-hero">
      <div><h2>${esc(t('overview'))}</h2><p class="muted">${lang() === 'bn' ? 'লাইভ সিস্টেম স্ন্যাপশট' : 'Live system snapshot'}</p></div>
      <span class="badge green pulsing">● ${lang() === 'bn' ? 'অনলাইন' : 'Online'}</span>
    </div>
    <div class="stat-grid admin">
      <div class="stat">${icon('users')}<strong>${donors.length}</strong><span>${esc(t('totalUsers'))}</span></div>
      <div class="stat">${icon('list')}<strong>${requests.length}</strong><span>${esc(t('requests'))}</span></div>
      <div class="stat">${icon('alert')}<strong>${emergency.length}</strong><span>${esc(t('emergencyCases'))}</span></div>
      <div class="stat">${icon('clock')}<strong>${pending.length}</strong><span>${esc(t('statusPending'))}</span></div>
    </div>
    <div class="grid-2 area">
      <div class="panel">
        <div class="panel-head"><h3>${esc(t('emergencyCases'))}</h3></div>
        ${emergency.length === 0 ? `<div class="empty sm">${icon('check')} OK</div>` : emergency.map(r => `
          <div class="mini-row"><span>${bloodBadge(r.bloodGroup)} ${esc(r.hospital)}</span><a href="#/request/${encodeURIComponent(r.id)}" class="link">›</a></div>`).join('')}
      </div>
      <div class="panel">
        <div class="panel-head"><h3>${esc(t('auditLog'))}</h3></div>
        ${audit.slice(0, 5).map(a => `
          <div class="mini-row"><span>${esc(a.actor)} · ${esc(a.action)}</span><small>${timeAgo(a.at, lang() === 'bn')}</small></div>`).join('') || `<div class="empty sm">—</div>`}
      </div>
    </div>`;
}

async function renderAdminUsers(root) {
  const donors = await Donors.list();
  root.innerHTML = `
    <div class="admin-hero"><div><h2>${esc(t('users'))}</h2><p class="muted">${donors.length} total</p></div></div>
    <div class="table-wrap panel">
      <table class="bh-table">
        <thead><tr><th>${esc(t('name'))}</th><th>${esc(t('bloodGroup'))}</th><th>${esc(t('contact'))}</th><th>${esc(t('district'))}</th><th>${esc(t('availability'))}</th><th class="ta-r">${esc(t('role'))}</th></tr></thead>
        <tbody>
          ${donors.map(d => `
            <tr>
              <td class="bold">${esc(d.name)}</td>
              <td>${bloodBadge(d.bloodGroup)}</td>
              <td dir="ltr" class="mono">${esc(maskPhone(d.phone))}</td>
              <td>${esc(d.district || '—')}</td>
              <td><label class="switch-inline sm"><input type="checkbox" data-id="${d.id}" class="availTgl" ${d.available ? 'checked' : ''}/><span class="switch"></span></label></td>
              <td class="ta-r"><span class="badge ${d.role === 'admin' ? 'red' : 'gray'}">${esc(d.role || 'donor')}</span></td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>`;
  root.querySelectorAll('.availTgl').forEach(c => c.addEventListener('change', async () => {
    await Donors.update(c.dataset.id, { available: c.checked });
    Audit.log(currentUser()?.name || 'admin', c.checked ? 'activate_user' : 'suspend_user', c.dataset.id);
    toast('✓', 'success');
  }));
}

async function renderAdminRequests(root) {
  const list = await Requests.list();
  root.innerHTML = `
    <div class="admin-hero"><div><h2>${esc(t('reqMgmt'))}</h2><p class="muted">${list.filter(r => r.status === 'pending').length} ${esc(t('statusPending'))}</p></div></div>
    <div class="card-list">
      ${list.length === 0 ? `<div class="empty">${icon('list')} —</div>` : list.map(r => `
        <article class="req-card ${r.emergency ? 'emg' : ''} admin">
          <div class="req-main">${bloodBadge(r.bloodGroup)}
            <div class="req-info">
              <h4>${esc(r.patientName)} · ${esc(r.hospital)}</h4>
              <p>${r.units} ${esc(t('units'))} · ${esc(r.component || 'Whole Blood')} · ${r.urgency === 'critical' ? `<span class="badge red">${esc(t('critical'))}</span>` : r.urgency === 'urgent' ? `<span class="badge amber">${esc(t('urgent'))}</span>` : ''} ${statusBadge(r.status)}</p>
              <p class="loc">${icon('location')} ${esc([r.upazila, r.district].filter(Boolean).join(', ') || '—')} · ${timeAgo(r.createdAt || Date.now(), lang() === 'bn')}</p>
            </div>
          </div>
          <div class="req-actions">
            ${r.status === 'pending' ? `
              <button class="btn success sm" data-act="accepted" data-id="${r.id}">${icon('check')} ${esc(t('approve'))}</button>
              <button class="btn ghost sm" data-act="cancelled" data-id="${r.id}">${icon('close')} ${esc(t('reject'))}</button>` : ''}
            ${r.status !== 'fulfilled' ? `<button class="btn primary sm" data-act="fulfilled" data-id="${r.id}">✓ ${esc(t('statusFulfilled'))}</button>` : ''}
            <button class="btn danger-ghost sm" data-act="__del" data-id="${r.id}">${icon('close')}</button>
          </div>
        </article>`).join('')}
    </div>`;
  root.querySelectorAll('[data-act]').forEach(b => b.addEventListener('click', async () => {
    const id = b.dataset.id, act = b.dataset.act;
    if (act === '__del') {
      if (!confirm(lang() === 'bn' ? 'মুছে ফেলবেন?' : 'Delete this request?')) return;
      await Requests.remove(id);
      Audit.log(currentUser()?.name || 'admin', 'delete_request', id);
    } else {
      await Requests.setStatus(id, act);
      Audit.log(currentUser()?.name || 'admin', 'set_' + act, id);
      if (act === 'accepted') await Notifications.add({ type: 'accepted', textKey: 'notifAccepted', body: id });
    }
    toast('✓', 'success');
    renderAdminRequests(root);
  }));
}

async function renderAdminSettings(root) {
  root.innerHTML = `
    <div class="admin-hero"><div><h2>${esc(t('settings'))}</h2></div></div>
    <div class="panel">
      <div class="mini-row"><span>${lang() === 'bn' ? 'মেইনটেন্যান্স মোড' : 'Maintenance mode'}</span>
        <label class="switch-inline"><input type="checkbox" id="mMode"/><span class="switch"></span></label></div>
      <div class="mini-row"><span>${esc(t('pushNotif'))}</span>
        <label class="switch-inline"><input type="checkbox" checked /><span class="switch"></span></label></div>
      <div class="mini-row"><span>${lang() === 'bn' ? 'FX অ্যানিমেশন' : 'FX Animations'}</span>
        <label class="switch-inline"><input type="checkbox" id="fxToggle" checked /><span class="switch"></span></label></div>
    </div>
    <button class="btn danger-ghost" id="adminLogout">${icon('logout')} ${esc(t('logout'))}</button>`;
  root.querySelector('#adminLogout').addEventListener('click', logout);
  root.querySelector('#mMode').addEventListener('change', e =>
    Audit.log(currentUser()?.name || 'admin', 'maintenance_' + (e.target.checked ? 'on' : 'off'), 'system'));
  root.querySelector('#fxToggle').addEventListener('change', e => {
    try { localStorage.setItem('bh_fx_off', e.target.checked ? '0' : '1'); } catch {}
    toast(e.target.checked ? (lang() === 'bn' ? 'FX চালু' : 'FX enabled') : (lang() === 'bn' ? 'FX বন্ধ' : 'FX disabled'), 'success');
  });
}

async function renderAdminVerifications(root) {
  const list = await NidVerifications.list();
  root.innerHTML = `
    <div class="admin-hero"><div><h2>${esc(t('nidVerifications'))}</h2><p class="muted">${list.length} total</p></div></div>
    <div class="table-wrap panel">
      <table class="bh-table">
        <thead><tr><th>${esc(t('name'))}</th><th>NID</th><th>${esc(t('status'))}</th><th class="ta-r">${esc(t('action'))}</th></tr></thead>
        <tbody>
          ${list.map(v => `
            <tr>
              <td class="bold">${esc(v.legalName || '—')}</td>
              <td class="mono">${esc((v.nidNumber || '').slice(0, 4) + '****')}</td>
              <td><span class="badge ${v.status === 'approved' ? 'green' : v.status === 'pending' ? 'amber' : 'red'}">${esc(v.status || 'pending')}</span></td>
              <td class="ta-r">${v.status === 'pending' ? `
                <button class="btn success sm" data-act="approved" data-id="${v.id}">${icon('check')}</button>
                <button class="btn danger-ghost sm" data-act="rejected" data-id="${v.id}">${icon('close')}</button>` : '—'}
              </td>
            </tr>`).join('') || `<tr><td colspan="4" style="text-align:center;color:var(--muted)">—</td></tr>`}
        </tbody>
      </table>
    </div>`;
  root.querySelectorAll('[data-act]').forEach(b => b.addEventListener('click', async () => {
    await NidVerifications.update(b.dataset.id, { status: b.dataset.act });
    Audit.log(currentUser()?.name || 'admin', 'nid_' + b.dataset.act, b.dataset.id);
    toast('✓', 'success');
    renderAdminVerifications(root);
  }));
}

async function renderAdminDonations(root) {
  const list = await Donations.list();
  root.innerHTML = `
    <div class="admin-hero"><div><h2>${esc(t('donationProofs'))}</h2><p class="muted">${list.length} total</p></div></div>
    <div class="table-wrap panel">
      <table class="bh-table">
        <thead><tr><th>${esc(t('donorName'))}</th><th>${esc(t('hospital'))}</th><th>${esc(t('bloodGroup'))}</th><th>${esc(t('status'))}</th><th class="ta-r">${esc(t('action'))}</th></tr></thead>
        <tbody>
          ${list.map(d => `
            <tr>
              <td class="bold">${esc(d.donorId || '—')}</td>
              <td>${esc(d.hospital || '—')}</td>
              <td>${bloodBadge(d.bloodGroup)}</td>
              <td><span class="badge ${d.status === 'verified' ? 'green' : d.status === 'submitted' ? 'amber' : 'gray'}">${esc(d.status || 'submitted')}</span></td>
              <td class="ta-r">${d.status === 'submitted' || d.status === 'awaiting_recipient' ? `
                <button class="btn success sm" data-act="verified" data-id="${d.id}">${icon('check')}</button>
                <button class="btn danger-ghost sm" data-act="rejected" data-id="${d.id}">${icon('close')}</button>` : '—'}
              </td>
            </tr>`).join('') || `<tr><td colspan="5" style="text-align:center;color:var(--muted)">—</td></tr>`}
        </tbody>
      </table>
    </div>`;
  root.querySelectorAll('[data-act]').forEach(b => b.addEventListener('click', async () => {
    await Donations.update(b.dataset.id, { status: b.dataset.act, adminApproved: b.dataset.act === 'verified' });
    Audit.log(currentUser()?.name || 'admin', 'donation_' + b.dataset.act, b.dataset.id);
    toast('✓', 'success');
    renderAdminDonations(root);
  }));
}

export async function renderAdmin(root, section = 'dash') {
  const u = currentUser();
  if (!u) {
    root.innerHTML = `<section class="section narrow denied">${icon('shield')}<h2>${lang() === 'bn' ? 'অ্যাক্সেস নেই' : 'Access Denied'}</h2><p class="muted">${lang() === 'bn' ? 'লগইন প্রয়োজন।' : 'Login required.'}</p><a class="btn primary" href="#/">${icon('home')} ${esc(t('home'))}</a></section>`;
    return;
  }
  const r = u.role;
  const allowed = ['admin','org_admin','super_admin','coordinator'];
  if (!allowed.includes(r)) {
    root.innerHTML = `<section class="section narrow denied">${icon('shield')}<h2>${lang() === 'bn' ? 'অ্যাক্সেস নেই' : 'Access Denied'}</h2><p class="muted">${lang() === 'bn' ? 'এই এলাকা শুধুমাত্র অনুমোদিত অ্যাডমিনের জন্য।' : 'This area is restricted to authorized admins.'}</p><a class="btn primary" href="#/">${icon('home')} ${esc(t('home'))}</a></section>`;
    return;
  }
  const tabs = [
    ['dash', 'dashboard', t('overview')],
    ['users', 'users', t('users')],
    ['requests', 'list', t('reqMgmt')],
    ['verifications', 'shield', t('nidVerifications')],
    ['donations', 'drop', t('donationProofs')],
    ['settings', 'settings', t('settings')],
  ];
  root.innerHTML = `
    <div class="admin-shell">
      <header class="admin-bar">
        <span class="admin-brand">${icon('shield')} ${esc(t('adminPanel'))}</span>
        <span class="admin-user">${esc(u.name)} · ${esc(r)}</span>
      </header>
      <nav class="admin-tabs" id="adminTabs">
        ${tabs.map(([id, ic, label]) => `<a href="#/admin/${id}" class="admin-tab ${section === id ? 'active' : ''}">${icon(ic)}<span>${esc(label)}</span></a>`).join('')}
      </nav>
      <div class="admin-content" id="adminContent"></div>
    </div>`;
  const content = root.querySelector('#adminContent');
  if (section === 'users') renderAdminUsers(content);
  else if (section === 'requests') renderAdminRequests(content);
  else if (section === 'settings') renderAdminSettings(content);
  else if (section === 'verifications') renderAdminVerifications(content);
  else if (section === 'donations') renderAdminDonations(content);
  else renderAdminOverview(content);
}
