// Blood Hero — shared UI helpers: icons, toast, modal, HTML escaping, misc.
import { t, lang } from './i18n.js';
import { logout } from './auth.js';

// ---------- XSS safety ----------
export function esc(s) {
  return String(s ?? '').replace(/[&<>"'`]/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;', '`': '&#96;',
  }[c]));
}
export function safeTel(p) { return String(p || '').replace(/[^0-9+]/g, ''); }

// ---------- inline SVG icons (no external icon font dependency) ----------
const P = (d) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
export const icons = {
  drop: P('<path d="M12 3s-7 8-7 13a7 7 0 0 0 14 0c0-5-7-13-7-13z"/>'),
  home: P('<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/>'),
  search: P('<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>'),
  bell: P('<path d="M6 8a6 6 0 0 1 12 0c0 7 3 8 3 8H3s3-1 3-8"/><path d="M10.3 21a2 2 0 0 0 3.4 0"/>'),
  user: P('<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>'),
  plus: P('<path d="M12 5v14M5 12h14"/>'),
  heart: P('<path d="M12 21C7 16.5 3 13 3 8.7 3 5.6 5.2 3.5 8 3.5c1.7 0 3.2.8 4 2.1a5 5 0 0 1 4-2.1c2.8 0 5 2.1 5 5.2 0 4.3-4 7.8-9 12.3z"/>'),
  location: P('<path d="M12 21s-7-6.1-7-11a7 7 0 0 1 14 0c0 4.9-7 11-7 11z"/><circle cx="12" cy="10" r="2.6"/>'),
  phone: P('<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.13.96.36 1.9.7 2.8a2 2 0 0 1-.45 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.45c.9.34 1.84.57 2.8.7A2 2 0 0 1 22 16.9z"/>'),
  calendar: P('<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 11h18"/>'),
  history: P('<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l3.5 2"/>'),
  gift: P('<rect x="3" y="8" width="18" height="4"/><path d="M5 12v9h14v-9M12 8v13M12 8s-1.5-5-5-5-2 5 0 5h5zM12 8s1.5-5 5-5 2 5 0 5h-5z"/>'),
  volunteer: P('<path d="M17 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/><path d="M21 11h-6M21 7h-6M21 15h-6"/>'),
  health: P('<path d="M12 3 4 6v6c0 5 3.4 8.4 8 9 4.6-.6 8-4 8-9V6z"/><path d="M12 8v6M9 11h6"/>'),
  settings: P('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1.02 1.55V21a2 2 0 1 1-4 0v-.09A1.7 1.7 0 0 0 9 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-1.55-1.02H3a2 2 0 1 1 0-4h.09A1.7 1.7 0 0 0 4.6 9a1.7 1.7 0 0 0-.34-1.88l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1.02-1.55V3a2 2 0 1 1 4 0v.09c0 .68.4 1.3 1.02 1.55.6.27 1.32.13 1.88-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06c-.47.47-.61 1.28-.34 1.88.25.62.87 1.02 1.55 1.02H21a2 2 0 1 1 0 4h-.09c-.68 0-1.3.4-1.51 1z"/>'),
  support: P('<circle cx="12" cy="12" r="9"/><path d="M9.2 9a2.8 2.8 0 0 1 5.5.7c0 1.8-2.7 2.3-2.7 4"/><circle cx="12" cy="17.4" r=".6" fill="currentColor"/>'),
  info: P('<circle cx="12" cy="12" r="9"/><path d="M12 8h.01M12 11v6"/>'),
  back: P('<path d="M19 12H5M12 19l-7-7 7-7"/>'),
  close: P('<path d="M18 6 6 18M6 6l12 12"/>'),
  check: P('<path d="M4 12.5 9.5 18 20 6.5"/>'),
  alert: P('<path d="M12 3 2 20h20L12 3z"/><path d="M12 10v4M12 17.5h.01"/>'),
  trophy: P('<path d="M8 21h8M12 17v4M7 4h10v6a5 5 0 0 1-10 0V4z"/><path d="M7 6H4a2 2 0 0 0 2 5h1M17 6h3a2 2 0 0 1-2 5h-1"/>'),
  qr: P('<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM20 14h1M14 20h1M20 20h1M18 17h.01"/>'),
  share: P('<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 10.6 6.8-3.9M8.6 13.4l6.8 3.9"/>'),
  lang: P('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18 15 15 0 0 1 0-18z"/>'),
  moon: P('<path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8z"/>'),
  dashboard: P('<rect x="3" y="3" width="7" height="9" rx="1"/><rect x="14" y="3" width="7" height="5" rx="1"/><rect x="14" y="12" width="7" height="9" rx="1"/><rect x="3" y="16" width="7" height="5" rx="1"/>'),
  users: P('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.5 3-5 6.5-5s6.5 1.5 6.5 5"/><path d="M17 8.5a3 3 0 1 1 .7-5.9M21.5 20c0-2.7-1.8-4.2-4-4.8"/>'),
  list: P('<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="4" cy="6" r=".8" fill="currentColor"/><circle cx="4" cy="12" r=".8" fill="currentColor"/><circle cx="4" cy="18" r=".8" fill="currentColor"/>'),
  activity: P('<path d="M3 12h4l2.5-7 4 14 2.5-7H21"/>'),
  shield: P('<path d="M12 3 4 6v6c0 5 3.4 8.4 8 9 4.6-.6 8-4 8-9V6z"/><path d="m9 12 2 2 4-4.5"/>'),
  wrench: P('<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1 .3.32A5.6 5.6 0 0 1 18 14a6 6 0 0 1-8.6-2L3 18.4V21h2.6L12 14.6A6 6 0 0 0 18 14a5.6 5.6 0 0 0 .4-7.4A6 6 0 0 1 18 6l-3.3.3z"/>'),
  logout: P('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>'),
  clock: P('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
  fb: P('<path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>'),
   award: P('<circle cx="12" cy="9" r="6"/><path d="m8.5 14-1.5 7 5-3 5 3-1.5-7"/>'),
   emergency: P('<circle cx="12" cy="12" r="9"/><path d="M12 7v5M12 16h.01"/>'),
   add: P('<path d="M12 5v14M5 12h14"/>'),
   filter: P('<path d="M3 6h18M7 12h10M10 18h4"/>'),
   loading: P('<circle cx="12" cy="12" r="9" opacity=".2"/><path d="M12 3v6l3 3"/>'),
   lock: P('<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>'),
   camera: P('<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>'),
   'chevron-down': P('<path d="m6 9 6 6 6-6"/>'),
   sun: P('<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>'),
   download: P('<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>'),
   file: P('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M16 13H8M16 17H8M10 9H8"/>'),
   menu: P('<path d="M3 12h18M3 6h18M3 18h18"/>'),
   'external-link': P('<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14 21 3"/>'),
   mail: P('<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><path d="m22 6-10 7L2 6"/>'),
};

export const icon = (name, cls = '') => `<span class="ic ${cls}">${icons[name] || icons.info}</span>`;

// ---------- toast ----------
let toastTimer;
export function toast(msg, type = 'info') {
  let el = document.getElementById('bh-toast');
  if (!el) {
    el = document.createElement('div');
    el.id = 'bh-toast';
    el.className = 'bh-toast';
    document.body.appendChild(el);
  }
  clearTimeout(toastTimer);
  el.className = 'bh-toast show ' + type;
  el.innerHTML = `${type === 'success' ? icon('check') : type === 'error' ? icon('alert') : icon('info')}<span>${esc(msg)}</span>`;
  toastTimer = setTimeout(() => el.classList.remove('show'), 3200);
}

// ---------- modal ----------
export function openModal(html, { wide = false } = {}) {
  closeModal();
  const wrap = document.createElement('div');
  wrap.className = 'bh-modal-backdrop';
  wrap.id = 'bh-modal';
  wrap.innerHTML = `<div class="bh-modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true">
    <button class="bh-modal-x" data-close aria-label="Close">${icons.close}</button>
    <div class="bh-modal-body">${html}</div></div>`;
  wrap.addEventListener('click', e => { if (e.target === wrap || e.target.closest('[data-close]')) closeModal(); });
  document.body.appendChild(wrap);
  requestAnimationFrame(() => wrap.classList.add('show'));
  return wrap;
}
export function closeModal() {
  document.getElementById('bh-modal')?.remove();
}

// ---------- guest protected-action gate ----------
// Shows a modal prompting login/register when a guest tries a protected action.
export function requireLoginModal() {
  const bn = lang() === 'bn';
  openModal(`
    <h3 class="modal-title">${bn ? '🔒 লগইন প্রয়োজন' : '🔒 Login required'}</h3>
    <p class="muted" style="text-align:center;">${bn
      ? 'এই কাজটি করতে লগইন করুন — রক্তদাতা হিসেবে নিবন্ধন করে জীবন বাঁচান।'
      : 'Please log in to continue — register as a donor and save lives.'}</p>
    <div class="grid-2" style="margin-top:10px;">
      <button id="reqLoginGo" class="btn primary lg">${esc(t('login'))}</button>
      <button id="reqRegisterGo" class="btn light lg">${esc(t('register'))}</button>
    </div>`);
  const go = () => { closeModal(); logout(); };
  document.getElementById('reqLoginGo')?.addEventListener('click', go);
  document.getElementById('reqRegisterGo')?.addEventListener('click', go);
}

// ---------- misc ----------
export function timeAgo(ts, bn = true) {
  const s = Math.floor((Date.now() - ts) / 1000);
  const map = bn
    ? [[60, 'সেকেন্ড'], [60, 'মিনিট'], [24, 'ঘণ্টা'], [7, 'দিন'], [4.3, 'সপ্তাহ'], [12, 'মাস'], [Infinity, 'বছর']]
    : [[60, 'sec'], [60, 'min'], [24, 'hr'], [7, 'day'], [4.3, 'week'], [12, 'month'], [Infinity, 'year']];
  let v = s, u = map[0][1];
  for (const [f, name] of map) { if (v < f) { u = name; break; } v = Math.floor(v / f); u = name; }
  v = Math.max(1, Math.floor(v));
  return bn ? `${toBn(v)} ${u} আগে` : `${v} ${u}${v > 1 ? 's' : ''} ago`;
}
export function toBn(n) {
  return String(n).replace(/[0-9]/g, d => '০১২৩৪৫৬৭৮৯'[d]);
}
export function statusBadge(st) {
  const cls = { pending: 'amber', accepted: 'green', fulfilled: 'blue', cancelled: 'gray' }[st] || 'gray';
  return `<span class="badge ${cls}">${esc(t('status' + st.charAt(0).toUpperCase() + st.slice(1)) || st)}</span>`;
}
export function bloodBadge(g) {
  const v = g ? String(g).trim() : '';
  if (!v) return `<span class="blood-badge muted">${esc(t('notProvided'))}</span>`;
  return `<span class="blood-badge">${esc(v)}</span>`;
}
