// Blood Hero — Bangladesh location & directory data
// ----------------------------------------------------
// Rangpur district data (upazilas, unions, hospitals, clinics, labs) is real,
// sourced from the project requirement files (Rangpur_Zila_Admin_List &
// Rangpur_Hospital_Clinic_Lab_List). Other districts use division-level names
// only — never invented granular data.
import { lang } from '../i18n.js';

export const DISTRICTS = ['Dhaka', 'Chattogram', 'Rangpur', 'Khulna', 'Sylhet', 'Rajshahi', 'Barishal', 'Mymensingh'];

const U = (bn, en) => ({ bn, en });
const W = (bn, en) => ({ bn, en });

// 8 upazilas of Rangpur district with their unions (from Rangpur_Zila_Admin_List)
export const RANGPUR_UPZILAS = [
  {
    ...U('রংপুর সদর', 'Rangpur Sadar'),
    unions: [W('চন্দনপাট', 'Chandanpat'), W('হাড়িদেবপুর', 'Haridebpur'), W('মমিনপুর', 'Mominpur'), W('খলেয়া', 'Khaleya'), W('সদ্যপুস্করিণী', 'Sabyapushkarni')],
  },
  {
    ...U('বদরগঞ্জ', 'Badarganj'),
    unions: [W('বিষ্ণুপুর', 'Bishnupur'), W('দামোদরপুর', 'Damodarpur'), W('গোপালপুর', 'Gopalpur'), W('গোপীনাথপুর', 'Gopinathpur'), W('কালুপাড়া', 'Kalupara'), W('কুতুবপুর', 'Kutubpur'), W('লোহানীপাড়া', 'Lohanipara'), W('মধুপুর', 'Madhupur'), W('রাধানগর', 'Radhanagar'), W('রামনাথপুর', 'Ramnathpur')],
  },
  {
    ...U('মিঠাপুকুর', 'Mithapukur'),
    unions: [W('বালারহাট', 'Balarhat'), W('বালুয়া মাসিমপুর', 'Balua Masimpur'), W('বড়বালা', 'Barabala'), W('বড় হযরতপুর', 'Bara Hazratpur'), W('ভাংনী', 'Bhangni'), W('চেংমারী', 'Chengmari'), W('দুর্গাপুর', 'Durgapur'), W('এমাদপুর', 'Emadpur'), W('গোপালপুর', 'Gopalpur'), W('কাফ্রিখাল', 'Kafrikhal'), W('খোড়াগাছ', 'Khoragachh'), W('লতিবপুর', 'Latibpur'), W('মিলনপুর', 'Milanpur'), W('মির্জাপুর', 'Mirzapur'), W('ময়েনপুর', 'Moyenpur'), W('পায়রাবন্দ', 'Pairaband'), W('রাণীপুকুর', 'Ranipukur')],
  },
  {
    ...U('গঙ্গাচড়া', 'Gangachara'),
    unions: [W('আলমবিদিতর', 'Alam Biditar'), W('বড়বিল', 'Barabil'), W('বেতগাড়ী', 'Betgari'), W('গঙ্গাচড়া', 'Gangachara'), W('গজঘণ্টা', 'Gajaghanta'), W('কোলকোন্দ', 'Kolkanda'), W('লক্ষ্মীটারী', 'Lakkhitari'), W('মর্নেয়া', 'Marania'), W('নোহালী', 'Nohali')],
  },
  {
    ...U('কাউনিয়া', 'Kaunia'),
    unions: [W('কাউনিয়া বালাপাড়া', 'Kaunia Balapara'), W('হারাগাছ', 'Haragachh'), W('কুর্শা', 'Kursha'), W('সারাই', 'Sarai'), W('শহীদবাগ', 'Shahidbagh'), W('টেপামধুপুর', 'Tepa Madhupur')],
  },
  {
    ...U('পীরগঞ্জ', 'Pirganj'),
    unions: [W('ভেন্ডাবাড়ী', 'Bhendabari'), W('বড় আলমপুর', 'Boro Alampur'), W('বড়দরগাহ', 'Borodargah'), W('চৈত্রকোল', 'Chaitrakul'), W('চতরা', 'Chatra'), W('কাবিলপুর', 'Kabilpur'), W('কুমেদপুর', 'Kumedpur'), W('মদনখালী', 'Madankhali'), W('মিঠিপুর', 'Mithapur'), W('পাঁচগাছী', 'Pachgachi'), W('পীরগঞ্জ', 'Pirganj'), W('রায়পুর', 'Raypur'), W('রামনাথপুর', 'Ramnathpur'), W('শানেরহাট', 'Shanerhat'), W('টুকুরিয়া', 'Tukuria')],
  },
  {
    ...U('পীরগাছা', 'Pirgachha'),
    unions: [W('আনন্দনগর', 'Anandanagar'), W('ছাওলা', 'Chhaola'), W('ইটাকুমারী', 'Itakumari'), W('কৈকুড়ী', 'Kaikuri'), W('কল্যাণী', 'Kalyani'), W('কান্দি', 'Kandi'), W('পারুল', 'Parul'), W('পীরগাছা', 'Pirgacha'), W('তাম্বুলপুর', 'Tambulpur')],
  },
  {
    ...U('তারাগঞ্জ', 'Taraganj'),
    unions: [W('আলমপুর', 'Alampur'), W('একরচালী', 'Ekarchali'), W('হারিয়ারকুটি', 'Hariarkuti'), W('কুর্শা', 'Kursha'), W('সয়ার', 'Sayar')],
  },
];

// ---------- location helpers ----------
export function upazilasFor(district) {
  if (district !== 'Rangpur') return [];
  return RANGPUR_UPZILAS.map(u => ({ bn: u.bn, en: u.en }));
}
export function unionsFor(district, upazila) {
  if (district !== 'Rangpur') return [];
  const u = RANGPUR_UPZILAS.find(x => x.bn === upazila || x.en === upazila);
  return u ? u.unions : [];
}
export const lname = (obj) => lang() === 'bn' ? obj.bn : obj.en;

// ---------- emergency numbers ----------
export const EMERGENCY_NUMBERS = [
  { label: 'National Emergency', labelBn: 'জাতীয় জরুরি নম্বর', phone: '999', icon: 'alert' },
  { label: 'Health Advice Hotline', labelBn: 'স্বাস্থ্য পরামর্শ হটলাইন', phone: '16263', icon: 'health' },
  { label: 'Blood Donation Helpline', labelBn: 'রক্তদান হেল্পলাইন', phone: '+8801712345678', icon: 'drop' },
];

// ---------- hospital / clinic / lab directory (real Rangpur data) ----------
// type: 'govt' | 'hospital' | 'clinic' | 'lab'
const E = (name, nameEn, type, area, areaBn, address, phones) => ({ name, nameEn, type, area, areaBn, address, phones });

export const DIRECTORY = [
  // --- Government (upazila-based) ---
  E('রংপুর মেডিকেল কলেজ হাসপাতাল', 'Rangpur Medical College Hospital', 'govt', 'রংপুর সদর', 'Rangpur Sadar', 'রংপুর-দিনাজপুর মহাসড়ক, ক্যান্টনমেন্ট, রংপুর - ৫৪০০', ['01881-907348', '0521-62288']),
  E('উপজেলা স্বাস্থ্য কমপ্লেক্স, রংপুর সদর', 'Upazila Health Complex, Rangpur Sadar', 'govt', 'রংপুর সদর', 'Rangpur Sadar', 'রংপুর সদর', []),
  E('উপজেলা স্বাস্থ্য কমপ্লেক্স, গংগাচড়া', 'Upazila Health Complex, Gangachara', 'govt', 'গঙ্গাচড়া', 'Gangachara', 'গঙ্গাচড়া', []),
  E('উপজেলা স্বাস্থ্য কমপ্লেক্স, কাউনিয়া', 'Upazila Health Complex, Kaunia', 'govt', 'কাউনিয়া', 'Kaunia', 'কাউনিয়া', []),
  E('উপজেলা স্বাস্থ্য কমপ্লেক্স, পীরগাছা', 'Upazila Health Complex, Pirgachha', 'govt', 'পীরগাছা', 'Pirgachha', 'পীরগাছা', []),
  E('উপজেলা স্বাস্থ্য কমপ্লেক্স, পীরগঞ্জ', 'Upazila Health Complex, Pirganj', 'govt', 'পীরগঞ্জ', 'Pirganj', 'পীরগঞ্জ', []),
  E('উপজেলা স্বাস্থ্য কমপ্লেক্স, বদরগঞ্জ', 'Upazila Health Complex, Badarganj', 'govt', 'বদরগঞ্জ', 'Badarganj', 'বদরগঞ্জ', []),
  E('উপজেলা স্বাস্থ্য কমপ্লেক্স, মিঠাপুকুর', 'Upazila Health Complex, Mithapukur', 'govt', 'মিঠাপুকুর', 'Mithapukur', 'মিঠাপুকুর (৫০ শয্যা)', []),
  E('উপজেলা স্বাস্থ্য কমপ্লেক্স, তারাগঞ্জ', 'Upazila Health Complex, Taraganj', 'govt', 'তারাগঞ্জ', 'Taraganj', 'তারাগঞ্জ', []),
  // --- Private hospitals ---
  E('ডক্টরস কমিউনিটি হাসপাতাল', 'Doctors Community Hospital', 'hospital', 'রংপুর সদর', 'Rangpur Sadar', 'গঙ্গাচড়া রোড, রংপুর - ৫৪০০', ['01701-264704', '01717-292458']),
  E('প্রাইম মেডিকেল কলেজ হাসপাতাল', 'Prime Medical College Hospital', 'hospital', 'রংপুর সদর', 'Rangpur Sadar', 'রংপুর সদর', ['01730-033166']),
  E('রংপুর কমিউনিটি মেডিকেল কলেজ ও হাসপাতাল', 'Rangpur Community Medical College & Hospital', 'hospital', 'রংপুর সদর', 'Rangpur Sadar', 'মেডিকেল কলেজ পূর্ব গেট, রংপুর', ['0258-9966367', '01730033200']),
  E('রংপুর সেন্ট্রাল হাসপাতাল', 'Rangpur Central Hospital', 'hospital', 'রংপুর সদর', 'Rangpur Sadar', 'মৌচাক কমপ্লেক্স, মেডিকেল মোড়, জেল রোড, ধাপ, রংপুর', ['0521-52126', '01759-063634']),
  E('রংপুর জেনারেল হাসপাতাল', 'Rangpur General Hospital', 'hospital', 'রংপুর সদর', 'Rangpur Sadar', 'ধাপ, জেল রোড, রংপুর - ৫৪০০', ['0521-55843', '01750-722667']),
  E('ইসলামী ব্যাংক কমিউনিটি হাসপাতাল', 'Islami Bank Community Hospital', 'hospital', 'রংপুর সদর', 'Rangpur Sadar', 'জেল রোড, ধাপ রোড, রংপুর - ৫৪০০', ['01750-908297']),
  E('লাইফ লাইন কমিউনিটি হাসপাতাল', 'Life Line Community Hospital', 'hospital', 'রংপুর সদর', 'Rangpur Sadar', 'বাংলাদেশ ব্যাংক মোড়, গঙ্গাচড়া রোড, রংপুর', ['01317-183574', '01719-257461']),
  E('সুস্বাস্থ্য হাসপাতাল', 'Susastho Hospital', 'hospital', 'রংপুর সদর', 'Rangpur Sadar', 'ধাপ জেল রোড, রংপুর', ['01839-402639', '01717-974489']),
  E('পপুলার হাসপাতাল', 'Popular Hospital', 'hospital', 'রংপুর সদর', 'Rangpur Sadar', 'সড়ক ভবন অফিসের বিপরীতে, রংপুর-দিনাজপুর হাইওয়ে, রংপুর - ৫৪০০', ['0521-63950']),
  E('হলি কেয়ার হাসপাতাল', 'Holly Care Hospital', 'hospital', 'রংপুর সদর', 'Rangpur Sadar', 'বাড়ি-৩৯, রোড-২, আর.কে. রোড, ইসলামবাগ, রংপুর - ৫৪০০', ['01704-698160']),
  E('ইউনাইটেড হাসপাতাল', 'United Hospital', 'hospital', 'রংপুর সদর', 'Rangpur Sadar', 'মেডিকেল মোড় জামে মসজিদ, মেডিকেল মোড়, রংপুর - ৫৪০০', ['01303-137922']),
  E('রংপুর স্পেশালাইজড হাসপাতাল', 'Rangpur Specialized Hospital', 'hospital', 'রংপুর সদর', 'Rangpur Sadar', 'আলমি বাড়ি, ধাপ জেল রোড, রংপুর', ['01319-998561']),
  E('গ্লোবাল আই অ্যান্ড হেলথ কেয়ার হাসপাতাল', 'Global Eye & Health Care Hospital', 'hospital', 'রংপুর সদর', 'Rangpur Sadar', 'গঙ্গাচড়া রোড, বাংলাদেশ ব্যাংক মোড়, রংপুর', ['01701-676450']),
  E('রংপুর হেলথ সিটি স্পেশালাইজড হাসপাতাল', 'Rangpur Health City Specialized Hospital', 'hospital', 'রংপুর সদর', 'Rangpur Sadar', 'শিমুলতলী রোড, রংপুর', ['01711-992732']),
  E('রাহিন জেনারেল হাসপাতাল ও রিয়াদ ডায়াগনস্টিক সেন্টার', 'Rahin General Hospital', 'hospital', 'রংপুর সদর', 'Rangpur Sadar', '৮ তোলা জামে মসজিদ, রংপুর', ['01712-879212']),
  E('আরসি হাসপাতাল ও ডায়াগনস্টিক সেন্টার', 'RC Hospital & Diagnostic Center', 'hospital', 'রংপুর সদর', 'Rangpur Sadar', 'ধাপ, রংপুর', ['01322-892828', '01737-373496']),
  E('প্রাইম মেডিকেল কলেজ হাসপাতাল (পীরজাবাদ শাখা)', 'Prime Medical College Hospital (Pirzabad)', 'hospital', 'বদরগঞ্জ', 'Badarganj', 'পীরজাবাদ, বদরগঞ্জ রোড, রংপুর', []),
  // --- Clinics ---
  E('জনতা ক্লিনিক ও নার্সিং সেন্টার', 'Janata Clinic & Nursing Center', 'clinic', 'রংপুর সদর', 'Rangpur Sadar', 'সিটি বাইপাস, রংপুর', ['01715-057530']),
  E('উত্তরা ক্লিনিক', 'Uttara Clinic', 'clinic', 'রংপুর সদর', 'Rangpur Sadar', 'জেল রোড, ধাপ, রংপুর', ['01712-787962']),
  E('নিউ রংপুর ক্লিনিক', 'New Rangpur Clinic', 'clinic', 'রংপুর সদর', 'Rangpur Sadar', 'রংপুর সদর', ['01581-651896']),
  // --- Diagnostic labs ---
  E('জেনারেল ডায়াগনস্টিক সেন্টার', 'General Diagnostic Center', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'রংপুর কমপ্লেক্স, ধাপ জেল রোড, রংপুর', ['01717-276708', '01773-896360']),
  E('হেলথ প্লাস ডায়াগনস্টিক', 'Health Plus Diagnostic', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'জেল রোড, মেডিকেল মোড়, রংপুর', ['01319-998514', '01751-990179']),
  E('প্রাইম ডায়াগনস্টিক সেন্টার', 'Prime Diagnostic Center', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'জেল রোড, ধাপ, রংপুর সদর, রংপুর - ৫৪০০', ['01762-728718']),
  E('আপডেট ডায়াগনস্টিক', 'Update Diagnostic', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'রংপুর-দিনাজপুর হাইওয়ে, জেল রোড, রংপুর - ৫৪০০', ['01971-555555']),
  E('এশিয়া ডায়াগনস্টিক সেন্টার', 'Asia Diagnostic Center', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'রংপুর কমপ্লেক্স, ধাপ মোড়, রংপুর', ['01755-660654', '01714-973650']),
  E('অ্যাপোলো ডায়াগনস্টিক অ্যান্ড ইমেজিং সেন্টার', 'Apollo Diagnostic & Imaging Center', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'জেল রোড, ধাপ, রংপুর', ['01733-008088']),
  E('পপুলার ডায়াগনস্টিক সেন্টার', 'Popular Diagnostic Center', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'ধাপ, জেল রোড, রংপুর - ৫৪০০', ['09666-787813', '09613-787813']),
  E('পিপল কেয়ার ডায়াগনস্টিক সেন্টার', 'People Care Diagnostic Center', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'হাতিল টাওয়ার, ধাপ জেল রোড, রংপুর', ['01734-074462', '01778-756715']),
  E('সেবা প্যাথলজিক্যাল সেন্টার', 'Sheba Pathological Center', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'ধাপ, মেডিকেল মোড়, জেল রোড, রংপুর', ['01322-932525', '01845-980096']),
  E('বেগম ডায়াগনস্টিক সেন্টার', 'Begum Diagnostic Center', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'শ্যামলী লেন, রংপুর', ['01750-783000']),
  E('রংপুর ডিজিটাল ডায়াগনস্টিক সেন্টার', 'Rangpur Digital Diagnostic Center', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'মেডিকেল মোড়, ধাপ, রংপুর', ['01317-183426', '01713-747688']),
  E('মেঘনা ডিজিটাল ডায়াগনস্টিক সেন্টার', 'Meghna Digital Diagnostic Center', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'রংপুর সদর', ['01765-906629']),
  E('লাইফ ডায়াগনস্টিক সেন্টার', 'Life Diagnostic Center', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'ধাপ, মেডিকেল মোড়, রংপুর', ['01740-946511']),
  E('ক্রিসেন্ট ডায়াগনস্টিক কমপ্লেক্স', 'Crescent Diagnostic Complex', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'ধাপ রোড, রংপুর - ৫৪০০', ['01333-172177', '0521-65707']),
  E('হার্টবিট ডায়াগনস্টিক সেন্টার', 'Heartbeat Diagnostic Center', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'কাকলি লেন, ধাপ, জেল রোড, রংপুর', ['0521525812']),
  E('রংধনু ডায়াগনস্টিক সেন্টার', 'Rongdhonu Diagnostic Center', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'রংপুর-দিনাজপুর হাইওয়ে, রংপুর', ['01783-166051', '01400-884292']),
  E('পেশেন্ট ডায়াগনস্টিক সেন্টার', 'Patient Diagnostic Center', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'গুড হেলথ হাসপাতালের পাশে, ধাপ, রংপুর - ৫৪০০', ['01731-481889']),
  E('রংপুর মেট্রোপলিটন ডায়াগনস্টিক সেন্টার', 'Rangpur Metropolitan Diagnostic Center', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'আলমি বাড়ি, জেল রোড, রংপুর', ['01729-612307']),
  E('সান ডায়াগনস্টিক সেন্টার', 'Sun Diagnostic Center', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'মরিয়ম এলাহী সরণি, মেডিকেল মোড়, রংপুর - ৫৪০০', ['01756-633828']),
  E('সনো ল্যাব', 'Sono Lab', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'ধাপ রোড, রংপুর - ৫৪০০', ['0521-65864']),
  E('ইকো ডায়াগনস্টিক সেন্টার', 'Echo Diagnostic Center', 'lab', 'রংপুর সদর', 'Rangpur Sadar', 'শহীদ মুক্তার এলাহী চত্বর, আর কে রোড, রংপুর - ৫৪০০', ['01766-212947']),
];

// For blood banks specifically (component-separation capable centers)
export const BLOOD_BANK_NUMBERS = [
  { name: 'Divisional Blood Bank, Rangpur', nameBn: 'বিভাগীয় ব্লাড ব্যাংক, রংপুর', phone: '0521-62288' },
  { name: 'Rangpur Medical College Hospital Blood Bank', nameBn: 'রংপুর মেডিকেল কলেজ হাসপাতাল ব্লাড ব্যাংক', phone: '01881-907348' },
];