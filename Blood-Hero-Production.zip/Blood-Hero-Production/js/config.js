// ============================================================
// Blood Hero — App Configuration
// ============================================================
// For production, inject config via a build step or inline script
// setting window.__CONFIG__ before this module loads.
// ============================================================

export const APP = {
  name: 'Blood Hero',
  nameBn: 'ব্লাড হিরো',
  tagline: 'Every Drop Saves a Life',
  taglineBn: 'প্রতিটি ফোঁটা জীবন বাঁচায়',
  version: '2.0.0',
  creator: 'Junayed',
  creatorFull: 'Junayed Islam',
  creatorEmail: 'junayed.islam.lemon.18@gmail.com',
  facebookUrl: 'https://www.facebook.com/junayed.limon.18',
};

const runtime = (typeof window !== 'undefined' && window.__CONFIG__) || {};
export const FIREBASE_CONFIG = runtime.FIREBASE_CONFIG || {
  apiKey: 'AIzaSyCG5iTMLTSshPKajWZpDymIX6hrdXHO4Ks',
  authDomain: 'blood-hero-2efa3.firebaseapp.com',
  projectId: 'blood-hero-2efa3',
  storageBucket: 'blood-hero-2efa3.firebasestorage.app',
  messagingSenderId: '143079323202',
  appId: '1:143079323202:web:1456fc93c6106f87f11fdb',
  measurementId: 'G-MLMJZVS8PW',
};

// Blood groups used across the app
export const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'];

// LocalStorage keys
export const LS = {
  lang: 'bh_lang',
  theme: 'bh_theme',
  session: 'bh_session',
  cache: 'bh_cache_',
};
