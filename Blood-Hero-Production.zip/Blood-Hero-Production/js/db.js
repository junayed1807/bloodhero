// Blood Hero — Data layer: Firebase Firestore with localStorage fallback.
// All reads/writes go through this module; if Firebase is unreachable or
// unconfigured, the app automatically runs in offline demo mode.
import { FIREBASE_CONFIG, LS, BLOOD_GROUPS } from './config.js';
import { daysUntilEligible, nextEligibleDate, isEligible, MIN_AGE, MAX_AGE, MIN_WEIGHT_KG, INTERVAL_DAYS_MALE, INTERVAL_DAYS_FEMALE } from './lib/eligibility.js';
import { rateLimit } from './lib/rateLimit.js';

let db = null;
let fire = null;
export let online = false;

// ---------- init ----------
export async function initDb() {
  try {
    const appMod = await import('https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js');
    const fsMod = await import('https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js');
    const app = appMod.initializeApp(FIREBASE_CONFIG);
    db = fsMod.getFirestore(app);
    fire = fsMod;
    // quick connectivity probe
    await fsMod.getDocs(fsMod.query(fsMod.collection(db, 'requests'), fsMod.limit(1)));
    online = true;
  } catch (e) {
    console.warn('[BloodHero] Firestore offline — demo mode.', e.message || e);
    online = false;
  }
  return online;
}

// ---------- helpers ----------
const lsGet = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
const lsSet = (k, v) => localStorage.setItem(k, JSON.stringify(v));
const uid = () => 'id_' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);



// ---------- demo seed data (offline mode) ----------
// Per-collection seeding: a collection is seeded ONLY if absent, so existing
// user/demo data is never overwritten on upgrade.
function seedLocal() {
  const seedIf = (name, data) => { if (lsGet(LS.cache + name, null) === null) lsSet(LS.cache + name, data); };
  const donors = [
    { id: uid(), name: 'জুনায়েদ ইসলাম', bloodGroup: 'O+', phone: '+8801712345678', district: 'Rangpur', upazila: 'রংপুর সদর', union: 'মমিনপুর', available: true, lastDonation: '2025-12-12', totalDonations: 12, livesSaved: 36, role: 'admin', emergencyContact: '+8801712345679', weight: 68, age: 26, nidStatus: 'approved', createdAt: Date.now() },
    { id: uid(), name: 'Sarah Ahmed', bloodGroup: 'A+', phone: '+8801812345678', district: 'Dhaka', upazila: 'Dhanmondi', available: true, lastDonation: '2025-11-02', totalDonations: 8, livesSaved: 24, role: 'donor', emergencyContact: '+8801812345679', weight: 60, age: 29, nidStatus: 'approved', createdAt: Date.now() },
    { id: uid(), name: 'রাহাত হোসেন', bloodGroup: 'B-', phone: '+8801912345678', district: 'Rangpur', upazila: 'বদরগঞ্জ', union: 'গোপালপুর', available: false, lastDonation: '2026-06-20', totalDonations: 5, livesSaved: 15, role: 'donor', weight: 72, age: 31, createdAt: Date.now() },
    { id: uid(), name: 'Maria Sultana', bloodGroup: 'O-', phone: '+8801612345678', district: 'Rangpur', upazila: 'মিঠাপুকুর', union: 'রাণীপুকুর', available: true, lastDonation: '2025-10-05', totalDonations: 15, livesSaved: 45, role: 'donor', nidStatus: 'approved', weight: 55, age: 24, createdAt: Date.now() },
    { id: uid(), name: 'Tanvir Hasan', bloodGroup: 'AB+', phone: '+8801512345678', district: 'Sylhet', upazila: 'Zindabazar', available: true, lastDonation: null, totalDonations: 0, livesSaved: 0, role: 'donor', weight: 63, age: 22, createdAt: Date.now() },
    { id: uid(), name: 'Nusrat Jahan', bloodGroup: 'A-', phone: '+8801412345678', district: 'Rangpur', upazila: 'গঙ্গাচড়া', union: 'গজঘণ্টা', available: true, lastDonation: '2026-01-15', totalDonations: 4, livesSaved: 12, role: 'donor', nidStatus: 'pending', weight: 58, age: 27, createdAt: Date.now() },
    { id: uid(), name: 'Mahmudul Karim', bloodGroup: 'O+', phone: '+8801312345678', district: 'Rangpur', upazila: 'পীরগঞ্জ', union: 'পীরগঞ্জ', available: true, lastDonation: '2026-02-20', totalDonations: 2, livesSaved: 6, role: 'donor', weight: 70, age: 33, createdAt: Date.now() },
  ];
  const requests = [
    { id: uid(), patientName: 'Abdul Karim', bloodGroup: 'O-', units: 2, hospital: 'রংপুর মেডিকেল কলেজ হাসপাতাল', district: 'Rangpur', upazila: 'রংপুর সদর', union: 'মমিনপুর', contact: '+8801711002233', urgency: 'critical', component: 'Whole Blood', status: 'pending', note: 'অস্ত্রোপচার আগামীকাল সকালে — জরুরি', createdAt: Date.now() - 720000 },
    { id: uid(), patientName: 'Fatema Begum', bloodGroup: 'B+', units: 1, hospital: 'রংপুর মেডিকেল কলেজ হাসপাতাল', district: 'Rangpur', upazila: 'রংপুর সদর', contact: '+8801711223344', urgency: 'normal', component: 'Whole Blood', status: 'pending', note: 'Thalassemia patient, monthly transfusion', createdAt: Date.now() - 3600000 },
    { id: uid(), patientName: 'কামরুল ইসলাম', bloodGroup: 'A+', units: 3, hospital: 'বিভাগীয় ব্লাড ব্যাংক, রংপুর', district: 'Rangpur', upazila: 'রংপুর সদর', union: 'খলেয়া', contact: '+8801811334455', urgency: 'critical', component: 'Platelets', status: 'pending', note: 'সড়ক দুর্ঘটনা, জরুরী', createdAt: Date.now() - 5400000 },
    { id: uid(), patientName: 'Selina Akter', bloodGroup: 'O+', units: 2, hospital: 'রংপুর জেনারেল হাসপাতাল', district: 'Rangpur', upazila: 'রংপুর সদর', contact: '+8801911445566', urgency: 'urgent', component: 'Whole Blood', status: 'accepted', acceptedBy: 'Sarah Ahmed', note: 'Delivery scheduled', createdAt: Date.now() - 86400000 },
    { id: uid(), patientName: 'রাশেদা খাতুন', bloodGroup: 'AB-', units: 1, hospital: 'ডক্টরস কমিউনিটি হাসপাতাল', district: 'Rangpur', upazila: 'রংপুর সদর', contact: '+8801511005566', urgency: 'critical', component: 'RBC', status: 'pending', note: 'Surgery tomorrow — rare group', createdAt: Date.now() - 900000 },
  ];
  const notifs = [
    { id: uid(), type: 'emergency', textKey: 'notifNewRequest', body: 'O- needed at রংপুর মেডিকেল — urgent', read: false, createdAt: Date.now() - 600000 },
    { id: uid(), type: 'accepted', textKey: 'notifAccepted', body: 'Selina Akter — রংপুর জেনারেল হাসপাতাল', read: false, createdAt: Date.now() - 7200000 },
    { id: uid(), type: 'system', textKey: 'notifUpdate', body: 'Blood Hero v2.0 — Need Map, Directory & more', read: true, createdAt: Date.now() - 172800000 },
  ];
  const centers = [
    { id: uid(), name: 'Dhaka Blood Center', district: 'Dhaka', upazila: 'Dhanmondi', open: true, nextSlot: '2:30 PM', team: true, type: 'blood_center', phone: '+8801712345678' },
    { id: uid(), name: 'Red Crescent Blood Center', district: 'Dhaka', upazila: 'Motijheel', open: true, nextSlot: '4:00 PM', team: true, type: 'blood_center', phone: '+8801812345678' },
    { id: uid(), name: 'Divisional Blood Bank, Rangpur', district: 'Rangpur', upazila: 'Sadar', open: true, nextSlot: 'Tomorrow 10:00 AM', team: false, type: 'blood_center', phone: '0521-62288' },
    { id: uid(), name: 'Chattogram Blood Bank', district: 'Chattogram', upazila: 'Agrabad', open: false, nextSlot: 'Mon 9:00 AM', team: true, type: 'blood_center', phone: '+8801912345678' },
    { id: uid(), name: 'Rangpur Medical College Hospital', district: 'Rangpur', upazila: 'Cantonment', open: true, nextSlot: '24/7 Emergency', team: true, type: 'hospital', phone: '01881-907348' },
    { id: uid(), name: 'Prime Medical College Hospital', district: 'Rangpur', upazila: 'Sadar', open: true, nextSlot: '24/7 Emergency', team: true, type: 'hospital', phone: '01730-033166' },
    { id: uid(), name: 'Rangpur Community Medical College Hospital', district: 'Rangpur', upazila: 'Medical College', open: true, nextSlot: '24/7 Emergency', team: true, type: 'hospital', phone: '0258-9966367' },
    { id: uid(), name: 'Rangpur Central Hospital', district: 'Rangpur', upazila: 'Mouchak', open: true, nextSlot: '24/7 Emergency', team: true, type: 'hospital', phone: '0521-52126' },
    { id: uid(), name: 'Popular Hospital, Rangpur', district: 'Rangpur', upazila: 'Dinajpur Highway', open: true, nextSlot: '24/7 Emergency', team: true, type: 'hospital', phone: '0521-63950' },
    { id: uid(), name: 'Rangpur General Hospital', district: 'Rangpur', upazila: 'Jel Road', open: true, nextSlot: '24/7 Emergency', team: true, type: 'hospital', phone: '0521-55843' },
    { id: uid(), name: 'Islami Bank Community Hospital', district: 'Rangpur', upazila: 'Jel Road', open: true, nextSlot: '24/7 Emergency', team: true, type: 'hospital', phone: '01750-908297' },
    { id: uid(), name: 'Life Line Community Hospital', district: 'Rangpur', upazila: 'Gangachara Road', open: true, nextSlot: '24/7 Emergency', team: true, type: 'hospital', phone: '01317-183574' },
    { id: uid(), name: 'Swasthya Hospital, Rangpur', district: 'Rangpur', upazila: 'Jel Road', open: true, nextSlot: '24/7 Emergency', team: true, type: 'hospital', phone: '01839-402639' },
    { id: uid(), name: 'General Diagnostic Centre', district: 'Rangpur', upazila: 'Jel Road', open: true, nextSlot: '9:00 AM - 9:00 PM', team: false, type: 'diagnostic', phone: '01717-276708' },
    { id: uid(), name: 'Health Plus Diagnostic', district: 'Rangpur', upazila: 'Medical Mor', open: true, nextSlot: '8:00 AM - 10:00 PM', team: false, type: 'diagnostic', phone: '01319-998514' },
    { id: uid(), name: 'Prime Diagnostic Centre', district: 'Rangpur', upazila: 'Sadar', open: true, nextSlot: '8:00 AM - 9:00 PM', team: false, type: 'diagnostic', phone: '01762-728718' },
    { id: uid(), name: 'Apollo Diagnostic & Imaging', district: 'Rangpur', upazila: 'Jel Road', open: true, nextSlot: '24/7 Service', team: false, type: 'diagnostic', phone: '01733-008088' },
    { id: uid(), name: 'Popular Diagnostic Centre', district: 'Rangpur', upazila: 'Sadar', open: true, nextSlot: '7:00 AM - 11:00 PM', team: false, type: 'diagnostic', phone: '09666-787813' },
    { id: uid(), name: 'City Lab & Consultation Centre', district: 'Rangpur', upazila: 'Shyamoli Lane', open: true, nextSlot: '8:00 AM - 9:00 PM', team: false, type: 'diagnostic', phone: '01970-050313' },
    { id: uid(), name: 'Rangpur Digital Diagnostic Centre', district: 'Rangpur', upazila: 'Medical Mor', open: true, nextSlot: '8:00 AM - 10:00 PM', team: false, type: 'diagnostic', phone: '01317-183426' },
    { id: uid(), name: 'Life Diagnostic Centre', district: 'Rangpur', upazila: 'Medical Mor', open: true, nextSlot: '8:00 AM - 9:00 PM', team: false, type: 'diagnostic', phone: '01740-946511' },
  ];
  seedIf('donors', donors);
  seedIf('requests', requests);
  seedIf('notifications', notifs);
  seedIf('centers', centers);
  seedIf('audit', []);
  // --- social/verification v2 collections (empty by default, demo-safe) ---
  seedIf('nidVerifications', []);
  seedIf('donations', []);
  seedIf('reviews', []);
  seedIf('reactions', []);
  seedIf('verifyRequests', []);
  // --- v2.1 upgrade: donor responses + family blood-group profiles ---
  seedIf('responses', []);
  seedIf('families', []);
  // --- v2.2: health, matches, badges, referrals ---
  seedIf('health_declarations', []);
  seedIf('request_matches', []);
  seedIf('badges', []);
  seedIf('user_badges', []);
  seedIf('referrals', []);
}

// ---------- generic collection access ----------
async function col(name) {
  if (online) {
    const snap = await fire.getDocs(fire.collection(db, name));
    const arr = [];
    snap.forEach(d => arr.push({ id: d.id, ...d.data() }));
    return arr;
  }
  seedLocal();
  return lsGet(LS.cache + name, []);
}
async function addDocTo(name, data) {
  const rec = { ...data, createdAt: data.createdAt ?? Date.now() };
  if (online) {
    const ref = await fire.addDoc(fire.collection(db, name), rec);
    return { id: ref.id, ...rec };
  }
  seedLocal();
  const arr = lsGet(LS.cache + name, []);
  rec.id = uid();
  arr.unshift(rec);
  lsSet(LS.cache + name, arr);
  return rec;
}
async function updateDocIn(name, id, patch) {
  if (online) { await fire.updateDoc(fire.doc(db, name, id), patch); return; }
  const arr = lsGet(LS.cache + name, []).map(x => x.id === id ? { ...x, ...patch } : x);
  lsSet(LS.cache + name, arr);
}
async function deleteDocFrom(name, id) {
  if (online) { await fire.deleteDoc(fire.doc(db, name, id)); return; }
  lsSet(LS.cache + name, lsGet(LS.cache + name, []).filter(x => x.id !== id));
}

// ---------- public API ----------
export const Donors = {
  list: () => col('donors'),
  async search({ group = '', district = '', upazila = '', availableOnly = false, q = '' }) {
    let arr = await col('donors');
    arr = arr.filter(d => d.showInSearch !== false);
    if (group) arr = arr.filter(d => d.bloodGroup === group);
    if (district) arr = arr.filter(d => (d.district || '').toLowerCase().includes(district.toLowerCase()));
    if (upazila) arr = arr.filter(d => (d.upazila || '').toLowerCase().includes(upazila.toLowerCase()));
    if (availableOnly) arr = arr.filter(d => d.available);
    if (q) arr = arr.filter(d => (d.name || '').toLowerCase().includes(q.toLowerCase()) || (d.phone || '').includes(q));
    return arr;
  },
  add: d => addDocTo('donors', d),
  update: (id, p) => updateDocIn('donors', id, p),
  remove: id => deleteDocFrom('donors', id),
};

export const Requests = {
  list: () => col('requests').then(a => a.sort((x, y) => (y.createdAt || 0) - (x.createdAt || 0))),
  add: r => addDocTo('requests', { status: 'pending', ...r }),
  setStatus: (id, status, extra = {}) => updateDocIn('requests', id, { status, ...extra }),
  remove: id => deleteDocFrom('requests', id),
};

export const Centers = { list: () => col('centers') };

export const Notifications = {
  list: () => col('notifications').then(a => a.sort((x, y) => (y.createdAt || 0) - (x.createdAt || 0))),
  add: n => addDocTo('notifications', { read: false, ...n }),
  markAllRead: async () => {
    const arr = await col('notifications');
    await Promise.all(arr.filter(n => !n.read).map(n => updateDocIn('notifications', n.id, { read: true })));
  },
};

export const Audit = {
  list: () => col('audit').then(a => a.sort((x, y) => (y.at || 0) - (x.at || 0))),
  log: (actor, action, target) => addDocTo('audit', { actor, action, target, at: Date.now() }),
};

// ---------- NEW v2: NID verification, donations (proof + recipient confirm), reviews, reactions ----------
export const Donations = {
  list: () => col('donations').then(a => a.sort((x, y) => (y.createdAt || 0) - (x.createdAt || 0))),
  add: d => addDocTo('donations', { status: 'pending_verification', proofUploaded: !!d.proofUrl, recipientId: d.recipientId || null, recipientConfirmed: false, adminApproved: false, ...d }),
  update: (id, p) => updateDocIn('donations', id, p),
  remove: id => deleteDocFrom('donations', id),
  forDonor: async (donorId) => (await Donations.list()).filter(d => d.donorId === donorId),
  verifiedCount: async (donorId) => (await Donations.list()).filter(d => d.donorId === donorId && d.status === 'verified').length,
};

export const NidVerifications = {
  list: () => col('nidVerifications').then(a => a.sort((x, y) => (y.createdAt || 0) - (x.createdAt || 0))),
  add: n => addDocTo('nidVerifications', { status: 'pending', ...n }),
  update: (id, p) => updateDocIn('nidVerifications', id, p),
  forUser: async (userId) => (await NidVerifications.list()).find(n => n.userId === userId),
};

export const Reviews = {
  list: () => col('reviews').then(a => a.sort((x, y) => (y.createdAt || 0) - (x.createdAt || 0))),
  add: r => addDocTo('reviews', { love: [], comments: [], ...r }),
  remove: id => deleteDocFrom('reviews', id),
  react: async (reviewId, userId) => {
    if (online) { /* client-side toggle handled in page; server version uses arrayUnion/arrayRemove */ return; }
    const arr = lsGet(LS.cache + 'reviews', []);
    const r = arr.find(x => x.id === reviewId);
    if (!r) return { loved: false };
    r.love = r.love || [];
    const i = r.love.indexOf(userId);
    if (i >= 0) r.love.splice(i, 1); else r.love.push(userId);
    lsSet(LS.cache + 'reviews', arr);
    return { loved: i < 0 };
  },
};

export const AdminTasks = {
  list: () => col('verifyRequests').then(a => a.sort((x, y) => (y.createdAt || 0) - (x.createdAt || 0))),
  add: t => addDocTo('verifyRequests', { status: 'open', ...t }),
  update: (id, p) => updateDocIn('verifyRequests', id, p),
};

// ---------- v2.1: one-tap "I can donate" responses on blood requests ----------
export const Responses = {
  list: () => col('responses').then(a => a.sort((x, y) => (y.createdAt || 0) - (x.createdAt || 0))),
  add: r => addDocTo('responses', r),
  remove: id => deleteDocFrom('responses', id),
  forRequest: async (requestId) => (await Responses.list()).filter(r => r.requestId === requestId),
  forDonor: async (donorId) => (await Responses.list()).filter(r => r.donorId === donorId),
};

// ---------- v2.1: family blood-group profiles (emergency contacts) ----------
export const Families = {
  list: () => col('families').then(a => a.sort((x, y) => (y.createdAt || 0) - (x.createdAt || 0))),
  add: m => addDocTo('families', m),
  remove: id => deleteDocFrom('families', id),
  forUser: async (userId) => (await Families.list()).filter(f => f.userId === userId),
};

// ---------- v2: health declarations ----------
export const HealthDeclarations = {
  list: () => col('health_declarations').then(a => a.sort((x, y) => (y.createdAt || 0) - (x.createdAt || 0))),
  add: d => addDocTo('health_declarations', { validUntil: Date.now() + 7 * 86400000, ...d }),
  forUser: async (userId) => (await HealthDeclarations.list()).filter(h => h.userId === userId),
};

// ---------- v2: request matches ----------
export const RequestMatches = {
  list: () => col('request_matches').then(a => a.sort((x, y) => (y.createdAt || 0) - (x.createdAt || 0))),
  add: m => addDocTo('request_matches', { status: 'notified', ...m }),
  update: (id, p) => updateDocIn('request_matches', id, p),
  forRequest: async (requestId) => (await RequestMatches.list()).filter(m => m.requestId === requestId),
  forDonor: async (donorId) => (await RequestMatches.list()).filter(m => m.donorId === donorId),
};

// ABO/Rh compatibility matrix: compatible groups for a given recipient group
const COMPATIBLE = {
  'O-': ['O-'],
  'O+': ['O-', 'O+'],
  'A-': ['O-', 'A-'],
  'A+': ['O-', 'O+', 'A-', 'A+'],
  'B-': ['O-', 'B-'],
  'B+': ['O-', 'O+', 'B-', 'B+'],
  'AB-': ['O-', 'A-', 'B-', 'AB-'],
  'AB+': ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'],
};

export function compatibleGroups(recipientGroup) {
  return COMPATIBLE[recipientGroup] || [recipientGroup];
}

export function matchScore(donor, request) {
  if (!donor || !request) return 0;
  const compat = compatibleGroups(request.bloodGroup).includes(donor.bloodGroup) ? 20 : 0;
  const avail = donor.available ? 10 : 0;
  const verified = (donor.nidStatus === 'approved' || (donor.totalDonations || 0) >= 5) ? 10 : 0;
  const recent = (Date.now() - (donor.createdAt || 0)) < 30 * 86400000 ? 5 : 0;
  return Math.round(compat + avail + verified + recent);
}

export function createMatchesForRequest(request) {
  return (async () => {
    const donors = await Donors.list();
    const compatible = donors.filter(d => compatibleGroups(request.bloodGroup).includes(d.bloodGroup) && d.available && d.allowBloodRequests !== false);
    const scored = compatible.map(d => ({ donorId: d.id, score: matchScore(d, request) }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 15);
    await Promise.all(scored.map(s => RequestMatches.add({ requestId: request.id, donorId: s.donorId, score: s.score })));
    return scored;
  })();
}

// ---------- v2: badges ----------
export const Badges = {
  list: () => col('badges').then(a => a.sort((x, y) => (y.createdAt || 0) - (x.createdAt || 0))),
  add: b => addDocTo('badges', b),
};
export const UserBadges = {
  list: () => col('user_badges').then(a => a.sort((x, y) => (y.createdAt || 0) - (x.createdAt || 0))),
  add: ub => addDocTo('user_badges', ub),
  forUser: async (userId) => (await UserBadges.list()).filter(ub => ub.userId === userId),
};

// ---------- v2: referrals ----------
export const Referrals = {
  list: () => col('referrals').then(a => a.sort((x, y) => (y.createdAt || 0) - (x.createdAt || 0))),
  add: r => addDocTo('referrals', r),
};

// ---------- privacy / public profile helpers ----------
export function maskPhone(p) {
  const s = String(p || '');
  if (s.length < 7) return '••••••••';
  return s.slice(0, 4) + '••••••' + s.slice(-3);
}

export function publicProfile(donor, viewer) {
  if (!donor) return null;
  const own = viewer && (viewer.uid === donor.id || viewer.phone === donor.phone);
  const admin = viewer && ['admin','org_admin','super_admin','coordinator','org_staff'].includes(viewer.role);
  const hideLoc = !own && !admin && donor.showLocation === false;
  const p = {
    id: donor.id,
    name: donor.name,
    bloodGroup: donor.bloodGroup,
    district: hideLoc ? undefined : donor.district,
    upazila: hideLoc ? undefined : (donor.available && donor.upazila ? donor.upazila : undefined),
    union: hideLoc ? undefined : donor.union,
    available: !!donor.available,
    totalDonations: donor.totalDonations || 0,
    nidStatus: donor.nidStatus,
    createdAt: donor.createdAt,
  };
  if (own || admin) {
    p.phone = donor.phone;
    p.emergencyContact = donor.emergencyContact;
    p.email = donor.email;
    p.address = donor.address;
    p.lastDonation = donor.lastDonation;
    p.weight = donor.weight;
    p.age = donor.age;
    p.gender = donor.gender;
  }
  return p;
}

export { BLOOD_GROUPS, daysUntilEligible, nextEligibleDate, isEligible, MIN_AGE, MAX_AGE, MIN_WEIGHT_KG };

// ---------- v2: verification tokens ----------
const APP_SECRET = 'BloodHero-v2-secret-change-in-production';

export function generateVerifyToken(donorId) {
  const payload = { sub: donorId, iat: Date.now(), exp: Date.now() + 300000 };
  const body = btoa(JSON.stringify(payload)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const sig = btoa(APP_SECRET + body).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  return body + '.' + sig;
}

export function verifyToken(token) {
  try {
    const [body, sig] = token.split('.');
    const expected = btoa(APP_SECRET + body).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    if (sig !== expected) return null;
    const payload = JSON.parse(atob(body.replace(/-/g, '+').replace(/_/g, '/')));
    if (payload.exp < Date.now()) return null;
    return payload;
  } catch { return null; }
}
