// ============================================================
// Blood Hero — API base URL resolution (single source of truth)
// ============================================================
// Resolution order:
//   1. window.__CONFIG__.API_BASE  — injected at deploy time (see DEPLOYMENT.md)
//   2. process.env.API_BASE        — build-time / server-side
//   3. '/api' (same-origin)        — default. The backend serves the frontend in
//                                    dev (localhost:3000) and Vercel proxies /api
//                                    to the backend in production via vercel.json.
// Never hardcode a backend hostname in page code.
// ============================================================

const fromWindow = (typeof window !== 'undefined' && window.__CONFIG__ && window.__CONFIG__.API_BASE) || '';
const fromEnv = (typeof process !== 'undefined' && process.env && process.env.API_BASE) || '';

export const API_BASE = (fromWindow || fromEnv || '/api').replace(/\/+$/, '');

// Absolute origin of the backend (useful for upload/asset URLs). Empty when the
// backend is same-origin.
export const API_ORIGIN = API_BASE.startsWith('http') ? new URL(API_BASE).origin : '';

// Build an absolute request path, keeping same-origin paths untouched.
export function apiUrl(path) {
  const p = String(path || '').startsWith('/') ? path : '/' + path;
  return API_BASE + p;
}