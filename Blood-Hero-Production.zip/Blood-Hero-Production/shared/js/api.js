// Blood Hero — Frontend API Service
// Communicates with the backend API instead of direct Firebase/localStorage

import { API_BASE } from './api-config.js';

let authToken = null;

export function setToken(token) {
  authToken = token;
  if (token) {
    localStorage.setItem('bh_token', token);
  } else {
    localStorage.removeItem('bh_token');
  }
}

export function getToken() {
  if (!authToken) {
    try { authToken = localStorage.getItem('bh_token'); } catch {}
  }
  return authToken;
}

export function clearToken() {
  authToken = null;
  try { localStorage.removeItem('bh_token'); } catch {}
}

async function request(path, options = {}) {
  const token = getToken();
  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers,
  };

  const url = `${API_BASE}${path}`;
  const config = { ...options, headers };

  if (config.body && !(config.body instanceof FormData)) {
    config.body = JSON.stringify(config.body);
    config.headers = headers;
  } else {
    delete config.headers['Content-Type'];
  }

  try {
    const res = await fetch(url, config);
    const data = await res.json();
    
    if (!res.ok) {
      throw new Error(data.error || `HTTP ${res.status}`);
    }
    return data;
  } catch (err) {
    console.error(`API Error [${config.method || 'GET'} ${path}]:`, err.message);
    throw err;
  }
}

export const api = {
  get: (path) => request(path),
  post: (path, body) => request(path, { method: 'POST', body }),
  put: (path, body) => request(path, { method: 'PUT', body }),
  patch: (path, body) => request(path, { method: 'PATCH', body }),
  delete: (path) => request(path, { method: 'DELETE' }),
  
  upload: async (path, formData) => {
    const token = getToken();
    const res = await fetch(`${API_BASE}${path}`, {
      method: 'POST',
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      body: formData,
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Upload failed');
    return data;
  }
};

export default api;
