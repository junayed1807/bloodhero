// Blood Hero — Backend API Client
// Connects the frontend to the backend when available.
// The public app obtains a backend token via the phone-OTP bridge
// (POST /api/auth/user/request-otp + verify-otp), so pages like impact and
// recipient programs read REAL backend data instead of a fake "demo copy".

import { API_BASE } from './api-config.js';
let token = null;
let useBackend = false;

export function setBackendToken(t) {
  token = t;
  if (t) {
    try { localStorage.setItem('bh_backend_token', t); } catch {}
    useBackend = true;
  } else {
    try { localStorage.removeItem('bh_backend_token'); } catch {}
    useBackend = false;
  }
}

export function getBackendToken() {
  if (!token) {
    try { token = localStorage.getItem('bh_backend_token'); } catch {}
  }
  return token;
}

// True only when we hold a token that actually authenticated against the backend.
export function isBackendAvailable() {
  return useBackend && !!getBackendToken();
}

export function enableBackendMode(t) {
  setBackendToken(t);
}

export function disableBackendMode() {
  token = null;
  useBackend = false;
  try { localStorage.removeItem('bh_backend_token'); } catch {}
}

async function backendRequest(path, options = {}) {
  const t = getBackendToken();
  const headers = {
    ...(t ? { Authorization: `Bearer ${t}` } : {}),
    ...options.headers,
  };

  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.error || `HTTP ${res.status}`);
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}

export const backendApi = {
  get: (path) => backendRequest(path),
  post: (path, body) => backendRequest(path, { method: 'POST', body: JSON.stringify(body), headers: { 'Content-Type': 'application/json' } }),
  put: (path, body) => backendRequest(path, { method: 'PUT', body: JSON.stringify(body), headers: { 'Content-Type': 'application/json' } }),
  patch: (path, body) => backendRequest(path, { method: 'PATCH', body: JSON.stringify(body), headers: { 'Content-Type': 'application/json' } }),
  delete: (path) => backendRequest(path, { method: 'DELETE' }),
};

// ---- Public-app phone-OTP bridge ----
// Request an OTP. In demo/log SMS mode the response carries devOtp so the
// flow can complete automatically; in real SMS mode the user types the code.
export async function requestUserOtp(phone) {
  return backendApi.post('/auth/user/request-otp', { phone });
}

// Verify the OTP and store the backend token.
export async function verifyUserOtp(phone, otp) {
  const res = await backendApi.post('/auth/user/verify-otp', { phone, otp });
  if (res.token) setBackendToken(res.token);
  return res;
}

// Convenience: connect the currently logged-in user app user to the backend.
// Returns { status: 'connected' | 'needs_otp', ... }.
// Serialized per phone: concurrent calls (register + impact render) would
// otherwise each request a fresh OTP and delete the other's row, causing a 401.
const _pendingConnects = new Map();
export function connectUserApp(phone) {
  const existing = _pendingConnects.get(phone);
  if (existing) return existing;
  const p = doConnectUserApp(phone).finally(() => _pendingConnects.delete(phone));
  _pendingConnects.set(phone, p);
  return p;
}
async function doConnectUserApp(phone) {
  const req = await requestUserOtp(phone);
  if (req.demo && req.devOtp) {
    const res = await verifyUserOtp(phone, req.devOtp);
    return { status: 'connected', user: res.user };
  }
  return { status: 'needs_otp', expires_in_seconds: req.expires_in_seconds };
}

export default { backendApi, setBackendToken, getBackendToken, isBackendAvailable, enableBackendMode, disableBackendMode, requestUserOtp, verifyUserOtp, connectUserApp };