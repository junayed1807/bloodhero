// Blood Hero — Shared storage utilities
// Handles profile pictures and donation proofs with privacy controls

const PROFILE_PIC_KEY = 'bh_profile_pic_';
const DONATION_PROOF_KEY = 'bh_donation_proof_';

export function saveProfilePicture(userId, base64Data) {
  try {
    localStorage.setItem(PROFILE_PIC_KEY + userId, base64Data);
    return true;
  } catch (e) {
    console.error('Failed to save profile picture:', e);
    return false;
  }
}

export function getProfilePicture(userId) {
  try {
    return localStorage.getItem(PROFILE_PIC_KEY + userId);
  } catch {
    return null;
  }
}

export function removeProfilePicture(userId) {
  try {
    localStorage.removeItem(PROFILE_PIC_KEY + userId);
  } catch {}
}

export function saveDonationProof(donationId, base64Data) {
  try {
    localStorage.setItem(DONATION_PROOF_KEY + donationId, base64Data);
    return true;
  } catch (e) {
    console.error('Failed to save donation proof:', e);
    return false;
  }
}

export function getDonationProof(donationId) {
  try {
    return localStorage.getItem(DONATION_PROOF_KEY + donationId);
  } catch {
    return null;
  }
}

export function validateImageFile(file) {
  const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
  const maxSize = 5 * 1024 * 1024; // 5MB

  if (!allowedTypes.includes(file.type)) {
    return { valid: false, error: 'Invalid file type. Only JPG, PNG, WEBP allowed.' };
  }
  if (file.size > maxSize) {
    return { valid: false, error: 'File too large. Max 5MB.' };
  }
  return { valid: true };
}

export function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
