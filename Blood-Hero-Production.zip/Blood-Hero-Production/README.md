# Blood Hero — ব্লাড হিরো

Connect blood donors with people who need blood across Bangladesh.
**Be a Hero, Save a Life.**

This repository is the **production-ready copy** of the Blood Hero application,
prepared for:

- **Frontend** → Vercel (static, no build step)
- **Backend** → Render (Node/Express)
- **Database** → SQLite today, managed PostgreSQL as the target
  (see `docs/DATABASE-MIGRATION.md`)
- **Storage** → local disk today, secure cloud object storage as the target
- **HTTPS** + custom domain

---

## Features

- Donor directory with blood-group, location, and availability filtering
- Blood request creation + automated matching
- Donation tracking with admin verification and reward badges/points/leaderboard
- NID verification workflow (private documents, admin-approved)
- Hospitals & ambulance directory
- Full admin panel with **Super Admin / Admin / Sub-admin** hierarchy and
  granular permissions
- Activity logs, login history, security events
- PWA (offline shell), Bangla/English i18n, dark/light mode
- QR-based public donor profile

## Architecture

```
User app (static SPA) ──/api/*──▶ Express backend (Render) ──▶ SQLite (→PostgreSQL)
Admin panel (static SPA) ──────────▶ same backend ──────────▶ (secure cloud storage)
Firestore (client-side user records, demo fallback) — legacy data layer for the user app
```

- User app: `index.html` + `js/`, `css/`, `shared/js/` (plain ESM, hash routing, no framework)
- Admin panel: `admin-panel/` (plain ESM, talks to the backend API only)
- Backend: `backend/` (Express 4, `sqlite3`, `bcryptjs`, `jsonwebtoken`)
- PWA: `sw.js`, `manifest.webmanifest` (never caches private/API data)

## Local development

```powershell
# Backend
cd backend
npm install
Copy-Item .env.example .env      # then edit values
npm start                        # http://localhost:3000

# Frontend
# Open index.html via the backend (it serves the root in dev), or use any static
# server. In dev the app resolves /api to localhost:3000.
```

### Health check
`GET http://localhost:3000/health` → `{"status":"ok","service":"blood-hero-api",...}`

## Environment variables

Full reference: `docs/ENVIRONMENT-VARIABLES.md`. Templates:
`backend/.env.example` (backend) and `.env.example` (frontend).

Backend essentials:

| Variable | Notes |
|---|---|
| `NODE_ENV` | `production` in production |
| `JWT_SECRET` | **Required in production**, ≥32 random chars; server fails closed otherwise |
| `DB_PATH` | SQLite path (persistent disk on Render) |
| `CORS_ORIGIN` | Comma-separated allowed origins (empty = same-origin Vercel proxy) |
| `ADMIN_INIT_PHONE/PASSWORD/NAME` | Bootstraps the first production super-admin |
| `SMS_PROVIDER`, `TWILIO_*` | OTP delivery; production fails closed without a real provider |

Frontend: `API_BASE` (default `/api`, resolved same-origin via the Vercel proxy).

## Database

- Current: SQLite (WAL mode), ~35 tables, created idempotently on boot.
- Target: managed PostgreSQL. See `docs/DATABASE-MIGRATION.md` and the read-only
  helper `backend/scripts/migrate-sqlite-to-postgres.js`.
- Backups: `docs/DATABASE-BACKUP-AND-RECOVERY.md` (plan — nothing automated yet).

## Deployment

Step-by-step: **`DEPLOYMENT.md`**. Blueprints: `deploy/render.yaml`,
`deploy/vercel.json`.

## Security

`docs/SECURITY-AUDIT.md` classifies findings by severity. **This copy is not yet
ready for a public production launch**: several CRITICAL/HIGH items (authorization
on request-status changes, admin suspend/activate status mapping, Firestore rules,
NID masking, upload plumbing, real SMS provider) remain open and must be fixed
first. This repository preserves the reference implementation so those fixes can
be applied in controlled, tested changes.

## Repository hygiene

`.gitignore` excludes `node_modules/`, `.env*` (except `.env.example`), `*.db*`,
`logs/`, `uploads/`, and OS/IDE junk. Obsolete test artifacts are archived in
`docs/archive/`. **No real credentials are committed.**