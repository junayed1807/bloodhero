# Blood Hero — Deployment Guide

Step-by-step guide to deploy this project to production.
**Windows-compatible commands.** Placeholders: `YOUR-DOMAIN` (frontend),
`api.YOUR-DOMAIN` (backend). Replace before you actually deploy.

> Nothing is deployed by this guide until you run the steps yourself. No URLs,
> credentials, or test results are assumed.

---

## 1. Create a GitHub repository

Create an empty private repository on GitHub (e.g. `Blood-Hero-Production`).
Do not add a README/license via the wizard (keep it empty to avoid merge conflicts).

## 2. Initialize Git (local)

```powershell
cd "D:\oneplus\fainal blood app\Blood-Hero-Production"
git init
git add .
git status          # inspect — see step 4
```

## 3. Review .gitignore

`.gitignore` (root + `backend/.gitignore`) must keep out:
`node_modules/`, `.env*` (except `.env.example`), `*.db*`, `logs/`, `uploads/*`,
OS/IDE junk. `package-lock.json` stays tracked.

## 4. Verify no secrets

```powershell
git status                        # staged file list
Get-ChildItem -Recurse -File | Where-Object { $_.Name -match '\.(env|pem|key|db|db-wal|db-shm)$' } | Select-Object FullName
```
Expected: only `.env.example` files match; no `.env`, no `*.db*`, no keys.

## 5. Commit

```powershell
git add .
git commit -m "Production-ready Blood Hero copy"
```

## 6. Push to GitHub

```powershell
git remote add origin https://github.com/<you>/Blood-Hero-Production.git
git push -u origin main
```

## 7. Create the PostgreSQL database (when ready)

Pick a managed provider (Render, Neon, Supabase, AWS RDS, ...). Create a database
and note the `DATABASE_URL` connection string. See
`docs/DATABASE-MIGRATION.md` before switching from SQLite.

> **SQLite-first option:** you can ship with SQLite on a persistent disk now and
> migrate later. This guide covers both — choose one path.

## 8. Configure the Render backend

Deploy the `backend/` folder (Root Directory = `backend`), or use the blueprint
`deploy/render.yaml` (Blueprint → New +).

- Runtime: Node
- Build command: `npm install`
- Start command: `npm start`
- Health check path: `/health`
- Persistent disk mounted at `/var/data` (for SQLite; not needed with PostgreSQL)

## 9. Configure environment variables (Render dashboard — never commit)

| Variable | Value |
|---|---|
| `NODE_ENV` | `production` |
| `TRUST_PROXY` | `true` |
| `JWT_SECRET` | random string ≥ 32 chars (`node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`) |
| `DB_PATH` | `/var/data/blood_hero.db` (SQLite path) |
| `ADMIN_INIT_PHONE` | your super-admin phone |
| `ADMIN_INIT_PASSWORD` | strong password (set once) |
| `ADMIN_INIT_NAME` | display name (optional) |
| `SMS_PROVIDER` | real provider (e.g. Twilio) — **required for working OTP** |
| `TWILIO_SID` / `TWILIO_AUTH_TOKEN` / `TWILIO_FROM` | Twilio credentials |
| `DATABASE_URL` | Postgres connection string (PostgreSQL path only) |

## 10. Configure CORS

If the frontend talks to the backend cross-origin (no Vercel proxy), set
`CORS_ORIGIN=https://YOUR-DOMAIN`. With the Vercel `/api` proxy, leave it empty
(same-origin) — production CORS defaults to disabled.

## 11. Configure cloud storage (recommended before launch)

Current uploads are local (`backend/uploads/`). For production, move NID/proof
documents to **private** object storage (AWS S3 / Cloudflare R2 / GCS / Supabase
Storage):
- Bucket: private; no public reads.
- Signed URLs for uploads and downloads.
- Enforce size/MIME/magic-byte checks and random filenames server-side.
- Update the upload routes to use the storage SDK. See
  `docs/SECURITY-AUDIT.md` H2/H3.

## 12. Deploy the backend

Deploy from the repo (Render auto-builds). Watch logs; confirm the DB initializes
and the bootstrap super-admin is created (SQLite path) or `DATABASE_URL`
connects (PostgreSQL path).

## 13. Test /health

```powershell
Invoke-RestMethod https://api.YOUR-DOMAIN/health
```
Expected: `{"status":"ok","service":"blood-hero-api","timestamp":...}`

## 14. Deploy the frontend to Vercel

Connect the repo to Vercel (Root Directory = repo root). Static site — no build
command. Or:
```powershell
npx vercel --prod
```

## 15. Configure the frontend API URL

Two options:

1. **Proxy (recommended):** set `deploy/vercel.json` rewrite
   `/api/:path*` → `https://api.YOUR-DOMAIN/api/:path*`, redeploy. App keeps
   using `/api` same-origin.
2. **Direct:** inject `window.__CONFIG__ = { API_BASE: 'https://api.YOUR-DOMAIN' }`
   before the app bundle in `index.html` (or via a Vercel edge middleware).

## 16. Configure the custom domain

- Vercel: add `YOUR-DOMAIN` + `www.YOUR-DOMAIN`, follow DNS setup.
- Render: add `api.YOUR-DOMAIN` (CNAME to your Render service), enable TLS.

## 17. Enable HTTPS

- Vercel and Render both provision TLS automatically once the domain is attached.
- Never serve the app or API over plain HTTP in production.

## 18. Test the complete application

Execute `docs/PRODUCTION-TEST-PLAN.md` end-to-end and record results. Minimum
signoff:
- [ ] `https://YOUR-DOMAIN/` loads; login works
- [ ] `https://YOUR-DOMAIN/admin-panel/` login works
- [ ] `/api/*` proxied/cross-origin works over HTTPS only
- [ ] `/health` returns ok
- [ ] File uploads store privately and cannot be read anonymously

## 19. Rollback procedure

- **Backend:** Render → previous deploy (one click), or redeploy the last known-good commit.
- **Database (PostgreSQL):** restore the latest `pg_dump` (see
  `docs/DATABASE-BACKUP-AND-RECOVERY.md`).
- **Database (SQLite):** stop backend, restore `blood_hero.db`, delete stale
  `-wal`/`-shm`, restart.
- **Frontend:** Vercel → previous deployment, or `vercel rollback`.
- If the PostgreSQL migration misbehaves, keep the backend pointed at SQLite
  (`DB_PATH`) until data integrity is proven.

---

## Remaining manual tasks (before public launch)

1. Fix CRITICAL/HIGH findings in `docs/SECURITY-AUDIT.md` (C1, C3, C4, C5, H1–H5, H7).
2. Configure a real SMS provider (Twilio) for OTP.
3. Move uploads to private cloud object storage (H2/H3).
4. Tighten Firestore rules (`deploy/firebase-setup.md`).
5. Execute and record the full test plan (`docs/PRODUCTION-TEST-PLAN.md`).
6. Configure automated database backups.